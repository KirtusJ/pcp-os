"""Recheck the captured Multiboot handoff, ACPI checksums, processor identities and kernel serial."""
from pathlib import Path
import json
import re
import struct

root = Path(__file__).resolve().parent
read = lambda name: (root / name).read_bytes()
word32 = lambda data, offset: struct.unpack_from("<I", data, offset)[0]
word64 = lambda data, offset: struct.unpack_from("<Q", data, offset)[0]
report = json.loads(read("firmware-tables.json"))
raw_map = read("multiboot-map.bin")
regions = []
offset = 0
while offset < len(raw_map):
    width, start, length, kind = struct.unpack_from("<IQQI", raw_map, offset)
    assert width >= 20 and offset + 4 + width <= len(raw_map)
    regions.append((start, start + length, kind))
    offset += width + 4
assert offset == len(raw_map)

def covered(start, length):
    end = start + length
    spans = sorted((max(start, a), min(end, b), k) for a, b, k in regions if a < end and start < b)
    assert all(k in (3, 4) for a, b, k in spans)
    at = start
    for a, b, _ in spans:
        assert a <= at
        at = max(at, b)
    assert at == end and length > 0

line = read("cmdline.txt").decode().strip()
named = [w for w in line.split() if w.startswith("acpi_rsdp=")]
assert len(named) == 1 and re.fullmatch(r"acpi_rsdp=0x[0-9a-f]{16}", named[0])
rsdp_at = int(named[0].split("=")[1], 16)
rsdp = read("rsdp.bin")
covered(rsdp_at, len(rsdp))
assert rsdp[:8] == b"RSD PTR " and rsdp[15] >= 2
assert len(rsdp) == word32(rsdp,20) == 36 and sum(rsdp[:20]) % 256 == sum(rsdp) % 256 == 0
xsdt = read("xsdt.bin")
covered(word64(rsdp,24), len(xsdt))
assert xsdt[:4] == b"XSDT" and len(xsdt) == word32(xsdt,4) and sum(xsdt) % 256 == 0
children = [v[0] for v in struct.iter_unpack("<Q", xsdt[36:])]
assert len(children) == len(report["types"]) == 6
apic_ids = []
for addr, sig in zip(children, report["types"]):
    body = read("acpi-" + sig + ".bin")
    covered(addr, len(body))
    assert sig.encode() == body[:4] and len(body) == word32(body,4) and sum(body) % 256 == 0
    if sig == "APIC":
        off = 44
        while off < len(body):
            typ, size = body[off:off+2]
            assert size >= 2 and off+size <= len(body)
            if typ == 0 and size >= 8 and word32(body,off+4) & 1:
                apic_ids.append(body[off+3])
            if typ == 9 and size >= 16 and word32(body,off+8) & 1:
                apic_ids.append(word32(body,off+4))
            off += size
qmp = json.loads(read("qmp-cpus.json"))
assert len(qmp) == 6 and len({(c["props"]["socket-id"], c["props"]["core-id"]) for c in qmp}) == 6
assert sorted(apic_ids) == report["qmp_ids"] == [0,1,2,4,5,6]
serial = read("serial.log").decode(errors="replace")
reported = re.findall(r"^processors: the root pointer is at (0x[0-9a-f]+)",serial,re.M)
assert len(reported) == 1 and int(reported[0],16) == rsdp_at
measurement = re.search(r"(?:^| )image=([0-9a-f]{64})(?: |$)",line)[1]
assert "running image (code and read-only data), SHA-256: " + measurement + " (measured; equal to the value the loader named)" in serial
assert "the firmware lists 6 usable (at the address the loader named)" in serial
assert "Verified 491400064 of 491400064 model bytes." in serial
assert sum(l.startswith("  pass ") for l in serial.splitlines()) == 71 and "Tailorbird first frame presented" in serial
assert "10 passed; 0 failed" in read("host-tests.log").decode()
print(f"RSDP {rsdp_at:#x}; RSDP, XSDT and six table ranges and checksums pass; MADT and QMP IDs {apic_ids}; measurement, 71 startup checks and first frame pass")

"""Verify bounded UEFI observations from the extracted evidence directory."""
from pathlib import Path
import json
import re

here = Path(__file__).resolve().parent

def load(run, name):
    return json.loads((here / run / name).read_text())

def serial(run):
    return (here / run / "serial.log").read_text(errors="replace")

def matching(text, pattern):
    return re.findall(pattern, text, re.M)

mode_names = ("ordinary", "extended", "extended-replay")
hashes = set()
for run in mode_names:
    log = serial(run)
    assert "Verified 491400064 of 491400064 model bytes." in log
    assert "processors: the firmware lists 6 usable (at the address the loader named)" in log
    named, = matching(log, r"^command line: image=([0-9a-f]{64}) ")
    measured, = matching(log, r"^running image .*SHA-256: ([0-9a-f]{64}) \(measured; equal to the value the loader named\)")
    assert named == measured
    hashes.add(measured)
    assert [c["apic_id"] for c in load(run,"qmp-cpus.json")] == [0,1,2,4,5,6]
    assert (here / run / "ap-idle.bin").read_bytes() == bytes.fromhex("fbf4ebfd")
    checks = matching(log, r"^  pass (.+)$")
    fails = matching(log, r"^  FAIL (.+)$")
    if run == "ordinary":
        assert "5 of 5 started and parked, the interrupt controller reached through memory" in log
        assert "20000 times: 120000 of 120000" in log
        assert "Tailorbird first frame presented" in log
        assert not fails
        blocks = (here / run / "registers.txt").read_text().split("CPU#")[1:]
        assert len(blocks) == 6
        def reg(key, block):
            return int(re.search(r"\b"+key+r"=\s*([0-9a-fA-F]+)", block)[1],16)
        for block in blocks[1:]:
            assert reg("RIP",block)==0x2047371 and reg("RFL",block)&512
            assert reg("CPL",block)==0 and reg("HLT",block)==1
        for key, count in (("GDT",5),("RSP",5),("CR3",1),("IDT",1)):
            assert len({reg(key,block) for block in blocks[1:]})==count
    else:
        assert "0 of 5 started and parked, the interrupt controller reached in its extended mode" in log
        assert len(fails)==1 and fails[0].startswith("every other processor that was tried answered")
        assert "it is in SAFE and starts no program" in log and "auto=tailorbird: not started" in log
        assert "120000 of 120000" not in log
    print(run, len(checks), "passed,", len(fails), "failed.")
assert len(hashes)==1
print("Same measured guest image in all three boots:", hashes.pop())

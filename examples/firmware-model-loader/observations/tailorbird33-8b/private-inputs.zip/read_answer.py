"""Read an exact lossless row on the pinned 1920x1080 Tailorbird screen. Requires numpy, Pillow."""
import argparse, hashlib, json
from pathlib import Path
import numpy as np
from PIL import Image

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("frame", type=Path)
parser.add_argument("--row", type=int, default=484, help="top pixel of the active text row")
args = parser.parse_args()
font = (root / "font-2x.bin").read_bytes()
if hashlib.sha256(font).hexdigest() != "754a70a3179a62fffc72e33ec462d9a1627f45531b3b2f3207edcd70d529429b":
    raise ValueError("kernel font digest differs")
with Image.open(args.frame) as im:
    if im.size != (1920,1080) or im.format not in ("PNG","PPM","BMP"):
        raise ValueError("requires an original 1920x1080 lossless frame")
    pixels = np.asarray(im.convert("RGB"))
x, y = 786, args.row
if not 0 <= y <= 1056: raise ValueError("row outside frame")
data = pixels[y:y+24, x:x+84*12]
bg = np.array([24,54,79])
font = np.frombuffer(font,np.uint8).reshape(95,40,20)
alpha = np.empty((95,24,12),dtype=np.int32)
for dy,dx in np.ndindex(24,12):
    a = font[:,dy*40//24:(dy+1)*40//24,dx*20//12:(dx+1)*20//12]
    alpha[:,dy,dx] = a.sum((1,2))//(a.shape[1]*a.shape[2])
def cells(ink):
    return ((bg*(255-alpha[...,None])+np.array(ink)*alpha[...,None]+127)//255).astype(np.uint8)
def palette(ink):
    return {tuple((bg*(255-a)+np.array(ink)*a+127)//255) for a in range(256)}
answer,status,warning = (242,247,252),(159,180,200),(227,162,75)
exclusive=palette(answer)-palette(status)-palette(warning)
def read(ink):
    table={v.tobytes():chr(i+32) for i,v in enumerate(cells(ink))}
    return "".join(table.get(data[:,i:i+12].tobytes(),"�") for i in range(0,84*12,12)).rstrip()
print(json.dumps({"frame_sha256":hashlib.sha256(args.frame.read_bytes()).hexdigest(),"row":y,
    "answer_only_pixels":sum(tuple(rgb) in exclusive for rgb in data.reshape(-1,3)),
    "answer_font_match":read(answer),"status_font_match":read(status)},ensure_ascii=False))

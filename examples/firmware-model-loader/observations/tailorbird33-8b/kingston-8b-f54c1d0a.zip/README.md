# Kingston 8B handoff at the #431 landing commit

C3 can stage this pair on a copy of the original 82-file Kingston build. Install only `EFI/BOOT/BOOTX64.EFI` and `PCPOS/KERNEL.ELF` at those paths. Read back the byte length and SHA-256 of every file against `expected-files.json`. The other 80 files, including the original Tailorbird, model worker, manifest, 75 shards and two notices, match both the original Kingston inventory and the earlier WHPX rehearsal. All other archive members are evidence for the handoff.

The kernel and EFI loader come from master commit f54c1d0a45e8fc328b950649adfb3fbea7768c81, tree 2c63bbafc951e363648dc9537a3fca7d19bebdc0. It includes the one-page drawing change #428, write-combining #429, desktop-first EFI #433, Details display diagnostics #434, changed-row drawing #432 and the elapsed clock #431. It precedes the launcher changes #435 and #436.

The kernel used the shipped 32 MiB relocation patch. Two builds from separate extractions with the same compiler staging path produced identical ELFs. Two EFI builds produced identical executables and build records. See binding.json for the kernel stage, tools, digests and compiler versions. See efi-build.json for the EFI build. reproduction.json compares both changed components against their original Kingston and earlier WHPX counterparts.

The virtual USB exposed all 82 files. B3 verified their sizes and SHA-256 values and hashed all 5,027,783,488 ordered shard bytes. A fresh OVMF boot of that read-only USB verified the full model and reached the desktop. Enter opened Programs. Ctrl+D opened Details and D returned to Programs. Enter on the selected Tailorbird launched the original guest with its companion. The capture ends at the first foreground frame. Clock selection is visible in the serial log. The display count and private drawing sentence appear in both the log and the Details capture.

C3 owns the Windows WHPX timing, physical write and readback, and attended EliteBook run. A3 independently checks the build. Firmware verification, clock selection and display behavior in B3's VM qualify only the files identified here.

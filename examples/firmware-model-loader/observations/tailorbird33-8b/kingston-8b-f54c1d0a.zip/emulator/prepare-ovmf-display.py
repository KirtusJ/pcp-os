"""Set the OVMF preferred graphics resolution in an unused, private VARS template."""
from pathlib import Path
import struct
import sys
import uuid
template, output = map(Path, sys.argv[1:])
raw = bytearray(template.read_bytes())
volume_header = struct.unpack_from('<H', raw, 0x30)[0]
assert raw[volume_header:volume_header+16] == uuid.UUID('aaf32c78-947b-439a-a180-2e144ec37792').bytes_le
store_size = struct.unpack_from('<I', raw, volume_header + 16)[0]
first = (volume_header + 28 + 3) & ~3
assert all(b == 255 for b in raw[first:volume_header + store_size])
name = 'PlatformConfig\0'.encode('utf-16-le')
data = struct.pack('<II',1920,1080)
vendor = uuid.UUID('7235c51c-0c80-4cab-87ac-3b084a6304b1').bytes_le
header = struct.pack('<HBBIQ16sIII16s',0x55aa,0x3f,0,7,0,bytes(16),0,len(name),len(data),vendor)
assert len(header)==60
entry = header + name + data
raw[first:first+len(entry)] = entry
with output.open('xb') as target:target.write(raw)

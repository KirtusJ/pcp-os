from pathlib import Path
import json,os,re,shutil,socket,subprocess as sp,sys,threading,time,hashlib
q=Path(__file__).resolve().parent;os.chdir(q);sys.path[:0]=['D:/C3/tools/iso33-python','D:/C3/tools/numpy'];from PIL import Image
from read_display import row
import numpy as np
now=time.perf_counter
prompt='Say hello in one short sentence.'
out=q/sys.argv[1];out.mkdir(exist_ok=False)
qemu=Path('D:/C3/tools/qemu-portable/bin/qemu-system-x86_64.exe');port=19336; mode=sys.argv[2] if len(sys.argv)>2 else 'whpx'
env={**os.environ,'TMP':'D:/C3/tmp','TEMP':'D:/C3/tmp'}
serial=out/'serial.log';serial.touch();shutil.copyfile(q/'OVMF_VARS_4M.fd',out/'vars.fd')
cpu=sys.argv[3] if len(sys.argv)>3 else 'max'
image=json.loads((q/'disc/image-receipt.json').read_text());backend=mode
args=[str(qemu),'-name','C3-offline-Qwen-8B','-machine','q35,max-ram-below-4g=512M','-accel',mode,'-cpu',cpu,'-smp','1','-m','6656M','-display','none','-vga','none','-device','VGA,xres=1920,yres=1080,edid=on','-monitor','none','-qmp',f'tcp:127.0.0.1:{port},server=on,wait=off','-serial','file:'+str(serial),'-nic','none','-no-reboot','-drive','if=pflash,unit=0,format=raw,readonly=on,file='+str(q/'OVMF_CODE_4M.fd'),'-drive','if=pflash,unit=1,format=raw,file='+str(out/'vars.fd'),'-drive','if=none,id=release,media=cdrom,readonly=on,format=vmdk,file='+str(q/'disc/read-only.vmdk'),'-device','ide-cd,bus=ide.0,drive=release,bootindex=1']
(out/'command.json').write_text(json.dumps(args,indent=2)+'\n')
zero=now()
with (out/'qemu.log').open('wb') as log:
 p=sp.Popen(args,cwd=q,env=env,stdout=log,stderr=sp.STDOUT,creationflags=sp.CREATE_NO_WINDOW)
(out/'pid').write_text(str(p.pid))
def alive():
 if p.poll() is not None:raise RuntimeError(f'Guest exited {p.returncode}; see qemu.log and serial.log')
def ev(name,**data):
 with (out/'events.jsonl').open('a',encoding='utf-8') as f:print(json.dumps(dict(event=name,since_launch=round(now()-zero,5),**data),ensure_ascii=True),file=f)
for _ in range(240):
 alive()
 try:sock=socket.create_connection(('127.0.0.1',port),timeout=1);break
 except OSError:time.sleep(.25)
else:raise RuntimeError('QMP startup timeout')
sock.settimeout(90);io=sock.makefile('rwb',buffering=0);assert 'QMP' in json.loads(io.readline())
def rpc(c,params={}):
 io.write((json.dumps(dict(execute=c,arguments=params))+'\n').encode())
 while True:
    msg=json.loads(io.readline())
    if 'error' in msg:raise RuntimeError(msg['error'])
    if 'return' in msg:return msg['return']
rpc('qmp_capabilities');blocks=rpc('query-block');(out/'block-devices.json').write_text(json.dumps(blocks,indent=2))
assert any(b['device']=='release' and b['inserted']['ro'] and b['inserted']['image']['virtual-size']==image['bytes'] for b in blocks)
def snap():
 a=now();path=out/'current.png';rpc('screendump',dict(filename=str(path),format='png'));b=now()
 with Image.open(path) as im:frame=im.convert('RGB')
 return a,b,frame
def captured(name):
 a,b,frame=snap();frame.save(out/(name+'.png'));return a,b,frame
def key(c):
 reply=rpc('human-monitor-command',{'command-line':'sendkey '+c+' 45'})
 if reply:raise RuntimeError(reply)
def serial_text():return serial.read_bytes().decode('utf-8','replace').replace('\r','')
ev('boot',sha256=image['sha256'],qemu=rpc('query-version')['qemu'],utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
last=-100.;prev=''
while 'tailorbird: model service: ready' not in serial_text():
 alive();s=serial_text()
 if re.search(r'^!!!! X64 Exception Type|^tailorbird: model service: (did not start|stopped)|^Taylor model worker: (?!verified,)|it is in SAFE and starts no program|^kernel panic',s,re.M|re.I):
    captured('before-ready-failure');raise RuntimeError('Guest failed before Ready, see serial.log')
 if now()-last>=30:
    a,b,frame=captured('latest-boot');ev('boot-frame',size=frame.size,serial_tail=s[-240:]);last=now()
 time.sleep(.2)
ready=now();s=serial_text();match=re.search(r'Q4_K/Q6_K projections: ([^\n]+)',s);assert match,s[-500:]
ev('ready',backend=match[1],ready_s=ready-zero);_,_,frame=captured('ready');assert frame.size==(1920,1080),frame.size
key('alt-c');time.sleep(.6);captured('fresh')
for ch in prompt:
 code={' ':'spc','.':'dot'}.get(ch,ch.lower())
 if ch.isupper():code='shift-'+code
 key(code);time.sleep(.11)
captured('typed')
t0=now();key('ret');t1=now();ev('submitted',prompt=prompt,enter_lower=t0-zero,enter_upper=t1-zero)
terminal=[];stopped=threading.Event()
def watch():
 prev=t0
 while not stopped.is_set():
    a=now();s=serial_text();end=now()
    m=re.search(r'^tailorbird: reply 1 kept (\d+) bytes and is (complete|failed|stopped by the person)\n',s,re.M)
    if m:
      terminal.append(dict(lower=max(0,prev-t1),upper=end-t0,bytes=int(m[1]),state=m[2].strip()));return
    prev=a;time.sleep(.035)
threading.Thread(target=watch,daemon=True).start()
bg=np.array([24,54,79])
def palette(rgb):
 rgb=np.array(rgb);return {tuple((bg*(255-a)+rgb*a+127)//255) for a in range(256)}
ink=palette([242,247,252])-palette([159,180,200])-palette([227,162,75])
codes=np.array([int(r)*65536+int(g)*256+int(b) for r,g,b in ink],dtype=np.uint32)
previous=None;first=None;laststage='';last_empty=None;saw_prompt=False
painted={};prev_negative=t0;last_visible=''
while True:
 alive();a,b,frame=snap()
 person=row(frame,436)['reply'];text=row(frame)
 if person==prompt:
    saw_prompt=True
    pixels=np.asarray(frame.crop((786,484,1794,508)),dtype=np.uint32);pcol=(pixels[:,:,0]<<16)|(pixels[:,:,1]<<8)|pixels[:,:,2];color_count=int(np.isin(pcol,codes).sum())
    if color_count>0 and not first:
        lower=0 if previous is None else max(0,previous-t1);first=dict(lower=lower,upper=b-t0,first_row=text['reply'],pixels=color_count)
        if last_empty is not None:last_empty.save(out/'last-empty.png')
        ev('first-visible-text',**first);frame.save(out/'first-text.png')
    if color_count and text['reply'] and '\ufffd' not in text['reply']:
        val=text['reply']
        if val!=last_visible:
            interval=dict(lower=max(0,prev_negative-t1),upper=b-t0)
            painted.setdefault(val,interval);ev('visible-reply',text=val,**interval)
            last_visible=val
    prev_negative=a
    if color_count==0 and not first:
        previous=a;last_empty=frame
    if text['status'] and '\ufffd' not in text['status'] and text['status']!=laststage:
        laststage=text['status'];ev('reading',status=laststage);frame.save(out/'reading.png')
 if terminal:
    term=terminal[0]
    if term['state']!='complete':raise RuntimeError(term)
    if first and saw_prompt and '\ufffd' not in text['reply'] and len(text['reply'].encode())==term['bytes']:
        frame.save(out/'complete.png');summary=dict(iso=image['sha256'],guest_ram_mib=6656,accelerator=mode,cpu=cpu,vcpus=1,nic=False,worker_backend=match[1],ready_from_launch_s=ready-zero,prompt=prompt,first=first,completion=term,answer=text['reply'],full_answer_visible=painted.get(text['reply']),terminal_frame_upper=b-t0)
        (out/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
        ev('completed',**term);break
    if now()-t0>term['upper']+10:
        frame.save(out/'terminal-unclassified.png');raise RuntimeError('Terminal event needs manual frame readback')
 time.sleep(.12)
stopped.set();sock.close()


"""Independent replay of lossless guest frames, submission timing and natural completion."""
import json,sys,hashlib,re,subprocess,os
from pathlib import Path
d=Path(__file__).resolve().parent;t=d/sys.argv[1]
result=json.loads((t/'result.json').read_text());receipt=json.loads((d/'disc/image-receipt.json').read_text())
assert result['iso']==receipt['sha256'] and not result['nic']
cmd=json.loads((t/'command.json').read_text());assert cmd[cmd.index('-nic')+1]=='none' and cmd[cmd.index('-smp')+1]=='1'
events=[json.loads(i) for i in (t/'events.jsonl').read_text().splitlines()]
assert len([e for e in events if e['event']=='submitted'])==1
serial=(t/'serial.log').read_bytes().decode('utf-8','replace').replace('\r','')
assert serial.count('tailorbird: reply 1 is being answered')==1
assert f"tailorbird: reply 1 kept {len(result['answer'].encode())} bytes and is complete\n" in serial
assert 'tailorbird: model service: ready\n' in serial and result['worker_backend'] in serial
assert all(0<=result[x]['lower']<=result[x]['upper'] for x in ('first','completion','full_answer_visible'))
assert result['first']['upper']<=result['completion']['upper'] or result['first']['lower']<=result['completion']['upper']
def replay(file,y):
    code=[sys.executable,'-X','utf8','-B',str(d/'read_answer.py'),str(t/file),'--row',str(y)]
    env={**os.environ,'PYTHONPATH':os.pathsep.join(['D:/C3/tools/iso33-python','D:/C3/tools/numpy']),'PYTHONDONTWRITEBYTECODE':'1'}
    return json.loads(subprocess.check_output(code,env=env))
frames={}
for name in ['last-empty.png','first-text.png','complete.png']:
    frames[name]={'answer':replay(name,484),'person':replay(name,436)}
    assert frames[name]['person']['answer_font_match']==result['prompt']
assert frames['last-empty.png']['answer']['answer_only_pixels']==0
assert frames['first-text.png']['answer']['answer_only_pixels']>0
assert frames['complete.png']['answer']['answer_font_match']==result['answer']
evidence={'iso_sha256':result['iso'],'frames':frames,'utc_boot':next(e['utc'] for e in events if e['event']=='boot'),'originals':{p:hashlib.sha256((t/p).read_bytes()).hexdigest() for p in ('events.jsonl','result.json','serial.log','command.json','ready.png','first-text.png','complete.png','last-empty.png')}}
(t/'replay.json').write_text(json.dumps(evidence,indent=2)+'\n')
print(json.dumps({'frames':list(frames),'answer':result['answer'],'complete':result['completion'],'first':result['first']}))


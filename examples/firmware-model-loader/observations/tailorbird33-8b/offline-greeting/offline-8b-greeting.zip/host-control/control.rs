use std::arch::asm;

#[repr(align(64))]
struct Area([u8; 1024]);

fn read_after_restore(template_mask: u32) -> u32 {
    let mut saved = Area([0; 1024]);
    let mut template = Area([0; 1024]);
    template.0[24..28].copy_from_slice(&template_mask.to_le_bytes());
    let mut observed = 0u32;
    // The private process restores its own x87/SSE/AVX registers before returning to Rust.
    unsafe {
        asm!(
            "xsave64 [{saved}]",
            "xrstor64 [{template}]",
            "stmxcsr [{observed}]",
            "xrstor64 [{saved}]",
            saved = in(reg) saved.0.as_mut_ptr(),
            template = in(reg) template.0.as_ptr(),
            observed = in(reg) &mut observed,
            in("eax") 7u32,
            in("edx") 0u32,
            options(nostack, preserves_flags),
        );
    }
    observed
}

fn main() {
    assert!(std::is_x86_feature_detected!("avx"));
    let zero = read_after_restore(0);
    let explicit = read_after_restore(0x1f80);
    println!("standard XRSTOR with XSTATE_BV=0, request=7: zero template -> 0x{zero:08x}, explicit reset template -> 0x{explicit:08x}");
    assert_eq!((zero, explicit), (0, 0x1f80));
}

# Desktop-first EFI with the original 8B Kingston payload

The prospective-tree directory records a local integration of the merged desktop-first master and the reviewed clock head. Two independent Git index operations produced the tree in provenance.json. The shipped 32 MiB relocation patch applied to that tree. B3 built its kernel and bound the EFI to that kernel, the original Tailorbird frontend and worker, and the original model manifest. For the WHPX rehearsal, replace EFI/BOOT/BOOTX64.EFI and PCPOS/KERNEL.ELF in a copy of the original Kingston medium. Check all 82 files against expected-files.json before boot. The 80 other files match the original medium. The source tree is accessible at commit 1778b550e06d05bed0f1e0934cc16461741bd142.

The earlier-kernel directory is a separate control. Its ELF and code measurement differed from the freshly built prospective tree, so B3 bound and booted both pairs separately. Each directory carries the corresponding component hashes and log.

Each USB view contained 82 files. B3 read the seven non-shard files through mtools, checked the FAT chains of all 75 model shards and hashed their bytes in order. The firmware then read and verified all 5,027,783,488 bytes before handing the model to the kernel. Two samples of the idle desktop matched exactly. Enter opened Programs, the second Enter started the original foreground with the 286,088-byte worker, and its service channel opened. The serial logs and full-resolution screenshots record the launch. Timings are host-monotonic samples. The run ends at the first foreground frame. C3 measures readiness and inference in WHPX.

In the first media construction attempt, OVMF found an MBR partition but did not mount its filesystem. QEMU had parsed an extra leading MBR extent from the descriptor. The corrected views had six extents. QEMU reported the intended disk size and extent count, and boundary reads from the first and last sectors of each extent matched independent backing-file reads before boot.

C3 owns the physical handoff. The merged-source comparison and attended results are tracked on PR 276.

# B3 one-page editor readback

The test sends h, e, Backspace and Backspace three times in each measured boot. Each capture is compared with the reference crop for the expected editor state. The crop contains both the text and the visible character count. Its bounds are (130, 910) to (510, 1010), excluding the right and lower edges, on the 1920 by 1080 screen.

Each time is milliseconds on the observing host, from just before sending the QMP key command to the return of the first matching QMP screenshot. A value is an upper bound on the first visible occurrence in this run. Ordinary QEMU scheduling, screenshot production and sampling cadence affect the result. No hardware latency or statistical population estimate is established. The loads were model-free, one vCPU, Q35/OVMF/GRUB, single-page vmware display, TCG, original Tailorbird ed31fc00, no guest NIC.

measurements/key-readback.json contains continuous captures, baseline then display candidate. measurements/key-readback-reversed.json spaces nonmatching captures by 35 ms and reverses the order, with the shadow-only kernel between them. intervals/ supplies another pair at 10 ms spacing in candidate-then-baseline order. Each samples entry in that pair records host milliseconds at QMP request, host milliseconds at QMP reply, and the resulting RGB crop digest. refs came from a separate settled boot and the empty, h and he PNGs were also read visually.

Replay with Python 3 and Pillow. Supply your QEMU binary, OVMF firmware and fresh variable template, the PCP OS optical-disk-check/check.py containing Monitor, and a GRUB USB directory for the chosen kernel, original guest and 1920 by 1080 desktop. replay.py --help lists the arguments. Pass references/ for --references. Use a new --output path for each boot. The script reads the boot tree through a read-only virtual FAT drive.

ELF SHA-256:
original bec4d5714b75e1fae19497dd5990067096b9329c0327da45a1838a70fb559a3a
offscreen-only cb86e7e5889c3be6a65fb040a6bb4cf543fad1a880d1b8c54473d78b429b6525
display-candidate df1d5713dd8035bb70e0f953ab09a15b6d3dad6632d7e98e9835e3e09cfe1e82

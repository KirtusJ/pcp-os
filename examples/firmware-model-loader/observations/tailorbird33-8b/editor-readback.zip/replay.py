"""Measure the first QMP capture whose editor pixels match a settled reference."""
import argparse
import hashlib
import json
import runpy
import shutil
import subprocess
import time
from pathlib import Path
from PIL import Image

def sha(data):
    return hashlib.sha256(data).hexdigest()

def take_snapshot(monitor, path):
    started = time.monotonic_ns()
    monitor.call('screendump', filename=str(path))
    received = time.monotonic_ns()
    with Image.open(path) as image:
        if image.size != (1920, 1080):
            raise ValueError(f'unexpected display size {image.size}')
        crop = image.crop((130, 910, 510, 1010)).convert('RGB')
    return started, received, sha(crop.tobytes())

def measure(args, refs):
    args.output.mkdir(parents=True, exist_ok=False)
    serial = args.output / 'serial.txt'
    frame = args.output / 'current.ppm'
    variables = args.output / 'vars.fd'
    shutil.copyfile(args.ovmf_vars, variables)
    command = [
        args.qemu, '-machine', 'q35', '-accel', 'tcg', '-cpu', 'max', '-smp', '1', '-m', '256M',
        '-drive', f'if=pflash,format=raw,readonly=on,file={args.ovmf_code}',
        '-drive', f'if=pflash,format=raw,file={variables}',
        '-drive', f'if=none,id=stick,readonly=on,format=raw,file=fat:{args.tree}',
        '-device', 'qemu-xhci', '-device', 'usb-storage,drive=stick,bootindex=1', '-vga', 'vmware',
        '-display', 'none', '-nic', 'none', '-monitor', 'none', '-serial', f'file:{serial}',
        '-no-reboot', '-qmp', 'stdio',
    ]
    monitor_type = runpy.run_path(str(args.monitor))['Monitor']
    trials = []
    with (args.output/'stderr.log').open('wb') as errors, subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=errors) as vm:
        monitor = None
        try:
            monitor = monitor_type(vm)
            monitor.call('qmp_capabilities')
            deadline = time.monotonic() + 70
            while time.monotonic() < deadline:
                if serial.exists() and 'Tailorbird first frame presented' in serial.read_text(errors='replace'):
                    break
                if vm.poll() is not None:
                    raise RuntimeError(f'QEMU exited before the first frame: {vm.returncode}')
                time.sleep(.1)
            else:
                raise TimeoutError('no first frame')
            time.sleep(.5)
            if 'display: Loader, 1920x1080, 1 page(s)' not in serial.read_text() or take_snapshot(monitor, frame)[2] != refs['empty']:
                raise ValueError('wrong framebuffer or initial editor crop')
            for cycle in range(3):
                for key, label in [('h', 'h'), ('e', 'he'), ('backspace', 'h'), ('backspace', 'empty')]:
                    time.sleep(.20)
                    issued = time.monotonic_ns()
                    monitor.key(key)
                    samples = []
                    while time.monotonic_ns() - issued < 4_000_000_000:
                        start, end, observed = take_snapshot(monitor, frame)
                        samples.append([round((start-issued)/1e6,3), round((end-issued)/1e6,3), observed])
                        if observed == refs[label]:
                            break
                        time.sleep(args.pause_ms/1000)
                    else:
                        raise TimeoutError(f'expected editor state {label}')
                    trials.append(dict(cycle=cycle+1, key=key, state=label, samples=samples))
        finally:
            if vm.poll() is None and monitor is not None:
                try:
                    monitor.call('quit')
                except (RuntimeError, TimeoutError, BrokenPipeError):
                    pass
            try:
                vm.wait(timeout=4)
            except subprocess.TimeoutExpired:
                vm.kill()
                vm.wait()
    if vm.returncode:
        raise RuntimeError(f'QEMU exit {vm.returncode}')
    return trials

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('qemu','monitor','ovmf-code','ovmf-vars','tree','output','references'):
        p.add_argument('--'+name, required=True, type=lambda s: Path(s).resolve())
    p.add_argument('--pause-ms',type=float,default=0)
    args = p.parse_args()
    refs = {}
    for name in ('empty','h','he'):
        with Image.open(args.references/(name+'.png')) as im:
            refs[name] = sha(im.convert('RGB').tobytes())
    if len(set(refs.values())) != 3:
        raise ValueError('editor references must be distinct')
    results = dict(kernel_sha256=sha((args.tree/'PCPOS/KERNEL.ELF').read_bytes()),guest_sha256=sha((args.tree/'PCPOS/TAILOR.ELF').read_bytes()),reference_sha256=refs,pause_ms=args.pause_ms,trials=measure(args,refs))
    (args.output/'samples.json').write_text(json.dumps(results,indent=2)+'\n')

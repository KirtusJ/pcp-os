# Desktop-first model-bound EFI boot

Director B3 built the PR 433 loader and its parent against the four hashes in inputs.json. Each read-only virtual USB contained the same kernel, original Tailorbird frontend, smaller matched worker, binary manifest and eight real shards. The two EFI build records identify the toolchain and resulting binaries. Each run used fresh OVMF variables.

Each serial log begins with the firmware reading and verifying the model. The kernel then reports the bytes reserved for the model. Compare the command lines to see which launch options were removed and which grants carried through.

In the candidate sequence, home and idle are identical 1920 by 1080 captures. Enter opened Programs with tailorbird selected. The next Enter launched it. In the parent sequence Tailorbird started without input. The final frame in each run was identical and showed Getting ready. The serial logs record the foreground identity, companion launch, model service channel and first frame. Events record host-monotonic seconds from each VM start. Serial offsets identify which records existed at each sampled frame or keypress. Frame hashes refer to the original P6 screendump bytes. The PNGs preserve their exact RGB pixels.

The physical Kingston uses a different 75-shard 8B payload. These captures cover the EFI launch path through the first frame. Readiness, inference and laptop timings require separate observations.

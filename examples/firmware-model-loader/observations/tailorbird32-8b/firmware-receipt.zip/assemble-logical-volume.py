import hashlib, json, math, os, re, struct, subprocess
from pathlib import Path
base = Path(os.environ['B3_ROOT'])
original = base/'service/qwen3-release/worker24-qwen3-8b.fat'
expected = json.loads((original.parent/'expected-files.json').read_text())
small = {p: (Path('BOOTX64.EFI') if p.startswith('EFI') else Path('parts')/Path(p).name) for p in expected if 'shard-' not in p}
size = original.stat().st_size
shadow = Path('shadow.fat')
env = os.environ | {'LD_LIBRARY_PATH': str(base/'runtime/usr/lib/x86_64-linux-gnu')}
def m(cmd, img, *a):
    return subprocess.check_output([str(base/'runtime/usr/bin'/cmd),'-i',str(img),*a],env=env)
def chains(img):
    rows = m('mshowfat', img, '::/PCPOS/shard-*.bin').decode().splitlines()
    result = {}
    for row in rows:
        name, entries = row.split(' ',1)
        runs=[]
        for a,b in re.findall(r'<(\d+)(?:-(\d+))?>',entries):
            runs.append((int(a),int(b or a)))
        assert runs and name.startswith('::/')
        result[name[3:]]=runs
    return result
def chunks(file, offset, length):
    file.seek(offset)
    while length:
        data=file.read(min(2**22,length))
        assert data
        yield data
        length-=len(data)
c=chains(original)
assert set(c) == {p for p in expected if 'shard-' in p} and len(c)==75
with original.open('rb') as f:
    b=f.read(512)
    sector,=struct.unpack_from('<H',b,11); spc=b[13]; reserved,=struct.unpack_from('<H',b,14); fats=b[16]; fatsectors,=struct.unpack_from('<I',b,36)
    assert sector==512
    data_sector=reserved+fats*fatsectors
    ranges=[]; whole_model=hashlib.sha256(); model_size=0
    for file in sorted(c):
        h=hashlib.sha256(); remain=expected[file]['bytes']; model_size+=remain
        for start,end in c[file]:
            left=(data_sector+(start-2)*spc)*sector; right=left+(end-start+1)*spc*sector
            ranges.append((left,right))
            amount=min(remain,right-left)
            for part in chunks(f,left,amount):h.update(part);whole_model.update(part)
            remain-=amount
        assert remain==0 and h.hexdigest()==expected[file]['sha256'],file
    model_hash=whole_model.hexdigest()
    assert model_hash=='d98cdcbd03e17ce47681435b5150e34c1417f50b5c0019dd560e4882c5745785' and model_size==5027783488
    spans=[]; cursor=0
    for left,right in sorted(ranges):
        assert left>=cursor and right<=size
        if left>cursor:spans.append((cursor,left,'shadow.fat'))
        if spans and spans[-1][2]=='original.fat' and spans[-1][1]==left:
            spans[-1]=(spans[-1][0],right,'original.fat')
        else: spans.append((left,right,'original.fat'))
        cursor=right
    if cursor<size:spans.append((cursor,size,'shadow.fat'))
    with shadow.open('xb') as w:
        w.truncate(size)
        for left,right,name in spans:
            if name!='shadow.fat':continue
            for part in chunks(f,left,right-left):
                if part.count(0)!=len(part):
                    w.seek(left);w.write(part)
                left+=len(part)
print('Verified all original shard hashes. Replacing four bound firmware and guest files.',flush=True)
for path,source in small.items():
    if path.endswith('.manifest'):continue
    m('mcopy',shadow,'-o',str(source),'::/'+path)
assert c==chains(shadow)
actual={}
for path,source in small.items():
    data=m('mtype',shadow,'::/'+path)
    assert source.read_bytes()==data,path
    actual[path]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
Path('original.fat').symlink_to(original)
descriptor=['# Disk DescriptorFile','version=1','CID=1015ac23','parentCID=ffffffff','createType="monolithicFlat"']
logical=hashlib.sha256();original_digest=hashlib.sha256()
with original.open('rb') as orig,shadow.open('rb') as changed:
    for left,right,name in spans:
        pos=left
        while pos<right:
            count=min(512*1024**2,right-pos)
            descriptor.append(f'RW {count//512} FLAT "{name}" {pos//512}')
            pos+=count
        for part in chunks(orig,left,right-left):
            original_digest.update(part)
            if name=='original.fat':logical.update(part)
        if name=='shadow.fat':
            for part in chunks(changed,left,right-left):logical.update(part)
assert original_digest.hexdigest()=='74a073346aa83f9a9c8e2aa0c78834325c0f8f02258a699ad5f3dd81f20650ee'
Path('volume.vmdk').write_text('\n'.join(descriptor)+'\n')
receipt={'format':'fresh read-only logical FAT32 removable volume','logical_volume_bytes':size,'logical_volume_sha256':logical.hexdigest(),'base_volume_sha256':original_digest.hexdigest(),'shard_files':len(c),'model_bytes':model_size,'model_sha256':model_hash,'component_readback':actual,'sector_bytes':sector,'cluster_sectors':spc,'extents':[{'start':l,'end_exclusive':r,'backing':n} for l,r,n in spans]}
Path('evidence/media.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)

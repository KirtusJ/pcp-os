import os,re,subprocess,json,hashlib
from pathlib import Path
descriptor=Path('volume.vmdk').read_text()
extents=re.findall(r'^RW (\d+) FLAT "([^"]+)" (\d+)$',descriptor,re.M)
current=0; query=[]; expected={}
for sectors,backing,start in extents:
    start=int(start)*512
    sectors=int(sectors)
    assert start==current
    with open(backing,'rb') as f:
        for offset in (start,start+(sectors//2)*512,start+(sectors-1)*512):
            f.seek(offset);expected[offset]=f.read(128)
            query.append({'execute':'human-monitor-command','arguments':{'command-line':f'qemu-io stick "read -v {offset} 128"'}})
    current+=sectors*512
cmds=[{'execute':'qmp_capabilities'},{'execute':'query-block'},*query,{'execute':'quit'}]
p=subprocess.run([os.environ['B3_ROOT']+'/hostbin/qemu-system-x86_64','-machine','none','-display','none','-nodefaults','-qmp','stdio','-drive','if=none,id=stick,readonly=on,format=vmdk,file=volume.vmdk'],input=''.join(json.dumps(x)+'\n' for x in cmds),capture_output=True,text=True,check=True)
lines=p.stdout.splitlines()
block=next(z for z in [json.loads(line) for line in lines if line.startswith('{')] if isinstance(z.get('return'),list))['return'][0]['inserted']
assert block['ro'] and block['image']['virtual-size']==current==5253365760
seen={}; data=bytearray()
for line in lines:
    row=re.match(r'^([0-9a-f]+): +((?:[0-9a-f]{2} ){16})',line)
    if row:
        if not data:start=int(row.group(1),16)
        data.extend(bytes.fromhex(row.group(2)))
        if len(data)==128:
            assert data==expected[start],start
            seen[start]=hashlib.sha256(data).hexdigest()
            data.clear()
assert not data and set(seen)==set(expected)
rec={'tool':'QEMU qemu-io; 128 bytes at first, middle and last sector of each extent','distinct_offsets':len(seen),'size_bytes':current,'readonly':block['ro'],'sample_hashes':seen}
Path('evidence/volume-samples.json').write_text(json.dumps(rec,indent=2)+'\n')
print('QEMU decoded and matched',len(seen),'distinct on-media offsets on the read-only logical volume.')

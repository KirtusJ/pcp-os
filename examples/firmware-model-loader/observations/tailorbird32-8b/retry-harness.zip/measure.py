from pathlib import Path
import hashlib, json, re, threading, time
import numpy as np
import sys
sys.path.insert(0,str(Path.cwd()))
from read_display import row
prompt='Say hello in one short sentence.'
vm.key('alt','c')
time.sleep(.7)
snap()[2].save(out/'fresh-conversation.png')
for ch in prompt:
    key={' ':'spc','.':'dot'}.get(ch,ch.lower())
    vm.key(*(['shift',key] if ch.isupper() else [key]))
    time.sleep(.14)
snap()[2].save(out/'typed.png')
submitted=time.monotonic()
vm.key('ret')
ack=time.monotonic()
ev('submitted',prompt=prompt,enter_call_s=submitted-zero,enter_ack_s=ack-zero)
terminal=[]
stop_monitor=threading.Event()
def watch_serial():
    prev=ack
    while not stop_monitor.is_set():
        before=time.monotonic()
        line=next((s for s in vm.log().splitlines() if s.startswith('tailorbird: reply 1 kept ')),None)
        after=time.monotonic()
        if line:
            terminal.append((prev-ack,after-submitted,line))
            ev('terminal-serial',lower_s=prev-ack,upper_s=after-submitted,serial=line)
            return
        prev=before
        stop_monitor.wait(.25)
threading.Thread(target=watch_serial,daemon=True).start()
panel=np.array([24,54,79])
def blends(hexcolor):
    ink=np.array(list(bytes.fromhex(hexcolor)))
    return {tuple((panel*(255-a)+ink*a+127)//255) for a in range(256)}
reply_ink=blends('f2f7fc')-blends('9fb4c8')-blends('e3a24b')-{tuple(panel)}
ink_codes=np.array([(r*65536+g*256+b) for r,g,b in reply_ink],dtype='int32')
last_negative=None;first=None;last_event=submitted;prevstate=None;timed_terminal=None
while True:
    live()
    a,b,frame=snap()
    bytes_of_row=np.array(frame.crop((786,484,1794,508)),dtype='int32')
    codes=bytes_of_row[:,:,0]*65536+bytes_of_row[:,:,1]*256+bytes_of_row[:,:,2]
    ink=int(np.isin(codes,ink_codes).sum())
    text=row(frame); person=row(frame,436)['reply']
    if not first and person==prompt:
        if ink:
            if last_negative is not None:
                last_negative[1].save(out/'last-no-visible-glyph.png')
            frame.save(out/'first-visible-glyph.png')
            first=(max(0,last_negative[0]-ack) if last_negative is not None else 0,b-submitted)
            ev('first-visible-glyph',lower_s=first[0],upper_s=first[1],ink_pixels=ink,answer_row=text['reply'],last_negative_status=last_negative[2] if last_negative is not None else None)
        else:
            last_negative=(a,frame,text['status'])
            last_crop=frame.crop((670,415,1802,514))
            chunk=out/'last-negative-frame.tmp'
            last_crop.save(chunk,format='PNG')
            chunk.replace(out/'last-negative-frame.png')
            record={'lower_s':a-ack,'upper_s':b-submitted,'answer':text['status'],'reply_ink_pixels':ink,'crop_sha256':hashlib.sha256((out/'last-negative-frame.png').read_bytes()).hexdigest()}
            chunk.write_text(json.dumps(record)+'\n')
            chunk.replace(out/'last-negative-frame.json')
    if text['status'] and '\ufffd' not in text['status'] and text['status']!=prevstate:
        prevstate=text['status']
        ev('answer-row-status',lower_s=a-ack,upper_s=b-submitted,value=prevstate)
        if prevstate.startswith('(preparing') and not (out/'reading.png').exists():frame.save(out/'reading.png')
    if terminal:
        if timed_terminal is None:timed_terminal=time.monotonic()
        if first or time.monotonic()-timed_terminal>10:
            frame.save(out/'terminal.png')
            ev('terminal-scanout',lower_s=a-ack,upper_s=b-submitted,rows=[row(frame,y)['reply'] for y in range(484,822,24)],serial=terminal[0][2],first_visible_s=first)
            break
    if time.monotonic()-last_event>=60:
        ev('observation',lower_s=a-ack,upper_s=b-submitted,first_visible=bool(first),waiting_line=prevstate,answer_row=text['reply'] if first else None)
        if not first and last_negative is not None:frame.save(out/'latest-reading.png')
        last_event=time.monotonic()
    time.sleep(3 if first is None else 4)
stop_monitor.set()
vm.key('ctrl','alt','delete')
vm.until('tailorbird ended STOPPED','desktop:')
time.sleep(.5)
snap()[2].save(out/'desktop.png')
vm.key('f10');time.sleep(.65);vm.key('ret')
rc=vm.child.wait(timeout=80)
lines=vm.log().splitlines()
ev('shutdown',qemu_exit=rc,passes=sum(s.startswith('  pass ') for s in lines),pools=[s for s in lines if (' of ' in s and 'given back' in s) or 'ALL SELF-TESTS PASS' in s])
assert rc==33

import errno, json, os, shutil, subprocess, sys, time, runpy
from reserve import private_backing
from pathlib import Path
from PIL import Image
base=Path(os.environ['B3_ROOT'])
from qmp_observer import Vm
out=Path('evidence').resolve()
if (out/'full-guest-attempt.json').exists():
    raise SystemExit('The single disk-backed attempt is already recorded.')
size=6656*(1<<20)
try:
    backing=private_backing('.',size)
except OSError as exc:
    if exc.errno not in (errno.ENOSPC,errno.EDQUOT):raise
    st=os.statvfs('.')
    (out/'capacity.json').write_text(json.dumps(dict(requested=size,available=st.f_bavail*st.f_frsize,errno=exc.errno,utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())))+'\n')
    raise SystemExit(75)

fw=base/'runtime/usr/share/OVMF'
vars_path=Path('trial-vars.fd').resolve()
shutil.copyfile(fw/'OVMF_VARS_4M.fd',vars_path)
serial=out/'guest-serial.txt'
q=[str(base/'hostbin/qemu-system-x86_64'),'-object',f'memory-backend-file,id=hostram,size={size},mem-path=/proc/self/fd/{backing},share=on,prealloc=off,merge=off,dump=off','-machine','q35,max-ram-below-4g=512M,memory-backend=hostram','-accel','tcg','-cpu','max','-smp','1','-m','6656M','-no-reboot','-nic','none','-display','none','-vga','std','-serial',f'file:{serial}','-qmp','stdio','-device','isa-debug-exit,iobase=0xf4,iosize=0x04','-drive',f'if=pflash,unit=0,format=raw,readonly=on,file={fw}/OVMF_CODE_4M.fd','-drive',f'if=pflash,unit=1,format=raw,file={vars_path}','-device','qemu-xhci,id=xhci','-drive',f'if=none,id=stick,readonly=on,format=vmdk,file={Path("volume.vmdk").resolve()}','-device','usb-storage,bus=xhci.0,drive=stick,bootindex=1']
(out/'command.json').write_text(json.dumps(q,indent=2)+'\n')
vm=Vm.__new__(Vm);vm.out=out;vm.serial=serial
st=os.fstat(backing)
with (out/'full-guest-attempt.json').open('x') as marker:
    json.dump(dict(volume='6a0ac4354ceb447be9088df1dc7bc2d8875efcc9f113130302c877ae47784583',bytes=size,reserved_bytes=st.st_blocks*512,nlink=st.st_nlink,mode=oct(st.st_mode&0o777),source='exclusive unlinked private disk file',utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())),marker)
zero=time.monotonic()
vm.child=subprocess.Popen(q,pass_fds=(backing,),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(out/'qemu.log').open('w'),text=True)
os.close(backing)
def ev(event,**rest):
    row={'event':event,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'boot_s':round(time.monotonic()-zero,4),**rest}
    with (out/'events.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    print(json.dumps(row),flush=True)
def live():
    if vm.child.poll() is not None:raise RuntimeError(('emulator exited',vm.child.returncode,vm.log().splitlines()[-3:]))
def snap():
    path=Path('current.ppm').resolve()
    live();a=time.monotonic();vm.rpc('screendump',filename=str(path));b=time.monotonic()
    with Image.open(path) as im: frame=im.convert('RGB')
    return a,b,frame
try:
    hello=json.loads(vm.child.stdout.readline());assert 'QMP' in hello
    vm.rpc('qmp_capabilities')
    block=next(x for x in vm.rpc('query-block') if x['device']=='stick')['inserted']
    assert block['ro'] and block['image']['virtual-size']==5253365760
    constants=vm.rpc('query-cpu-model-expansion',type='full',model={'name':'max'})['model']['props']
    flags={k:constants.get(k) for k in ['avx','avx2','xsave','sse2','sse4.1','sse4.2','fma','xsaveopt','hypervisor']}
    assert flags['avx2'] and flags['xsave']
    memdev=vm.rpc('query-memdev');assert any(x['size']==size and x['id']=='hostram' for x in memdev)
    ev('boot',private_disk_backed=memdev,qemu=hello['QMP']['version'],processor='max',flags=flags,virtual_size=block['image']['virtual-size'],readonly=block['ro'])
    first_frame=False;last=zero
    while 'tailorbird: model service: ready' not in vm.log():
        live()
        if not first_frame and 'Tailorbird first frame presented' in vm.log():
            first_frame=True;ev('foreground-first-frame');snap()[2].save(out/'loading.png')
        if time.monotonic()-last>=60:
            last=time.monotonic()
            ev('boot-progress',last_serial=vm.log().splitlines()[-1:],rss=Path(f'/proc/{vm.child.pid}/status').read_text().partition('VmRSS:')[2].splitlines()[0].strip())
        time.sleep(.35)
    ev('ready',backend=[s for s in vm.log().splitlines() if 'worker:' in s.lower()][-3:])
    snap()[2].save(out/'ready.png')
    while not Path('measure.py').exists():live();time.sleep(.25)
    runpy.run_path('measure.py',init_globals={**globals()})
finally:
    if vm.child.poll() is None:vm.child.terminate()
    ev('emulator-exit',code=vm.child.wait())

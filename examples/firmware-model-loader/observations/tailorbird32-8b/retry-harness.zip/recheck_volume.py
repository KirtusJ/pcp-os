import hashlib,json,re
from pathlib import Path
p=Path('volume.vmdk').resolve()
rows=re.findall(r'^RW (\d+) FLAT "([^"]+)" (\d+)$',p.read_text(),re.M)
assert rows
h=hashlib.sha256();cursor=0
for units,name,sector in rows:
    assert name in ('original.fat','shadow.fat') and int(sector)*512==cursor
    remaining=int(units)*512
    with (p.parent/name).open('rb') as f:
        f.seek(cursor)
        while remaining:
            chunk=f.read(min(4<<20,remaining));assert chunk
            h.update(chunk);cursor+=len(chunk);remaining-=len(chunk)
assert cursor==5253365760 and h.hexdigest()=='6a0ac4354ceb447be9088df1dc7bc2d8875efcc9f113130302c877ae47784583'
Path('evidence/volume-recheck.json').write_text(json.dumps({'bytes':cursor,'sha256':h.hexdigest()})+'\n')

"""Synchronous QMP commands for one private QEMU stdio connection."""
import json,time
class Vm:
    def rpc(self,name,**args):
        self.child.stdin.write(json.dumps({'execute':name,'arguments':args})+'\n')
        self.child.stdin.flush()
        for line in self.child.stdout:
            item=json.loads(line)
            if 'return' in item:return item['return']
            if 'error' in item:raise RuntimeError(item['error'])
        raise RuntimeError('QMP ended')
    def log(self):
        return self.serial.read_text(errors='replace') if self.serial.exists() else ''
    def key(self,*keys):
        return self.rpc('send-key',keys=[{'type':'qcode','data':key} for key in keys],**{'hold-time':70})
    def until(self,*markers):
        until=time.monotonic()+90
        while time.monotonic()<until:
            if all(s in self.log() for s in markers):return
            if self.child.poll() is not None:break
            time.sleep(.1)
        raise RuntimeError((markers,self.log().splitlines()[-5:]))

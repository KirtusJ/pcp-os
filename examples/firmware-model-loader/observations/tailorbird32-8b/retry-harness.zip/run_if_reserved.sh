#!/bin/sh
# Run only after confirming the directors' capacity disposition still applies.
set -eu
cd "$(dirname "$0")"
. ./env.sh
exec 9>trial.lock
flock -n 9 || exit 0
[ ! -e evidence/full-guest-attempt.json ] || exit 0
python - <<'PY'
import os,sys
v=os.statvfs('.')
if v.f_bavail*v.f_frsize<6656*(1<<20):
    sys.exit(75)
PY
python recheck_volume.py
exec ../smp/helper-build/release/pcp-delegate retry-ledger.redb "backed-$(date -u +%s)" private-8b-measurement -- python boot_retry.py

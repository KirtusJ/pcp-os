import errno, os, stat
from pathlib import Path
def private_backing(directory,size):
    # Hold an unlinked, regular disk file for this one emulator. No named file survives its exit.
    dirpath=Path(directory)
    assert dirpath.is_dir() and stat.S_IMODE(dirpath.stat().st_mode)==0o700
    f=os.open(dirpath/'guest-ram.reserve',os.O_RDWR|os.O_CREAT|os.O_EXCL,0o600)
    try:
        os.unlink(dirpath/'guest-ram.reserve')
        os.posix_fallocate(f,0,size)
        st=os.fstat(f)
        if st.st_size!=size or st.st_blocks*512<size or st.st_nlink!=0:raise RuntimeError('incomplete private regular-file reservation')
        return f
    except BaseException:
        os.close(f);raise

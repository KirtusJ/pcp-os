from pathlib import Path
from PIL import Image
import numpy as np
bg=np.array([24,54,79])
colors={'reply':np.array([242,247,252]),'status':np.array([159,180,200])}
fonts=np.frombuffer(Path('font-2x.bin').read_bytes(),dtype='uint8').reshape(95,40,20)
masks=np.empty((95,24,12),dtype='int32')
for dy in range(24):
    for dx in range(12):
        tile=fonts[:,dy*40//24:(dy+1)*40//24,dx*20//12:(dx+1)*20//12]
        masks[:,dy,dx]=tile.sum(axis=(1,2))//(tile.shape[1]*tile.shape[2])
maps={}
for kind,color in colors.items():
    cells=((bg*(255-masks[...,None])+color*masks[...,None]+127)//255).astype('uint8')
    maps[kind]={arr.tobytes():chr(i+32) for i,arr in enumerate(cells)}
def row(frame,y=484):
    assert frame.size==(1920,1080)
    pixels=np.asarray(frame)
    output={}
    for kind,table in maps.items():
        chars=[table.get(pixels[y:y+24,x:x+12].tobytes(),'\ufffd') for x in range(786,786+84*12,12)]
        output[kind]=''.join(chars).rstrip()
    return output
if __name__=='__main__':
    import sys
    with Image.open(sys.argv[1]) as im:
        for y in [436,484,508,532]:print(y,row(im.convert('RGB'),y))

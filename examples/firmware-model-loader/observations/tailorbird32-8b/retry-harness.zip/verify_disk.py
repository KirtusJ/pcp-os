import json,os,subprocess,hashlib
from pathlib import Path
from reserve import private_backing
base=Path(os.environ['B3_ROOT'])
size=64<<20
fd=private_backing('.',size)
payload=b'A3 private RAM verification\n'
Path('probe.bin').write_bytes(payload)
args=[str(base/'hostbin/qemu-system-x86_64'),'-object',f'memory-backend-file,id=hostram,size={size},mem-path=/proc/self/fd/{fd},share=on,prealloc=off,dump=off','-machine','q35,memory-backend=hostram','-accel','tcg','-S','-cpu','max','-m','64M','-nodefaults','-display','none','-serial','none','-monitor','none','-nic','none','-qmp','stdio','-device',f'loader,file={Path("probe.bin").resolve()},addr=0x800000,force-raw=on']
with subprocess.Popen(args,pass_fds=(fd,),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) as p:
    try:
        h=p.stdout.readline();assert h and 'QMP' in json.loads(h)
        def rpc(n,**a):
            p.stdin.write(json.dumps({'execute':n,'arguments':a})+'\n');p.stdin.flush()
            while l:=p.stdout.readline():
                j=json.loads(l)
                if 'return'in j:return j['return']
                if 'error'in j:raise RuntimeError(j)
            raise RuntimeError('ended')
        rpc('qmp_capabilities')
        back=rpc('query-memdev')[0];assert back['size']==size
        assert os.pread(fd,len(payload),0x800000)==payload
        assert not Path('guest-ram.reserve').exists() and os.fstat(fd).st_nlink==0
        s=os.fstat(fd);info={'test':'separate 64 MiB VM, paused at reset','reserved_bytes':s.st_blocks*512,'links_after_reservation':s.st_nlink,'mode':oct(s.st_mode & 0o777),'guest_payload_visible_in_exclusive_disk_file':True,'guest_payload_sha256':hashlib.sha256(payload).hexdigest(),'qemu_memdev':back}
        print(json.dumps(info));Path('evidence/backing-control.json').write_text(json.dumps(info,indent=2)+'\n')
        rpc('quit')
    finally:
        if p.poll() is None:p.terminate()
        p.wait(timeout=8);os.close(fd)

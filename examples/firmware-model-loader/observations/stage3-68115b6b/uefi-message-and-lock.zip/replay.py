"""Verify the two saved emulator observations after extracting this archive."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent
def read(folder, name):
    return (root / folder / name).read_text()
configuration = json.loads(read(".", "configuration.json"))
start = int(configuration["ap_idle_start"],16)
end = int(configuration["ap_idle_end"],16)
assert end == start + 4
assert hashlib.sha256((root/"receipt.json").read_bytes()).hexdigest() == read(".","receipt-pin").strip()
for mode, label in [("extended","in its extended mode"),("ordinary","through memory")]:
    serial = read(mode,"serial.log")
    assert "Verified 491400064 of 491400064 model bytes" in serial
    assert "processors: the firmware lists 6 usable (at the address the loader named)" in serial
    assert [c["apic_id"] for c in json.loads(read(mode,"qmp-cpus.json"))] == [0,1,2,4,5,6]
    assert f"5 of 5 started and parked, the interrupt controller reached {label}" in serial
    assert "all 6 processors added to one count together" in serial and "20000 times: 120000 of 120000" in serial
    assert "Tailorbird first frame presented" in serial
    assert len(re.findall(r"^  pass ", serial, re.M)) == 74
    assert not re.search(r"^  FAIL ", serial, re.M)
    named = re.search(r"^command line: image=([0-9a-f]{64}) ",serial,re.M)[1]
    assert named == configuration["image_measurement"]
    assert f"SHA-256: {named} (measured; equal to the value the loader named)" in serial
    assert (root/mode/"ap-idle.bin").read_bytes() == bytes.fromhex("fbf4ebfd")
    blocks=read(mode,"registers.txt").split("CPU#")[1:]
    assert len(blocks) == 6
    def reg(name,block):
        return int(re.search(r"\b"+name+r"=\s*([0-9a-fA-F]+)",block)[1],16)
    for index,block in enumerate(blocks[1:],1):
        assert int(block.split()[0]) == index
        assert reg("RIP",block) == start+2 and reg("RFL",block)&512
        assert reg("CPL",block) == 0 and reg("HLT",block) == 1
    for key,expected in (("RSP",5),("GDT",5),("CR3",1),("IDT",1)):
        assert len({reg(key,b) for b in blocks[1:]}) == expected
    print(mode, "74 checks, 120000 increments, 5 matching secondary idle registers, first frame")

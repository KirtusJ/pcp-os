import argparse
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=["extended", "ordinary"])
parser.add_argument("base", type=Path, help="QEMU/OVMF runtime root")
parser.add_argument("medium", type=Path)
parser.add_argument("kernel", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--trace", action="store_true", help="capture QEMU interrupt diagnostics around secondary startup")
args = parser.parse_args()
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=True)
serial = out / "serial.log"
assert not serial.exists(), "select a fresh observation directory"
ovmf = args.base / "runtime/usr/share/OVMF"
nvram = out / "vars.fd"
shutil.copyfile(ovmf / "OVMF_VARS_4M.fd", nvram)
flag = "+x2apic" if args.mode == "extended" else "-x2apic"
cmd = [str(args.base/"hostbin/qemu-system-x86_64"), "-machine", "q35,max-ram-below-4g=512M", "-accel", "tcg,thread=multi", "-cpu", "max,"+flag, "-m", "1536M", "-smp", "6,sockets=2,cores=3,threads=1", "-display", "none", "-nic", "none", "-no-reboot", "-monitor", "none", "-qmp", "stdio", "-serial", "file:"+str(serial), "-drive", f"if=pflash,format=raw,unit=0,readonly=on,file={ovmf/'OVMF_CODE_4M.fd'}", "-drive", f"if=pflash,format=raw,unit=1,file={nvram}", "-device", "qemu-xhci,id=xhci", "-drive", f"if=none,id=stick,readonly=on,format=raw,file={args.medium.resolve()}", "-device", "usb-storage,bus=xhci.0,drive=stick,bootindex=1"]
symbols = subprocess.check_output(["nm", args.kernel], text=True)
start, end = [int(re.search(r"^(\w+) T "+name+"$", symbols, re.M)[1],16) for name in ("ap_idle","ap_idle_end")]
elf = args.kernel.read_bytes()
phoff, = struct.unpack_from("<I",elf,28)
phsize, phnum = struct.unpack_from("<HH",elf,42)
segments = [struct.unpack_from("<8I",elf,phoff+i*phsize) for i in range(phnum)]
seg, = [s for s in segments if s[0]==1 and s[6]&1 and s[2]<=start<end<=s[2]+s[4]]
offset=seg[1]+start-seg[2]
expected=elf[offset:offset+end-start]
assert expected==bytes.fromhex("fbf4ebfd")
def save(name,value):
    (out/name).write_text(json.dumps(value,indent=2)+"\n")
if args.trace:
    cmd += ["-D",str(out/"interrupts.raw")]
with (out/"machine.log").open("wb") as error:
    machine=subprocess.Popen(cmd,env={**os.environ,"B3_ROOT":str(args.base)},stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=error)
    def qmp(request,params=None):
        message={"execute":request}
        if params is not None: message["arguments"]=params
        machine.stdin.write((json.dumps(message)+"\n").encode())
        machine.stdin.flush()
        while True:
            response=json.loads(machine.stdout.readline())
            if "return" in response: return response["return"]
            if "error" in response: raise RuntimeError(response)
    try:
        welcome=json.loads(machine.stdout.readline())
        save("qmp-greeting.json",welcome)
        qmp("qmp_capabilities")
        cpus=sorted(qmp("query-cpus-fast"),key=lambda cpu:cpu["cpu-index"])
        cpus_with_id=[dict(cpu,apic_id=qmp("qom-get",{"path":cpu["qom-path"],"property":"apic-id"})) for cpu in cpus]
        save("qmp-cpus.json",cpus_with_id)
        deadline=time.monotonic()+180
        trace_on=False
        while machine.poll() is None and time.monotonic()<deadline:
            text=serial.read_text(errors="replace") if serial.exists() else ""
            if args.trace and not trace_on and "Verified 469762048" in text:
                assert not qmp("human-monitor-command",{"command-line":"log int"})
                trace_on=True
            if "Tailorbird first frame presented" in text or "it is in SAFE and starts no program" in text:
                break
            time.sleep(.2)
        qmp("stop")
        regs=qmp("human-monitor-command",{"command-line":"info registers -a"})
        (out/"registers.txt").write_text(regs)
        dump=out/"ap-idle.bin"
        qmp("pmemsave",{"val":seg[3]+start-seg[2],"size":end-start,"filename":str(dump)})
    finally:
        machine.terminate()
        try:machine.wait(5)
        except subprocess.TimeoutExpired:machine.kill();machine.wait()
raw=serial.read_text(errors="replace")
if "it is in SAFE and starts no program" in raw:
    save("result.json",{"mode":args.mode,"outcome":"SAFE","apic_ids":[c["apic_id"] for c in cpus_with_id],"pass_lines":len(re.findall(r"^  pass ",raw,re.M)),"failures":[line.strip() for line in raw.splitlines() if line.strip().startswith("FAIL ")],"serial_smp":[line for line in raw.splitlines() if line.startswith("other processors:")]})
    raise SystemExit("Qualification failed: guest entered SAFE; see raw serial and QMP captures")
assert "Tailorbird first frame presented" in raw,raw[-1300:]
assert "Verified 491400064 of 491400064 model bytes" in raw
assert [c["apic_id"] for c in cpus_with_id]==[0,1,2,4,5,6]
mode_text="in its extended mode" if args.mode=="extended" else "through memory"
assert f"5 of 5 started and parked, the interrupt controller reached {mode_text}; 6 thread(s) on 6 core(s) in all" in raw
assert "all 6 processors added to one count together, each giving the kernel's lock up and taking it again 20000 times: 120000 of 120000" in raw
assert re.search(r"^  pass every processor answers a message,.*the count is exact$",raw,re.M)
assert not re.search(r"^\s*FAIL\b",raw,re.M)
image=re.search(r"^command line: image=([0-9a-f]{64})\b",raw,re.M)[1]
assert f"SHA-256: {image} (measured; equal to the value the loader named)" in raw
assert dump.read_bytes()==expected
blocks=regs.split("CPU#")[1:]
assert len(blocks)==6
secondary=[]
for i,block in enumerate(blocks[1:],1):
    assert int(block.split()[0])==i
    def reg(label):return int(re.search(r"\b"+label+r"=\s*([0-9a-fA-F]+)",block)[1],16)
    assert reg("RIP")==start+2 and reg("RFL")&512 and reg("HLT")==1 and reg("CPL")==0
    secondary.append({key:hex(reg(key)) for key in ("RIP","RSP","RFL","GDT","IDT","CR3")})
assert all(len({cpu[key] for cpu in secondary})==5 for key in ("RSP","GDT"))
assert all(len({cpu[key] for cpu in secondary})==1 for key in ("IDT","CR3"))
summary={"mode":args.mode,"apic_ids":[c["apic_id"] for c in cpus_with_id],"pass_lines_before_first_frame":len(re.findall(r"^  pass ",raw,re.M)),"image_measurement":image,"ap_idle":[hex(start),hex(end)],"elf_and_guest_idle_bytes":expected.hex(),"secondary_registers":secondary,"serial_smp":[line for line in raw.splitlines() if line.startswith("other processors:")]}
save("result.json",summary)
print(json.dumps(summary),flush=True)

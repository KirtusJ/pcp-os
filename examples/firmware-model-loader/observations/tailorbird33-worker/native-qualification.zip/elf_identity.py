from pathlib import Path
import re, json, hashlib, subprocess, struct
p=Path(__file__).resolve().parent
ident=json.loads((p/"identity.json").read_text())
workers=["model-worker","model-worker-qwen3-8b"]
text_hash={}
normalized={}
info={}
for n in workers:
    elf=(p/n).read_bytes()
    off,=struct.unpack_from("<Q",elf,32)
    ents,count=struct.unpack_from("<HH",elf,54)
    segments=[struct.unpack_from("<IIQQQQQQ",elf,off+i*ents) for i in range(count)]
    code=[s for s in segments if s[0]==1 and s[1]&1];assert code
    text_hash[n]=[hashlib.sha256(elf[s[2]:s[2]+s[5]]).hexdigest() for s in code]
    asm=subprocess.check_output(["objdump","-d","-M","intel",p/n],text=True)
    ops={}
    for op in ("cpuid","xgetbv","vpmaddubsw","vpmaddwd","vmulpd"):
        values=[int(v,16) for v in re.findall(r"^\s*([0-9a-f]+):\s+(?:[0-9a-f]{2}\s+)+\b"+op+r"\b",asm,re.M)]
        assert values and all(any(s[3]<=v<s[3]+s[5] for s in code) for v in values)
        ops[op]=len(values)
    pin=ident["pins"][n].encode()
    assert elf.count(pin)==1
    pin_at=elf.index(pin)
    assert not any(s[2]<=pin_at<s[2]+s[5] for s in code)
    info[n]={"executable_segments":text_hash[n],"opcodes":ops,"manifest_offset":pin_at}
    normalized[n]=elf.replace(pin,b"0"*64,1)
print(json.dumps(info,indent=2))
print("code equal:",text_hash[workers[0]]==text_hash[workers[1]],"whole ELFs equal after neutralizing their manifest pin:",normalized[workers[0]]==normalized[workers[1]])

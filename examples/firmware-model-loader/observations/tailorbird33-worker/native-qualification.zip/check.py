from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile
import json, os, re, subprocess

here=Path(__file__).resolve().parent
base=Path("/workspace/scratch/fe41c884a67c")
kernel=here.parent/"k397/PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32"
def digest(data): return sha256(data).hexdigest()
assert digest(kernel.read_bytes())=="49aa3c9d5c8f2506e60bd91951e8a2941e43952244a596f87809548e35e2d9a3"
assert digest((here/"worker.zip").read_bytes())=="dcf196f7edf1ee8ac6f4e56ac2430c9d5d49008691dd243dae8274f601b74f4a"
assert digest((here/"ui.zip").read_bytes())=="77d8043edc50b9db562ca6e00a822bce83cbbe810f5b743557074ddb94d5c822"
with ZipFile(here/"ui.zip") as z:
    assert z.testzip() is None
    (here/"tailorbird").write_bytes(z.read("tailorbird"))
with ZipFile(here/"worker.zip") as z:
    assert z.testzip() is None
    src=z.read("source.txt").decode()
    assert "5638f4bf8e1c10b3ef9d4c022563b69e7f1664f2" in src and "ce5aed7757a416590b8071b52041bfa868d59fa5" in src
    pins={n.decode():h for h,n in [line.split() for line in z.read("model-manifests.txt").splitlines()]}
    identity={"tailorbird":digest((here/"tailorbird").read_bytes())}
    for line in z.read("binaries.sha256").decode().splitlines():
        h,n=line.split()
        blob=z.read(n)
        assert digest(blob)==h
        identity[n]=h
        (here/n).write_bytes(blob)
        if n in pins:
            assert blob.count(pins[n])==1 and all(blob.count(val)==0 for val in pins.values() if val!=pins[n])
    (here/"identity.json").write_text(json.dumps({"files":identity,"pins":{k:v.decode() for k,v in pins.items()}},indent=2)+"\n")
    lane=("x86_64-pcpos-worker","x86_64-unknown-none")
    for idx,cpu in enumerate(["qemu64","max,-avx2","max","max,-fma","max,-f16c","max,-xsave"],1):
        for n in lane:
            optimized=n==lane[0]
            ordered="AVX2" if optimized and 3<=idx<=5 else "scalar"
            packed="AVX2 Q8_K" if optimized and idx==3 else ordered
            h=identity[n]
            def check(raw):
                assert raw.count("Qwen Q4_K/Q6_K projections passed with "+ordered+"\n")==1
                assert raw.splitlines().count("Qwen inference backend: "+packed)==2
                assert raw.splitlines().count("Qwen upstream Q8_K dots, four prompt positions, Stop and retry passed")==int(packed=="AVX2 Q8_K")
                assert raw.count("Qwen worker prefill progress passed opt-in, Stop and retry")==2
                assert raw.count("Qwen decoder passed 128 reference logits")==1 and "ALL SELF-TESTS PASS" in raw
                assert h in raw and "qwen-probe ended DONE: exit 0" in raw
                match=re.search(r"kernel heap: .*?frames: (\d+) of (\d+) free",raw); assert match[1]==match[2]
            if idx<=5: check(z.read(f"{n}-{idx}.log").decode().replace("\r",""))
            d=here/(n+"-"+str(idx));d.mkdir(exist_ok=True)
            (d/"qwen-probe").write_bytes(z.read(n))
            log=d/"serial.log"
            cmd=[str(base/"hostbin/qemu-system-x86_64"),"-machine","pc","-accel","tcg","-cpu",cpu,"-m","256M","-kernel",str(kernel),"-initrd",str(d/"qwen-probe"),"-append","auto=qwen-probe then=off","-display","none","-nic","none","-serial","file:"+str(log),"-no-reboot","-device","isa-debug-exit,iobase=0xf4,iosize=0x04"]
            ret=subprocess.run(cmd,timeout=115,env={**os.environ,"B3_ROOT":str(base)},cwd=d,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
            assert ret.returncode==33,(n,cpu,ret.returncode,ret.stderr[-140:],log.read_text()[-300:])
            check(log.read_text())
            print(cpu,n,packed,"exit 33",flush=True)

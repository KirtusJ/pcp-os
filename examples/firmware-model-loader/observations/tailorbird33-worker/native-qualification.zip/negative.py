from pathlib import Path
from hashlib import sha256
import os,shutil,subprocess,time,re
p=Path(__file__).resolve().parent
d=p/'8b-no-payload';d.mkdir(exist_ok=True)
base=Path('/workspace/scratch/fe41c884a67c')
front=d/'tailorbird.elf';back=d/'model-worker'
shutil.copyfile(p/'tailorbird',front);shutil.copyfile(p/'model-worker-qwen3-8b',back)
f=sha256(front.read_bytes()).hexdigest();b=sha256(back.read_bytes()).hexdigest()
assert b=='1400620be191ec0d6d18e6ff4da363cb6983913115067e3ee424abce5131a32c'
kernel=p.parent/'stage397final/parts/KERNEL.ELF'
log=d/'serial.log';assert not log.exists()
cmd=[str(base/'hostbin/qemu-system-x86_64'),'-machine','q35','-accel','tcg','-cpu','max','-m','256M','-smp','1','-kernel',str(kernel),'-initrd','tailorbird.elf,model-worker','-append',f'auto=tailorbird.elf then=off desktop=800x600 worker_for={f} worker_image={b}','-display','none','-nic','none','-monitor','none','-serial','file:'+str(log),'-no-reboot']
with (d/'machine.log').open('wb') as err:
    guest=subprocess.Popen(cmd,cwd=d,env={**os.environ,'B3_ROOT':str(base)},stdout=subprocess.DEVNULL,stderr=err)
    try:
        end=time.monotonic()+55
        while time.monotonic()<end and guest.poll() is None:
            raw=log.read_text(errors='replace') if log.exists() else ''
            if 'tailorbird: model service: did not start' in raw:break
            time.sleep(.1)
        raw=log.read_text(errors='replace')
        assert b in raw and 'companion model-worker (286088 bytes)' in raw
        assert 'Taylor model worker:' in raw and 'tailorbird: model service: did not start' in raw,raw[-700:]
        assert not re.search('projections:|model service: ready',raw)
        print('\n'.join(l for l in raw.splitlines() if l.startswith(('Taylor model worker:','tailorbird: model service:','tailorbird.elf is started'))))
    finally:
        guest.terminate()
        try:guest.wait(4)
        except subprocess.TimeoutExpired:guest.kill();guest.wait()

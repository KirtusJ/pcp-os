import json,os,re,shutil,subprocess,time
from pathlib import Path
from PIL import Image
out=Path(__file__).resolve().parent
base=Path("/workspace/scratch/fe41c884a67c")
firm=base/"runtime/usr/share/OVMF"
fat=Path("/tmp/b3-33-coder-5638f4bf.fat")
serial=out/"native-serial.log"
assert not serial.exists()
shutil.copyfile(firm/"OVMF_VARS_4M.fd",out/"vars.fd")
cmd=[str(base/"hostbin/qemu-system-x86_64"),"-machine","q35,max-ram-below-4g=512M","-accel","tcg","-cpu","max","-m","1536M","-smp","1","-display","none","-monitor","none","-qmp","stdio","-serial","file:"+str(serial),"-nic","none","-no-reboot","-drive",f"if=pflash,format=raw,unit=0,readonly=on,file={firm/'OVMF_CODE_4M.fd'}","-drive",f"if=pflash,format=raw,unit=1,file={out/'vars.fd'}","-device","qemu-xhci,id=xhci","-drive",f"if=none,id=stick,readonly=on,format=raw,file={fat}","-device","usb-storage,bus=xhci.0,drive=stick,bootindex=1"]
start=time.monotonic()
def log(event,detail):
    with (out/"events.jsonl").open("a") as f:
        print(json.dumps({"event":event,"seconds_since_launch":round(time.monotonic()-start,3),"detail":detail}),file=f)
with (out/"machine.log").open("wb") as err:
    p=subprocess.Popen(cmd,env={**os.environ,"B3_ROOT":str(base)},stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
    def rpc(key,args=None):
        msg={"execute":key}
        if args: msg["arguments"]=args
        p.stdin.write((json.dumps(msg)+"\n").encode());p.stdin.flush()
        while True:
            q=json.loads(p.stdout.readline())
            if "return" in q:return q["return"]
            if "error" in q:raise ValueError(q)
    def wait_for(pattern,timeout):
        end=time.monotonic()+timeout
        while time.monotonic()<end and p.poll() is None:
            s=serial.read_text(errors="replace") if serial.exists() else ""
            hit=re.search(pattern,s,re.M)
            if hit:log("serial",hit[0]);return hit
            if re.search(r"^Taylor model worker: (?!verified,).*",s,re.M) or "it is in SAFE and starts no program" in s:
                raise RuntimeError(s[-800:])
            time.sleep(.15)
        raise RuntimeError((pattern,serial.read_text(errors="replace")[-450:]))
    def key(code):
        response=rpc("human-monitor-command",{"command-line":"sendkey "+code+" 45"})
        assert not response,response
        time.sleep(.09)
    def typed(text):
        for c in text:
            key({" ":"spc",".":"dot"}.get(c.lower(),("shift-"+c.lower()) if c.isupper() else c))
        key("ret");log("entered",text)
    def snap(name):
        tmp=out/"screen.ppm";rpc("screendump",{"filename":str(tmp)})
        with Image.open(tmp) as im:im.save(out/(name+".png"))
        tmp.unlink()
    try:
        hello=json.loads(p.stdout.readline())
        assert "QMP" in hello
        log("emulator",hello["QMP"]["version"])
        rpc("qmp_capabilities")
        wait_for(r"^Tailorbird first frame presented$",160)
        wait_for(r"^Taylor model worker: verified, tokenized and preflighted; Q4_K/Q6_K projections: AVX2 Q8_K$",600)
        wait_for(r"^tailorbird: model service: ready.*$",30)
        snap("ready")
        typed("Describe the colors of a rainbow in one sentence.")
        wait_for(r"^tailorbird: reply 1 is being answered$",30)
        time.sleep(1);key("alt-s")
        wait_for(r"^tailorbird: reply 1 kept \d+ bytes and is stopped by the person.*$",35)
        snap("stopped")
        key("alt-c");time.sleep(.5)
        typed("Say hello.")
        wait_for(r"^tailorbird: reply 2 is being answered$",35)
        wait_for(r"^tailorbird: reply 2 kept \d+ bytes and [^\n]*$",360)
        snap("reply")
    finally:
        p.terminate()
        try:p.wait(5)
        except subprocess.TimeoutExpired:p.kill();p.wait()

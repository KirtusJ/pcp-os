"""Offline readback of the paired worker qualification results."""
from pathlib import Path
import json,re
root=Path(__file__).resolve().parent
identity=json.loads((root/"identity.json").read_text())
wanted8="1400620be191ec0d6d18e6ff4da363cb6983913115067e3ee424abce5131a32c"
assert identity["files"]["model-worker-qwen3-8b"]==wanted8
assert "whole ELFs equal after neutralizing their manifest pin: True" in (root/"elf-identity.log").read_text()
counts={}
for idx,mask in enumerate(("qemu64","max,-avx2","max","max,-fma","max,-f16c","max,-xsave"),1):
    for lane in ("x86_64-pcpos-worker","x86_64-unknown-none"):
        text=(root/(lane+"-"+str(idx))/"serial.log").read_text()
        packed=("AVX2 Q8_K" if idx==3 else "AVX2" if idx in (4,5) else "scalar") if lane=="x86_64-pcpos-worker" else "scalar"
        assert text.splitlines().count("Qwen inference backend: "+packed)==2
        assert ("Qwen upstream Q8_K dots, four prompt positions, Stop and retry passed" in text)==(packed=="AVX2 Q8_K")
        assert text.count("Qwen worker prefill progress passed opt-in, Stop and retry")==2 and "Qwen decoder passed 128 reference logits" in text
        assert identity["files"][lane] in text and "qwen-probe ended DONE: exit 0" in text and "ALL SELF-TESTS PASS" in text
        returned=re.search(r"kernel heap: .*?frames: (\d+) of (\d+) free",text)
        assert returned[1]==returned[2]
        counts[packed]=counts.get(packed,0)+1
assert counts=={"scalar":9,"AVX2":2,"AVX2 Q8_K":1}
assert (root/"matrix.log").read_text().count("exit 33")==12
n=(root/"8b-no-payload/serial.log").read_text()
assert wanted8 in n and "Taylor model worker: no loader model" in n and "tailorbird: model service: did not start" in n and "projections:" not in n
s=(root/"production/native-serial.log").read_text()
assert "Verified 491400064 of 491400064 model bytes." in s and identity["files"]["model-worker"] in s
assert "Taylor model worker: verified, tokenized and preflighted; Q4_K/Q6_K projections: AVX2 Q8_K" in s
assert "reply 1 kept 0 bytes and is stopped by the person" in s and "reply 2 is being answered" in s
terminal=re.search(r"reply 2 kept (\d+) bytes and is complete",s)
print("Native probes",counts,"; 8B missing-model refusal; Coder Ready, Stop and new turn.")
if terminal:print("Coder second reply completed with",terminal[1],"bytes.")

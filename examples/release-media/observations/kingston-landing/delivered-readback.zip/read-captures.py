"""Read both diagnostic lines directly from the transferred framebuffer pixels."""
import ast
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
from zipfile import ZipFile
import numpy as np
from PIL import Image

here = Path(__file__).resolve().parent
work = Path((here.parent / "clock-desktop-binding/active-work").read_text().strip())
font = work / "landing/PCP_OS_Rust/crates/pcpos-kernel/src/font.rs"
a = np.array(ast.literal_eval("[" + font.read_text().split(" = [",1)[1].split("];",1)[0] + "]"),dtype=np.int32).reshape(95,20,10,1)
palette = (np.array([16,40,63])*(255-a) + np.array([159,180,200])*a + 127)//255
palette = palette.astype(np.uint8)
with ZipFile(here / "kingston-8b-f54c1d0a.zip") as z:
    def rgb(name):
        im = Image.open(BytesIO(z.read("boot/"+name+".png"))).convert("RGB")
        assert im.size == (1920,1080)
        return np.array(im)
    home, idle, details = [rgb(n) for n in ("home","idle","details")]
    assert np.array_equal(home, idle)
    binding = json.loads(z.read("binding.json"))
    verified_tools = {}
    for name, row in binding["kernel_build"]["tools"].items():
        measured = sha256(Path(row["path"]).read_bytes()).hexdigest()
        assert measured == row["sha256"]
        verified_tools[name] = measured
    lines = ["display memory: 2025 of the 2025 pages a picture is written to are mapped write-combining, read back from the kernel's tables", "display: a program that asks draws to memory of its own, and the kernel shows each finished picture"]
    matched = []
    for text in lines:
        expected=np.concatenate([palette[ord(c)-32] for c in text],axis=1)
        rows=[y for y in range(0,1080,20) if np.array_equal(details[y:y+20,40:40+expected.shape[1]],expected)]
        assert len(rows)==1, text
        matched.append({"x":40,"y":rows[0],"foreground":"#9fb4c8","text":text})
    s=z.read("boot/serial.txt").decode().splitlines()
    assert all(line in s for line in [*lines, "elapsed clock: 64-bit ACPI HPET main counter"])
    print(json.dumps({"idle_home_equal":True,"home_rgb_sha256":sha256(home.tobytes()).hexdigest(),"native_rows":matched,"tool_hashes":verified_tools},indent=2))

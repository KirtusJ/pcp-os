"""Match the published B3 transfer against A3's independently built and measured files."""
import hashlib
import json
from pathlib import Path
import sys
from zipfile import ZipFile

audit = Path(__file__).resolve().parent.parent
work = Path((audit / "clock-desktop-binding/active-work").read_text().strip())
own = work / "landing-rebuild"
package = Path(sys.argv[1])
published_sha = sys.argv[2]
def digest(data):
    return hashlib.sha256(data).hexdigest()
assert digest(package.read_bytes()) == published_sha, "transfer digest"
match = {"EFI/BOOT/BOOTX64.EFI":own/"BOOTX64.EFI","PCPOS/KERNEL.ELF":own/"parts/KERNEL.ELF","efi-build.json":own/"efi-build.json","expected-files.json":own/"expected-files.json","inputs.json":own/"inputs.json"}
with ZipFile(package) as bundle:
    names = bundle.namelist()
    assert len(names) == len(set(names)) and bundle.testzip() is None
    checksum_rows = [s.split("  ",1) for s in bundle.read("SHA256SUMS").decode().splitlines()]
    checks = {n:h for h,n in checksum_rows}
    assert len(checks) == len(checksum_rows) and set(checks) == set(names) - {"SHA256SUMS"}
    for name in checks:
        assert digest(bundle.read(name)) == checks[name], name
    for member, path in match.items():
        assert bundle.read(member) == path.read_bytes(), member
    binding = json.loads(bundle.read("binding.json"))
    assert binding["kernel_source"] == "f54c1d0a45e8fc328b950649adfb3fbea7768c81"
    assert binding["loader_source"] == binding["kernel_source"]
    inv = json.loads(bundle.read("expected-files.json"))
    retained = json.loads((own/"retained.json").read_bytes())
    assert len(inv) == 82 and len(retained["members"]) == 80
    assert set(inv) == set(retained["members"]) | {"PCPOS/KERNEL.ELF","EFI/BOOT/BOOTX64.EFI"}
    assert all(inv[k] == v for k,v in retained["members"].items())
    for path in ["PCPOS/KERNEL.ELF","EFI/BOOT/BOOTX64.EFI"]:
        assert {"bytes":len(bundle.read(path)), "sha256":checks[path]} == inv[path]
    print(json.dumps({"published_archive_sha256":published_sha, "published_archive_bytes":package.stat().st_size,"checked_archive_members":len(checks),"byte_identical_members":list(match),"verified_inventory_files":len(inv),"model_sha256":retained["model_sha256"],"binding":binding["kernel_source"]},indent=2))

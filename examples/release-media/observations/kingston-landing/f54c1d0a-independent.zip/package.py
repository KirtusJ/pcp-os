"""Archive independent measurements and validate the links between their inputs."""
import hashlib
import json
from pathlib import Path
import subprocess
from zipfile import ZIP_DEFLATED, ZipFile

here = Path(__file__).resolve().parent
audit = here.parent
p = Path((audit / "clock-desktop-binding/active-work").read_text().strip())
build = p / "landing-rebuild"
run = p / "landing-ordinary-retry"
kernel = build / "parts/KERNEL.ELF"
kroot = p / "landing/PCP_OS_Rust/crates/pcpos-kernel"
def digest(f):
    return hashlib.sha256(f.read_bytes()).hexdigest()
def git(fmt):
    return subprocess.check_output(["git","-C",audit / "source","show","-s","--format="+fmt,"f54c1d0a"],text=True).strip()
result = json.loads((run/"result.json").read_bytes())
handoff = json.loads((run/"handoff.json").read_bytes())
serial = (run/"serial.log").read_text().splitlines()
inventory = json.loads((build/"expected-files.json").read_bytes())
retained = json.loads((build/"retained.json").read_bytes())
efi = build / "BOOTX64.EFI"
differences = {"PCPOS/KERNEL.ELF":kernel, "EFI/BOOT/BOOTX64.EFI":efi}
for path, src in differences.items():
    assert inventory[path] == {"bytes":src.stat().st_size, "sha256":digest(src)}
assert retained["members"] == {k:v for k,v in inventory.items() if k not in differences}
assert handoff["returncode"] == 33 and "ALL SELF-TESTS PASS" in "\n".join(serial)
assert result["kernel_sha256"] == digest(kernel)
assert any(x.startswith("display memory: 2025 of the 2025 pages") for x in serial)
assert "elapsed clock: 64-bit ACPI HPET main counter" in serial
assert sum(line.lstrip().startswith("pass ") for line in serial) == 71
summary = {
    "source":git("%H"),"git_tree":git("%T"),"parents":git("%P").split(),
    "kernel_requested_features":["proposals","model-memory"], "load_base_mib":32,
    "kernel_stage":"/dev/shm/b3-bound-initial/postmerge-0e3dd8a3",
    "code_ro_sha256":subprocess.check_output(["python3",kroot/"tools/measure.py",kernel],text=True).strip(),
    "sha256":{f.name:digest(f) for f in (kernel,efi,build/"inputs.json",build/"efi-build.json",build/"expected-files.json")},
    "retained_files":len(retained["members"]), "model_bytes":retained["model_bytes"], "model_sha256":retained["model_sha256"],
    "probe_framesize":[1920,1080],"probe_checks":71,"probe_exit":33,"probe_elapsed_host_ns":result["host_busy_start_to_last_end_ns"]
}
assert summary["git_tree"] == "2c63bbafc951e363648dc9537a3fca7d19bebdc0"
bundle = here / "f54c1d0a-independent.zip"
with ZipFile(bundle,"w",ZIP_DEFLATED,compresslevel=9) as z:
    z.writestr("summary.json",json.dumps(summary,indent=2)+"\n")
    for name in ["inputs.json","expected-files.json","efi-build.json","retained.json"]:
        z.write(build/name,name)
    for name in ["README.md","rebuild.py","read-original.py","kernel.log","efi.log","package.py"]:
        z.write(here/name,name)
    for name in ["result.json","handoff.json","serial.log","grub-serial.raw"]:
        z.write(run/name,"probe/"+name)
    z.write(audit/"clock-desktop-binding/canonical.sh","kernel-build.sh")
    z.write(audit/"clock-suite/compare.py","probe/compare.py")
    z.write(p/"probe/grub-after.cfg","probe/grub.cfg")
    z.write(p/"landing-clock-media/qemu-grub","probe/qemu-grub")
    z.write(p/"landing-ordinary/stderr.log","controls/missing-qemu-module-path.log")
    z.write(here/"retained.log","controls/original-fat-missing-notice.log")
with ZipFile(bundle) as z:
    assert z.testzip() is None
print(bundle.stat().st_size, digest(bundle))

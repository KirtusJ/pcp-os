"""Compare the ordinary guest monotonic clock and application summary to host elapsed time."""
import argparse, hashlib, json, queue, re, shutil, subprocess, threading, time
from pathlib import Path

def digest(path):
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('kernel',type=Path)
    p.add_argument('output',type=Path)
    p.add_argument('--qemu',default='qemu-system-x86_64')
    p.add_argument('--accelerator',default='tcg')
    p.add_argument('--cpu',default='max')
    p.add_argument('--machine',default='q35')
    p.add_argument('--append',default='')
    p.add_argument('--vm-core',type=int)
    p.add_argument('--vm-nice',type=int,default=0)
    args=p.parse_args()
    out=args.output.resolve()
    out.mkdir(parents=True,exist_ok=False)
    kernel=args.kernel.resolve()
    probe=Path(__file__).resolve().parent/'clock.elf'
    shutil.copyfile(probe,out/'clock.elf')
    cmd=[args.qemu,'-machine',args.machine,'-accel',args.accelerator,'-cpu',args.cpu,'-smp','1','-m','192M',
         '-display','none','-nic','none','-no-reboot','-kernel',str(kernel),'-initrd','clock.elf',
         '-append',('auto=clock.elf '+args.append).rstrip(),'-serial','stdio','-monitor','none',
         '-device','isa-debug-exit,iobase=0xf4,iosize=0x04']
    if args.vm_core is not None:
        cmd = ['taskset','-c',str(args.vm_core),'nice','-n',str(args.vm_nice),*cmd]
    messages=queue.Queue()
    timestamps={}
    lines=[]
    with (out/'stderr.log').open('wb') as err,subprocess.Popen(cmd,cwd=out,stdout=subprocess.PIPE,stderr=err) as vm:
        def record():
            for raw in vm.stdout:
                instant=time.perf_counter_ns()
                messages.put((instant,raw.decode(errors='replace').strip()))
            messages.put((0,None))
        reader=threading.Thread(target=record,daemon=True)
        reader.start()
        try:
            deadline=time.monotonic()+180
            while True:
                remaining=deadline-time.monotonic()
                if remaining<=0:raise TimeoutError('Guest run exceeded 180 seconds')
                try: now,line=messages.get(timeout=remaining)
                except queue.Empty as exc:raise TimeoutError('Guest run exceeded 180 seconds') from exc
                if line is None:break
                lines.append(line)
                match=re.fullmatch(r'CLOCK-(BUSY|REL|ABSMONO|ABSREAL|PAST)-(BEGIN|END)(?: (\d+))?',line)
                if match:
                    marker=match.group(1)+'-'+match.group(2)
                    if marker in timestamps:raise ValueError('Duplicate phase marker '+marker)
                    timestamps[marker]=(now,int(match.group(3)) if match.group(3) else None)
            code=vm.wait(timeout=3)
        finally:
            if vm.poll() is None:vm.terminate()
            vm.wait(timeout=10)
            reader.join(timeout=2)
            (out/'serial.log').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    if code!=33 or not any('ALL SELF-TESTS PASS' in line for line in lines):
        raise ValueError('See serial.log and stderr.log for kernel result')
    report={'kernel_sha256':digest(kernel),'probe_sha256':digest(probe),'cpu':args.cpu,
            'accelerator':args.accelerator,'machine':args.machine,'kernel_append':args.append,
            'vm_core':args.vm_core,'vm_nice_increment':args.vm_nice,'host_clock':vars(time.get_clock_info('perf_counter')),'phases':{}}
    if 'CLOCK-INTERFACES-AGREE' not in lines:
        raise ValueError('Guest interface checks failed; see serial.log')
    for phase in ['BUSY','REL','ABSMONO','ABSREAL','PAST']:
        t0=timestamps[phase+'-BEGIN'][0]
        t1,guest=timestamps[phase+'-END']
        report['phases'][phase]={'host_ns':t1-t0,'guest_clock_gettime_ns':guest}
    report['host_busy_start_to_last_end_ns']=timestamps['PAST-END'][0]-timestamps['BUSY-BEGIN'][0]
    report['application']=next(line for line in lines if line.startswith('clock.elf ended DONE: exit 0 '))
    (out/'result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report['phases']))
if __name__=='__main__':main()

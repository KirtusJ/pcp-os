"""Build the desktop-first EFI from the pinned landing kernel and original loader inputs."""
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
from zipfile import ZipFile

audit = Path(__file__).resolve().parent.parent
stage = Path((audit / "clock-desktop-binding/active-work").read_text().strip())
src = stage / "landing"
out = stage / "landing-rebuild"
parts = out / "parts"
parts.mkdir(parents=True, exist_ok=True)
def digest(data):
    return sha256(data).hexdigest()
def record(data):
    return {"bytes": len(data), "sha256": digest(data)}
def save(path, obj):
    path.write_text(json.dumps(obj, sort_keys=True, indent=2) + "\n")
with ZipFile(audit / "postmerge-qualification.zip") as historical, ZipFile(audit.parent / "release-395-ggml/upstream/inputs.zip") as original:
    inventory = json.loads(historical.read("expected-files.json"))
    receipt = json.loads(historical.read("inputs.json"))
    for name in ["TAILOR.ELF","WORKER.ELF","model.manifest"]:
        data = original.read("parts/" + name)
        assert record(data) == inventory["PCPOS/" + name]
        (parts / name).write_bytes(data)
kernel = (src / "PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32").read_bytes()
(parts / "KERNEL.ELF").write_bytes(kernel)
receipt["files"]["KERNEL.ELF"] = digest(kernel)
save(out / "inputs.json", receipt)
b3 = Path(os.environ["B3_ROOT"])
compiler = b3 / "service/compiler/installed"
env = dict(os.environ, PATH=str(compiler / "bin") + ":" + os.environ["PATH"], LD_LIBRARY_PATH=str(compiler / "lib"))
subprocess.run(["python3", src / "examples/firmware-model-loader/build.py", parts, out / "inputs.json","--receipt-sha256",digest((out / "inputs.json").read_bytes()),"--gnu-efi",b3 / "runtime/usr","--build-record",out / "efi-build.json",out / "BOOTX64.EFI"], env=env, check=True)
efi = (out / "BOOTX64.EFI").read_bytes()
pins = b"".join(bytes.fromhex(receipt["files"][n]) for n in ("KERNEL.ELF","TAILOR.ELF","WORKER.ELF","model.manifest"))
assert efi.count(pins) == 1 and b"auto=tailorbird then=menu" not in efi
inventory["EFI/BOOT/BOOTX64.EFI"] = record(efi)
inventory["PCPOS/KERNEL.ELF"] = record(kernel)
assert len(inventory) == 82
save(out / "expected-files.json", inventory)
for path in [parts / "KERNEL.ELF", out / "BOOTX64.EFI", out / "inputs.json", out / "efi-build.json", out / "expected-files.json"]:
    print(path.name, record(path.read_bytes()), flush=True)

"""Measure the original FAT payloads without allocating a copy of the model."""
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess

audit = Path(__file__).resolve().parent.parent
stage = Path((audit / "clock-desktop-binding/active-work").read_text().strip())
out = stage / "landing-rebuild"
inventory = json.loads((out / "expected-files.json").read_text())
b3 = Path(os.environ["B3_ROOT"]) / "runtime/usr"
image = audit.parent / "worker-32/original.fat"
env = dict(os.environ, LD_LIBRARY_PATH=str(b3 / "lib/x86_64-linux-gnu"))
manifest = (out / "parts/model.manifest").read_bytes()
model_bytes, chunk_bytes, count = struct.unpack_from("<QII", manifest, 8)
assert count == 75 and manifest[:8] == b"PCPMDL01"
whole = hashlib.sha256()
observed = {}
shard_number = 0
for name in sorted(inventory):
    if name in ("EFI/BOOT/BOOTX64.EFI", "PCPOS/KERNEL.ELF"):
        continue
    is_shard = name.startswith("PCPOS/shard-")
    if not is_shard:
        if name in ("PCPOS/TAILOR.ELF", "PCPOS/WORKER.ELF", "PCPOS/model.manifest"):
            data = (out / "parts" / Path(name).name).read_bytes()
        else:
            notice = {"PCPOS/MODEL-LICENSE.txt":"upstream/LICENSE", "PCPOS/RUNTIME-NOTICE.txt":"THIRD_PARTY_NOTICES"}
            data = (audit.parent / "release-395-ggml" / notice[name]).read_bytes()
        observed[name] = {"bytes":len(data), "sha256":hashlib.sha256(data).hexdigest()}
        assert observed[name] == inventory[name], name
        continue
    length = 0
    h = hashlib.sha256()
    with subprocess.Popen([str(b3 / "bin/mtype"), "-i", str(image), "::" + name], env=env, stdout=subprocess.PIPE) as reader:
        for buf in iter(lambda: reader.stdout.read(1024 * 1024), b""):
            length += len(buf)
            h.update(buf)
            if is_shard:
                whole.update(buf)
        assert reader.wait() == 0, name
    if is_shard:
        assert name == f"PCPOS/shard-{shard_number:05}.bin"
        assert h.digest() == manifest[56+32*shard_number:88+32*shard_number]
        assert length == min(chunk_bytes, model_bytes - shard_number * chunk_bytes)
        shard_number += 1
    observed[name] = {"bytes": length, "sha256": h.hexdigest()}
    assert observed[name] == inventory[name], (name, observed[name], inventory[name])
assert len(observed) == 80 and shard_number == count
assert whole.digest() == manifest[24:56]
assert sum(v["bytes"] for k, v in observed.items() if k.startswith("PCPOS/shard-")) == model_bytes
result = {"sources":"75 model shards from original.fat; foreground, worker and manifest from upstream/inputs.zip via parts; license and notice from original release sources", "unchanged":len(observed), "shards":shard_number, "model_bytes":model_bytes, "model_sha256":whole.hexdigest(), "members":observed}
(out / "retained.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
print(len(observed), shard_number, model_bytes, whole.hexdigest())

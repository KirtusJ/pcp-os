set -eu
. ../worker-32/env.sh
test -n "$1"
a3work=$(cat clock-desktop-binding/active-work)
a3name=$(basename "$a3work")
mkdir -p "$a3work/private-shm/$a3name" "$a3work/private-shm/b3-kingston-60c3/buildcache" "$a3work/private-shm/b3-bound-initial/postmerge-0e3dd8a3"
export PCPOS_KERNEL_STAGE="$1" PCPOS_KERNEL_FEATURES=proposals,model-memory CARGO_BUILD_JOBS=1 TMPDIR="$a3work/tmp"
bwrap --bind / / --dev /dev --proc /proc --bind "$a3work/private-shm" /dev/shm --bind "$a3work" "$a3work" -- sh "$a3work/$2/PCP_OS_Rust/crates/pcpos-kernel/run.sh" build
sha256sum "$a3work/$2/PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32"

"""Launch the same Tailorbird guest from each supported desktop surface and read the return destination."""
import ast
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import time

import numpy as np
from PIL import Image

out=Path(__file__).resolve().parent
w=Path((out/'active-work').read_text().strip())
capture=w/'routes';capture.mkdir()
kernel=w/'master/PCP_OS_Rust/crates/pcpos-kernel'
app=w/'target/x86_64-unknown-none/release/tailorbird'
app_hash=sha256(app.read_bytes()).hexdigest()
assert app_hash=='d16b3ef6e5c1ef4da25b87c16ad268711e89d294f3cbd9c0e9faf583c5f7faf8'
shutil.copyfile(app,capture/'tailorbird')
binary=kernel/'target/pcpos-kernel.elf32'
log=capture/'serial.log'
data=(kernel/'src/font.rs').read_text().split(' = [',1)[1].split('];',1)[0]
glyph=np.array(ast.literal_eval('['+data+']'),dtype=np.int32).reshape(95,20,10,1)
background=np.array([16,40,63]);teal=np.array([65,186,215])
letters=((background*(255-glyph)+teal*glyph+127)//255).astype(np.uint8)
def expected(s):
    return np.concatenate([letters[ord(c)-32] for c in s],axis=1)
monitor=runpy.run_path(str(out.parents[1]/'model-free-current/docs/examples/optical-disk-check/check.py'))['Monitor']
events=[]
def snapshot(label):
    f=capture/'now.ppm'
    q.call('screendump',filename=str(f))
    with Image.open(f) as im:
        assert im.size==(1920,1080)
        im.save(capture/(label+'.png'))
        return np.asarray(im)
def has_line(image,s):
    words=expected(s)
    # Kernel text-screen titles are at column 2 and its machine heading is at column 2.
    for y in range(0,1080-19,20):
        if np.array_equal(image[y:y+20,20:20+words.shape[1]],words):
            return y
    return None
def keys(*k):
    q.key(*k);time.sleep(.52)
def logwait(text,count):
    end=time.monotonic()+18
    while log.read_text(errors='replace').lower().count(text.lower())<count:
        if proc.poll() is not None or time.monotonic()>end:
            raise AssertionError((text,count,log.read_text(errors='replace')[-850:]))
        time.sleep(.1)
def route(label,count,identify):
    keys('ret')
    logwait('Tailorbird first frame presented',count)
    time.sleep(.45);snapshot(label+'-guest')
    keys('esc')
    logwait('tailorbird ended DONE: exit 0',count)
    time.sleep(.5)
    image=snapshot(label+'-after-esc')
    if identify=='MACHINE':
        y=has_line(image,identify)
        assert y is not None,(label,identify)
    else:
        keys('f1')
        help_image=snapshot(label+'-f1')
        y=has_line(help_image,identify)
        assert y is not None,(label,identify)
        keys('esc')
    events.append({'launch':label,'key':'Esc','guest_sha256':app_hash,'identified_by':identify,'text_y':y})
args=['qemu-system-x86_64','-machine','q35','-accel','tcg','-cpu','max','-m','256M','-kernel',str(binary),'-initrd','tailorbird','-append','desktop=1920x1080 ui_scale=1','-display','none','-vga','std','-nic','none','-no-reboot','-serial','file:'+str(log),'-qmp','stdio','-device','isa-debug-exit,iobase=0xf4,iosize=0x04']
with (capture/'stderr.log').open('w') as err,subprocess.Popen(args,cwd=capture,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as proc:
    try:
        q=monitor(proc);q.call('qmp_capabilities')
        logwait('desktop: 1920x1080 at 1x UI scale',1);time.sleep(.6)
        keys('ret');keys('ctrl','p')
        route('programs',1,'KEYS IN THE PROGRAMS')
        keys('esc');keys('right')
        route('pinned-home',2,'KEYS ON THE DESKTOP')
        keys('spc');keys('ctrl','d')
        route('details',3,'MACHINE')
        keys('esc');keys('f10');keys('ret')
        code=proc.wait(timeout=12)
        lines=log.read_text(errors='replace').splitlines()
        assert code==33 and any('ALL SELF-TESTS PASS' in s for s in lines)
        launches=[s for s in lines if s.lower().startswith('starting tailorbird (')]
        assert len(launches)==3 and all(app_hash in s for s in launches)
        result={'kernel_source':'1c417d8a008215bfda91c51e13276a2bd5fab0cf','kernel_sha256':sha256(binary.read_bytes()).hexdigest(),'guest_source':'4bc760a861a476f2914c1ad08370d54c88e86564','guest_sha256':app_hash,'geometry':[1920,1080],'model':'omitted','clean_exits':len(launches),'vm_exit':code,'events':events}
        (capture/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
    finally:
        if proc.poll() is None:proc.kill()
        proc.wait()

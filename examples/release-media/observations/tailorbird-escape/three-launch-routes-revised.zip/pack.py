"""Compare the native screenshots to the guest's font and package lossless crops."""
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import sys
from zipfile import ZIP_DEFLATED, ZipFile

from PIL import Image

here = Path(__file__).resolve().parent
stage = Path((here / "active-work").read_text().strip())
capture = stage / "routes"
sys.path.insert(0, str(stage / "source/guest/tests"))
import view_scale as oracle

glyphs = oracle.kernel_glyphs()
doubled = oracle.double_glyphs()
guest_pngs = sorted(capture.glob("*-guest.png"))
assert len(guest_pngs) == 3
assert len({sha256(path.read_bytes()).digest() for path in guest_pngs}) == 1
guest = Image.open(guest_pngs[0]).convert("RGB")
samples = [
    ("PCP OS > Programs > Tailorbird (Esc closes Tailorbird)", 22, 52, oracle.SOFT, oracle.PANEL),
    ("Esc", 212, 516, oracle.TEXT, oracle.PANEL),
    ("closes Tailorbird", 239, 516, oracle.SOFT, oracle.GROUND),
    ("F6", 359, 516, oracle.TEXT, oracle.PANEL),
    ("fit", 380, 516, oracle.SOFT, oracle.GROUND),
]
for label, x, y, ink, ground in samples:
    for i, letter in enumerate(label):
        left = (x + i * 6) * 2
        actual = guest.crop((left, y * 2, left + 12, y * 2 + 24)).tobytes()
        expected = oracle.stop_cell_rgb(glyphs, doubled, letter, 12, 24, ink, ground)
        assert actual == expected, (label, i, letter)
def png(frame):
    stream = BytesIO()
    frame.save(stream, format="PNG")
    return stream.getvalue()
meta = json.loads((capture / "result.json").read_text())
meta["identical_guest_captures"] = True
meta["glyphs_checked"] = [dict(text=s, logical_x=x, logical_y=y) for s,x,y,_,_ in samples]
meta["original_png_sha256"] = {p.name: sha256(p.read_bytes()).hexdigest() for p in sorted(capture.glob("*.png"))}
archive = here / "three-launch-routes-revised.zip"
with ZipFile(archive, "w", ZIP_DEFLATED, compresslevel=9) as bundle:
    bundle.writestr("observations.json", json.dumps(meta, indent=2) + "\n")
    bundle.write(capture / "serial.log", "serial.log")
    for name in ("routes.py", "pack.py", "README.md"):
        bundle.write(here / name, name)
    bundle.writestr("guest-header.png", png(guest.crop((32, 96, 728, 136))))
    bundle.writestr("guest-shortcuts.png", png(guest.crop((404, 1016, 824, 1068))))
    for event in meta["events"]:
        name = event["launch"]
        path = capture / (name + ("-after-esc.png" if name == "details" else "-f1.png"))
        y = event["text_y"]
        width = 10 * len(event["identified_by"])
        with Image.open(path) as screen:
            box = (20, y, 20 + width, y + 20)
            bundle.writestr(name + "-native-heading.png", png(screen.crop(box)))
with ZipFile(archive) as bundle:
    assert bundle.testzip() is None
print(archive.stat().st_size, sha256(archive.read_bytes()).hexdigest())

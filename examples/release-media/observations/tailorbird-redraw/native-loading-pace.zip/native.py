"""Compare the parent and candidate with exactly the same worker and keyboard sequence."""
import hashlib, json, re, shutil, subprocess, sys, time
from pathlib import Path
from PIL import Image
import numpy as np
root = Path(__file__).resolve().parent
audit = root.parent
sys.path.insert(0,str(audit/'pace41/guest/tests'))
from qemu_smoke import Qemu

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def expected(name, steps):
    refs=root/'refs'
    refs.mkdir(exist_ok=True)
    script=refs/(name+'.txt')
    script.write_text('\n'.join(['notes','folder taylor',*steps,'shot '+name])+'\n')
    renderer=audit/'pace41/target/debug/examples/talk_frames'
    subprocess.run([str(renderer),str(script),str(refs),'800','600'],check=True)
    return np.asarray(Image.open(refs/(name+'.ppm')).convert('RGB'))
empty=expected('empty',['loading 41943040 67108864'])
typed=expected('typed',['loading 41943040 67108864','type g'])
ready=expected('ready',['ready','type g'])
changed=np.any(empty!=typed,axis=2)
assert np.count_nonzero(changed)>12
which=sys.argv[1]
out=root/which
out.mkdir(exist_ok=False)
guest=root/(which.split('-')[0]+'.elf'); fixture=root/'fixture.elf'; kernel=audit/'postmerge-kernel.elf32'
for path,name in [(guest,'tailorbird.elf'),(fixture,'fixture.elf'),(kernel,'kernel.elf32')]:
    shutil.copyfile(path,out/name)
m=subprocess.check_output([sys.executable,str(audit/'pace41/pcp-os/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'),str(kernel)],text=True).strip()
cmd=f'image={m} auto=tailorbird.elf then=off desktop=800x600 propose_image={digest(guest)} worker_for={digest(guest)} worker_image={digest(fixture)}'
vm=Qemu(Path('kernel.elf32'),'tailorbird.elf,fixture.elf',out,'q35',cmd)
def wait_serial(text,limit=40):
    began=time.monotonic()
    while text not in vm.serial():
        if vm.proc.poll() is not None or time.monotonic()-began>limit: raise RuntimeError((text,vm.serial()[-2000:]))
        time.sleep(.02)
def frame():
    vm.qmp('screendump',filename=str(out/'sample.ppm'))
    return np.asarray(Image.open(out/'sample.ppm').convert('RGB'))
def until(predicate, label, limit):
    began=time.monotonic()
    while time.monotonic()-began<limit:
        picture=frame()
        if predicate(picture):
            Image.fromarray(picture).save(out/(label+'.png'))
            return time.monotonic()
        time.sleep(.035)
    raise RuntimeError('no matching capture: '+label)
try:
    wait_serial('Tailorbird first frame presented')
    wait_serial('fixture: tenth progress sent')
    before=frame()
    assert not np.array_equal(before[changed],typed[changed])
    start=time.monotonic()
    vm.qmp('send-key',keys=[{'type':'qcode','data':'g'}],**{'hold-time':60})
    echo=until(lambda p:np.array_equal(p[changed],typed[changed]),'typed-during-load',2.5)
    assert 'fixture: forty progress reports sent' not in vm.serial()
    wait_serial('fixture: forty progress reports sent')
    until(lambda p:np.array_equal(p,typed),'final-progress',2.5)
    wait_serial('test worker: said it is ready')
    until(lambda p:np.array_equal(p,ready),'ready',3)
    vm.key('esc')
    status=vm.proc.wait(timeout=10)
    serial=vm.serial()
    assert status==33 and 'ALL SELF-TESTS PASS' in serial
    end=next(l for l in serial.splitlines() if l.startswith('tailorbird.elf ended DONE:'))
    count=int(re.search(r'(\d+) frames shown',end).group(1))
    result={'guest_sha256':digest(guest),'worker_sha256':digest(fixture),'kernel_sha256':digest(kernel),'reports':40,'presentations':count,'echo_by_host_ms':round((echo-start)*1000,2),'typed_pixels_checked':int(changed.sum()),'exit':status,'summary':end}
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
finally:
    vm.stop()

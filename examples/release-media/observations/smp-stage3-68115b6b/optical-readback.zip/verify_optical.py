from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from PIL import Image
import hashlib,io,json,re,runpy
root=Path('optical'); upstream=runpy.run_path('reference/examples/tester-cd/check.py')
rows={}
for lane in ('original','candidate'):
 for n,ids in ((1,[0]),(2,[0,1]),(4,[0,1,2,3]),(8,list(range(8))),(6,[0,1,2,4,5,6])):
    folder=root/f'{lane}-{n}'
    r=json.loads((folder/'result.json').read_text());p=r['park']
    assert r['exit']==0 and r['shutdown']['guest'] and [v['apic_id'] for v in r['cpus']]==ids
    enabled=lane=='candidate'
    start=71 if not enabled else 73+int(n>1)
    assert (r['startup_passes'],r['final_passes'])==(start,start+1)
    assert not enabled or (p['idle_code_equals_elf'] and p['secondary_completions']==[1]*(n-1) and not p['pending'] and p['targets']==ids[1:] and p['shared_count']==(n*20000 if n>1 else 0))
    rows[folder.name]={k:r[k] for k in ['iso','kernel','source','startup_passes','final_passes','shutdown','exit','serial_sha256']}
    rows[folder.name].update(apic_ids=ids,count=p.get('shared_count'),completions=p.get('secondary_completions'),pending=p.get('pending'))
app=root/'queue-roundtrip';sr=(app/'serial.txt').read_text()
for name in ('queue-saved','queue-restored','queue-finished-restored'):
    upstream['check_desk_label']((app/(name+'.ppm')).read_bytes(),'notes')
assert sr.count('rdesk.elf ended DONE: exit 0')==3 and 'state=FINISHED store=Queue restored' in sr
assert '120000 of 120000' in sr and 'a second processor.' in sr.split('ALL SELF-TESTS PASS.')[-1]
receipt=json.loads((root/'candidate-receipt.json').read_text());assert sorted(receipt['changed_disc_entries'])==['kernel.elf32','limine.conf','readme.txt']
report={'pr':401,'head':'68115b6b89520fe44075794f625de96450453c4d','ci_run':45036172808,'ci_iso_artifact':14760091403,'ci_receipt_artifact':14758994388,'runs':rows,'extra_queue_run':{'state_restored_twice':True,'tasks_exited_done':3,'label':'notes','three_lossless_frames_label_matches_source_font':True,'register_events':56,'guest_shutdown':json.loads((app/'result.json').read_text())['shutdown']},'observed_terminal_claim':sr.splitlines()[-1],'measurement_limit':'All guests used QEMU 10.0.13 TCG and read-only optical media. The queue ran on the boot CPU.','observer_correction':'The first observer looked for the stage-2 loop in ap_main. The corrected observer uses the stage-3 ap_idle/ap_idle_end ELF symbols. Final candidate images also identify the feature and running measurement in readme.txt.'}
Path('outcomes.json').write_text(json.dumps(report,indent=2)+'\n')
archive=Path('stage3-optical-68115b6b.zip')
with ZipFile(archive,'w',ZIP_DEFLATED) as z:
 for name in ['outcomes.json','ap_readback.py','verify_optical.py','optical/comparison_media.py','optical/check_cd.py','optical/queue_work.py','optical/receipt-original.json','optical/candidate-receipt.json','optical/compiler.txt']:z.write(name,name)
 for folder in [*(root/name for name in rows),app]:
    for f in folder.iterdir():
        if f.name in ['result.json','serial.txt','work-count.bin','work-completions.bin','work-pending.bin','work-targets.bin','ap-idle.bin','per-ap-reports.bin','answered-count.bin'] or folder==app and re.fullmatch(r'cpu-\d+.txt',f.name):z.write(f,str(f.relative_to(root)))
 for name in ('queue-saved','queue-restored','queue-finished-restored'):
    with Image.open(app/(name+'.ppm')) as im:
        b=io.BytesIO();im.save(b,format='PNG');z.writestr('queue-roundtrip/'+name+'.png',b.getvalue())
print(archive.stat().st_size,hashlib.sha256(archive.read_bytes()).hexdigest(),receipt['iso_sha256'])

from pathlib import Path
import re, struct, subprocess, json
def capture_aps(rpc,out,kernel,serial,expected_started=True):
    syms=[]
    for line in subprocess.check_output(['nm','-S',str(kernel)],text=True).splitlines():
        m=re.match(r'^([0-9a-fA-F]+) ([0-9a-fA-F]+) \w (\S+)$',line)
        if m:syms.append((int(m[1],16),int(m[2],16),m[3]))
    def symbol(fn):
        found=[(a,n,k) for a,n,k in syms if fn(k)]
        assert len(found)==1,found
        return found[0]
    def phys(tag,addr,n):
        path=out/(tag+'.bin');rpc('pmemsave',val=addr,size=n,filename=str(path))
        data=path.read_bytes();assert len(data)==n
        return data
    def cap(m,pattern):return int(re.search(pattern,m,re.M)[1],16)
    samples=[]
    cpus=rpc('query-cpus-fast')
    for cpu in cpus:
        i=cpu['cpu-index'];qpath=cpu['qom-path']
        apic=rpc('qom-get',path=qpath,property='apic-id')
        regs=rpc('human-monitor-command',**{'command-line':'info registers','cpu-index':i})
        (out/f'cpu-{i}.txt').write_text(regs)
        sample={'index':i,'apic':apic,'ip':cap(regs,r'\b[RE]IP=([0-9a-f]+)'),'csbase':cap(regs,r'^CS\s*=\s*\w+\s+([0-9a-f]+)'),'sp':cap(regs,r'\b[RE]SP=([0-9a-f]+)'),'hlt':cap(regs,r'\bHLT=(\d)'),'cpl':cap(regs,r'\bCPL=(\d)'),'flags':cap(regs,r'\b[RE]FL=([0-9a-f]+)'),'cr3':cap(regs,r'\bCR3=([0-9a-f]+)'),'cr4':cap(regs,r'\bCR4=([0-9a-f]+)'),'cr0':cap(regs,r'\bCR0=([0-9a-f]+)'),'gdt':cap(regs,r'^GDT=\s*([0-9a-f]+)'),'idt':cap(regs,r'^IDT=\s*([0-9a-f]+)'),'longmode':bool(re.search(r'^CS .* CS64',regs,re.M))}
        samples.append(sample)
    slots=rpc('query-hotpluggable-cpus')
    result={'cpus':samples,'slot_count':len(slots),'populated_slots':sum('qom-path' in x for x in slots),'other_cpu_lines':[x for x in serial.splitlines() if x.startswith('other processors:')]}
    (out/'park-status.json').write_text(json.dumps(result,indent=2)+'\n')
    if not expected_started:
        assert not result['other_cpu_lines'] and all(not (s['cr0'] & (1<<31)) for s in samples[1:])
        return result
    a,n,name=symbol(lambda s:s.endswith('others4SAID'))
    data=phys('per-ap-reports',a,n);words=[v[0] for v in struct.iter_unpack('<Q',data)]
    a,n,name=symbol(lambda s:s.endswith('others8ANSWERED'))
    count=int.from_bytes(phys('answered-count',a,n),'little')
    labels={m[2]:int(m[1],16) for line in subprocess.check_output(['nm',str(kernel)],text=True).splitlines()
            if (m:=re.match(r'^([0-9a-fA-F]+) \w (ap_idle|ap_idle_end)$',line))}
    a=labels['ap_idle']; n=labels['ap_idle_end']-a
    code=phys('ap-idle',a,n)
    assert code==bytes.fromhex('fbf4ebfd')
    result.update(ap_idle_address=a,ap_idle_size=n,answered=count,said_words=words,said_apic_ids=[w&0xffffffff for w in words[:count]])
    aps=samples[1:]
    result['park_instruction_precedes_ip']=[(a<s['ip']<=a+n and code[s['ip']-a-1]==0xf4) for s in aps]
    (out/'park-status.json').write_text(json.dumps(result,indent=2)+'\n')
    assert all(result['park_instruction_precedes_ip'])
    for s in aps:
        assert s['hlt']==1 and s['cpl']==0 and s['longmode'] and s['flags']&0x200 and s['cr0']&(1<<31)
    assert sorted(result['said_apic_ids'])==sorted(s['apic'] for s in aps)
    assert count==len(aps) and all(w==0 for w in words[count:])
    assert len({s['sp'] for s in aps})==len(aps) and len({s['gdt'] for s in samples})==len(samples)
    assert len({s['cr3'] for s in aps})<=1 and len({s['idt'] for s in aps})<=1
    assert any(f'{count} of {count} started and parked' in x for x in result['other_cpu_lines']),result
    def words_at(suffix,fmt,label):
        start,length,_=symbol(lambda k:k.endswith(suffix))
        return [v[0] for v in struct.iter_unpack(fmt,phys(label,start,length))]
    done=words_at('others4DONE','<Q','work-completions')
    asked=words_at('others5ASKED','<Q','work-pending')
    apic_targets=words_at('others8IDENTITY','<I','work-targets')
    shared_count,=words_at('count_together5COUNT','<Q','work-count')
    assert done[:count]==[1]*count and not any(done[count:]) and not any(asked)
    assert apic_targets[:count]==result['said_apic_ids']
    expected=20000*(count+1) if count else 0
    assert shared_count==expected,(shared_count,expected)
    if count:
        assert any(f'{expected} of {expected}' in x for x in result['other_cpu_lines'])
    else:
        assert not any('added to one count' in x for x in result['other_cpu_lines'])
    for s in aps:
        off=s['ip']-a
        assert code[off-2:off+2]==bytes.fromhex('fbf4ebfd')
    elf=kernel.read_bytes()
    phoff=struct.unpack_from('<I',elf,28)[0]
    phsize,phnum=struct.unpack_from('<HH',elf,42)
    execseg,=[v for i in range(phnum) if (v:=struct.unpack_from('<8I',elf,phoff+i*phsize))[0]==1 and v[6]&1 and v[2]<=a and a+n<=v[2]+v[4]]
    start=execseg[1]+a-execseg[2]
    assert elf[start:start+n]==code
    result.update(shared_count=shared_count,secondary_completions=done[:count],pending=sum(bool(x) for x in asked),targets=apic_targets[:count],idle_code_equals_elf=True)

    return result

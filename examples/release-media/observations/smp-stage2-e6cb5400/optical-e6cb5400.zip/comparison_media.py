from pathlib import Path
import os,importlib.util,hashlib,zipfile,json,subprocess
mod=importlib.util.spec_from_file_location('builder','builder.py')
b=importlib.util.module_from_spec(mod);mod.loader.exec_module(b)
sha=lambda v:hashlib.sha256(v).hexdigest()
r=json.loads(Path('receipt-original.json').read_text())
arc=Path('tester.zip')
assert sha(arc.read_bytes())=='ab70d533ba71b6860c1897e2a6c3eeef6f97ee796b16bc90da8c3a5df190fa69'
with zipfile.ZipFile(arc) as z:original=z.read('pcp-os-tester.iso')
assert sha(original)==r['iso_sha256'] and len(original)==r['iso_bytes']
Path('original.iso').write_bytes(original)
files=b.read_back(original)
assert set(files)==set(r['on_disc'])
assert all(len(v)==r['on_disc'][k]['bytes'] and sha(v)==r['on_disc'][k]['sha256'] for k,v in files.items())
Path('original.elf32').write_bytes(files['kernel.elf32'])
files.pop('boot.cat');files['kernel.elf32']=Path('optical-processors.elf32').read_bytes()
digest=subprocess.check_output(['python','../reference/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py','optical-processors.elf32'],text=True).strip()
old=r['kernel_measurement'].encode()
assert files['limine.conf'].count(old)>=1
files['limine.conf']=files['limine.conf'].replace(old,digest.encode())
env=os.environ|{'SOURCE_DATE_EPOCH':str(b.EPOCH),'TZ':'UTC','LC_ALL':'C'}
root=Path('tree');root.mkdir()
for n,v in files.items():(root/n).write_bytes(v)
isos=[]
for n in ('candidate-1.iso','candidate-2.iso'):
 b.assemble(root.resolve(),Path(n).resolve(),env);isos.append(Path(n).read_bytes())
assert isos[0]==isos[1]
result=b.read_back(isos[0]);assert set(result)==set(r['on_disc'])
for n,v in files.items():
 assert result[n]==v if n!='limine-bios-cd.bin' else result[n][:8]+result[n][64:]==v[:8]+v[64:],n
orig=b.read_back(original)
changed=[n for n in orig if orig[n]!=result[n]]
rec={'source_commit':r['source_commit'],'ci_zip_artifact_id':14758569771,'ci_receipt_artifact_id':14758863292,'iso_sha256':sha(isos[0]),'original_iso_sha256':r['iso_sha256'],'original_compiler':r['rustc'],'source_image_bytes':len(original),'iso_bytes':len(isos[0]),'kernel_measurement':digest,'kernel_sha256':sha(files['kernel.elf32']),'original_kernel_measurement':r['kernel_measurement'],'changed_disc_entries':changed,'compiler':Path('compiler.txt').read_text(),'reproduced_candidate':True,'candidate_class':'Diagnostic remaster of CI queue-desk media with processors enabled','on_disc':{n:{'bytes':len(v),'sha256':sha(v)} for n,v in result.items()}}
Path('candidate-receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({k:v for k,v in rec.items() if k!='on_disc'}))

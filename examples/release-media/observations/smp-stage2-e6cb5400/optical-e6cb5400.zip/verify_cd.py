from pathlib import Path
import hashlib,json,struct,zipfile
from importlib import util
root=Path('.')
r=json.loads(Path('candidate-receipt.json').read_text())
assert set(r['changed_disc_entries'])<={'kernel.elf32','limine.conf','limine-bios-cd.bin','boot.cat'}
assert {'kernel.elf32','limine.conf'}<=set(r['changed_disc_entries'])
expected={1:[0],2:[0,1],4:[0,1,2,3],6:[0,1,2,4,5,6],8:list(range(8))}
summaries=[]
for n,ids in expected.items():
 for lane in ('original','candidate'):
    p=Path(f'{lane}-{n}')
    d=json.loads((p/'result.json').read_text());ap=d['park']
    assert d['exit']==0 and d['shutdown']['guest'] and [v['apic_id'] for v in d['cpus']]==ids
    if lane=='original':
        assert not ap['other_cpu_lines'] and d['startup_passes']==71 and d['final_passes']==72
        assert all(v['hlt'] and not(v['cr0'] & (1<<31)) for v in ap['cpus'][1:])
    else:
        raw=Path('optical-processors.elf32').read_bytes()
        start=struct.unpack_from('<I',raw,28)[0];step,num=struct.unpack_from('<HH',raw,42)
        addr=ap['ap_main_address'];size=ap['ap_main_size']
        seg,=[s for i in range(num) if (s:=struct.unpack_from('<8I',raw,start+step*i))[0]==1 and s[6]&1 and s[2]<=addr and addr+size<=s[2]+s[4]]
        code=raw[seg[1]+addr-seg[2]:seg[1]+addr-seg[2]+size]
        assert code==(p/'ap-main.bin').read_bytes()
        assert [v&0xffffffff for v in ap['said_words'][:ap['answered']]]==ids[1:] and ap['answered']==n-1
        for v in ap['cpus'][1:]:
            off=v['ip']-addr;assert code[off-2:off+2]==bytes.fromhex('faf4ebfc')
        assert d['startup_passes']==73 and d['final_passes']==74
    summaries.append({'lane':lane,'cpus':n,'ids':ids,'shutdown':d['shutdown'],'startup':d['startup_passes'],'final':d['final_passes'],'reported_secondaries':ap.get('said_apic_ids',[]),'sha256':d['iso']})
Path('outcomes.json').write_text(json.dumps(summaries,indent=2)+'\n')
with zipfile.ZipFile('optical-e6cb5400.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in ['outcomes.json','receipt-original.json','candidate-receipt.json','boots.log','comparison_media.py','check_cd.py','verify_cd.py']:z.write(f,f)
 z.write('../ap_readback.py','ap_readback.py')
 for lane in ('original','candidate'):
    for n in expected:
        p=Path(f'{lane}-{n}')
        for f in sorted(p.iterdir()):
            if f.name in {'result.json','serial.txt','ap-main.bin','per-ap-reports.bin','answered-count.bin'}:z.write(f,str(f))
out=Path('optical-e6cb5400.zip')
print(out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest(),r['changed_disc_entries'])

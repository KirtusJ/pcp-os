import importlib.util, json, os, re, subprocess, sys, time
from pathlib import Path
from ap_readback import capture_aps
qemu=os.environ['B3_ROOT']+'/hostbin/qemu-system-x86_64'
root=Path('evidence').resolve()
def read_registers(binary,smp,label,machine='q35',size='256M',expected=True):
    out=root/label;out.mkdir()
    serial=out/'serial.txt'
    binary=Path(binary).resolve()
    digest=subprocess.check_output(['python3','reference/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py',binary],text=True).strip()
    args=[qemu,'-machine',machine,'-cpu','max','-accel','tcg','-smp',str(smp),'-m',size,'-kernel',str(binary),'-append',f'image={digest} then=off','-no-reboot','-no-shutdown','-display','none','-monitor','none','-nic','none','-serial',f'file:{serial}','-qmp','stdio']
    (out/'args.json').write_text(json.dumps(args,indent=2)+'\n')
    with (out/'stderr.txt').open('w') as err,subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True) as p:
        try:
            def rpc(cmd,**a):
                p.stdin.write(json.dumps({'execute':cmd,'arguments':a})+'\n');p.stdin.flush()
                while line:=p.stdout.readline():
                    j=json.loads(line)
                    if 'return'in j:return j['return']
                    if 'error'in j:raise RuntimeError(j)
                raise RuntimeError('QMP closed')
            assert 'QMP' in json.loads(p.stdout.readline())
            rpc('qmp_capabilities')
            until=time.monotonic()+180
            while time.monotonic()<until:
                status=rpc('query-status')['status']
                if status=='shutdown':break
                time.sleep(.15)
            assert status=='shutdown',status
            log=serial.read_text(errors='replace')
            assert 'ALL SELF-TESTS PASS' in log and digest+' (measured; equal' in log
            result=capture_aps(rpc,out,binary,log,expected)
            cpus=result['cpus']
            if expected:
                for cpu in cpus[1:]:
                    assert all(cpu[k]==cpus[0][k] for k in ['cr0','cr3','cr4','idt'])
            result.update(measurement=digest,status=status,passes=sum(l.startswith('  pass ') for l in log.splitlines()))
            (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
            text=rpc('human-monitor-command',**{'command-line':'info registers -a'})
            return 'VM status: shutdown\n',text,result
        finally:
            if p.poll() is None:p.terminate()
            p.wait(timeout=10)
def main():
    # Use the upstream predicates, replacing only its Unix-socket monitor transport.
    source=Path('reference/examples/processors/check_started.py').read_text()
    start=source.index('    with tempfile.TemporaryDirectory() as folder:',source.index('def registers('))
    end=source.index('    found = []',start)
    bridge='    status, text, _ = read_registers(kernel, smp, "stock-registers-"+Path(kernel).stem, machine="pc", expected=Path(kernel).stem!="plain")\n'
    scope={'__name__':'upstream_checks','read_registers':read_registers}
    exec(compile(source[:start]+bridge+source[end:],'check_started_with_stdio.py','exec'),scope)
    args0=sys.argv[:]
    sys.argv=['check_started.py',*[str(root/(n+'.elf32')) for n in ('processors','plain','processors-extended-demo','processors-silent-demo')],'--qemu',qemu]
    try:scope['main']()
    finally:sys.argv=args0
if __name__=='__main__':
    if sys.argv[1:] and sys.argv[1]=='extras':
        for n,top,label in [('processors','1','single'),('processors','2,sockets=1,cores=2,threads=1,maxcpus=2','two'),('processors','8','eight'),('processors','2,sockets=2,cores=4,threads=1,maxcpus=8','empty-slots'),('processors-extended-demo','6,sockets=2,cores=3,threads=1','extended-sparse')]:
            _,_,r=read_registers(root/(n+'.elf32'),top,label)
            if label=='extended-sparse':assert 'in its extended mode' in ' '.join(r['other_cpu_lines'])
            if label=='empty-slots':assert (r['slot_count'],r['populated_slots'],r['answered'])==(8,2,1)
            print(label,r['answered'],r['said_apic_ids'],r['other_cpu_lines'],r['passes'],flush=True)
    else:main()

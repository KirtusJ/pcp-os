from pathlib import Path
import re, struct, subprocess, json
def capture_aps(rpc,out,kernel,serial,expected_started=True):
    syms=[]
    for line in subprocess.check_output(['nm','-S',str(kernel)],text=True).splitlines():
        m=re.match(r'^([0-9a-fA-F]+) ([0-9a-fA-F]+) \w (\S+)$',line)
        if m:syms.append((int(m[1],16),int(m[2],16),m[3]))
    def symbol(fn):
        found=[(a,n,k) for a,n,k in syms if fn(k)]
        assert len(found)==1,found
        return found[0]
    def phys(tag,addr,n):
        path=out/(tag+'.bin');rpc('pmemsave',val=addr,size=n,filename=str(path))
        data=path.read_bytes();assert len(data)==n
        return data
    def cap(m,pattern):return int(re.search(pattern,m,re.M)[1],16)
    samples=[]
    cpus=rpc('query-cpus-fast')
    for cpu in cpus:
        i=cpu['cpu-index'];qpath=cpu['qom-path']
        apic=rpc('qom-get',path=qpath,property='apic-id')
        regs=rpc('human-monitor-command',**{'command-line':'info registers','cpu-index':i})
        (out/f'cpu-{i}.txt').write_text(regs)
        sample={'index':i,'apic':apic,'ip':cap(regs,r'\b[RE]IP=([0-9a-f]+)'),'csbase':cap(regs,r'^CS\s*=\s*\w+\s+([0-9a-f]+)'),'sp':cap(regs,r'\b[RE]SP=([0-9a-f]+)'),'hlt':cap(regs,r'\bHLT=(\d)'),'cpl':cap(regs,r'\bCPL=(\d)'),'flags':cap(regs,r'\b[RE]FL=([0-9a-f]+)'),'cr3':cap(regs,r'\bCR3=([0-9a-f]+)'),'cr4':cap(regs,r'\bCR4=([0-9a-f]+)'),'cr0':cap(regs,r'\bCR0=([0-9a-f]+)'),'gdt':cap(regs,r'^GDT=\s*([0-9a-f]+)'),'idt':cap(regs,r'^IDT=\s*([0-9a-f]+)'),'longmode':bool(re.search(r'^CS .* CS64',regs,re.M))}
        samples.append(sample)
    slots=rpc('query-hotpluggable-cpus')
    result={'cpus':samples,'slot_count':len(slots),'populated_slots':sum('qom-path' in x for x in slots),'other_cpu_lines':[x for x in serial.splitlines() if x.startswith('other processors:')]}
    (out/'park-status.json').write_text(json.dumps(result,indent=2)+'\n')
    if not expected_started:
        assert not result['other_cpu_lines'] and all(not (s['cr0'] & (1<<31)) for s in samples[1:])
        return result
    a,n,name=symbol(lambda s:s.endswith('others4SAID'))
    data=phys('per-ap-reports',a,n);words=[v[0] for v in struct.iter_unpack('<Q',data)]
    a,n,name=symbol(lambda s:s.endswith('others8ANSWERED'))
    count=int.from_bytes(phys('answered-count',a,n),'little')
    a,n,_=symbol(lambda s:s=='ap_main')
    code=phys('ap-main',a,n)
    result.update(ap_main_address=a,ap_main_size=n,answered=count,said_words=words,said_apic_ids=[w&0xffffffff for w in words[:count]])
    aps=samples[1:]
    result['park_instruction_precedes_ip']=[(a<s['ip']<=a+n and code[s['ip']-a-1]==0xf4) for s in aps]
    (out/'park-status.json').write_text(json.dumps(result,indent=2)+'\n')
    assert all(result['park_instruction_precedes_ip'])
    for s in aps:
        assert s['hlt']==1 and s['cpl']==0 and s['longmode'] and not s['flags']&0x200 and s['cr0']&(1<<31)
    assert sorted(result['said_apic_ids'])==sorted(s['apic'] for s in aps)
    assert count==len(aps) and all(w==0 for w in words[count:])
    assert len({s['sp'] for s in aps})==len(aps) and len({s['gdt'] for s in samples})==len(samples)
    assert len({s['cr3'] for s in aps})<=1 and len({s['idt'] for s in aps})<=1
    assert any(f'{count} of {count} started and parked' in x for x in result['other_cpu_lines']),result
    return result

from pathlib import Path
import struct,json,hashlib
root=Path('evidence')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def file_bytes(elf,addr,count):
    raw=elf.read_bytes()
    assert raw[:5]==b'\x7fELF\x01'
    ofs=struct.unpack_from('<I',raw,28)[0];step,n=struct.unpack_from('<HH',raw,42)
    for i in range(n):
        kind,off,virt,phys,fs,ms,flags,align=struct.unpack_from('<8I',raw,ofs+i*step)
        if kind==1 and flags&1 and virt<=addr and addr+count<=virt+fs:
            return raw[off+addr-virt:off+addr-virt+count]
    raise ValueError('no matching executable file segment')
rows=[]
for label,elf in [('sparse-uefi','volume/PCPOS/KERNEL.ELF'),('stock-registers-processors','evidence/processors.elf32'),('single','evidence/processors.elf32'),('two','evidence/processors.elf32'),('eight','evidence/processors.elf32'),('empty-slots','evidence/processors.elf32'),('extended-sparse','evidence/processors-extended-demo.elf32')]:
    folder=root/label
    result=json.loads((folder/'result.json').read_text());ap=result.get('park',result)
    elf=Path(elf)
    code=file_bytes(elf,ap['ap_main_address'],ap['ap_main_size'])
    assert (folder/'ap-main.bin').read_bytes()==code
    sites=set()
    for cpu in ap['cpus'][1:]:
        s=cpu['ip']-ap['ap_main_address'];assert code[s-2:s]==b'\xfa\xf4'
        sites.add((cpu['ip'],code[s-2:s+2].hex()))
    raw=[w[0] for w in struct.iter_unpack('<Q',(folder/'per-ap-reports.bin').read_bytes())]
    n=int.from_bytes((folder/'answered-count.bin').read_bytes(),'little')
    ids=[v&0xffffffff for v in raw[:n]]
    assert len(ids)==len(set(ids))==len(ap['cpus'])-1 and sorted(ids)==sorted(c['apic'] for c in ap['cpus'][1:]) and not any(raw[n:])
    rows.append({'boot':label,'kernel_file_sha256':sha(elf),'complete_ap_main_equals_elf':True,'ap_main_sha256':hashlib.sha256(code).hexdigest(),'recorded_ap_ids':ids,'instruction_sites':[{'resume_ip':hex(ip),'bytes':b} for ip,b in sorted(sites)],'configured_slots':ap['slot_count'],'populated':ap['populated_slots'],'checks':result.get('pass_lines',result.get('passes')),'kernel_report':ap['other_cpu_lines']})
info={'kernel':'e6cb540076121aa75dec124f85fd1c59ec6ee9ff','efi_loader':'7aa76bc1942abc9a0494cab9271c6d4fd7501749','qemu':'10.0.13 TCG','mask':'All snapshots read from each private QEMU guest, offline','upstream_checker_transport':'QMP stdio for the two monitor reads; upstream cases and predicates preserved','matrix_exit':(root/'matrix-exits.txt').read_text().strip(),'rows':rows,'stock_images':{p.name:sha(p) for p in sorted(root.glob('*.elf32'))}}
assert info['matrix_exit']=='0 0'
(root/'identity.json').write_text(json.dumps(info,indent=2)+'\n')
print([(r['boot'],r['recorded_ap_ids'],r['instruction_sites']) for r in rows])

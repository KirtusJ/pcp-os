# OVMF Secure Boot comparison for the model-free PCP OS preview

This record covers the retained 70,410,240-byte ISO from kernel `355e5c13` and Tailorbird `f1613bed`. All four candidate boots used that same read-only medium, the same secure-capable firmware binary and 512 MiB. Each used a fresh writable copy of its Debian variable template. No PCI network controller or internal disk was attached.

| Variable template | Optical | Emulated USB |
| --- | --- | --- |
| Stock enrolled Microsoft trust database | Firmware reported Access Denied for the selected optical device | Firmware reported Access Denied for the selected USB device |
| Stock empty template | Desktop, 72 passing checks, confirmed shutdown | Desktop, 72 passing checks, confirmed shutdown |

A separate USB control booted the stock Microsoft-signed Debian shim with the same enrolled template and firmware code. OVMF started that executable. Shim then reported the missing `grubx64.efi` second stage on its purpose-built control volume. The stock vendor package and EFI hashes are in `vendor-control/result.json`. The package came from Debian’s pool, linked in `summary.json`.

The firmware profiles are recorded in the two distributor descriptors. The serial logs contain the device-specific messages. Each PNG is a lossless capture of the VM’s display. The screenshot in an empty-template boot was taken at the desktop before F10 and Enter. The serial records include the subsequent confirmed shutdown. The target hardware was never involved.

## Repeating the private VM tests

Install QEMU with x86-64 Q35/OVMF support, mtools, dosfstools and Python 3.11 or later. Place the reviewed ISO at `model-free.iso`. Supply the directory containing Debian's OVMF files. From a new directory, run each of the four combinations using `python3 compare.py model-free.iso /usr/share/OVMF optical enrolled optical-enrolled`, replacing the transport and template with the corresponding values `optical` or `usb`, and `enrolled` or `empty`. Use a separate output directory per run.

The independent stock-loader control uses a fresh, disposable regular file named `vendor-control/signed-control.fat`. Place the exact package linked in `summary.json` at `vendor-control/shim.deb` and verify the stated digest before extraction. Create its FAT and run the check as follows.

```sh
cd vendor-control
dpkg-deb -x shim.deb files
truncate -s 16M signed-control.fat
mkfs.fat -F 16 -i 1248CEAD -n VENDORCTRL signed-control.fat
mmd -i signed-control.fat ::/EFI ::/EFI/BOOT
mcopy -i signed-control.fat files/usr/lib/shim/shimx64.efi.signed ::/EFI/BOOT/BOOTX64.EFI
cd ..
python3 vendor_control.py vendor-control /usr/share/OVMF
```

The FAT volume’s timestamps can vary on reassembly. The harness requires an exact package digest and extracted EFI bytes. The PCP OS ISO, firmware, private variable stores and vendor package are excluded from this evidence archive.

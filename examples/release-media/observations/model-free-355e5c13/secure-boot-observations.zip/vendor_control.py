"""Boot the unchanged stock Debian shim on a separate USB control with enrolled firmware."""
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys
import time
from pathlib import Path

work = Path(sys.argv[1]).resolve()
firmware = Path(sys.argv[2]).resolve()
media = work / 'signed-control.fat'
code = firmware / 'OVMF_CODE_4M.secboot.fd'
template = firmware / 'OVMF_VARS_4M.ms.fd'
vars_file = work / 'variables.fd'
serial = work / 'serial.txt'
shim_file = work / 'files/usr/lib/shim/shimx64.efi.signed'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
shim = shim_file.read_bytes()
assert sha(work/'shim.deb') == '3c802fa303c0e6bf126adee74028d1042e3120360d159c2c05181dc9b2f61005'
assert sha(shim_file) == 'e103c5d02657879f141b086ed703584d28bb9e2721b423333be085ee1b4d397b'
assert subprocess.check_output(['mcopy','-i',str(media),'::/EFI/BOOT/BOOTX64.EFI','-']) == shim
pe = struct.unpack_from('<I', shim, 0x3c)[0]
assert shim[pe:pe+4] == b'PE\0\0' and struct.unpack_from('<H',shim,pe+24)[0] == 0x20b
cert, size = struct.unpack_from('<II', shim, pe+24+112+4*8)
assert 0 < cert < cert+size <= len(shim)
shutil.copyfile(template, vars_file)
cmd = ['qemu-system-x86_64','-machine','q35,smm=on','-accel','tcg','-cpu','max','-m','512M',
       '-global','driver=cfi.pflash01,property=secure,value=on',
       '-drive','if=pflash,format=raw,readonly=on,file='+str(code),
       '-drive','if=pflash,format=raw,file='+str(vars_file),
       '-display','none','-vga','std','-nic','none','-audiodev','none,id=snd0',
       '-device','AC97,audiodev=snd0','-no-reboot','-serial','file:'+str(serial),'-qmp','stdio',
       '-device','isa-debug-exit,iobase=0xf4,iosize=0x04','-device','qemu-xhci,id=xhci',
       '-drive','if=none,format=raw,readonly=on,file='+str(media)+',id=stick',
       '-device','usb-storage,bus=xhci.0,drive=stick,bootindex=1']
with (work/'stderr.txt').open('w') as err:
    vm = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err, text=True)
    def qmp(name, **kwargs):
        vm.stdin.write(json.dumps({'execute':name,'arguments':kwargs})+'\n')
        vm.stdin.flush()
        while True:
            line = vm.stdout.readline()
            if not line:
                raise RuntimeError('QEMU exited')
            res = json.loads(line)
            if 'error' in res:
                raise RuntimeError(res['error'])
            if 'return' in res:
                return res['return']
    try:
        version = json.loads(vm.stdout.readline())['QMP']['version']
        qmp('qmp_capabilities')
        deadline = time.monotonic()+18
        while time.monotonic()<deadline:
            log = serial.read_text(errors='replace') if serial.exists() else ''
            if 'BdsDxe: starting Boot' in log and ('Not Found' in log or 'not found' in log):
                break
            if 'Access Denied' in log or vm.poll() is not None:
                break
            time.sleep(.1)
        qmp('screendump',filename=str(work/'screen.ppm'))
        qmp('quit')
        status = vm.wait(timeout=10)
        log = serial.read_text(errors='replace')
        assert 'BdsDxe: starting Boot' in log and 'USB HARDDRIVE' in log, log
        assert 'grubx64.efi' in log.lower() or 'not found' in log.lower(), log
        result = dict(qemu=version, firmware_sha256=sha(code), template_sha256=sha(template),
                      media_sha256=sha(media), shim_sha256=sha(shim_file), deb_sha256=sha(work/'shim.deb'),
                      package_version='1.51~1+deb13u1+16.1-2~deb13u1', certificate_table=[cert,size],
                      firmware_started_efi=True, guest_contains_second_stage=False, qmp_exit=status)
        (work/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(result))
    finally:
        if vm.poll() is None: vm.kill()
        vm.wait()

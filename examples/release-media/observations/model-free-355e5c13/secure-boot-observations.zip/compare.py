"""Compare the same model-free medium with Debian's two stock Secure Boot variable templates."""
import argparse
import hashlib
import json
import re
import shutil
import subprocess
import time
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('medium', type=Path)
parser.add_argument('firmware', type=Path)
parser.add_argument('mode', choices=['optical', 'usb'])
parser.add_argument('profile', choices=['enrolled', 'empty'])
parser.add_argument('dest', type=Path)
parser.add_argument('--qemu', default='qemu-system-x86_64')
args = parser.parse_args()
medium = args.medium.resolve()
out = args.dest.resolve()
out.mkdir(parents=True, exist_ok=False)

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

iso_digest = 'c95a4f99c966a863ae044e6abeaccbd271d36aadff29c527d460f31e289ab3ac'
assert medium.stat().st_size == 70410240 and digest(medium) == iso_digest
code = (args.firmware / 'OVMF_CODE_4M.secboot.fd').resolve()
template = args.firmware / ('OVMF_VARS_4M.ms.fd' if args.profile == 'enrolled' else 'OVMF_VARS_4M.fd')
vars_file = out / 'variables.fd'
shutil.copyfile(template, vars_file)
serial = out / 'serial.txt'
cmd = [args.qemu, '-machine', 'q35,smm=on', '-accel', 'tcg', '-cpu', 'max',
       '-m', '512M', '-global', 'driver=cfi.pflash01,property=secure,value=on',
       '-drive', 'if=pflash,format=raw,readonly=on,file='+str(code),
       '-drive', 'if=pflash,format=raw,file='+str(vars_file),
       '-display', 'none', '-vga', 'std', '-nic', 'none',
       '-audiodev', 'none,id=snd0', '-device', 'AC97,audiodev=snd0',
       '-no-reboot', '-serial', 'file:'+str(serial), '-qmp', 'stdio',
       '-device', 'isa-debug-exit,iobase=0xf4,iosize=0x04']
if args.mode == 'optical':
    cmd += ['-drive', 'file='+str(medium)+',format=raw,media=cdrom,readonly=on', '-boot', 'd']
else:
    cmd += ['-device', 'qemu-xhci,id=xhci', '-drive', 'if=none,format=raw,readonly=on,file='+str(medium)+',id=stick',
            '-device', 'usb-storage,bus=xhci.0,drive=stick,bootindex=1']

def read_serial():
    return serial.read_text(errors='replace') if serial.exists() else ''

def rpc(name, **params):
    vm.stdin.write(json.dumps({'execute':name, 'arguments':params})+'\n')
    vm.stdin.flush()
    while True:
        line = vm.stdout.readline()
        if not line:
            raise RuntimeError('QEMU exited during '+name)
        answer = json.loads(line)
        if 'return' in answer:
            return answer['return']
        if 'error' in answer:
            raise RuntimeError(answer['error'])

def key(name):
    rpc('send-key', keys=[{'type':'qcode', 'data':name}], **{'hold-time':70})

def pci_classes(devices):
    for device in devices:
        yield device['class_info']['class']
        yield from pci_classes(device.get('pci_bridge', {}).get('devices', []))

with (out/'stderr.txt').open('w') as stderr:
    vm = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr, text=True)
    try:
        greeting = json.loads(vm.stdout.readline())
        rpc('qmp_capabilities')
        media = [entry['inserted'] for entry in rpc('query-block') if 'inserted' in entry]
        classes = [c for bus in rpc('query-pci') for c in pci_classes(bus['devices'])]
        assert all(c >> 8 != 2 for c in classes)
        assert len(media) == 3 and sum(d['file'] == str(medium) and d['ro'] for d in media) == 1
        record = dict(mode=args.mode, profile=args.profile, qemu=greeting['QMP']['version'],
                      acceleration='TCG', machine='q35,smm=on', guest_ram_mib=512, pci_classes=classes,
                      media_sha256=iso_digest, media_bytes=medium.stat().st_size,
                      code_name=code.name, code_sha256=digest(code),
                      template=template.name, template_sha256=digest(template),
                      devices=[{'filename':Path(d['file']).name, 'read_only':d['ro']} for d in media])
        deadline = time.monotonic()+45
        refusal = None
        while time.monotonic() < deadline:
            log = read_serial()
            refusal = re.search(r'BdsDxe: failed to (?:load|start) Boot[^\r\n]*?(?:Security Violation|Access Denied)', log, re.I)
            if refusal or 'desktop: ' in log:
                break
            if vm.poll() is not None:
                raise RuntimeError('premature exit '+str(vm.returncode))
            time.sleep(.1)
        record['firmware_refusal'] = refusal.group() if refusal else None
        record['desktop'] = 'desktop: ' in log
        rpc('screendump', filename=str(out/'screen.ppm'))
        if args.profile == 'enrolled':
            assert refusal and not record['desktop'] and 'PCP OS kernel' not in log, log[-1400:]
            label = 'DVD-ROM' if args.mode == 'optical' else 'USB HARDDRIVE'
            assert label in refusal.group(), refusal.group()
            rpc('quit')
        else:
            assert record['desktop'] and 'PCP OS kernel' in log and not refusal, log[-1400:]
            time.sleep(.35)
            key('f10')
            time.sleep(.6)
            key('ret')
        record['exit_code'] = vm.wait(timeout=12)
        log = read_serial()
        record['passed_kernel_checks'] = len(re.findall(r'^  pass ', log, re.M))
        record['completed_self_tests'] = 'ALL SELF-TESTS PASS' in log
        if args.profile == 'empty':
            assert record['exit_code'] == 33 and record['completed_self_tests'] and record['passed_kernel_checks'] == 72
        else:
            assert record['exit_code'] == 0 and not record['completed_self_tests']
        (out/'result.json').write_text(json.dumps(record, indent=2)+'\n')
        print(json.dumps(record))
    finally:
        if vm.poll() is None:
            vm.kill()
        vm.wait()

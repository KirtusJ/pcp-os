"""Compare emulator output against the picture sequence and PCM track extracted from the selected ISO."""
import argparse
import hashlib
import json
from pathlib import Path
import wave

import numpy as np
from PIL import Image
from scipy.signal import correlate, correlation_lags

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def stereo(path):
    with wave.open(str(path)) as source:
        assert (source.getsampwidth(), source.getframerate(), source.getnchannels()) == (2, 48000, 2)
        return np.frombuffer(source.readframes(source.getnframes()),'<i2').reshape(-1,2)

def inspect(assets, captured):
    header=b'P6\n48 24\n255\n'
    stride=len(header)+48*24*3
    data=(assets/'CLIP.PPM').read_bytes()
    assert len(data)==32*stride
    frames=[]
    for index in range(32):
        offset=index*stride
        assert data[offset:offset+len(header)]==header
        frames.append(np.frombuffer(data[offset+len(header):offset+stride],dtype=np.uint8).reshape(24,48,3))
    pictures=[]
    for requested in (2,16,28):
        path=captured/f'video-{requested}.ppm'
        with Image.open(path) as image:
            assert image.size==(640,360)
            pixels=np.asarray(image)[36:324,32:608,:]
        matches=[i for i,f in enumerate(frames) if np.array_equal(pixels, f.repeat(12,axis=0).repeat(12,axis=1))]
        assert matches==[requested],(requested,matches)
        pictures.append({'frame':requested,'screendump_sha256':sha(path),'matching_pixel_count':576*288})
    expected=stereo(assets/'CLIP.WAV')
    recorded=stereo(captured/'playback.wav')
    assert len(expected)==153600 and 0<len(recorded)<=len(expected)
    trailing=len(expected)-len(recorded)
    assert not np.any(expected[len(recorded):])
    channels=[]
    for channel in range(2):
        ref=expected[:,channel].astype(float)
        actual=recorded[:,channel].astype(float)
        corr=correlate(actual,ref,method='fft')
        lag=int(correlation_lags(len(actual),len(ref))[np.argmax(corr)])
        assert lag==0
        ref=ref[:len(actual)]
        gain=float(actual@ref/(ref@ref))
        residual=actual-gain*ref
        correlation=float(np.corrcoef(actual,ref)[0,1])
        assert correlation>.99999 and np.sqrt(np.mean(residual**2))<1
        nonzero=np.flatnonzero(actual)
        assert np.array_equal(nonzero,np.flatnonzero(ref))
        channels.append({'channel':channel,'alignment_samples':lag,'gain':gain,'correlation':correlation,'residual_rms_pcm_units':float(np.sqrt(np.mean(residual**2))),'first_nonzero_sample':int(nonzero[0]),'last_nonzero_sample':int(nonzero[-1])})
    return {'pictures':pictures,'reference_frames':len(expected),'captured_stereo_frames':len(recorded),'trailing_silent_frames_omitted':trailing,'pcm_rate':48000,'reference_wave_sha256':sha(assets/'CLIP.WAV'),'recorded_wave_sha256':sha(captured/'playback.wav'),'stereo_channels':channels}
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('assets',type=Path)
    ap.add_argument('captures',type=Path)
    args=ap.parse_args()
    print(json.dumps(inspect(args.assets,args.captures),indent=2))

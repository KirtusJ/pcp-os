"""Read each framebuffer cell by exact equality with an independently rendered glyph."""
import ast
import json
from pathlib import Path

import numpy as np
from PIL import Image

directory = Path(__file__).resolve().parent
source = directory/'font.rs'
table = source.read_text().split('= [', 1)[1].split('];', 1)[0]
glyph = np.asarray(ast.literal_eval('[' + table + ']'), dtype=np.int32).reshape(95, 20, 10, 1)
ink = np.array([242, 247, 252], dtype=np.int32)

def read_row(im, x, y, count):
    paper = im[y:y+20, x-1:x]
    render = (paper * (255-glyph) + ink * glyph + 127) // 255
    result = []
    for i in range(count):
        actual = im[y:y+20,x+10*i:x+10*i+10]
        hits = np.flatnonzero(np.all(actual == render, axis=(1,2,3)))
        if len(hits) != 1:
            raise ValueError((i, x, y, [int(c) for c in hits]))
        result.append(chr(32 + hits[0]))
    return ''.join(result).rstrip()

results = {}
for mode, path in [('before',directory/'before.png'),('cd',directory/'cd/programs.png'),('raw',directory/'raw/programs.png')]:
    im = np.asarray(Image.open(path).convert('RGB'), dtype=np.int32)
    x = im.shape[1]//200*10 + 40
    labels = [read_row(im,x,y,12) for y in [180,300]]
    assert labels == (['tailorbird','surf.elf'] if mode == 'before' else ['Tailorbird','Surfbird']), (mode,labels)
    results[mode] = labels
print(json.dumps(results))
(directory/'labels.json').write_text(json.dumps(results,indent=2)+'\n')

set -eu
. ../env.sh
export PATH="/workspace/scratch/4f027d3a3d6d/run/media-bin:$PATH"
python comparison_media.py
for lane in ci-1 ci-6 local-1 local-6; do
 count=6; topology=6,sockets=2,cores=3,threads=1
 case $lane in *-1) count=1; topology=1,sockets=1,cores=1,threads=1;; esac
 iso=original.iso; receipt=receipt-original.json; binary=original.elf32; extra=''
 case $lane in local-*) iso=candidate-1.iso; receipt=candidate-receipt.json; binary=optical-processors.elf32; extra=--processors;; esac
 python -I check_cd.py --iso "$iso" --receipt "$receipt" --kernel "$binary" $extra --qemu "$B3_ROOT/hostbin/qemu-system-x86_64" --output "$lane" --count "$count" --topology "$topology"
done

"""Verify that the reader rejects a changed glyph or colour, then preserve native observations."""
import json
from zipfile import ZipFile, ZIP_DEFLATED
from PIL import Image
import numpy as np
import pixels

receipts = []
for geom in ("1920x1080","640x480","320x200"):
    for mode in ("hpet","pit"):
        directory = pixels.work / (mode+"-"+geom)
        summary = json.loads((directory/"result.json").read_bytes())
        assert summary["passed"] == 71 and summary["exit"] == 33
        sentence = summary["text"]
        foreground = summary["colour"]
        with Image.open(directory/"details.png") as frame:
            clean = frame.convert("RGB")
        def accepts(im):
            result = pixels.match(sentence,pixels.read_rows(im))
            return result is not None and result[0] == [foreground]
        assert accepts(clean)
        x,y,_,_ = summary["boxes"][0]
        patch = (x,y,x+10,y+20)
        erased = clean.copy()
        erased.paste(tuple(pixels.ground),patch)
        assert not accepts(erased)
        changed = clean.copy()
        mask = pixels.a[ord(sentence[0])-32]
        other = pixels.inks["soft" if foreground=="amber" else "amber"]
        glyph = ((pixels.ground*(255-mask)+np.array(other)*mask+127)//255).astype(np.uint8)
        changed.paste(Image.fromarray(glyph),patch)
        rival = pixels.match(sentence,pixels.read_rows(changed))
        assert rival is not None and rival[0] == ["amber","soft"] and not accepts(changed)
        receipts.append({"case":directory.name,"original":True,"erased_glyph_rejected":True,"same_glyph_in_other_colour_rejected":True,"coordinates":patch})
with ZipFile(pixels.here/"details-clock-evidence.zip","w",ZIP_DEFLATED,compresslevel=9) as bundle:
    bundle.writestr("negative-controls.json",json.dumps(receipts,indent=2)+"\n")
    for name in ("README.md","pixels.py","check-and-pack.py","build.log"):
        bundle.write(pixels.here/name,name)
    for receipt in receipts:
        tag = receipt["case"]
        folder = pixels.work/tag
        for f in [folder/"result.json",folder/"serial.log",*sorted(folder.glob("clock-*.png"))]:
            bundle.write(f,tag+"/"+f.name)
with ZipFile(pixels.here/"details-clock-evidence.zip") as bundle:
    assert bundle.testzip() is None
print(len(receipts), "clean observations and 12 negative controls")

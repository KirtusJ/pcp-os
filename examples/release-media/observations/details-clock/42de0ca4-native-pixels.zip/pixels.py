"""Read Details from native QEMU framebuffers and compare every clock glyph and its colour."""
import ast
from hashlib import sha256
import json
from pathlib import Path
import re
import runpy
import subprocess
import sys
import time

import numpy as np
from PIL import Image

here = Path(__file__).resolve().parent
work = Path((here / "active-work").read_text().strip())
Monitor = runpy.run_path(str(here.parents[1] / "model-free-current/docs/examples/optical-disk-check/check.py"))["Monitor"]
kernel_dir = work / "src/PCP_OS_Rust/crates/pcpos-kernel"
kernel = kernel_dir / "target/pcpos-kernel.elf32"
kernel_hash = sha256(kernel.read_bytes()).hexdigest()
font_text = (kernel_dir / "src/font.rs").read_text()
a = np.array(ast.literal_eval("[" + font_text.split(" = [",1)[1].split("];",1)[0] + "]"), dtype=np.int32).reshape(95,20,10,1)
ground = np.array([16,40,63])
inks = {"soft":[159,180,200], "amber":[227,162,75]}
lookup = {}
for tag, ink in inks.items():
    pixels = ((ground*(255-a) + np.array(ink)*a+127)//255).astype(np.uint8)
    for i, cell in enumerate(pixels):
        lookup[cell.tobytes()] = (chr(i+32), tag if i else "ground")
phrases = {"hpet":"elapsed clock: 64-bit ACPI HPET main counter","pit":"elapsed clock: delivered PIT interrupts (elapsed time can be lost under load)"}
def read_rows(im):
    raw = np.asarray(im)
    rows = []
    for y in range(0, im.height - 19, 20):
        row = [lookup.get(raw[y:y+20,x:x+10].tobytes(),("?",None)) for x in range(0,im.width-9,10)]
        rows.append(("".join(c for c,_ in row).rstrip(), row))
    return rows
def match(phrase, rows):
    for start, (line,_) in enumerate(rows):
        if not line.lstrip().startswith("elapsed clock:"):
            continue
        parts = []
        colours = []
        boxes = []
        for n in range(start, min(len(rows), start+5)):
            line, cells = rows[n]
            if not line.strip():
                break
            stripped = line.strip()
            parts.append(stripped)
            x = len(line) - len(line.lstrip())
            colours.extend(tag for c,tag in cells[x:x+len(stripped)] if c!=" ")
            boxes.append((10*x, 20*n, 10*(x+len(stripped)),20*n+20))
            value = " ".join(parts)
            if value == phrase:
                return sorted(set(colours)), boxes, parts
            if not phrase.startswith(value+" "):
                break
    return None
def verify(clock, geom):
    expected_colour = "soft" if clock=="hpet" else "amber"
    width,height = map(int,geom.split("x"))
    dest = work / (clock+"-"+geom)
    dest.mkdir()
    serial = dest / "serial.log"
    machine = "q35" if clock=="hpet" else "q35,hpet=off"
    args = ["qemu-system-x86_64","-machine",machine,"-accel","tcg","-cpu","max","-smp","1","-m","256M","-kernel",str(kernel),"-append",f"desktop={geom} ui_scale=1","-vga","std","-display","none","-nic","none","-serial","file:"+str(serial),"-no-reboot","-qmp","stdio","-device","isa-debug-exit,iobase=0xf4,iosize=0x04"]
    with (dest/"stderr.log").open("w") as stderr, subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr) as vm:
        try:
            mon=Monitor(vm)
            mon.call("qmp_capabilities")
            deadline=time.monotonic()+45
            while time.monotonic()<deadline and vm.poll() is None:
                if serial.exists() and f"desktop: {geom} at 1x UI scale" in serial.read_text(errors="replace"):
                    break
                time.sleep(.1)
            log=serial.read_text(errors="replace")
            assert f"desktop: {geom} at 1x UI scale" in log, log[-900:]
            assert [s for s in log.splitlines() if s.startswith("elapsed clock: ")] == [phrases[clock]]
            def key(*args):
                mon.key(*args)
                time.sleep(.32)
            time.sleep(.4)
            key("spc")
            key("ctrl","d")
            previous=None
            for down in range(20):
                ppm=dest/"screen.ppm"
                mon.call("screendump",filename=str(ppm))
                with Image.open(ppm) as frame:
                    im=frame.convert("RGB")
                assert im.size == (width,height)
                rows=read_rows(im)
                result=match(phrases[clock],rows)
                if result:
                    colours,boxes,parts=result
                    assert colours==[expected_colour], colours
                    im.save(dest/"details.png")
                    for i,box in enumerate(boxes):
                        im.crop(box).save(dest/f"clock-{i}.png")
                    break
                if previous == [line for line,_ in rows]:
                    raise AssertionError([line for line,_ in rows])
                previous=[line for line,_ in rows]
                key("down")
            else:
                raise AssertionError("Clock sentence never fully visible")
            key("esc");key("esc");key("f10");key("ret")
            code=vm.wait(timeout=10)
            log=serial.read_text(errors="replace")
            assert code==33 and "ALL SELF-TESTS PASS" in log
            data={"source":"42de0ca4b206dcba972e0687f10d5e95f236d054","elf_sha256":kernel_hash,"machine":machine,"geometry":geom,"nav":["Space","Ctrl+D"],"down_presses":down,"text":phrases[clock],"colour":expected_colour,"foreground_rgb":inks[expected_colour],"boxes":boxes,"parts":parts,"screen_rgb_sha256":sha256(im.tobytes()).hexdigest(),"exit":code,"passed":sum(x.lstrip().startswith("pass ") for x in log.splitlines())}
            (dest/"result.json").write_text(json.dumps(data,indent=2)+"\n")
            print(json.dumps(data),flush=True)
        finally:
            if vm.poll() is None: vm.kill()
            vm.wait()
if __name__=="__main__":
    for s in ("1920x1080","640x480"):
        for mode in ("hpet","pit"):
            verify(mode,s)

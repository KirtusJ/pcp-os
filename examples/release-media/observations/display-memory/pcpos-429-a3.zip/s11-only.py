from pathlib import Path
import runpy
import json
import re

driver=runpy.run_path('wc-test/check_started.py')
kernel=Path('wc-review/PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32')
r=driver['boot']('qemu-system-x86_64',kernel,'pc','256M','4',cpu='max,mtrr=off,pat=on')
assert r['status']==33 and r['passes']==75 and not r['fails'] and not r['given'],r
assert len(r['table'])==1 and r['table'][0].startswith('other processors: 3 came up with another page-attribute table')
assert len(r['count'])==1 and r['count'][0].endswith('80000 of 80000')
Path('wc-test/s11.log').write_text('\n'.join(r.pop('lines'))+'\n')
Path('wc-test/s11.json').write_text(json.dumps(r,indent=2)+'\n')
print(r['status'],r['passes'],r['table'])

"""Boot the unchanged kernel with an explicit set of x86 memory-type features."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
tag, cpu, machine, count, *firmware = sys.argv[1:]
if len(firmware)>1:
    raise SystemExit("supply at most one firmware path")
out = Path('wc-test')
image = Path('wc-review/PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32')
cmd = ['qemu-system-x86_64','-machine',machine,'-accel','tcg','-cpu',cpu,'-smp',count,'-m','192M',
       '-vga','std','-display','none','-nic','none','-monitor','none','-serial','stdio','-no-reboot',
       '-kernel',str(image),'-append','then=off','-device','isa-debug-exit,iobase=0xf4,iosize=0x04']
if firmware:
    cmd += ["-bios", firmware[0]]
p = subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=70)
(out / (tag+'.log')).write_bytes(p.stdout)
(out / (tag+'.stderr')).write_bytes(p.stderr)
lines=p.stdout.decode(errors='replace').splitlines()
signal = [s for s in lines if s.startswith(('other processors:', 'display:', 'display memory:','ALL SELF-TESTS','FAIL','  FAIL'))]
rec={'args':cmd,'kernel_sha256':hashlib.sha256(image.read_bytes()).hexdigest(),'exit':p.returncode,
     'pass_count':sum(s.lstrip().startswith('pass ') for s in lines),'selected_lines':signal}
if firmware:
    rec['firmware_sha256'] = hashlib.sha256(Path(firmware[0]).read_bytes()).hexdigest()
(out/(tag+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
print(tag,p.returncode,rec['pass_count'],*signal,sep='\n')
if p.returncode!=33 or not any(s.startswith('ALL SELF-TESTS PASS') for s in signal):sys.exit(1)

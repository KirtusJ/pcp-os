.section .text
.global _start
_start:
    stmxcsr -4(%rsp)
    mov -4(%rsp), %edi
    xor $0x1f80, %edi
    xor %eax, %eax
    int $0x80
.section .note.GNU-stack,"",@progbits
.section .rodata
.byte 0
.section .data
.byte 0

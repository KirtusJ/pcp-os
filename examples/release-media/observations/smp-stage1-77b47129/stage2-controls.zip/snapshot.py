"""Capture the pre-SMP QEMU processor state after the measured kernel's startup checks."""
from pathlib import Path
import json, os, re, subprocess, struct, sys, time
out=Path(sys.argv[1]).resolve()
out.mkdir()
topology=sys.argv[2]
src=Path("kernel-stock/PCP_OS_Rust/crates/pcpos-kernel")
kernel=src/"target/pcpos-kernel.elf32"
measure=subprocess.check_output(["python3",src/"tools/measure.py",kernel],text=True).strip()
def require(x,msg):
    if not x:raise RuntimeError(msg)
elf=kernel.read_bytes()
phoff=struct.unpack_from("<I",elf,28)[0]
entsize,n=struct.unpack_from("<HH",elf,42)
segments=[]
for offset in range(phoff,phoff+n*entsize,entsize):
    kind,_,vaddr,paddr,_,size,flags,_=struct.unpack_from("<8I",elf,offset)
    if kind==1 and flags&1:segments.append([vaddr,vaddr+size])
serial=out/"serial.txt"
args=[os.environ["B3_ROOT"]+"/hostbin/qemu-system-x86_64","-machine","q35,accel=tcg","-cpu","max","-smp",topology,"-m","256M",
    "-kernel",str(kernel),"-append","image="+measure,"-nic","none","-display","none","-monitor","none","-serial","file:"+str(serial),"-qmp","stdio","-no-reboot"]
with (out/"stderr.txt").open("w") as err, subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True) as vm:
    try:
        def rpc(name,**kwargs):
            vm.stdin.write(json.dumps({"execute":name,"arguments":kwargs})+"\n")
            vm.stdin.flush()
            while line:=vm.stdout.readline():
                q=json.loads(line)
                if "return" in q:return q["return"]
                require("error" not in q,str(q))
            raise RuntimeError("QMP closed")
        version=json.loads(vm.stdout.readline())["QMP"]["version"]
        rpc("qmp_capabilities")
        while True:
            log=serial.read_text(errors="replace") if serial.exists() else ""
            if "leaves no memory behind" in log:break
            require(vm.poll() is None,"guest exited during startup")
            time.sleep(.1)
        time.sleep(.25)
        rpc("stop")
        require(not rpc("query-status")["running"],"pause did not take")
        cpu_rows=[]
        for cpu in rpc("query-cpus-fast"):
            index=cpu["cpu-index"]
            apic=rpc("qom-get",path=cpu["qom-path"],property="apic-id")
            regs=rpc("human-monitor-command",**{"command-line":"info registers","cpu-index":index})
            (out/f"cpu-{index}.txt").write_text(regs)
            ip=int(re.search(r"\b[RE]IP=([\da-f]+)",regs,re.I).group(1),16)
            csbase=int(re.search(r"^CS\s*=\s*[\da-f]+\s+([\da-f]+)",regs,re.M|re.I).group(1),16)
            hlt=int(re.search(r"\bHLT=([01])",regs).group(1))
            linear=csbase+ip
            cpu_rows.append(dict(index=index,apic=apic,ip=ip,csbase=csbase,linear_ip=linear,halted=hlt,
                                 in_kernel_exec=any(a<=linear<b for a,b in segments)))
        slots=rpc("query-hotpluggable-cpus")
        observed=[l for l in log.splitlines() if l.startswith("processors: ")]
        result=dict(machine="q35",version=version,topology=topology,kernel_measurement=measure,exec_ranges=segments,
                    cpus=cpu_rows,slots=slots,serial=observed)
        (out/"result.json").write_text(json.dumps(result,indent=2)+"\n")
        print(topology,observed,[(r["apic"],r["halted"],hex(r["linear_ip"]),r["in_kernel_exec"]) for r in cpu_rows],flush=True)
        rpc("quit")
        vm.wait(timeout=10)
    finally:
        if vm.poll() is None:
            vm.terminate()
            vm.wait(timeout=10)

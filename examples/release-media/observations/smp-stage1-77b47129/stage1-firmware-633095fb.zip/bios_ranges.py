"""Observe the Multiboot map and firmware-advertised ACPI tables at the private guest's kernel entry."""
import hashlib, json, os, re, shutil, struct, subprocess
from pathlib import Path
dst=Path("evidence/bios-map");dst.mkdir()
kernel=Path("kernel-stock/PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32").resolve()
k=kernel.read_bytes()
entry=struct.unpack_from('<I',k,24)[0]
args=[os.environ['B3_ROOT']+'/hostbin/qemu-system-x86_64','-machine','pc','-accel','tcg','-cpu','max','-m','256M','-smp','2','-nic','none','-display','none','-monitor','none','-serial','file:'+str((dst/'serial.txt').resolve()),'-S','-gdb','stdio','-kernel',str(kernel),'-append','then=off']
def require(ok,m):
 if not ok:raise RuntimeError(m)
with (dst/"stderr.txt").open('wb') as err, subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,bufsize=0) as vm:
 try:
  def rsp(command):
   data=command.encode()
   vm.stdin.write(b'$'+data+b'#'+f'{sum(data)%256:02x}'.encode())
   x=vm.stdout.read(1)
   while x!=b'$':
    require(x in (b'+',),('GDB reply',x));x=vm.stdout.read(1)
   buf=bytearray()
   while True:
    x=vm.stdout.read(1)
    if x==b'#':break
    require(x,'end of GDB stream');buf.extend(x)
   expected=vm.stdout.read(2);require(expected==f'{sum(buf)%256:02x}'.encode(),'checksum')
   vm.stdin.write(b'+');return bytes(buf).decode()
  def read(addr,n):
   require(0<addr<1<<32 and 0<n<=1<<20,'unexpected range')
   parts=[]
   for offset in range(0,n,512):
    length=min(512,n-offset);val=rsp(f'm{addr+offset:x},{length:x}')
    require(len(val)==2*length,'short debug read')
    parts.append(bytes.fromhex(val))
   return b''.join(parts)
  version=rsp('qSupported:multiprocess+;xmlRegisters=i386')
  require(rsp(f'Z1,{entry:x},1')=='OK','kernel entry breakpoint')
  stop=rsp('c');require(stop.startswith(('T05','S05')),'no entry stop: '+stop)
  regs=bytes.fromhex(rsp('g'))
  magic,info=struct.unpack_from('<QQ',regs)
  ip=struct.unpack_from('<Q',regs,16*8)[0]
  require((magic,ip)==(0x2badb002,entry),(hex(magic),hex(ip),hex(entry)))
  mb=read(info,52)
  flags=struct.unpack_from('<I',mb)[0]
  require(flags&4 and flags&64,'no command line or map')
  cmd_ptr=struct.unpack_from('<I',mb,16)[0]
  nr,mp=struct.unpack_from('<II',mb,44)
  rawmap=read(mp,nr)
  (dst/'multiboot-map.bin').write_bytes(rawmap)
  descriptors=[]
  j=0
  while j<nr:
   size,base,length,kind=struct.unpack_from('<IQQI',rawmap,j)
   require(size>=20,'descriptor length')
   descriptors.append((base,base+length,kind));j+=4+size
  require(j==nr,'map length')
  cmd=read(cmd_ptr,1024).split(b'\0',1)[0].decode()
  bios_address=int.from_bytes(read(0x40e,2),'little')<<4
  candidates=[]
  for start,size in [(bios_address,1024),(0xe0000,0x20000)]:
   if start<0x400:continue
   block=read(start,size)
   for offset in range(0,size-19,16):
    if block[offset:offset+8]==b'RSD PTR ' and sum(block[offset:offset+20])%256==0:candidates.append(start+offset)
  require(len(candidates)==1,'one BIOS root')
  root=candidates[0]
  def record(label,addr,b,checksum=True):
   if checksum:require(sum(b)%256==0,label+' checksum')
   covers=[{'start':a,'end_exclusive':e,'type':t} for a,e,t in descriptors if a<=addr and addr+len(b)<=e]
   require(len(covers)<=1,'ambiguous descriptor: '+label)
   return {'signature':label,'address':addr,'length':len(b),'range':covers[0] if covers else None,'sha256':hashlib.sha256(b).hexdigest()}
  rs=read(root,36)
  require(rs[:8]==b'RSD PTR ' and sum(rs[:20])%256==0,'RSDP')
  wide=rs[15]>=2 and struct.unpack_from('<Q',rs,24)[0]!=0
  rows=[record('RSDP',root,rs if wide else rs[:20])]
  def table(addr):
   h=read(addr,36);n=struct.unpack_from('<I',h,4)[0];require(36<=n<=1<<20,'ACPI length')
   data=read(addr,n);sig=h[:4].decode('ascii');rows.append(record(sig,addr,data));return data
  addr=struct.unpack_from('<Q',rs,24)[0] if wide else struct.unpack_from('<I',rs,16)[0]
  x=table(addr)
  require(x[:4]==(b'XSDT' if wide else b'RSDT'),'root table')
  for a, in struct.iter_unpack('<Q' if wide else '<I',x[36:]):table(a)
  (dst/'result.json').write_text(json.dumps({'entry':ip,'multiboot_info':info,'map_bytes':nr,'cmdline':cmd,'tables':rows},indent=2)+'\n')
  print([(v['signature'],hex(v['address']),v['length'],v['range']['type'] if v['range'] else None) for v in rows],flush=True)
 finally:
  if vm.poll() is None:
   vm.terminate()
   vm.wait(timeout=10)

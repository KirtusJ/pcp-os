"""Observe the Multiboot map and firmware-advertised ACPI tables at the private guest's kernel entry."""
import hashlib, json, os, re, shutil, struct, subprocess
from pathlib import Path
dst=Path("evidence/efi-map");dst.mkdir()
k=Path("volume/PCPOS/KERNEL.ELF").read_bytes()
entry=struct.unpack_from('<I',k,24)[0]
args=json.loads(Path("evidence/sparse-uefi/command.json").read_text())
args[args.index("-qmp"):args.index("-qmp")+2]=["-S","-gdb","stdio"]
s=args.index("-serial")+1;args[s]="file:"+str((dst/"serial.txt").resolve())
oldvar=next(a for a in args if a.startswith("if=pflash,unit=1"))
var=dst/"vars.fd"
shutil.copyfile(Path(os.environ["B3_ROOT"])/"runtime/usr/share/OVMF/OVMF_VARS_4M.fd",var)
args[args.index(oldvar)]="if=pflash,unit=1,format=raw,file="+str(var.resolve())
def require(ok,m):
 if not ok:raise RuntimeError(m)
with (dst/"stderr.txt").open('wb') as err, subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,bufsize=0) as vm:
 try:
  def rsp(command):
   data=command.encode()
   vm.stdin.write(b'$'+data+b'#'+f'{sum(data)%256:02x}'.encode())
   x=vm.stdout.read(1)
   while x!=b'$':
    require(x in (b'+',),('GDB reply',x));x=vm.stdout.read(1)
   buf=bytearray()
   while True:
    x=vm.stdout.read(1)
    if x==b'#':break
    require(x,'end of GDB stream');buf.extend(x)
   expected=vm.stdout.read(2);require(expected==f'{sum(buf)%256:02x}'.encode(),'checksum')
   vm.stdin.write(b'+');return bytes(buf).decode()
  def read(addr,n):
   require(0<addr<1<<32 and 0<n<=1<<20,'unexpected range')
   parts=[]
   for offset in range(0,n,512):
    length=min(512,n-offset);val=rsp(f'm{addr+offset:x},{length:x}')
    require(len(val)==2*length,'short debug read')
    parts.append(bytes.fromhex(val))
   return b''.join(parts)
  version=rsp('qSupported:multiprocess+;xmlRegisters=i386')
  require(rsp(f'Z1,{entry:x},1')=='OK','kernel entry breakpoint')
  stop=rsp('c');require(stop.startswith(('T05','S05')),'no entry stop: '+stop)
  regs=bytes.fromhex(rsp('g'))
  magic,info=struct.unpack_from('<QQ',regs)
  ip=struct.unpack_from('<Q',regs,16*8)[0]
  require((magic,ip)==(0x2badb002,entry),(hex(magic),hex(ip),hex(entry)))
  mb=read(info,52)
  flags=struct.unpack_from('<I',mb)[0]
  require(flags&4 and flags&64,'no command line or map')
  cmd_ptr=struct.unpack_from('<I',mb,16)[0]
  nr,mp=struct.unpack_from('<II',mb,44)
  rawmap=read(mp,nr)
  (dst/'multiboot-map.bin').write_bytes(rawmap)
  descriptors=[]
  j=0
  while j<nr:
   size,base,length,kind=struct.unpack_from('<IQQI',rawmap,j)
   require(size>=20,'descriptor length')
   descriptors.append((base,base+length,kind));j+=4+size
  require(j==nr,'map length')
  cmd=read(cmd_ptr,1024).split(b'\0',1)[0].decode()
  pointers=re.findall(r'(?:^| )acpi_rsdp=0x([0-9a-f]{16})(?= |$)',cmd)
  require(len(pointers)==1,'named root')
  root=int(pointers[0],16)
  def record(label,addr,b,checksum=True):
   if checksum:require(sum(b)%256==0,label+' checksum')
   covers=[{'start':a,'end_exclusive':e,'type':t} for a,e,t in descriptors if a<=addr and addr+len(b)<=e]
   require(len(covers)==1,'single containing descriptor: '+label)
   return {'signature':label,'address':addr,'length':len(b),'range':covers[0],'sha256':hashlib.sha256(b).hexdigest()}
  rs=read(root,36)
  require(rs[:8]==b'RSD PTR ' and rs[15]>=2 and sum(rs[:20])%256==0,'RSDP')
  rows=[record('RSDP',root,rs)]
  def table(addr):
   h=read(addr,36);n=struct.unpack_from('<I',h,4)[0];require(36<=n<=1<<20,'ACPI length')
   data=read(addr,n);sig=h[:4].decode('ascii');rows.append(record(sig,addr,data));return data
  x=table(struct.unpack_from('<Q',rs,24)[0])
  require(x[:4]==b'XSDT','expected XSDT')
  for a, in struct.iter_unpack('<Q',x[36:]):table(a)
  (dst/'result.json').write_text(json.dumps({'entry':ip,'multiboot_info':info,'map_bytes':nr,'cmdline':cmd,'tables':rows},indent=2)+'\n')
  print([(v['signature'],hex(v['address']),v['length'],v['range']['type']) for v in rows],flush=True)
 finally:
  if vm.poll() is None:
   vm.terminate()
   vm.wait(timeout=10)

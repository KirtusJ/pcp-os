# Display and clock integration replay

A3 checked display head 45829763f24daeed106659673ba476b94abac42b and a clean Git merge tree of that head with clock head 2c43e202010e04a2436e027b013787bb8714d358. The complete merge tree is 9651e888d002e2b459dd3f6bdeb90b196e59ea1d. Its PCP_OS_Rust subtree is 2c66f2242814331a94e4a57459664bdd346fec67. The integrated tree was local when the runs began. The candidate kernel received both the processors and proposals features and the default 1 MiB load address. Built using rustc 1.100.0 (0ef1bc386 2026-11-09). QEMU was 10.0.13 with TCG. The test guests had no network interface.

The display-head ELF SHA-256 is 7adae6639f4659f773e973ba08e95d94aa0a51375be83be85b3e2dab6aa69e6b. The combined ELF SHA-256 is 6530daadefd2292f0a192b5bfe49dca746207d16e00414c4ff51c3c92d7aa165. The clock guest SHA-256 is 372b77ffedf0b065ed43b20e01318f58535cdbcaeb590361d67fdbd80e45fc51. Every run has a full serial log. The result JSON and any vm-status.json are original host observations. In the EFI runs the QEMU wrapper changes the original comparison driver's 192 MiB to 256 MiB, uses a private copy of OVMF variables, and substitutes the recorded GRUB configuration and a private snapshot disk for direct Multiboot loading. Hence the startup route and actual VM options for an EFI run are given by the serial log and vm-status.json. The guest requests no framebuffer and produces zero frames.

## Replay

Check out the display head for display-* or materialize the tree from git merge-tree --write-tree with the two heads for current-*. Run the kernel crate's run.sh build with PCPOS_KERNEL_FEATURES=processors,proposals. For the one-vCPU clock cases and the original drivers, use the pinned clock replay listed below. Run the four-vCPU cases using the command in each result.json. The two upstream SeaBIOS images come from the earlier processor replay and differ in CONFIG_MTRR_INIT. To select the alternate firmware PAT entry in current-pat-uc-minus, use the earlier clock replay's patched SeaBIOS with the one-byte enable-pat3 control. The two selected PAT trials use exactly the same firmware and kernel.

Both single-surface cases boot virtio-vga under OVMF and GRUB. The EFI executable was made with grub-mkimage, Debian GRUB 2.12-9+deb13u2. The early configuration runs configfile "$cmdpath/grub.cfg". The included grub.cfg loads the test kernel and clock guest. The 64 MiB FAT image contains EFI/BOOT/BOOTX64.EFI, EFI/BOOT/grub.cfg, kernel.elf32 and clock.elf. The EFI SHA-256 is 395fde23b5a8ca7a11cdc301e79d06def66fde676139cac6c18bda858ee6f374. The UI qualification here observes the kernel's drawing-path selection and the page-table readback. The existing one-page rendering trials and the attended laptop comparison provide separate evidence about visible frames.

A preliminary local reconciliation of the three PRs emitted the same display messages in the opposite order. Its measurements are excluded from the reported results. During that preliminary preparation, two VM invocations stopped before boot due to host device configuration. A third ended mid-probe without a captured exit status. The later EFI executions recorded QEMU status. The first display-only PAT exercise completed the guest checks but its host text assertion expected a different verb in the secondary-CPU report. Correcting the reader and repeating the same case reproduced the numeric result.

## Supporting records

- Exact #429 processor fixture and firmware provenance at https://github.com/KirtusJ/pcp-os/pull/429#issuecomment-7083898656
- Exact #431 original probe, paired PAT control, and drivers at https://github.com/KirtusJ/pcp-os/pull/431#issuecomment-7084191047
- Actual model-free optical and USB GRUB handoff at https://github.com/KirtusJ/pcp-os/issues/406#issuecomment-7082998296
- Native preloaded EFI clock control at https://github.com/KirtusJ/pcp-os/pull/431#issuecomment-7084240230
- Linux x86 PAT documentation at https://docs.kernel.org/arch/x86/pat.html
- GNU Multiboot2 ACPI information tags at https://www.gnu.org/software/grub/manual/multiboot2/multiboot.html

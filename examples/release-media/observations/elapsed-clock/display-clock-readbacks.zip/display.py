"""Observe processor and framebuffer readback on the exact display head."""
from pathlib import Path
import subprocess
import sys
import json
root=Path(__file__).resolve().parent
name=sys.argv[1]
firmware=root.parent/"wc-test"
cases={
    "four-restore": ("max",firmware/"mtrr-init.bin",4050,"other memory types"),
    "four-pat-only": ("max",firmware/"no-mtrr-init.bin",4050,"another page-attribute table"),
    "four-no-pat": ("max,-pat",firmware/"mtrr-init.bin",0,"other memory types"),
}
cpu,bios,pages,msg=cases[name]
out=root/("display-"+name)
out.mkdir()
args=["qemu-system-x86_64","-machine","q35","-accel","tcg","-cpu",cpu,"-smp","4,sockets=1,cores=2,threads=2","-m","192M","-bios",str(bios),"-vga","std","-display","none","-nic","none","-monitor","none","-serial","stdio","-no-reboot","-kernel",str(root/"display-head.elf"),"-append","then=off","-device","isa-debug-exit,iobase=0xf4,iosize=0x04"]
p=subprocess.run(args,capture_output=True,timeout=75)
(out/"serial.log").write_bytes(p.stdout)
(out/"stderr.log").write_bytes(p.stderr)
lines=p.stdout.decode(errors="replace").splitlines()
summary={"exit":p.returncode,"args":args,"pass_count":sum(l.lstrip().startswith("pass ") for l in lines),"readback":[l for l in lines if l.startswith(("display:","display memory:","other processors:","ALL SELF-TESTS PASS"))]}
(out/"result.json").write_text(json.dumps(summary,indent=2)+"\n")
assert p.returncode==33 and summary["pass_count"]==75
assert any(f"{pages} of the 4050" in l for l in lines)
assert any("3 of 3 started and parked" in l for l in lines)
assert any("3 came up" in l and msg in l for l in lines)
assert any("80000 of 80000" in l for l in lines)
print(name,summary["pass_count"],pages,p.returncode)

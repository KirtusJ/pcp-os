"""Read the 82 members of the display rehearsal from its transfer and prior payload sources."""
from pathlib import Path
from hashlib import sha256
import json
import os
import struct
import subprocess
import sys
from zipfile import ZipFile
p=Path(__file__).resolve().parent
work=p.parent
release=work.parent / "release-395-ggml"
transfer=Path(sys.argv[1]).resolve()
out=Path(sys.argv[2]).resolve()
def row(data):
    return {"bytes":len(data),"sha256":sha256(data).hexdigest()}
with ZipFile(transfer) as z, ZipFile(work/"postmerge-qualification.zip") as baseline, ZipFile(release/"upstream/inputs.zip") as original:
    assert len(z.namelist())==len(set(z.namelist())) and z.testzip() is None
    sums={name:h for h,name in (line.split("  ",1) for line in z.read("SHA256SUMS").decode().splitlines())}
    assert set(sums)==set(z.namelist())-{"SHA256SUMS"}
    assert all(sha256(z.read(name)).hexdigest()==expected for name,expected in sums.items())
    inventory=json.loads(z.read("expected-files.json"))
    inventory_hash=row(z.read("expected-files.json"))["sha256"]
    previous=json.loads(baseline.read("expected-files.json"))
    b=json.loads(z.read("binding.json"))
    assert row(baseline.read("expected-files.json"))["sha256"]==b["baseline_inventory_sha256"]
    diffs=sorted(k for k in inventory if inventory[k]!=previous[k])
    assert len(inventory)==82 and inventory.keys()==previous.keys() and diffs==["EFI/BOOT/BOOTX64.EFI","PCPOS/KERNEL.ELF"]
    members={f:z.read(f) for f in diffs}
    for n in ("TAILOR.ELF","WORKER.ELF","model.manifest"):
        members["PCPOS/"+n]=original.read("parts/"+n)
    members["PCPOS/MODEL-LICENSE.txt"]=(release/"upstream/LICENSE").read_bytes()
    members["PCPOS/RUNTIME-NOTICE.txt"]=(release/"THIRD_PARTY_NOTICES").read_bytes()
    observed={f:row(d) for f,d in members.items()}
    assert all(observed[f]==inventory[f] for f in members)
    pins=json.loads(z.read("inputs.json"))["files"]
    order=("KERNEL.ELF","TAILOR.ELF","WORKER.ELF","model.manifest")
    packed=b"".join(bytes.fromhex(observed["PCPOS/"+name]["sha256"]) for name in order)
    assert all(observed["PCPOS/"+n]["sha256"]==pins[n] for n in order)
    efi=members["EFI/BOOT/BOOTX64.EFI"]
    assert efi.count(packed)==1
    manifest=members["PCPOS/model.manifest"]
    assert manifest[:8]==b"PCPMDL01"
    total,chunk,count=struct.unpack_from("<QII",manifest,8)
    assert (total,count)==(5027783488,75)
    full=sha256()
    toolsroot=Path(os.environ["B3_ROOT"])/"runtime/usr"
    env=dict(os.environ,LD_LIBRARY_PATH=str(toolsroot/"lib/x86_64-linux-gnu"))
    origin=work.parent/"worker-32/original.fat"
    for i in range(count):
        f=f"PCPOS/shard-{i:05}.bin"
        length=0
        digest=sha256()
        with subprocess.Popen([str(toolsroot/"bin/mtype"),"-i",str(origin),"::"+f],stdout=subprocess.PIPE,env=env) as stream:
            for data in iter(lambda:stream.stdout.read(1024*1024),b""):
                length+=len(data)
                digest.update(data)
                full.update(data)
            assert stream.wait()==0
        observed[f]={"bytes":length,"sha256":digest.hexdigest()}
        assert length==min(chunk,total-i*chunk) and digest.digest()==manifest[56+i*32:88+i*32]
    assert full.digest()==manifest[24:56] and observed==inventory
    rec={"archive":row(transfer.read_bytes()),"source":b["kernel_source"],"inventory":inventory_hash,"baseline":b["baseline_inventory_sha256"],"changed":diffs,"verified_files":len(observed),"model_bytes":total,"shards":count,"model_sha256":full.hexdigest(),"efi_pin_offset":efi.index(packed),"sources":"transferred EFI and kernel, retained input components and notices, prior FAT for the 75 model shards"}
    out.write_text(json.dumps(rec,indent=2)+"\n")
    print(json.dumps(rec))

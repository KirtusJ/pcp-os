# B3 comparison at 2c43e202010e04a2436e027b013787bb8714d358

The one change from f0d994df checks IA32_PAT entry 3 when the CPU supports PAT. On this kernel the timer mapping selects that entry. If firmware selected a type other than UC there, the kernel uses its delivered-PIT fallback. On older CPUs without PAT the original PWT/PCD uncached encoding still works.

candidate/KERNEL.ELF is the original, uninstrumented 1 MiB model-free kernel used in every run in this archive. See the original replay archive at https://github.com/KirtusJ/pcp-os/pull/431#issuecomment-7084068761 for A3's test guest, the command lines and the observer patch. The additional no-PAT run used compare.py KERNEL.ELF no-pat --cpu max,pat=off. All four JSONs contain the exact configuration.

One HPET run included a delayed scheduling opportunity during the requested two-second realtime sleep. The guest recorded 4.201 s and the host 4.204 s inside that phase. The desktop recorded 13 seconds for that run. Elapsed time includes a late wakeup. A clock does not guarantee a dispatch time.

The two incomplete contended-PIT captures ended before the final markers. They cannot yield a duration. A completed contended-PIT run from the preceding revision is included in the original replay archive.

No WHPX, physical or 8B performance claim follows from these model-free runs.

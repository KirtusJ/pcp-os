.section .text
.globl _start
_start:
    and $-16, %rsp
    call probe_main
.section .note.GNU-stack,"",@progbits

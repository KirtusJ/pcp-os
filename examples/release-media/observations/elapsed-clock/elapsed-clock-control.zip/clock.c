/* Ordinary x86-64 Linux-personality interfaces as seen by an application. */
typedef unsigned long word;
struct timestamp { word seconds, fraction; };
enum { REALTIME, MONOTONIC };
static const word billion = 1000000000UL;
static volatile word computation = 7;

static long invoke(long number, long a, long b, long c, long d) {
    long result;
    register long fourth __asm__("r10") = d;
    __asm__ volatile ("syscall" : "=a"(result)
        : "a"(number), "D"(a), "S"(b), "d"(c), "r"(fourth)
        : "rcx", "r11", "memory");
    return result;
}
static void emit(const char *line) {
    word length = 0;
    while (line[length]) ++length;
    invoke(1, 1, (long)line, length, 0);
}
static void finish(long status) {
    invoke(60, status, 0, 0, 0);
    for (;;) {}
}
static void check(int ok, const char *error) {
    if (!ok) { emit(error); finish(10); }
}
static word clock_ns(long clock) {
    struct timestamp t = {0};
    check(invoke(228, clock, (long)&t, 0, 0) == 0, "FAIL clock_gettime\n");
    check(t.fraction < billion, "FAIL timespec normalization\n");
    return t.seconds * billion + t.fraction;
}
static void span(const char *end, word start) {
    word now = clock_ns(MONOTONIC);
    check(now >= start, "FAIL monotonic went backwards\n");
    word delta = now - start;
    char digits[22];
    digits[20] = '\n'; digits[21] = 0;
    for (int i = 19; i >= 0; --i) { digits[i] = '0' + delta % 10; delta /= 10; }
    emit(end); emit(digits);
}
static void epoch_interfaces(void) {
    struct timestamp tv = {0};
    long slot = -1;
    word before = clock_ns(REALTIME);
    check(invoke(96, (long)&tv, 0, 0, 0) == 0, "FAIL gettimeofday call\n");
    long seconds = invoke(201, (long)&slot, 0, 0, 0);
    word after = clock_ns(REALTIME);
    check(tv.fraction < 1000000 && after >= before, "FAIL realtime bracket\n");
    word us = tv.seconds * 1000000 + tv.fraction;
    check(us >= before / 1000 && us <= after / 1000, "FAIL realtime/gettimeofday differ\n");
    check(seconds >= 0 && seconds == slot && (word)seconds >= before / billion &&
          (word)seconds <= after / billion, "FAIL realtime/time differ\n");
}
static void sleep_phase(const char *begin, const char *end, int clock, int absolute, int expired) {
    emit(begin);
    word start = clock_ns(MONOTONIC);
    word clock_before = clock_ns(clock);
    word duration = 2 * billion;
    word requested = absolute ? clock_before + duration : duration;
    if (expired) requested = clock_before > 1000000 ? clock_before - 1000000 : 0;
    struct timestamp target = {requested / billion, requested % billion};
    check(invoke(230, clock, absolute, (long)&target, 0) == 0, "FAIL clock_nanosleep call\n");
    word actual = clock_ns(clock);
    check(actual >= (absolute ? requested : clock_before + duration), "FAIL early wake\n");
    span(end, start);
    epoch_interfaces();
}
void probe_main(void) {
    epoch_interfaces();
    emit("CLOCK-BUSY-BEGIN\n");
    word start = clock_ns(MONOTONIC);
    word previous = start;
    do {
        word x = computation;
        for (unsigned i=0; i<131072; ++i) x = x * 6364136223846793005UL + 1442695040888963407UL;
        computation = x;
        word now = clock_ns(MONOTONIC);
        check(now >= previous, "FAIL monotonic while computing\n");
        previous = now;
    } while (previous - start < 5 * billion);
    span("CLOCK-BUSY-END ", start);
    sleep_phase("CLOCK-REL-BEGIN\n", "CLOCK-REL-END ", MONOTONIC, 0, 0);
    sleep_phase("CLOCK-ABSMONO-BEGIN\n", "CLOCK-ABSMONO-END ", MONOTONIC, 1, 0);
    sleep_phase("CLOCK-ABSREAL-BEGIN\n", "CLOCK-ABSREAL-END ", REALTIME, 1, 0);
    sleep_phase("CLOCK-PAST-BEGIN\n", "CLOCK-PAST-END ", MONOTONIC, 1, 1);
    emit("CLOCK-INTERFACES-AGREE\n");
    finish(0);
}

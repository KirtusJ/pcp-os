"""Put QEMU and one arithmetic process on one CPU, with the serial reader on another."""
import os
from pathlib import Path
import subprocess
import sys
import time

cores = sorted(os.sched_getaffinity(0))
if len(cores) < 2:
    raise SystemExit("Two allowed host CPUs are needed for this contention control")
vm_core, reader_core = cores[:2]
os.sched_setaffinity(0, {reader_core})
competitor_code = "while True:\n    for i in range(50_000):\n        value = i * i"
peer_cmd = ["taskset", "-c", str(vm_core), sys.executable, "-c", competitor_code]
with subprocess.Popen(peer_cmd, stdout=subprocess.DEVNULL) as peer:
    try:
        time.sleep(0.2)
        comparison = Path(__file__).with_name("compare.py")
        subprocess.run([sys.executable, str(comparison), *sys.argv[1:], "--vm-core", str(vm_core)], check=True)
    finally:
        peer.terminate()
        peer.wait(timeout=5)
print(f"Host CPU {vm_core} shared by QEMU and one arithmetic process; serial reader on CPU {reader_core}.")

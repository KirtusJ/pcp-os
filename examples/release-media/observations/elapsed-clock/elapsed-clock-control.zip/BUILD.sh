set -eu
cc -c -O2 -ffreestanding -fno-stack-protector -mno-red-zone -fno-pie -mcmodel=large -o clock.o clock.c
cc -c -o start.o start.S
ld --build-id=none -T guest.ld -o clock.elf start.o clock.o
sha256sum clock.elf

# Guest elapsed time under CPU load

This is an independent application-level control for KirtusJ/pcp-os issue 422. The archived runs use the same merged PCP OS source and the same kernel executable. The kernel SHA-256 is 5aa50fbf8c77a98a2c7f27f1b74ad902d1385a1f27832c4f7fe9d987a2468169. It is the 1 MiB-load-address model-free build from 0e3dd8a37b9b16cf84c92328dc4890c879563fcf. The probe SHA-256 is 372b77ffedf0b065ed43b20e01318f58535cdbcaeb590361d67fdbd80e45fc51.

Each run boots the kernel with one ordinary Linux-personality guest on one Q35 TCG vCPU, 192 MiB RAM and no network interface. The guest performs integer arithmetic until its monotonic clock advances five seconds. It then makes three two-second waits, one relative and two absolute, using the monotonic and realtime clocks. It also supplies an expired monotonic deadline. At every phase boundary it checks that realtime reads bracket gettimeofday and time at their respective resolutions. It verifies every requested future deadline against the same guest clock. The serial reader timestamps complete lines using the host monotonic performance counter. Its elapsed values include serial delivery and host scheduling latency. The advertised 1 ns resolution of the host clock is not a measurement uncertainty bound. The archived desktop task record is in each serial log and JSON result.

## Running the comparison

Run these commands in the directory containing the probe. Use an absent output directory for each run. The contention control requires Linux taskset and at least two permitted logical CPUs. QEMU and one additional ordinary runnable process share one logical CPU. The serial reader has another. The QEMU process receives a nice increment of eight. Each process terminates at the end of the run.

```sh
sh BUILD.sh
python compare.py /path/to/KERNEL.ELF result-normal
python contended.py /path/to/KERNEL.ELF result-contended --vm-nice 8
```

The captured runs used GCC 14.2.0, Python 3.12.14 and QEMU 10.0.13. No screenshot capture, model runtime or external service is involved. Elapsed times depend on host scheduling. A head implementing a new clock may need additional source-specific arguments or a separate fallback build. Each tested revision and selected runtime source should accompany its results.

[Linux kernel timekeeping](https://docs.kernel.org/timers/timekeeping.html) · [Linux clock_nanosleep](https://man7.org/linux/man-pages/man2/clock_nanosleep.2.html) · [Python performance counter](https://docs.python.org/3/library/time.html#time.perf_counter_ns)

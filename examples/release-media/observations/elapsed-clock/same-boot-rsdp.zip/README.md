# Model-free UEFI root-pointer handoff control

Each pair booted the same 64 MiB FAT disk with the same OVMF firmware, GRUB EFI, model-free kernel, and clock guest. GRUB's lsefisystab command reported the EFI configuration tables on a separate serial port. The host observed the ACPI 2.0 GUID and returned either its address from this boot or the word omit. The common GRUB configuration added the kernel's existing acpi_rsdp parameter only when an address was supplied. All four boots exposed a Q35 HPET and used the same 1920 × 1080 single-surface framebuffer. Each boot used a private copy of the firmware variables and a snapshot of the disk.

The ordinary pair used 256 MiB. The contended pair used 288 MiB, one runnable CPU competitor, and QEMU at nice +8 on the same logical CPU. Within each pair, the root-pointer handoff was the experimental difference. Across pairs, both RAM and CPU load changed. The different addresses in the two pairs check that the host obtained the address from that boot's firmware table.

The source is the clean combination of PCP OS #429 at 45829763f24daeed106659673ba476b94abac42b and #431 at 2c43e202010e04a2436e027b013787bb8714d358. PCP_OS_Rust subtree 2c66f2242814331a94e4a57459664bdd346fec67. The 1 MiB kernel used the processors and proposals features. The experiment uses a test clock guest and an instrumented GRUB configuration. The delivered preview and proposed Kingston disk were not changed.

## Reproduction

Use the clock guest and comparison drivers from the earlier elapsed-time replay below. Place qemu-grub and probe.img together. The QEMU executable must be on PATH, the Debian virtio-vga module must be discoverable, and B3_ROOT/runtime/usr/share/OVMF must contain the OVMF_CODE_4M.fd and OVMF_VARS_4M.fd files. To use a standard installation, adapt the firmware directory in the wrapper.

Build GRUB 2.12's EFI executable with the module list in build-esp.sh. Its early configuration reads EFI/BOOT/grub.cfg. Supply the tested kernel ELF and clock guest when making the FAT disk. The FAT volume ID and timestamps on a new disk can differ from the recorded disk. The same immutable disk bytes were used for every trial here. Run the shell commands below in a directory containing the original drivers and guest, substituting actual paths.

```sh
A3_RSDP_CONTROL=omit python3 compare.py /path/to/KERNEL.ELF ordinary-omit --qemu /path/to/qemu-grub
A3_RSDP_CONTROL=pass python3 compare.py /path/to/KERNEL.ELF ordinary-pass --qemu /path/to/qemu-grub
A3_TEST_RAM=288M A3_RSDP_CONTROL=pass python3 contended.py /path/to/KERNEL.ELF load-pass --qemu /path/to/qemu-grub --vm-nice 8
A3_TEST_RAM=288M A3_RSDP_CONTROL=omit python3 contended.py /path/to/KERNEL.ELF load-omit --qemu /path/to/qemu-grub --vm-nice 8
```

handoff.json records the actual QEMU arguments, declared RSDP address, host response and QEMU status. grub-serial.raw contains the original EFI configuration-table listing and the two experiment markers. result.json and serial.log record the ordinary guest calls, host marker timings and kernel checks. The host measures serial delivery with CLOCK_MONOTONIC. The two early socket-based attempts stopped before collecting any firmware output because this environment disallowed local sockets. The recorded trials used named pipes.

ACPI 6.6 §5.2.5.2 specifies discovery through the EFI configuration table and conveyance of the RSDP to the operating system. This experiment exercises the kernel's already-supported handoff parameter. The test-only serial relay demonstrates the change in behavior. A general boot implementation would obtain the address from its own current firmware environment.

- ACPI specification at https://uefi.org/sites/default/files/resources/ACPI_Spec_6.6.pdf
- Baseline kernel, clock guest and host replay at https://github.com/KirtusJ/pcp-os/pull/431#issuecomment-7084191047
- Display and clock combined source readback at https://github.com/KirtusJ/pcp-os/pull/431#issuecomment-7084426969

#!/bin/sh
set -eu
: "${GRUB_MODULES:?set GRUB_MODULES to the x86_64-efi modules directory}"
: "${KERNEL_ELF:?set KERNEL_ELF to the model-free kernel}"
: "${CLOCK_ELF:?set CLOCK_ELF to the clock probe}"
test ! -e probe.img
printf '%s\n' 'configfile "$cmdpath/grub.cfg"' > early.cfg
grub-mkimage -O x86_64-efi -d "$GRUB_MODULES" -p /EFI/BOOT -c early.cfg -o BOOTX64.EFI normal configfile fat part_gpt part_msdos multiboot boot efi_gop all_video gfxterm search search_fs_file serial lsefisystab echo read test
truncate -s 64M probe.img
mkfs.fat -F32 probe.img
mmd -i probe.img ::EFI ::EFI/BOOT
mcopy -i probe.img BOOTX64.EFI grub.cfg ::EFI/BOOT/
mcopy -i probe.img "$KERNEL_ELF" ::kernel.elf32
mcopy -i probe.img "$CLOCK_ELF" ::clock.elf

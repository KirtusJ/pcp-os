# Independent elapsed-clock replay for PCP OS #431

This archive records source revision 2c43e202010e04a2436e027b013787bb8714d358. The 1 MiB model-free kernel was built with the repository's run.sh build command and its default features. The clock guest and the two original measurement drivers come from the independent control at 93f78cfb54afee2bf0284451ee1ca2c0e92e0204. Their digests and the measured kernel are in SHA256SUMS. The ordinary runs used QEMU 10.0.13 TCG, one Q35 vCPU and 192 MiB RAM. The host observed first-to-last serial markers with CLOCK_MONOTONIC. All returned durations include host scheduling and serial delivery latency.

From the extracted directory, give each run a new output directory.

```sh
python3 compare.py KERNEL.ELF hpet
python3 contended.py KERNEL.ELF hpet-load --vm-nice 8
python3 compare.py KERNEL.ELF pit --machine q35,hpet=off
python3 contended.py KERNEL.ELF pit-load --machine q35,hpet=off --vm-nice 8
python3 compare.py KERNEL.ELF no-pat --cpu max,-pat
```

The guest checks monotonic and realtime reads, gettimeofday and time, a relative two-second wait, two absolute two-second deadlines and an already expired deadline. The result JSON gives the host and guest intervals. The serial log identifies the selected clock. The desktop application summary covers a slightly wider interval, in whole seconds. The CPU contention driver puts one ordinary integer workload and the VM on the same CPU, with the serial reader on another.

The paired firmware trial used one SeaBIOS image built from upstream a6ed6b701f0a57db0569ab98b0661c12a6ec3ff8 with firmware.patch and seabios.config. Its SHA-256 was 49ce8c74c499fac5952e609750e45b9a3415660293cc4a7d5ff9562de8a349b7. Apply the patch in that SeaBIOS revision, copy seabios.config to .config, and run make PYTHON=python3. On the same one-vCPU Q35 machine, pass -bios out/bios.bin in both runs. For the alternate setting also pass -fw_cfg name=opt/a3/pat3-uc-minus,file=enable-pat3. The one-byte file is included. The firmware then sets PAT entry 3 to the architecturally defined UC-minus type. The default and altered runs use the same test kernel and firmware binary. Each driver can invoke a wrapper for these QEMU arguments through --qemu. The no-PAT run uses stock firmware and keeps the HPET device present.

Incomplete runs have their own directory. One attempt on the reviewed head ended during the first computation phase. Its exit status was not captured. One no-PAT run ended with host signal 9 during an absolute wait. A preceding test on the superseded f0d994df binary also ended during computation. Their serial output is preserved. The measured comparisons use completed runs. The two binaries and their pre/post-revision observations are identified separately.

References

- https://docs.kernel.org/timers/timekeeping.html
- https://www.intel.com/content/dam/www/public/us/en/documents/technical-specifications/software-developers-hpet-spec-1-0a.pdf
- https://docs.kernel.org/arch/x86/pat.html
- https://man7.org/linux/man-pages/man2/clock_nanosleep.2.html
- https://github.com/qemu/seabios/commit/a6ed6b701f0a57db0569ab98b0661c12a6ec3ff8

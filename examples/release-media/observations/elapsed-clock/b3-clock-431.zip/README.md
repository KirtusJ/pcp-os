# B3 elapsed-clock observations

Candidate commit f0d994df39bf41a0c7716f911ca9fd10e7829480 (PR 431), based on master a4797647839a04ca00c9b6346867cdb34a2bd955. The included ELF is the model-free kernel with the default 1 MiB relocation. It is for the comparison guest. The physical-media pipeline uses a separate relocation and binding.

The four v4 folders used the same uninstrumented kernel and A3's clock.elf (372b77ffedf0b065ed43b20e01318f58535cdbcaeb590361d67fdbd80e45fc51). Each JSON contains the host monotonic and guest nanosecond readings for each phase. The host reader includes serial transport and scheduling delays. QEMU 10.0.13 TCG, q35, one vCPU and 192 MiB. The contended runs assign QEMU nice +8 on a CPU shared with an integer workload and put the serial reader on another CPU.

To repeat, extract A3's elapsed-clock-control.zip from commit 93f78cfb54afee2bf0284451ee1ca2c0e92e0204 under examples/release-media/observations/elapsed-clock/. In the extracted directory run the following commands, replacing KERNEL.ELF with the candidate's absolute path. Use previously absent output folders.

    python compare.py KERNEL.ELF normal
    python contended.py KERNEL.ELF load --vm-nice 8
    python compare.py KERNEL.ELF fallback --machine q35,hpet=off
    python contended.py KERNEL.ELF fallback-load --machine q35,hpet=off --vm-nice 8

For the interrupt-gap experiment apply irq-gap.patch in a clean checkout of the candidate. Build via sh PCP_OS_Rust/crates/pcpos-kernel/run.sh build and run the following with that observer ELF. The host sleeps on an independent monotonic clock, then releases the guest via a byte on the serial port. The counters straddle that release and include the marker transmission. gap.py checks for a successful boot, zero delivered scheduling ticks and agreement within 250 ms on HPET. The observed error was below 2 ms. The original observer ELF had SHA-256 758e569acf79b12df6f43533816fd5d04b021e3908583d1e3482af39ee663ee3.

    timeout 60 python gap.py OBSERVER.ELF gap-on
    timeout 60 python gap.py OBSERVER.ELF gap-off --no-hpet

The prototype log is an earlier negative control. Under contention the old boot assertion required exactly 51 delivered idle interrupts for a 50 ms sleep even when elapsed time used the HPET. The candidate separately checks the guest's actual deadline and preserves the old exact-tick assertion on the PIT fallback.

All runs here used emulation. C3 owns WHPX and physical timing.

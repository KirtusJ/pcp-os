"""Hold IRQ delivery off until a byte arrives from a separately timed host process."""
import argparse, json, subprocess, time
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('kernel',type=Path);p.add_argument('out',type=Path);p.add_argument('--no-hpet',action='store_true')
a=p.parse_args();a.out.mkdir()
q=['qemu-system-x86_64','-machine','q35'+(',hpet=off' if a.no_hpet else ''),'-accel','tcg','-cpu','max','-m','192M','-display','none','-no-reboot','-nic','none','-kernel',str(a.kernel.resolve()),'-append','then=off','-monitor','none','-serial','stdio','-device','isa-debug-exit,iobase=0xf4,iosize=0x04']
with (a.out/'serial.log').open('wb') as fp,subprocess.Popen(q,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL) as vm:
 try:
  for line in vm.stdout:
   now=time.perf_counter_ns();fp.write(line)
   if b'IRQ-GAP-BEGIN' in line:
    begin=now;time.sleep(2.0);vm.stdin.write(b'X');vm.stdin.flush()
   if b'IRQ-GAP-END ' in line:
    delta,ticks=map(int,line.split(b'IRQ-GAP-END ')[1].split())
    result=dict(host_ns=now-begin,guest_ns=delta,delivered_ticks=ticks)
  assert vm.wait(timeout=3)==33
 finally:
  if vm.poll() is None: vm.kill()
  vm.wait()
assert result['delivered_ticks']==0 and result['host_ns']>=2_000_000_000
assert (result['guest_ns']==0 if a.no_hpet else abs(result['host_ns']-result['guest_ns'])<250_000_000),result
(a.out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(result)

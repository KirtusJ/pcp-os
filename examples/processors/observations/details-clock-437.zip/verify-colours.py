"""Compare every clock-glyph pixel to the font from the reviewed commit."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from PIL import Image
from collections import Counter
import ast, hashlib, io, json, sys
root = Path(sys.argv[1])
out = Path(sys.argv[2])
src = root/'plain/src/PCP_OS_Rust/crates/pcpos-kernel/src'
font = ast.literal_eval('['+(src/'font.rs').read_text().split(' = [',1)[1].split('];',1)[0]+']')
background = (0x10,0x28,0x3f)
colours={'HPET':(0x9f,0xb4,0xc8),'PIT':(0xe3,0xa2,0x4b)}
messages={'HPET':'elapsed clock: 64-bit ACPI HPET main counter','PIT':'elapsed clock: delivered PIT interrupts (elapsed time can be lost under load)'}
digest=lambda b:hashlib.sha256(b).hexdigest()
def spans(rows,sentence):
    for start,line in enumerate(rows):
        if not line.strip().startswith('elapsed clock:'):continue
        parts=[]
        for i in range(start,len(rows)):
            s=rows[i].strip()
            if not s:break
            parts.append((i,rows[i].index(s),s))
            joined=' '.join(p[2] for p in parts)
            if joined==sentence:return parts
            if not sentence.startswith(joined+' '):break
    return []

def disagreements(image, parts, colour):
    mismatch=0
    for row,col,words in parts:
        for pos,letter in enumerate(words):
            for j,alpha in enumerate(font[ord(letter)-32]):
                expected=tuple((b*(255-alpha)+c*alpha+127)//255 for b,c in zip(background,colour))
                actual=image.getpixel(((col+pos)*10+j%10,row*20+j//10))
                mismatch+=actual!=expected
    return mismatch

files={'official-check.txt':(root/'D1-D7.txt').read_bytes()}
report={}
cases=[('stock/plain-1','HPET'),('stock/no-hpet','PIT'),('stock/short-1024x600','HPET'),('stock/narrow-640x480','HPET'),('fallback-short','PIT'),('fallback-640','PIT'),('fallback-small','PIT')]
for key,clock in cases:
    directory=root/key
    readback=(directory/'serial.txt').read_bytes()
    assert [s for s in readback.decode().splitlines() if s.startswith('elapsed clock:')]==[messages[clock]]
    for file in sorted(directory.glob('details-*.txt')):
        rows=file.read_text().splitlines()
        parts=spans(rows,messages[clock])
        if not parts:continue
        with Image.open(file.with_suffix('.ppm')) as frame:
            frame=frame.convert('RGB')
            errors={kind:disagreements(frame,parts,colour) for kind,colour in colours.items()}
            assert errors[clock]==0 and errors['PIT' if clock=='HPET' else 'HPET']>0, (key,errors)
            width,height=frame.size
            box=(0,parts[0][0]*20,width,(parts[-1][0]+1)*20)
            png=io.BytesIO();frame.crop(box).save(png,'PNG')
            files[key+'/clock-band.png']=png.getvalue()
        files[key+'/visible-rows.txt']=file.read_bytes()
        files[key+'/serial.txt']=readback
        report[key]={'sentence':messages[clock],'capture':file.stem,'geometry':[width,height],'clock_row_locations':[p[0] for p in parts],'mismatching_pixels':errors,'text_rgb':list(colours[clock]),'pixels_examined':sum(len(p[2])*200 for p in parts),'screenshot_band':box}
        break
    assert key in report,key
meta={'commit':'42de0ca4b206dcba972e0687f10d5e95f236d054','source_tree':'063938341abe6621088f5a218b114630904de0f0','kernel_elf_sha256':{v:digest((root/v/'KERNEL.ELF').read_bytes()) for v in ['plain','full']},'matrix':report}
files['readback.json']=(json.dumps(meta,indent=2)+'\n').encode()
files['verify-colours.py']=Path(__file__).read_bytes()
files['SHA256SUMS']=''.join(digest(b)+'  '+p+'\n' for p,b in sorted(files.items())).encode()
with ZipFile(out,'w',ZIP_DEFLATED) as z:
    for p,b in sorted(files.items()):z.writestr(p,b)
with ZipFile(out) as z:assert z.testzip() is None and all(z.read(p)==b for p,b in files.items())
print({k:(v['capture'],v['clock_row_locations'],v['mismatching_pixels']) for k,v in report.items()})
print(out.stat().st_size,digest(out.read_bytes()))

from pathlib import Path
import sys,hashlib,os,shutil,subprocess,time,json,re
import numpy as np
from PIL import Image
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'ui/guest/tests'))
from qemu_smoke import Qemu

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
font_path=root/'ui/pcp-os/PCP_OS_Rust/crates/pcpos-kernel/src/font-2x.bin'
assert digest(font_path)=='754a70a3179a62fffc72e33ec462d9a1627f45531b3b2f3207edcd70d529429b'
font=np.frombuffer(font_path.read_bytes(),np.uint8).reshape(95,40,20)
small_path=font_path.with_name('font.rs')
small=np.array([[int(n) for n in re.findall(r'\d+',row)] for row in re.findall(r'^    \[(.*?)\],$',small_path.read_text(),re.M)],np.uint8).reshape(95,20,10)
def notice(im):
    w,h=im.size
    if min(w//960,h//540): num=min(w//960,h//540);den=1
    elif w*540<h*960:num,den=w,960
    else:num,den=h,540
    x0=(w-960*num//den)//2;y0=(h-540*num//den)//2
    X=lambda x:x0+x*num//den
    Y=lambda y:y0+y*num//den
    img=np.asarray(im.convert('RGB')); result=[]
    bg=np.array([16,40,63]);ink=np.array([227,162,75]);cache={}
    for i in range(70):
        at=535+6*i; x,y,xx,yy=X(at),Y(513),X(at+6),Y(523)
        if xx>w:break
        dw,dh=xx-x,yy-y
        if (dw,dh) not in cache:
            masks=np.empty((95,dh,dw),np.int32)
            face=font if dw>10 or dh>20 else small
            _,sh,sw=face.shape
            for dy,dx in np.ndindex(dh,dw):
                tile=face[:,dy*sh//dh:max((dy+1)*sh//dh,dy*sh//dh+1),dx*sw//dw:max((dx+1)*sw//dw,dx*sw//dw+1)]
                masks[:,dy,dx]=tile.sum(axis=(1,2))//(tile.shape[1]*tile.shape[2])
            a=masks[...,None]; colors=((bg*(255-a)+ink*a+127)//255).astype(np.uint8)
            cache[(dw,dh)]={c.tobytes():chr(j+32) for j,c in enumerate(colors)}
        result.append(cache[(dw,dh)].get(img[y:yy,x:xx].tobytes(),'�'))
    return ''.join(result).rstrip()
def check(width,height,old):
    d=root/('modal-'+str(width)+('-parent' if old else '-candidate'));d.mkdir(exist_ok=False)
    k=root/('older' if old else 'kernel')/'PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32'
    m=subprocess.check_output([sys.executable,root/'kernel/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py',k],text=True).strip()
    shutil.copyfile(k,d/'kernel.elf32');shutil.copyfile(root/'tailorbird.elf',d/'tailorbird.elf')
    vm=Qemu(Path('kernel.elf32'),Path('tailorbird.elf'),d,'q35',f'image={m} auto=tailorbird.elf then=off desktop={width}x{height} propose_image={digest(d/"tailorbird.elf")}')
    records={}
    def wait(s):
        limit=time.monotonic()+25
        while s not in vm.serial():
            if time.monotonic()>limit:raise RuntimeError((s,vm.serial()[-400:]))
            time.sleep(.1)
    def snap(name):
        time.sleep(.45)
        vm.screenshot(name)
        path=d/(name+'.ppm')
        with Image.open(path) as im:
            assert im.size==(width,height),(im.size,width,height)
            im.save(d/(name+'.png')); records[name]=notice(im)
        path.unlink()
        (d/'decoded.json').write_text(json.dumps(records,indent=2)+'\n')
    try:
        wait('Tailorbird first frame presented')
        for c in 'note':vm.key(c)
        vm.key('alt','n');snap('kernel-question')
        vm.key('alt','g');wait('DENIED by the person');snap('question-dismissed')
        assert 'GAVE UP proposing' not in vm.serial()
        vm.key('alt','g');snap('first-foreground-press')
        assert 'GAVE UP proposing' not in vm.serial()
        vm.key('alt','g')
        wait('tailorbird: PCP OS did not confirm' if old else 'tailorbird: PCP OS confirmed')
        snap('after-pair')
        if not old:
            n=vm.serial().count('GAVE UP proposing');assert n==1
            vm.key('alt','n');snap('post-give-up')
            assert vm.serial().count('GAVE UP proposing')==1
            assert not any(l.startswith('proposal ') and 'CREATED' in l for l in vm.serial().splitlines())
        vm.key('esc')
        assert vm.proc.wait(timeout=30)==33
    finally:vm.stop()
    print(width,height,old,records,flush=True)
if __name__=="__main__":
 for w,h,old in [(800,600,False),(1920,1080,False),(800,600,True)]:check(w,h,old)

from modal import *
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor
dst=root/os.environ.get('B3_GUEST_SOURCE','fixed-7fd9fe01');tools=Path(os.environ.get('B3_BIN_DIR','/tmp/b3-ui-sweep-head/x86_64-unknown-none/release')); fixed=os.environ.get('B3_LEGEND_FIXED')=='yes'
kernel=root/'current-kernel/PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32'
SHA=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
RGB=lambda color:np.array([(color>>i)&255 for i in (16,8,0)],dtype=np.int32)
@lru_cache(None)
def book(dw,dh,bg,fg):
 face=font if dw>10 or dh>20 else small;_,sh,sw=face.shape;coverage=np.zeros((95,dh,dw),np.int32)
 for y,x in np.ndindex(dh,dw):
  sl=face[:,y*sh//dh:max((y+1)*sh//dh,y*sh//dh+1),x*sw//dw:max((x+1)*sw//dw,x*sw//dw+1)]
  coverage[:,y,x]=sl.sum(axis=(1,2))//(sl.shape[1]*sl.shape[2])
 background=RGB(bg) if isinstance(bg,int) else np.array(bg,dtype=np.int32)[:,None,:]
 a=coverage[...,None];pixels=((background*(255-a)+RGB(fg)*a+127)//255).astype(np.uint8)
 return {m.tobytes():chr(32+j) for j,m in enumerate(pixels)}
def read(im,x,y,size,text,fg,bg=0x18364f):
 w,h=im.size;num=min(w//960,h//540);den=1
 if not num:num,den=(w,960) if w*540<h*960 else (h,540)
 X=lambda n:(w-960*num//den)//2+n*num//den;Y=lambda n:(h-540*num//den)//2+n*num//den
 dw,dh={1:(6,12),2:(10,20)}[size];a=np.asarray(im);out=''
 for i in range(len(text)):
  left,right=X(x+i*dw),X(x+(i+1)*dw);top,bottom=Y(y),Y(y+dh)
  assert 0<=left<right<=w and 0<=top<bottom<=h
  base=tuple(tuple(int(v) for v in row) for row in a[top:bottom,X(905),:3]) if x==872 and y==244 else bg
  out+=book(right-left,bottom-top,base,fg).get(a[top:bottom,left:right,:3].tobytes(),'~')
 return out
SOFT=0x9fb4c8;GROUND=0x10283f;AMBER=0xe3a24b;GOOD=0x8fe0c2
def observe(case):
 width,lane=case;h=600 if width==800 else 1080
 d=dst/(os.environ.get('B3_SCAN_PREFIX','')+lane+'-'+str(width));d.mkdir(exist_ok=False);k=d/'kernel.elf32';os.link(kernel,k)
 elf=tools/'tailorbird';worker=tools/'talk-test-worker';shutil.copyfile(elf,d/'tailorbird.elf')
 m=subprocess.check_output([sys.executable,root/'kernel/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py',k],text=True).strip()
 cmd=f'image={m} auto=tailorbird.elf then=off desktop={width}x{h} propose_image={SHA(elf)}';init='tailorbird.elf'
 if lane=='ready':
  shutil.copyfile(worker,d/'talk-test-worker');cmd+=f' worker_for={SHA(elf)} worker_image={SHA(worker)}';init+=',talk-test-worker'
 vm=Qemu(Path('kernel.elf32'),init,d,'q35',cmd);seen={}
 def wait(s):
  until=time.monotonic()+35
  while s not in vm.serial():
   if time.monotonic()>until:raise RuntimeError((lane,width,s,vm.serial()[-600:]))
   time.sleep(.1)
 def snap(n,rows):
  time.sleep(.55);vm.screenshot(n);p=d/(n+'.ppm')
  with Image.open(p) as im:
   assert im.size==(width,h);im.save(d/(n+'.png'));seen[n]=[read(im,*row) for row in rows]
  p.unlink();(d/'decoded.json').write_text(json.dumps(seen,indent=2)+'\n')
  for row,found in zip(rows,seen[n]):
   if row[3]!=found:raise RuntimeError((lane,width,n,row[3],found))
 full='Taylor makes no more files until started again.'
 legend='\x22notes\x22 marks where new notes go'
 before_rows=[(600,196,1,legend,SOFT),(872,244,1,'notes',GOOD)]
 after_rows=[(600,196,1,' '*len(legend) if fixed else legend,SOFT),(872,244,1,' '*5 if fixed else 'notes',GOOD)]
 try:
  wait('Tailorbird first frame presented')
  if lane=='ready':wait('tailorbird: model service: ready')
  if lane=='note':
   for c in 'note':vm.key(c)
   vm.key('alt','n');time.sleep(.4);vm.key('f12');time.sleep(.3);vm.key('ret');wait('tailorbird: Made ')
   vm.key('alt','p');snap('before-give-up-projects',before_rows);vm.key('alt','p')
  vm.key('alt','g');vm.key('alt','g');wait('tailorbird: PCP OS confirmed')
  lamp=(796,26,2,'Talk only' if lane=='ready' else 'No new files',GOOD if lane=='ready' else AMBER,GROUND)
  if lane=='note':
   snap('earlier-note',[lamp,(420,384,1,full,SOFT)])
   vm.key('alt','p');snap('populated-projects',[lamp,*after_rows]);vm.key('ret');snap('active-project',[lamp,(440,196,1,full,SOFT)])
  else:
   first,second=('Type and press Enter to talk to','me. I make no more files now.') if lane=='ready' else ('You asked me to make no more','files. PCP OS holds me to it.')
   snap('greeting',[lamp,(420,316,2,first,SOFT),(420,340,2,second,SOFT),(420,370,1,'Start Taylor again from Programs to allow notes again.',SOFT)])
   if lane=='absent':
    vm.key('alt','p');snap('empty-projects',[lamp,(339,286,1,full,SOFT),after_rows[0]])
  vm.key('esc');assert vm.proc.wait(timeout=35)==33
 finally:vm.stop()
 print(width,lane,'verified',sum(len(rows) for rows in seen.values()),'lines',flush=True)
if __name__=="__main__":
 with ThreadPoolExecutor(3) as pool:
  fs=[pool.submit(observe,(w,s)) for w in [800,1920] for s in os.environ.get('B3_CASES','absent,ready,note').split(',')]
  for f in fs:f.result()

from modal import *
from concurrent.futures import ThreadPoolExecutor
elf=Path('/tmp/b3-ui-sweep-fixed/x86_64-unknown-none/release/tailorbird')
dst=root/'fixed-2a9cca10'
def observe(lane):
 d=dst/lane;d.mkdir()
 old=lane=='parent';candidate=root/('modal-800-parent' if old else 'modal-800-candidate')
 os.link(candidate/'kernel.elf32',d/'kernel.elf32');shutil.copyfile(elf,d/'tailorbird.elf')
 m=subprocess.check_output([sys.executable,root/'kernel/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py',d/'kernel.elf32'],text=True).strip()
 vm=Qemu(Path('kernel.elf32'),Path('tailorbird.elf'),d,'q35',f'image={m} auto=tailorbird.elf then=off desktop=800x600 propose_image={digest(elf)}');data={}
 def wait(s):
  end=time.monotonic()+30
  while s not in vm.serial():
   if time.monotonic()>end:raise RuntimeError((lane,s,vm.serial()[-400:]))
   time.sleep(.1)
 def snap(s):
  time.sleep(.55);vm.screenshot(s);f=d/(s+'.ppm')
  with Image.open(f) as im:im.save(d/(s+'.png'));data[s]=notice(im)
  f.unlink()
 try:
  wait('Tailorbird first frame presented')
  if lane=='conversation':
   for c in 'stop asking to make files':vm.key('spc' if c==' ' else c)
   vm.key('ret');snap('after-typed-request')
   for c in 'note':vm.key(c)
   vm.key('alt','n');snap('permission-question')
   assert 'GAVE UP proposing' not in vm.serial();vm.key('esc');wait('DENIED by the person')
  else:
   vm.key('alt','g');snap('armed');vm.key('shift');snap('after-shift')
   assert data['armed'].startswith('Press Alt+G again') and data['after-shift']=='',data
   vm.key('alt','g');snap('fresh-first');assert data['fresh-first']==data['armed'] and 'GAVE UP proposing' not in vm.serial()
   vm.key('alt','g');snap('fresh-second')
   expect='PCP OS did not confirm whether Taylor can still make files.' if old else 'PCP OS confirmed: Taylor makes no more files until started again.'
   assert data['fresh-second']==expect,data
   assert vm.serial().count('GAVE UP proposing')==(0 if old else 1)
  vm.key('esc');assert vm.proc.wait(timeout=30)==33
 finally:vm.stop()
 (d/'decoded.json').write_text(json.dumps(data,indent=2)+'\n');print(lane,data,flush=True)
with ThreadPoolExecutor(3) as pool:list(pool.map(observe,['parent','candidate','conversation']))

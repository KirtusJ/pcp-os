from modal import *
d=root/'modifier-dismissal';d.mkdir(exist_ok=False)
base=root/'modal-800-candidate'
for f in ['kernel.elf32','tailorbird.elf']:os.link(base/f,d/f)
k=d/'kernel.elf32'
m=subprocess.check_output([sys.executable,root/'kernel/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py',k],text=True).strip()
vm=Qemu(Path('kernel.elf32'),Path('tailorbird.elf'),d,'q35',f'image={m} auto=tailorbird.elf then=off desktop=800x600 propose_image={digest(d/"tailorbird.elf")}')
out={}
def snap(tag):
 time.sleep(1);vm.screenshot(tag)
 f=d/(tag+'.ppm')
 with Image.open(f) as im:
  out[tag]=notice(im);im.save(d/(tag+'.png'))
 f.unlink()
try:
 end=time.monotonic()+25
 while 'Tailorbird first frame presented' not in vm.serial():
  if time.monotonic()>end:raise RuntimeError('no frame')
  time.sleep(.1)
 vm.key('alt','g');snap('armed');vm.key('shift');snap('shift-only')
 vm.key('alt','g');snap('first-again')
 assert 'GAVE UP proposing' not in vm.serial()
 vm.key('alt','g');snap('second-again')
 assert vm.serial().count('GAVE UP proposing')==1
 vm.key('esc');assert vm.proc.wait(timeout=30)==33
finally:vm.stop()
(d/'decoded.json').write_text(json.dumps(out,indent=2)+'\n');print(out)

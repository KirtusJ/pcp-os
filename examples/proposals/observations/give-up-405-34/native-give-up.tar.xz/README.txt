Independent Director B3 QEMU observations for KirtusJ/pcp-os#405 and tailorbird#34.
Kernel d50d3a1293e222175231d5919e4d173ca1bd60c3 and immediate parent c3f899ad74e565de460e9fdccf4b0f87e2f5d2c3; Tailorbird 5355665d88ce1c7b49c47d9a16ea0dbb1871594c; PCP OS dependency ce5aed7757a416590b8071b52041bfa868d59fa5.
PPM images contain full unscaled QEMU scanout. decoded.json reads the kernel modal from the native 10x20 font and the amber app status from its appropriate 10x20 or 20x40 source face. An empty status read means no amber status text was decoded there. Read the serial for the pending question's refusal. No model was loaded in these UI boots.
Standard UI runner was unmodified. For the standard proposal suite only QMP transport was adapted from Unix socket to QMP stdio; no acceptance predicates changed. No optional companion and no register dump in this run. All captured emulator exit statuses were 33.
The original tested UI predates subsequent wording and repaint fixes.

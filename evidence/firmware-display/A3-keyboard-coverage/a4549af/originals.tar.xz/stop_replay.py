"""Read the stopped screens and final console counts independently from saved guest records."""
from pathlib import Path
import hashlib,json,re,runpy,sys
import numpy as np
src,root=map(lambda s:Path(s).resolve(),sys.argv[1:])
api=runpy.run_path(str(src/'examples/tester-cd/check_small_screens.py'))
glyphs=api['CHECK']['kernel_glyphs']()
font={ch:np.array(mask,dtype=bool).reshape(20,10) for mask,ch in glyphs.items()}
out={}
for p in sorted(root.glob('*x*/result.json')):
    f=p.parent
    meta=json.loads(p.read_text())
    size=meta['size'];w,h=map(int,size.split('x'))
    pic=(f/'stopped.ppm').read_bytes()
    assert hashlib.sha256(pic).hexdigest()==meta['frame_sha256']
    m,s,d,pixels=pic.split(b'\n',3)
    assert m==b'P6' and s==f'{w} {h}'.encode() and d==b'255' and len(pixels)==w*h*3
    rows=api['PINS']['read'](pic,glyphs)
    assert rows==(f/'decoded.txt').read_text().splitlines()
    mask=np.zeros((h,w),dtype=bool)
    for n,line in enumerate(rows):
        for i,ch in enumerate(line):mask[n*20:n*20+20,i*10:i*10+10]=font[ch]
    color=np.frombuffer(pixels,dtype='u1').reshape(h,w,3)
    assert np.array_equal(mask,(color!=color[0,0]).any(2))
    shown=' '.join(' '.join(rows).split());log=(f/'serial.txt').read_text()
    assert 'HLT=1' in (f/'cpu.txt').read_text()
    assert shown.startswith('PCP OS has stopped.') and shown.endswith('This kernel cannot switch the computer off. Hold its power button until it goes dark.')
    pauses=list(re.finditer(r'^  pass (.+)$',log,re.M))
    assert "register of its own start, verification and stop" in pauses[-1][1]
    assert bool(re.search(r'display: .+?\b'+size+r'\b',log))
    failed=re.search(r'(\d+) SELF-TEST\(S\) FAILED',log)
    visible=re.search(r'Verified: all (\d+) self-tests it ran passed\.',shown)
    bad=re.search(r'NOT VERIFIED: (\d+) self-test\(s\) failed\.',shown)
    delivered=len(pauses)
    assert (int(bad[1]) if bad else 0)==(int(failed[1]) if failed else 0)
    if failed:assert not visible
    else:assert visible and int(visible[1])+1==delivered
    no_keyboard='keyboard: no controller' in log
    assert ('No keyboard this kernel can use answered: it drives PS/2 keyboards only.' in shown)==no_keyboard
    out[f.name]={'visible_passed':int(visible[1]) if visible else None,'serial_passed':delivered,'visible_failed':int(bad[1]) if bad else None,'serial_failed':int(failed[1]) if failed else 0,'keyboard_reason':no_keyboard,'skipped_tests_shown':'Not run:' in shown,'cpu_halted':True}
assert len(out)==6
print(json.dumps(out,indent=2))

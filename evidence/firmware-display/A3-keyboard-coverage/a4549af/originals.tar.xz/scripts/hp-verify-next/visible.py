"""Compare native F5 and operating the same program across the two tracked keyboard configurations."""
import hashlib, json, re, runpy, subprocess, sys, time
from pathlib import Path
here=Path(__file__).resolve().parent
rt=here.parent
src=rt/'hp-count-fixed'
kind,size=sys.argv[1:]
w,h=map(int,size.split('x'))
out=here/(kind+'-'+size)
out.mkdir()
def sha(blob):return hashlib.sha256(blob).hexdigest()
def log():return serial.read_text(errors='replace') if serial.exists() else ''
stock=runpy.run_path(str(src/'examples/tester-cd/check_small_screens.py'))
glyph=stock['CHECK']['kernel_glyphs']()
opt=runpy.run_path(str(src/'examples/optical-disk-check/check.py'))
elf=rt/'hp-count-demo/kernel.elf32' if kind=='demo' else here/'default.elf32'
measurement=runpy.run_path(str(src/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](elf.read_bytes())
readiso=runpy.run_path(str(src/'examples/tester-cd/build.py'))['read_back']
app=readiso((rt/'a3-release314/queue/pcp-os-tester.iso').read_bytes())['rdesk.elf']
(out/'rdesk.elf').write_bytes(app)
serial=out/'serial.txt'
cpu=['-cpu','qemu64']
cmd=[rt/'bin/qemu-system-x86_64','-machine','pc','-accel','tcg',*cpu,'-m','128M','-vga','none','-device','VGA,vgamem_mb=64','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel',elf,'-initrd','rdesk.elf','-append',f'desktop={size} image={measurement}']
r=dict(size=size,kind=kind,kernel_sha256=sha(elf.read_bytes()),measurement=measurement,app_sha256=sha(app),passed=False)
with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        mon=opt['Monitor'](vm);mon.call('qmp_capabilities')
        def press(*keys):
            mon.key(*keys);time.sleep(.4)
        def capture(name):
            p=out/(name+'.ppm')
            old=None
            for _ in range(30):
                mon.call('screendump',filename=str(p));data=p.read_bytes()
                if data==old:break
                old=data;time.sleep(.2)
            else:raise ValueError(name)
            magic,shape,depth,pixels=data.split(b'\n',3)
            assert magic==b'P6' and depth==b'255' and shape==f'{w} {h}'.encode() and len(pixels)==w*h*3
            rows=stock['PINS']['read'](data,glyph)
            (out/(name+'.txt')).write_text('\n'.join(rows)+'\n')
            return rows,sha(data)
        opt['wait_for'](lambda:'desktop: '+size in log(),'desktop',60)
        assert measurement+' (measured; equal' in log()
        start=sum(l.startswith('  pass ') for l in log().splitlines())
        _,home=capture('home')
        press('f5')
        pages=[]; hashes=[]
        for i in range(1,35):
            rows,digest=capture('verification-'+str(i))
            if hashes and digest==hashes[-1]:break
            hashes.append(digest);pages.append(rows)
            if not any('Up/Down scroll' in s for s in rows):break
            press('down')
        assert pages
        merged=[];lines=h//20
        for page in pages:
            first,per=(3,lines-6) if lines>=14 else (1,lines-2)
            part=page[first:first+per]
            overlap=max((k for k in range(1,min(len(part),len(merged))+1) if merged[-k:]==part[:k]),default=0)
            if merged:assert overlap>0
            merged+=part[overlap:]
        text=' '.join(' '.join(merged).split())
        assert f'Verified at start: all {start} self-tests passed.' in text
        reason='Not run at start: the six tests that press keys, because this keyboard controller does not replay keys for a test.'
        assert (reason in text)==(kind=='demo')
        assert ('the self-tests that press keys were not run: this keyboard controller does not replay keys for a test' in log())==(kind=='demo')
        (out/'verification-complete.txt').write_text(text+'\n')
        press('esc');_,back=capture('home-returned');assert back==home
        press('spc');selection,_=capture('programs')
        assert any('rdesk.elf' in line for line in selection)
        press('ret');opt['wait_for'](lambda:'state=NONE store=New queue' in log(),'Queue Desk',60)
        for k in ('n','k','e','y','s','ret'):press(k)
        opt['wait_for'](lambda:'state=ACTIVE store=Session save' in log(),'Queue Desk save',40)
        p=out/'saved-label.ppm'
        for _ in range(10):
            mon.call('screendump',filename=str(p))
            try:stock['CHECK']['check_desk_label'](p.read_bytes(),'keys');break
            except ValueError:time.sleep(.25)
        else:raise ValueError('missing saved label')
        press('esc');opt['wait_for'](lambda:'rdesk.elf ended DONE: exit 0' in log(),'queue closed',45)
        press('esc');press('f10');power,_=capture('power')
        assert not stock['power_problems'](power)
        press('ret');r['exit_code']=vm.wait(timeout=30)
        final=sum(l.startswith('  pass ') for l in log().splitlines())
        assert r['exit_code']==0 and final==start+1 and 'ALL SELF-TESTS PASS.' in log()
        r.update(passed=True,verification_pages=len(pages),startup_checks=start,final_checks=final,skipped_reason_on_f5=reason in text,app_label='keys')
    finally:
        if vm.poll() is None:vm.kill();vm.wait()
        (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(kind,size,r['startup_checks'],r['final_checks'])

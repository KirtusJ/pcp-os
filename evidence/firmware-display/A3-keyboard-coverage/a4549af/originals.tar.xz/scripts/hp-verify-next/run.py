from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,sys
here=Path(__file__).resolve().parent
def run(item):
 kind,size=item
 name=kind+'-'+size
 cmd=[here.parent/'desk-build/release/pcp-delegate',here/'tasks.redb','visible-'+name,'Read F5 and enter a request through the virtual keyboard at '+name,'--',sys.executable,'-IB',here/'visible.py',kind,size]
 with (here/(name+'.log')).open('w') as log:
  code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
 print(name,code,flush=True)
 return code
with ThreadPoolExecutor(max_workers=2) as pool:
 codes=list(pool.map(run,[(k,s) for s in ['320x200','1920x1080'] for k in ['demo','default']]))
sys.exit(any(codes))

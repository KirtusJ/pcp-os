import hashlib,json,runpy,sys
from pathlib import Path
here=Path(__file__).resolve().parent
source=here.parent/'hp-count-fixed'
build=here.parent/'hp-count-work/tester'
receipt=json.loads((build/'receipt.json').read_text())
assert receipt['source_commit']=='a4549af9c9ead717d32bcb2154b66fdf2445cd3c' and not receipt['uncommitted_changes']
image=(build/'pcp-os-tester.iso').read_bytes()
assert hashlib.sha256(image).hexdigest()==receipt['iso_sha256']
data=runpy.run_path(str(source/'examples/tester-cd/build.py'))['read_back'](image)['kernel.elf32']
(here/'default.elf32').write_bytes(data)
print(receipt['source_commit'],receipt['iso_sha256'],hashlib.sha256(data).hexdigest())

"""Compare duplicate-preserving records for all six boots in the counts directory."""
from collections import Counter
from pathlib import Path
import json,sys
root=Path(sys.argv[1])
def read(kind,mode):
 p=root/(kind+'-'+mode+'-checked')
 s=(p/'serial.txt').read_text();m=json.loads((p/'receipt.json').read_text())
 assert m['kind']==kind and m['mode']==mode and m['exit']==33
 assert 'ALL SELF-TESTS PASS.' in s and m['append'] in s
 checks=Counter(line[7:] for line in s.splitlines() if line.startswith('  pass '))
 assert sum(checks.values())==m['passed_checks']
 return checks
out={}
full=read('default','normal')
for kind in ('default','demo','no-controller'):
 a=read(kind,'normal');b=read(kind,'opt-in')
 gain=Counter({'a built-in address space gives its frames back at every allocation cutoff and after a successful construction':1})
 assert b-a==gain and not a-b
 omitted=full-a
 assert not a-full and sum(omitted.values())==(0 if kind=='default' else 6)
 assert a['rejected batch returns the frames of every member']==3
 assert any('sleeps 50 ms' in line for line in a)
 assert any('name of 32 bytes' in line for line in a) and any('name of 33 bytes' in line for line in a)
 assert any('cannot be admitted as a task leaves no memory behind' in line for line in a)
 out[kind]={'normal':sum(a.values()),'opt_in':sum(b.values()),'omitted':dict(omitted)}
assert out['demo']['omitted']==out['no-controller']['omitted']
print(json.dumps(out,indent=2))

"""Compare which named checks actually run on default and demonstration kernels."""
import hashlib,json,runpy,subprocess,sys
from pathlib import Path
here=Path(__file__).resolve().parent
rt=here.parent
kind,mode=sys.argv[1:]
source=rt/"hp-screen-source"
out=here/(kind+"-"+mode+"-checked")
out.mkdir()
kernel=rt/"hp-replay/kernel.elf32" if kind=="demo" else rt/"hp-screen/320x200-keys-match/kernel.elf32"
measured=runpy.run_path(str(source/"PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py"))["measure"](kernel.read_bytes())
append="image="+measured+" then=off"+(" test=frame-cutoffs" if mode=="opt-in" else "")
cmd=[rt/"bin/qemu-system-x86_64","-machine","pc","-accel","tcg","-cpu","max","-m","128M","-smp","1","-nic","none","-display","none","-monitor","none","-serial","stdio","-no-reboot","-device","isa-debug-exit,iobase=0xf4,iosize=0x04","-kernel",kernel,"-append",append]
with (out/"serial.txt").open("wb") as s,(out/"stderr.txt").open("wb") as e:
    ret=subprocess.run(cmd,stdout=s,stderr=e,timeout=100).returncode
log=(out/"serial.txt").read_text()
assert ret==33 and "ALL SELF-TESTS PASS." in log and not any(i.startswith("  FAIL") for i in log.splitlines())
command_lines=[s for s in log.splitlines() if s.startswith("command line: ")]
assert len(command_lines)==1 and command_lines[0].endswith(" "+append)
assert measured+" (measured; equal" in log
expect="a built-in address space gives its frames back at every allocation cutoff and after a successful construction"
actual=[i[7:] for i in log.splitlines() if i.startswith("  pass ")]
assert (expect in actual)==(kind=="default" and mode=="opt-in")
assert len(actual)==(59 if kind=="demo" else 72+int(mode=="opt-in"))
(out/"receipt.json").write_text(json.dumps({"kind":kind,"mode":mode,"append":append,"kernel_sha256":hashlib.sha256(kernel.read_bytes()).hexdigest(),"exit":ret,"passed_checks":len(actual),"requested_check_recorded":expect in actual},indent=2)+"\n")
print(kind,mode,len(actual),expect in actual)

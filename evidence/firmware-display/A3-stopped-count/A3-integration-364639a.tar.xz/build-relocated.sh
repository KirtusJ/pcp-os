set -eu
w="$1"; out="$2"; rt="$3"
old_build=/workspace/scratch/edecb50126f6/boot-audit/uefi-bios-regression
export CARGO_HOME="$out/cargo" CARGO_NET_OFFLINE=true
export PATH="$rt/register-live/rust197/bin:$rt/register-live/rust197/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$old_build/bin:$rt/root/usr/bin:$PATH"
export LD_LIBRARY_PATH="$rt/lib" PCPOS_KERNEL_STAGE=/dev/shm/pcp-a3-peer-362/build
cd "$w/PCP_OS_Rust/crates/pcpos-kernel"
for profile in default; do
    feature="$profile"
    if [ "$profile" = default ]; then feature=""; fi
    PCPOS_KERNEL_FEATURES="$feature" sh run.sh build > "$out/build-$profile.log" 2>&1
    cp target/pcpos-kernel.elf32 "$out/$profile.elf32"
done

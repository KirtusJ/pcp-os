"""Verify the four virtual boots made with tree 5a01a8797a396c479569015f0f92931c8f14452d."""
from pathlib import Path
import hashlib,json,re,sys
base=Path(__file__).resolve().parent
src=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(src/'examples/firmware-owned-uefi'))
from refusal_screen import matches
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
image=json.loads((base/'image.json').read_text())
for n in ('std-128','ordinary','memory-refused','guard-refused'):
    d=base/'guests'/n;r=json.loads((d/'result.json').read_text());serial=(d/'serial.txt').read_text();trace=(d/'firmware.txt').read_text()
    passed=len(re.findall(r'^  pass ',serial,re.M))
    if n=='std-128':
        assert r['passed'] and r['self_tests']==passed==72 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
        assert image['measurement'] in serial and 'owned-handoff' in trace
        assert all(not any(i['counter_deltas']['sentinel'].values()) for i in r['intervals'])
        continue
    assert r['exit']==0 and r['usb_before']==r['usb_after']==image['usb_sha256']
    a,b=r['snapshots'][-2:]
    assert a['stage']=='selected' and b['stage']=='end'
    assert a['counters']['sentinel']==b['counters']['sentinel']
    assert b['counters']['sentinel']['rd_operations']==48 and b['counters']['sentinel']['rd_bytes']==359424
    assert not any(v for k,v in b['counters']['sentinel'].items() if k not in ('rd_operations','rd_bytes'))
    assert a['vars_sha256']==b['vars_sha256']==sha(d/'end-vars.fd')==sha(d/'selected-vars.fd')
    assert a['nvme_sha256']==b['nvme_sha256']=='16963acd2f53b44c46fd01314a7b40d9e08933fb9929091bc3b9315e272d364c'
    shutdown=any(e.get('event')=='SHUTDOWN' and e['data']=={'guest':True,'reason':'guest-shutdown'} for e in r['events'])
    assert shutdown==(n!='guard-refused')
    if n=='ordinary':
        assert passed==66 and 'owned-handoff' in trace and image['measurement'] in serial
    elif n=='guard-refused':
        assert passed==0 and not trace and 'Press any key to continue...' in serial
        assert (d/'end.png').read_bytes()==(d/'selected.png').read_bytes()
    else:
        assert not passed and 'owned-handoff' not in trace and 'handoff-refused' in trace
        assert 'refusal_watchdog_status=0000000000000000' in trace and 'refusal-power-confirmed' in trace
        for s in ('refusal','unchanged','question','cancelled','still-cancelled','new-question'):
            prompt='Switch off? Enter switches off. Esc cancels.' if 'question' in s else 'Press F10 to request power off.'
            assert matches((d/(s+'.ppm')).read_bytes(),prompt)
print('72 and 66 verified; both firmware refusal paths and all six frames verified')

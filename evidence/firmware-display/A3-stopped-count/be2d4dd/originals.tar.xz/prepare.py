import hashlib,json,runpy,sys
from pathlib import Path
here=Path(__file__).resolve().parent
source=here.parent/'hp-closed-src'
build=here.parent/'hp-closed/cd'
receipt=json.loads((build/'receipt.json').read_text())
assert receipt['source_commit']=='be2d4dd42521b6d49f7cdc3ab0d39682db6f22d3' and not receipt['uncommitted_changes']
image=(build/'pcp-os-tester.iso').read_bytes()
assert hashlib.sha256(image).hexdigest()==receipt['iso_sha256']
data=runpy.run_path(str(source/'examples/tester-cd/build.py'))['read_back'](image)['kernel.elf32']
(here/'default.elf32').write_bytes(data)
print(receipt['source_commit'],receipt['iso_sha256'],hashlib.sha256(data).hexdigest())

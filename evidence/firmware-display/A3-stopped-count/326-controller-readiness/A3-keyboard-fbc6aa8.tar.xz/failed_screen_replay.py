"""Read the actual final pass/fail numerators and denominators on independent stopped-screen cases."""
import hashlib,json,re,runpy,sys
from pathlib import Path
import numpy as np
src,base=(Path(z).resolve() for z in sys.argv[1:])
s=runpy.run_path(str(src/'examples/tester-cd/check_small_screens.py'))
glyph=s['CHECK']['kernel_glyphs']()
table={ch:np.array(mask,dtype=bool).reshape(20,10) for mask,ch in glyph.items()}
out={}
for n in ('320x200-none-wrong','1920x1080-none-wrong','320x200-keys-match'):
    p=base/n
    result=json.loads((p/'result.json').read_text())
    data=(p/'stopped.ppm').read_bytes()
    assert hashlib.sha256(data).hexdigest()==result['frame_sha256']
    decoded=s['PINS']['read'](data,glyph)
    assert decoded==(p/'decoded.txt').read_text().splitlines()
    body=' '.join(' '.join(decoded).split())
    serial=(p/'serial.txt').read_text()
    passed=sum(l.startswith('  pass ') for l in serial.splitlines())
    failed=sum(l.startswith('  FAIL ') for l in serial.splitlines())
    assert 'HLT=1' in (p/'cpu.txt').read_text()
    assert "the kernel's register of its own start, verification and stop verifies and replays without a problem" in serial
    assert body.endswith("Hold its power button until it goes dark.")
    if failed:
        match=re.search(r'NOT VERIFIED: (\d+) of (\d+) self-tests failed\.',body)
        assert match and tuple(map(int,match.groups()))==(failed,passed+failed)==(1,41)
        assert '1 SELF-TEST(S) FAILED' in serial
    else:
        assert passed==72 and 'Verified: all 72 self-tests it ran passed.' in body
    magic,shape,depth,raw=data.split(b'\n',3)
    w,h=map(int,shape.split())
    pixels=np.frombuffer(raw,dtype='u1').reshape(h,w,3)
    expected=np.zeros((h,w),bool)
    for y,line in enumerate(decoded):
        for x,ch in enumerate(line):expected[y*20:y*20+20,x*10:x*10+10]=table[ch]
    assert np.array_equal(expected,(pixels!=pixels[0,0]).any(2))
    out[n]={'passed':passed,'failed':failed,'displayed_total':passed+failed,'cpu_halted':True}
print(json.dumps(out,indent=2))

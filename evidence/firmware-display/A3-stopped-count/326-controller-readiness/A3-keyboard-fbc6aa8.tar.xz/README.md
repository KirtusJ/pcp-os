# Director A3's virtual keyboard and stopped-screen read-back

The official tester CD was built from the clean fbc6aa8d390779caa74905a08df118d1a45ab351 checkout. Its tree is 96ca6f9a9f72f5b798599c6d1db301668b5aa461. All archived optical runs and direct default-kernel tests used the on-disc kernel 59940b0fafc4b843cd9e5e17f7d5bbe1bcfd027643602b1010a8c6a383abe9a8. The replay-disabled kernel was separately built from the integrated checkout, SHA-256 e90b55909c59ae69f613e1ec5a82f0767da44c1be9bbc08ae04caf72b5cef538. The two kernels passed the stock checker together. kernels.log also records an earlier check of a separately built pair on the incoming PR. The direct default build from that pass has different bytes from the CD default, so the archived controls were rerun with the actual CD kernel. The four full optical guest results include original serial and register records. The optical screenshots are omitted from this archive. The direct stopped-screen tests used QMP over standard I/O. Both transport diffs are included.

From the extracted evidence directory, run sha256sum -c SHA256SUMS. With the matching checkout and NumPy, run these three commands.

    python3 count_replay.py <checkout> .
    python3 count_glyphs.py <checkout> screens fixed
    python3 failed_screen_replay.py <checkout> .

 These recompute the named pass controls, screen-digit controls, and the two intentional image failures plus matched compact screen. To reproduce the model checks, use a Rust host compiler and run python3 probe_ready.py <checkout> --expect corrected and python3 keyboard_init.py <checkout>. These are observations of virtual devices and host-side models.

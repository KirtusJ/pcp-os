"""Change only the displayed count on genuine stopped frames and run the stock predicate."""
import ast, json, re, runpy, sys
from pathlib import Path
import numpy as np
src, records = (Path(i).resolve() for i in sys.argv[1:3])
checker=runpy.run_path(str(src/"examples/tester-cd/check_stopped_screen.py"))
glyphs=checker["CHECK"]["kernel_glyphs"]()
font=(src/"PCP_OS_Rust/crates/pcpos-kernel/src/font.rs").read_text()
alpha=np.array(ast.literal_eval("["+font.split(" = [",1)[1].split("];",1)[0]+"]"),dtype=np.uint32).reshape(95,20,10)
ground=np.array([0x10,0x28,0x3F],dtype=np.uint32)
ink=np.array([0x8F,0xE0,0xC2],dtype=np.uint32)
def glyph(char):
    a=alpha[ord(char)-32][:,:,None]
    return ((ground*(255-a)+ink*a+127)//255).astype('u1')
rx=re.compile(r'Verified: all (\d+) self-tests it ran passed\.')
expected_initial=sys.argv[3]
assert expected_initial in ('prior','fixed')
out={}
for case in sorted(records.iterdir()):
    if not case.is_dir() or not (case/"stopped.ppm").is_file():continue
    log=(case/"serial.txt").read_text()
    if "ALL SELF-TESTS PASS." not in log:continue
    count=sum(s.startswith("  pass ") for s in log.splitlines())
    assert any(s.startswith("  pass the kernel's register of its own start, verification and stop") for s in log.splitlines())
    keyboard="keyboard: a PS/2 controller answered" in log
    frame=(case/"stopped.ppm").read_bytes()
    rows=checker["PINS"]["read"](frame,glyphs)
    m=rx.search(checker["text_of"](rows))
    assert m
    shown=m[1]
    y=next(n for n,line in enumerate(rows) if "Verified: all " in line)
    x=rows[y].index("Verified: all ")+len("Verified: all ")
    magic,shape,depth,data=frame.split(b"\n",3)
    w,h=map(int,shape.split()); original=np.frombuffer(data,dtype="u1").reshape(h,w,3)
    assert (int(shown)==count)==(expected_initial=='fixed')
    changed={}
    for label,value in [('original',shown),('corrected',str(count)),('one short',str(count-1)),('wrong number',str(count+7)),('last digit erased',shown[:-1]+' '),('both erased',' '*len(shown))]:
        buffer=original.copy()
        assert len(value)==len(shown)
        for i,digit in enumerate(value):
            buffer[y*20:y*20+20,(x+i)*10:(x+i+1)*10]=glyph(digit)
        raw=buffer.tobytes()
        if label=='original':assert raw==data
        ppm=b'\n'.join([magic,shape,depth,raw])
        read=checker["PINS"]["read"](ppm,glyphs)
        expected=rows.copy();expected[y]=(rows[y][:x]+value+rows[y][x+len(value):]).rstrip()
        assert read==expected
        found=checker["stopped_problems"](read,keyboard,count)
        observed=rx.search(checker["text_of"](read))
        oracle=bool(observed and int(observed[1])==count)
        changed[label]={"digits":value,"stock_accepts":not found,"agrees_with_serial":oracle}
        assert bool(not found)==oracle and oracle==(value==str(count)),(case,value,found,oracle)
        if not oracle: assert found==[f'the count on the screen is not the {count} passes of the serial log']
    out[case.name]={"serial":count,"display_original":int(shown),"controls":changed}
assert len(out)==4
print(json.dumps(out,indent=2))

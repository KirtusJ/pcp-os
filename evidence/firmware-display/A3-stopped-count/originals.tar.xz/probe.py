"""Observe the final screen of a halted virtual PC with or without a keyboard controller."""
from pathlib import Path
import hashlib,json,re,runpy,subprocess,sys,time
import numpy as np

here=Path(__file__).resolve().parent
rt=here.parent
source=rt/'hp-screen-source'
size,keyboard,measurement=sys.argv[1:]
good=measurement=='match'
present=keyboard=='keys'
w,h=map(int,size.split('x'))
case='-'.join([size,keyboard,measurement])
out=here/case
out.mkdir()
log_path=out/'serial.txt'
def log():
    return log_path.read_text(errors='replace') if log_path.exists() else ''
def digest(data):return hashlib.sha256(data).hexdigest()
receipt=json.loads((here/'tester/receipt.json').read_text())
image=(here/'tester/pcp-os-tester.iso').read_bytes()
assert digest(image)==receipt['iso_sha256']
files=runpy.run_path(str(source/'examples/tester-cd/build.py'))['read_back'](image)
(out/'kernel.elf32').write_bytes(files['kernel.elf32'])
(out/'surf.elf').write_bytes(files['surf.elf'])
opt=runpy.run_path(str(source/'examples/optical-disk-check/check.py'))
stock=runpy.run_path(str(source/'examples/tester-cd/check_small_screens.py'))
font=stock['CHECK']['kernel_glyphs']()
ink_by_char={char:np.array(mask,dtype=bool).reshape(20,10) for mask,char in font.items()}
value=receipt['kernel_measurement']
named=value if good else value[:-1]+('1' if value[-1]!='1' else '2')
cmd=[rt/'bin/qemu-system-x86_64','-machine','pc,i8042='+('on' if present else 'off'),'-accel','tcg','-cpu','qemu64,hypervisor=off','-m','128M','-vga','none','-device','VGA,vgamem_mb=64','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(log_path),'-no-reboot','-kernel','kernel.elf32','-initrd','surf.elf','-append',f'desktop={size} image={named}']
report={'source':receipt['source_commit'],'size':size,'keyboard':keyboard,'expected_measurement':measurement,'observed':False}
with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        mon=opt['Monitor'](vm);mon.call('qmp_capabilities')
        if present:
            opt['wait_for'](lambda:'desktop: '+size in log(),'desktop',60)
            time.sleep(.55)
            mon.key('f10');time.sleep(.6);mon.key('ret')
        opt['wait_for'](lambda:bool(re.search(r'(ALL SELF-TESTS PASS\.|\d+ SELF-TEST\(S\) FAILED)',log())),'final serial result',70)
        path=out/'stopped.ppm'
        flags=''
        end=time.monotonic()+20
        while time.monotonic()<end:
            flags=mon.call('human-monitor-command',**{'command-line':'info registers'})
            if 'HLT=1' in flags:break
            time.sleep(.15)
        report['cpu_halted']='HLT=1' in flags
        assert report['cpu_halted']
        (out/'cpu.txt').write_text(flags)
        time.sleep(.35)
        mon.call('screendump',filename=str(path));data=path.read_bytes()
        time.sleep(.4);mon.call('screendump',filename=str(path));assert path.read_bytes()==data
        mag,shape,depth,pix=data.split(b'\n',3)
        assert (mag,shape,depth,len(pix))==(b'P6',f'{w} {h}'.encode(),b'255',w*h*3)
        rows=stock['PINS']['read'](data,font)
        (out/'decoded.txt').write_text('\n'.join(rows)+'\n')
        text=' '.join(' '.join(rows).split())
        assert text.startswith('PCP OS has stopped.') and text.endswith('This kernel cannot switch the computer off. Hold its power button until it goes dark.'),text
        raster=np.frombuffer(pix,dtype='u1').reshape(h,w,3)
        actual=(raster!=raster[0,0]).any(axis=2)
        expected=np.zeros((h,w),dtype=bool)
        for y,line in enumerate(rows):
            for x,ch in enumerate(line):
                assert ch in ink_by_char,(y,x,ch)
                expected[y*20:(y+1)*20,x*10:(x+1)*10]=ink_by_char[ch]
        assert np.array_equal(actual,expected),'unread or leftover image outside the stopped-screen glyphs'
        final=log()
        assert re.search(r'display: [^\n]*?\b'+re.escape(size)+r'\b',final)
        assert (('keyboard: a PS/2 controller answered' in final) if present else ('keyboard: no controller' in final))
        passed=sum(line.startswith('  pass ') for line in final.splitlines())
        fail=re.search(r'(\d+) SELF-TEST\(S\) FAILED',final)
        failed=int(fail[1]) if fail else 0
        visible=re.search(r'Verified: all (\d+) self-tests it ran passed\.',text)
        bad=re.search(r'NOT VERIFIED: (\d+) self-test\(s\) failed\.',text)
        assert (failed==0) == good,(failed,case)
        report.update(observed=True,frame_sha256=digest(data),rows=[l.strip() for l in rows if l.strip()],whole_power_instruction=True,original_glyphs_only=True,serial_pass_count=passed,serial_fail_count=failed,visible_pass_count=int(visible[1]) if visible else None,visible_fail_count=int(bad[1]) if bad else None,keyboard_reason_visible='No keyboard this kernel can use answered: it drives PS/2 keyboards only.' in text,skipped_inputs_disclosed='Not run:' in text)
        mon.call('quit');vm.wait(timeout=10)
    finally:
        if vm.poll() is None:vm.kill();vm.wait()
        (out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(case,report)

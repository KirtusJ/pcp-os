from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,sys
here=Path(__file__).resolve().parent
samples=[('320x200','none','match'),('1920x1080','none','match'),('800x600','keys','match'),('320x200','none','wrong'),('1920x1080','none','wrong'),('320x200','keys','match')]
def run(args):
    name='-'.join(args)
    cmd=[here.parent/'desk-build/release/pcp-delegate',here/'tasks.redb',name,'Observe the stopped screen in a virtual PC for '+name,'--',sys.executable,'-IB',here/'probe.py',*args]
    with (here/(name+'.log')).open('w') as log:
        code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
    print(name,code,flush=True)
    return code
with ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(run,samples))
sys.exit(any(results))

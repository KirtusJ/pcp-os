"""Observe keyboard initialization with modeled status, data and timeouts. No hardware I/O."""
import os, subprocess,sys,tempfile,json
from pathlib import Path
src=Path(sys.argv[1]).resolve()
dev=(src/'PCP_OS_Rust/crates/pcpos-kernel/src/dev.rs').read_text()
body=dev[dev.index('fn controller_wait_write('):dev.index('fn keyboard_byte(')]
model=r"""
use std::collections::VecDeque;
use std::sync::Mutex;
use std::sync::atomic::{AtomicBool,Ordering};
struct Keyboard { present:bool }
struct Cell(Mutex<Keyboard>);
impl Cell {fn with<T>(&self,f:impl FnOnce(&mut Keyboard)->T)->T{f(&mut self.0.lock().unwrap())}}
static KEYBOARD:Cell=Cell(Mutex::new(Keyboard{present:false}));
static IRQ:AtomicBool=AtomicBool::new(false);
mod arch{
 use super::*;
 pub fn without_interrupts<T>(f:impl FnOnce()->T)->T{f()}
 pub fn interrupt_line_on(n:u8){assert_eq!(n,1);IRQ.store(true,Ordering::SeqCst);}
}
struct Controller{case:String, writes:Vec<(u16,u8)>, pending:VecDeque<(u8,u8)>, polled:u32, requests:usize}
static CTRL:Mutex<Option<Controller>>=Mutex::new(None);
fn in8(port:u16)->u8{
 let mut lock=CTRL.lock().unwrap();let c=lock.as_mut().unwrap();
 if port==0x60{return c.pending.pop_front().expect("read with empty buffer").1;}
 assert_eq!(port,0x64);
 c.polled+=1;
 if c.case=="absent"{return 0xff;}
 let last=c.writes.last().copied();
 let busy=match c.case.as_str(){
  "busy" => true,
  "busy-after-config" => last==Some((0x64,0x60)),
  "busy-final-byte" => last==Some((0x64,0xae)),
  "busy-after-first-off" => last==Some((0x64,0xad)),
  "busy-then-cleanup" => last==Some((0x64,0xad)) && c.polled<=100000,
  "ready-last-poll" => last==Some((0x64,0xae)) && c.polled<100000,
  "one-poll-late" => last==Some((0x64,0xae)) && c.polled<=100000,
  _=>false,
 };
 (if busy{2}else{0})|c.pending.front().map(|(status,_)|1|*status).unwrap_or(0)
}
fn out8(port:u16,v:u8){
 let mut lock=CTRL.lock().unwrap();let c=lock.as_mut().unwrap();c.polled=0;c.writes.push((port,v));
 if (port,v)==(0x64,0x20) && !matches!(c.case.as_str(),"no-config"|"busy") {c.pending.push_back((0,0x04));}
 if (port,v)==(0x60,0xf4) {
  c.requests+=1;
  let answer:&[(u8,u8)]=match c.case.as_str(){
   "silent" => &[], "unexpected" => &[(0,0xaa)], "resend" => &[(0,0xfe)],
   "resend-then-ack" if c.requests<2 => &[(0,0xfe)],
   "two-resends-then-ack" if c.requests<3 => &[(0,0xfe)],
   "aux-ack-only"=>&[(0x20,0xfa)], "aux-then-kbd-ack"=>&[(0x20,0x08),(0,0xfa)],
   "scan-then-kbd-ack"=>&[(0,0x1e),(0,0xfa)],
   "parity-ack"=>&[(0x80,0xfa)], "timeout-ack"=>&[(0x40,0xfa)],
   _=>&[(0,0xfa)]
  };
  c.pending.extend(answer.iter().copied());
 }
}
fn main(){
 for case in ["absent","busy","no-config","ack","silent","unexpected","resend","resend-then-ack","two-resends-then-ack","busy-after-config","busy-final-byte","busy-after-first-off","busy-then-cleanup","ready-last-poll","one-poll-late","aux-ack-only","aux-then-kbd-ack","scan-then-kbd-ack","parity-ack","timeout-ack"]{
  *CTRL.lock().unwrap()=Some(Controller{case:case.into(),writes:vec![],pending:VecDeque::new(),polled:0,requests:0});
  IRQ.store(false,Ordering::SeqCst);KEYBOARD.with(|k|k.present=false);
  let status=keyboard_init();
  let l=CTRL.lock().unwrap();let c=l.as_ref().unwrap();
  println!("{}|{:?}|{}|{}|{}|{}|{}",case,status,IRQ.load(Ordering::SeqCst),KEYBOARD.with(|k|k.present),c.requests,c.writes.iter().map(|(p,v)|format!("{:02X}={:02X}",p,v)).collect::<Vec<_>>().join(","),c.pending.iter().map(|(s,v)|format!("{:02X}/{:02X}",s,v)).collect::<Vec<_>>().join(","));
 }
}
"""
with tempfile.TemporaryDirectory() as td:
    d=Path(td);(d/'model.rs').write_text(model+body)
    subprocess.run([os.environ.get('RUSTC','rustc'),'--edition=2021',str(d/'model.rs'),'-o',str(d/'model')],check=True)
    out={}
    for line in subprocess.check_output([d/'model'],text=True).splitlines():
        name,verdict,irq,present,attempts,writes,left=line.split('|')
        assert irq==present
        out[name]={'status':verdict,'irq1':irq=='true','enable_requests':int(attempts),'writes':writes.split(',') if writes else [],'unread':left.split(',') if left else []}
    print(json.dumps(out,indent=2))

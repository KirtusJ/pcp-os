"""Read OVMF's one-time boot menu using disposable guest files and QMP."""
from pathlib import Path
import hashlib,json,shutil,sys,time,subprocess
here=Path(__file__).resolve().parent
rt=Path('/workspace/scratch/6fbc6fd5187a/runtime')
sys.path.insert(0,str(here/'src/examples/firmware-owned-uefi'))
from usb_trial import OPTICAL,usb_command
from usb_observer import capture,compare
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
class Guest:
    def __init__(self,name,allowed,ram=128):
        self.out=(here/'guests'/name).resolve()
        self.out.mkdir()
        fw=rt/'root/usr/share/OVMF'
        self.usb=here/'stock/usb.img'
        self.args=usb_command(str(rt/'bin/qemu-system-x86_64'),fw/'OVMF_CODE_4M.fd',fw/'OVMF_VARS_4M.fd',self.usb,self.out,ram)
        a=self.args
        a[a.index('-machine')+1]='q35,i8042=off'
        a[a.index('-boot')+1]='menu=on,splash-time=5000,strict=on'
        if not allowed:a[a.index('-cpu')+1]='max,-hypervisor'
        idx=next(i for i,v in enumerate(a) if v.startswith('usb-storage,'))
        a[idx]=a[idx].replace('bootindex=1','bootindex=2')
        idx=next(i for i,v in enumerate(a) if v.startswith('nvme,'))
        a[idx]+=',bootindex=1'
        a.extend(['-device','usb-kbd,id=external-usb-keyboard,bus=xhci.0'])
        shutil.copyfile(here/'internal-original.raw',self.out/'internal.raw')
        self.err=(self.out/'stderr.txt').open('wb')
        self.vm=subprocess.Popen(a,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.err)
        self.mon=OPTICAL['Monitor'](self.vm)
        self.rpc=self.mon.call
        self.rpc('qmp_capabilities')
        self.actions=[]; self.records=[]
        self.receipt={'args':a,'usb_before':sha(self.usb),'efi':sha(here/'stock/BOOTX64.EFI'),'code':sha(fw/'OVMF_CODE_4M.fd'),'firmware_template':sha(fw/'OVMF_VARS_4M.fd'),'qemu':subprocess.check_output([a[0],'--version'],text=True).splitlines()[0]}
        vols=self.rpc('query-block')
        assert next(d for d in vols if d.get('device')=='stick')['inserted']['ro']
        self.capture('before')
        self.rpc('cont')
    def key(self,k):
        self.actions.append(k);self.mon.key(k);time.sleep(.2)
    def serial(self):
        p=self.out/'serial.txt'
        return p.read_text(errors='replace') if p.exists() else ''
    def frame(self,name):
        self.rpc('screendump',filename=str(self.out/(name+'.png')),format='png')
    def capture(self,name):
        if self.rpc('query-status')['status']=='running':self.rpc('stop')
        self.records.append(capture(self.rpc,self.out,name))
        stats=next(q['stats'] for q in self.rpc('query-blockstats') if q.get('device')=='stick')
        self.records[-1]['usb_counters']={k:stats[k] for k in self.records[-1]['counters']['sentinel']}
        self.frame(name)
    def end(self):
        try:
            self.rpc('quit')
            self.vm.wait(timeout=12)
        finally:
            if self.vm.poll() is None:self.vm.kill();self.vm.wait()
            self.err.close()
            self.receipt.update(keys=self.actions,snapshots=self.records,events=self.mon.events,usb_after=sha(self.usb),exit=self.vm.returncode)
            (self.out/'result.json').write_text(json.dumps(self.receipt,indent=2)+'\n')

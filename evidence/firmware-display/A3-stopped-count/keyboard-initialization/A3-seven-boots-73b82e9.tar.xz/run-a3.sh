set -eu
rt="$1"; v=/dev/shm/pcp-a3-usb-73b
worker="$rt/desk-build/release/pcp-delegate"; register="$rt/a3-joint/tasks.redb"
"$worker" "$register" usb73brelocatedimage 'Prepare read-only QEMU image for the proposed combined tree' -- python3 -B "$v/make_usb.py" > "$v/build.log" 2>&1
"$worker" "$register" usb73bstandard 'Boot virtual USB with the emulated keyboard' -- python3 -B "$v/run_guest.py" std-128 > "$v/std.log" 2>&1 &
p_std=$!
"$worker" "$register" usb73bpicked 'Boot virtual USB without the emulated keyboard controller' -- python3 -B "$v/selected.py" ordinary > "$v/ordinary.log" 2>&1 &
p_ord=$!
wait "$p_std"
wait "$p_ord"
"$worker" "$register" usb73bguard 'Check virtual firmware returns to its boot menu' -- python3 -B "$v/selected.py" guard-refused > "$v/guard.log" 2>&1 &
p_guard=$!
"$worker" "$register" usb73bmemory 'Check virtual firmware allocation refusal and confirmed power off' -- python3 -B "$v/selected.py" memory-refused > "$v/memory.log" 2>&1 &
p_mem=$!
wait "$p_guard"
wait "$p_mem"
python3 -B "$v/replay.py" "$v/src"

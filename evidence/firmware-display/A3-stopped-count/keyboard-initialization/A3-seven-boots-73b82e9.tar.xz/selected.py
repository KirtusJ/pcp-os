from menu_vm import Guest,OPTICAL,sha
import sys,time
from refusal_screen import matches
mode=sys.argv[1];g=Guest(mode,mode!='guard-refused',128 if mode=='ordinary' else 64)
wait=OPTICAL['wait_for']
try:
    for _ in range(50):
        if 'Boot Maintenance Manager' in g.serial():break
        g.key('f2')
    assert 'Boot Maintenance Manager' in g.serial()
    g.key('down');g.key('down');g.key('ret')
    wait(lambda:'Boot Manager Menu' in g.serial(),'one-time menu',12)
    off=len(g.serial());g.key('down')
    wait(lambda:'Device Path' in g.serial()[off:] and '/USB' in g.serial()[off:],'selected USB path',12)
    g.capture('selected');g.rpc('cont')
    off=len(g.serial());g.key('ret')
    if mode=='ordinary':
        wait(lambda:g.rpc('query-status')['status']=='shutdown','USB guest shutdown',45)
        assert len([l for l in g.serial().splitlines() if l.startswith('  pass ')])==66
        assert 'owned-handoff' in (g.out/'firmware.txt').read_text()
    elif mode=='guard-refused':
        wait(lambda:'Press any key to continue...' in g.serial()[off:] and 'Boot Manager Menu' in g.serial()[off:],'firmware returned to picker',15)
        time.sleep(2)
        assert not (g.out/'firmware.txt').read_bytes()
    else:
        first='Press F10 to request power off.';question='Switch off? Enter switches off. Esc cancels.'
        def verify(stage,action,n):
            wait(lambda:g.serial()[off:].count(action)>=n,'firmware action',15)
            file=g.out/(stage+'.ppm')
            def check():
                g.rpc('screendump',filename=str(file));return matches(file.read_bytes(),action)
            wait(check,'complete frame',12)
            assert g.rpc('query-status')['status']=='running'
        verify('refusal',first,1)
        g.key('ret');g.key('q');verify('unchanged',first,1)
        g.key('f10');verify('question',question,1)
        g.key('esc');verify('cancelled',first,2)
        g.key('ret');verify('still-cancelled',first,2)
        assert 'refusal-power-confirmed' not in (g.out/'firmware.txt').read_text()
        g.key('f10');verify('new-question',question,2)
        g.key('ret')
        wait(lambda:g.rpc('query-status')['status']=='shutdown','confirmed firmware shutdown',20)
        trace=(g.out/'firmware.txt').read_text()
        assert 'handoff-refused' in trace and 'refusal-power-confirmed' in trace and 'owned-handoff' not in trace
    g.capture('end')
    if mode=='guard-refused':assert (g.out/'selected.png').read_bytes()==(g.out/'end.png').read_bytes()
    a,b=g.records[-2:]
    assert a['counters']['sentinel']==b['counters']['sentinel']
    print(mode,'ok',b['qemu_status'],a['counters']['sentinel']['rd_operations'],b['counters']['sentinel']['rd_operations'])
finally:g.end()

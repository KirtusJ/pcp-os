set -eu
peer_dir=/dev/shm/pcp-a3-usb-73b
rt="$1"
old_build=/workspace/scratch/edecb50126f6/boot-audit/uefi-bios-regression
export CARGO_HOME="$old_build/cargo" CARGO_NET_OFFLINE=true
export PATH="$rt/register-live/rust197/bin:$rt/register-live/rust197/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$old_build/bin:$rt/root/usr/bin:$PATH"
export LD_LIBRARY_PATH="$rt/lib"
export PCPOS_KERNEL_STAGE=/dev/shm/pcp-a3-peer-362/build
cd "$peer_dir/src/PCP_OS_Rust/crates/pcpos-kernel"
for profile in default; do
    feature="$profile"
    if [ "$profile" = default ]; then feature=""; fi
    PCPOS_KERNEL_FEATURES="$feature" sh run.sh build > "$peer_dir/build-$profile.log" 2>&1
    cp target/pcpos-kernel.elf32 "$peer_dir/$profile.elf32"
    python3 -IB tools/measure.py "$peer_dir/$profile.elf32"
done

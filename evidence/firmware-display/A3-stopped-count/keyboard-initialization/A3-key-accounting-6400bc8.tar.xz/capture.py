"""Capture one diskless QEMU run with the exact-tree probe's boot routine."""
from pathlib import Path
import json, runpy, sys
stage = Path(__file__).parent
source = stage / "source/PCP_OS_Rust/crates/pcpos-kernel/tests/replay_probe.py"
profile, qemu = sys.argv[1:]
probe = runpy.run_path(str(source))
code, log, count = probe["boot"](qemu, stage / (profile+".elf32"), 120)
(stage / (profile+".serial")).write_text(log)
result = {"profile":profile,"code":code,"passes":count,"failures":[s.strip() for s in log.splitlines() if s.startswith("  FAIL")],"summary":log.splitlines()[-1],"register_closed":any(s.startswith("  pass the kernel's register of its own start, verification and stop") for s in log.splitlines())}
(stage / (profile+".json")).write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result))

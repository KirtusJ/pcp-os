"""Run the checked-in acceptance logic over preserved genuine and controlled transcripts."""
from pathlib import Path
import contextlib, io, json, runpy, sys
from unittest.mock import patch
stage = Path(__file__).parent
src = stage / "source/PCP_OS_Rust/crates/pcpos-kernel/tests/replay_probe.py"
probe = runpy.run_path(str(src))
profiles = ["default","no-key-replay-demo","lost-key-demo"]
def load(p):
    record = json.loads((stage / (p+".json")).read_text())
    return record["code"],(stage / (p+".serial")).read_text(),record["passes"]
cases = dict(zip(profiles,map(load,profiles)))
original = cases[profiles[-1]]
first_fail = next(n for n,s in enumerate(original[1].splitlines()) if s.startswith("  FAIL "))
clipped = "\n".join(original[1].splitlines()[:first_fail+1])+"\n"
def check(data):
    c=dict(cases)
    code,log=data
    c[profiles[-1]]=(code,log,sum(s.startswith("  pass ") for s in log.splitlines()))
    def read(qemu,path,timeout):
        return c[str(path)]
    with patch.dict(probe["main"].__globals__,{"boot":read}),patch.object(sys,"argv",[str(src),profiles[0],profiles[1],"--lost-keys",profiles[2]]),contextlib.redirect_stdout(io.StringIO()):
        try: probe["main"]()
        except SystemExit as exc: return exc.code or 0
    return 0
cases_to_test={"positive":original[:2],"clipped_exit_0":(0,clipped),"clipped_signal":(-15,clipped),"clipped_exit_35":(35,clipped),"default_exit_33_with_failure":(33,clipped),"no_named_failure":(35,"4 SELF-TEST(S) FAILED\n")}
report={k:{"input_exit":v[0],"checker_exit":check(v)} for k,v in cases_to_test.items()}
print(json.dumps(report,indent=2))

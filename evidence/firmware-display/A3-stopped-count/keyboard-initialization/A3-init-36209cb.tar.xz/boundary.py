"""Probe the total reply budget using the original A3 I/O model and kernel source."""
from pathlib import Path
import os, runpy, sys, tempfile

original = Path(__file__).with_name("observe.py").read_text()
scenarios = """
   "noise-only" => { c.pending.extend(std::iter::repeat((0,0x1e)).take(100_003)); &[] },
   "ack-at-limit" => { c.pending.extend(std::iter::repeat((0,0x1e)).take(99_999)); &[(0,0xfa)] },
   "ack-after-limit" => { c.pending.extend(std::iter::repeat((0,0x1e)).take(100_000)); &[(0,0xfa)] },
   "error-then-ack" => &[(0x80,0xfa),(0x40,0xfa),(0,0xfa)],
   "aux-resend-then-ack" => &[(0x20,0xfe),(0,0xfa)],
   "scan-then-resend" if c.requests==1 => &[(0,0x1e),(0,0xfe)],
"""
original = original.replace('"silent" => &[],', scenarios + '\n   "silent" => &[],', 1)
original = original.replace('for case in ["absent"', 'for case in ["noise-only","ack-at-limit","ack-after-limit","error-then-ack","aux-resend-then-ack","scan-then-resend","absent"', 1)
original = original.replace('c.pending.iter().map(|(s,v)|format!("{:02X}/{:02X}",s,v)).collect::<Vec<_>>().join(",")', 'format!("count={},polls={}",c.pending.len(),c.polled)')
original = original.replace("'unread':left.split(',') if left else []", "'unread_count':int(left.split(',')[0].split('=')[1]),'reply_polls':int(left.split(',')[1].split('=')[1])")
with tempfile.TemporaryDirectory() as folder:
    harness = Path(folder) / "extended_model.py"
    harness.write_text(original)
    runpy.run_path(str(harness), run_name="__main__")

"""Run the guest's stopped-screen text layout against a recording cell display."""
import json, os, subprocess, sys, tempfile
from pathlib import Path

src = Path(sys.argv[1]) / "PCP_OS_Rust/crates/pcpos-kernel/src"
main = (src / "main.rs").read_text()
session = (src / "session.rs").read_text()
def fragment(source, start, end):
    a = source.index(start)
    return source[a:source.index(end, a)]
reasons = fragment(main, "let no_keyboard = match keyboard_start", "let start = session::Start")
skips = fragment(main, "let not_run = if replays", "if failed == 0 {")
layout = fragment(session, "pub fn stopped_screen(", "/// Everything the loader gave")
wrapping = fragment(session, "fn wrapped(", "/// The sentence about verification")
model = """
extern crate alloc;
mod dev { #[derive(Clone,Copy,PartialEq,Debug)] pub enum KeyboardStart {Ready,Absent,ControllerBusy,NoAcknowledgement} }
pub struct Start {no_keyboard: Option<&'static str>, not_run: Option<&'static str>, display: Option<()>}
mod ui {
    pub const AMBER:u32=1;pub const SOFT:u32=2;pub const TEXT:u32=3;
    pub const BAD:u32=4;pub const GOOD:u32=5;pub const GROUND:u32=0;
    pub fn grid()->(u32,u32){(80,30)}
    pub fn clear(_:u32){}
    pub fn at(x:u32,y:u32,s:&str,_:u32,_:u32){assert!(x+s.chars().count() as u32<=80 && y<30);println!("{}",s);}
}
fn main(){
    for keyboard_start in [dev::KeyboardStart::Absent,dev::KeyboardStart::ControllerBusy,dev::KeyboardStart::NoAcknowledgement] {
        let keyboard=keyboard_start==dev::KeyboardStart::Ready;
        let replays=false;let failed=0;
        println!("CASE {:?}",keyboard_start);
""" + skips + reasons + """
        stopped_screen(&Start {display:Some(()), no_keyboard, not_run},0,66);
    }
}
""" + wrapping + layout
with tempfile.TemporaryDirectory() as folder:
    d = Path(folder)
    (d / "text.rs").write_text(model)
    subprocess.run([os.environ.get("RUSTC","rustc"),"--edition=2021",str(d/"text.rs"),"-o",str(d/"text")],check=True)
    cases={}
    for part in subprocess.check_output([str(d/"text")],text=True).split("CASE ")[1:]:
        name,*lines=part.splitlines()
        cases[name]=" ".join(l for l in lines if l)
    for name,phrase in [("Absent","No keyboard controller answered"),("ControllerBusy","did not take its set-up in time"),("NoAcknowledgement","did not acknowledge being told to send keys")]:
        assert phrase in cases[name] and "66 self-tests" in cases[name] and "Hold its power button" in cases[name]
        if name!="Absent": assert "no keyboard controller" not in cases[name].lower()
    print(json.dumps(cases,indent=2))

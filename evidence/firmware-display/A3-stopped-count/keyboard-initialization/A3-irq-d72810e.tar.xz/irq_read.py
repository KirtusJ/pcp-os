"""Observe the revision's keyboard interrupt receiver using marked and clean status bytes."""
from pathlib import Path
import subprocess, sys, json, tempfile, os
p=Path(sys.argv[1])
s=p.read_text()
start=s.rindex("#[derive",0,s.index("pub struct Key {"))
decl=s[start:s.index("fn controller_wait_write(")]
receiver=s[s.index("fn keyboard_byte("):s.index("/// Whether this keyboard controller replays")]
model="""
#![allow(dead_code)]
use std::sync::atomic::{Ordering,AtomicBool};
mod arch {
    pub struct Single<T>(std::sync::Mutex<T>);
    impl<T> Single<T> {
        pub const fn new(t:T)->Self {Self(std::sync::Mutex::new(t))}
        pub fn with<U>(&self,f:impl FnOnce(&mut T)->U)->U {f(&mut *self.0.lock().unwrap())}
    }
}
static PORT:std::sync::Mutex<Option<(u8,u8)>>=std::sync::Mutex::new(None);
fn in8(p:u16)->u8 {
    let mut port=PORT.lock().unwrap();
    match p {0x64=>port.map(|v|v.0|1).unwrap_or(0),0x60=>port.take().unwrap().1,_=>panic!()}
}
fn main(){
    let op=std::env::args().nth(1).unwrap();
    let marker:u8=std::env::args().nth(2).unwrap().parse().unwrap();
    let value=if op=="replay"{0xf4}else{0x1e};
    if op=="replay"{PROBE.store(0x100|0xf4,Ordering::SeqCst);}
    *PORT.lock().unwrap()=Some((marker,value));
    interrupt(1);
    assert!(PORT.lock().unwrap().is_none());
    println!("{} {}",PROBE_HIT.load(Ordering::SeqCst),KEYBOARD.with(|k|k.count));
}
"""
with tempfile.TemporaryDirectory() as td:
    t=Path(td); (t/"model.rs").write_text(model+decl+receiver)
    subprocess.run([os.environ.get("RUSTC","rustc"),"--edition=2021",str(t/"model.rs"),"-o",str(t/"model")],check=True)
    out={}
    for op in ("replay","ordinary_key"):
        for label,status in (("clean",0),("auxiliary",32),("timeout",64),("parity",128)):
            hit,count=subprocess.check_output([str(t/"model"),op,str(status)],text=True).split()
            out[op+"/"+label]={"replay_recognized":hit=="true","queued_keys":int(count)}
    print(json.dumps(out,indent=2))

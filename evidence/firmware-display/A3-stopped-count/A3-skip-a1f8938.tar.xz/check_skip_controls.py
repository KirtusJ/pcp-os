"""Exercise the shipped skip predicate on recorded QEMU frames and controlled evidence changes."""
import hashlib,json,runpy,sys
from pathlib import Path
source, guests, output=map(Path,sys.argv[1:])
c=runpy.run_path(str(source)); glyphs=c['CHECK']['kernel_glyphs']()
def record(name,screen='stopped'):
    p=guests/name; frame=(p/(screen+'.ppm')).read_bytes()
    return (p/'serial.txt').read_text(),c['PINS']['read'](frame,glyphs)
busy=c['SETUP_REFUSED']; silent=c['NO_ACK']; replay=c['NO_REPLAY']; prefix=c['SKIP_RECORD']
serial, rows=record('busy-800'); silent_serial,silent_rows=record('silent-800')
ready, ready_rows=record('kbd-800');nr,f5=record('noreplay-800','f5'); small,small_rows=record('busy-320')
line=prefix+busy+'\n'
report={}
def check(name,should_pass,s,r,expected,**opt):
    reasons=c['skip_problems'](s,r,expected,**opt)
    report[name]={'expected_accept':should_pass,'accepted':not reasons,'problems':reasons}
    assert (not reasons)==should_pass,(name,reasons)
check('native-busy',True,serial,rows,busy)
check('native-ready',True,ready,ready_rows,None)
check('native-f5',True,nr,f5,replay,f5=True)
check('native-compact-omission',True,small,small_rows,busy,compact=True)
check('missing-serial-skip',False,serial.replace(line,''),rows,busy)
check('duplicate-serial-skip',False,serial.replace(line,line+line),rows,busy)
check('contradictory-serial-skips',False,serial.replace(line,line+prefix+silent+'\n'),rows,busy)
check('incorrect-serial-skip',False,serial.replace(line,prefix+silent+'\n'),rows,busy)
check('swapped-keyboard-outcome',False,serial.replace('keyboard: '+c['BUSY'],'keyboard: '+c['SILENT']),rows,busy)
check('missing-keyboard-outcome',False,serial.replace('keyboard: '+c['BUSY']+'\n',''),rows,busy)
check('ready-serial-claims-skip',False,ready+line,ready_rows,None)
check('stale-silent-frame',False,serial,silent_rows,busy)
check('stale-ready-frame',False,serial,ready_rows,busy)
check('ready-with-skip-frame',False,ready,rows,None)
check('stale-stop-for-f5',False,nr,record('noreplay-800')[1],replay,f5=True)
check('duplicate-visible-skip',False,serial,rows+['Not run: '+c['SIX_KEYS']+busy+'.'],busy)
check('orphaned-compact-reason',False,small,small_rows+[busy+'.'],busy,compact=True)
check('compact-wrong-skip',False,small,small_rows+['Not run: '+c['SIX_KEYS']+silent+'.'],busy,compact=True)
output.write_text(json.dumps(report,indent=2)+'\n')
print(sum(v['expected_accept'] for v in report.values()),'positive,',sum(not v['expected_accept'] for v in report.values()),'adverse controls agree')

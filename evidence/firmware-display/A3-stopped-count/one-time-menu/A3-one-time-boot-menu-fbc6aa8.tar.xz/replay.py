"""Recompute seven boot-menu observations from the unmodified guest records."""
from pathlib import Path
import hashlib,json,re,struct
root=Path(__file__).resolve().parent
def digest(b):return hashlib.sha256(b).hexdigest()
def boot_order(raw):
    base=struct.unpack_from('<H',raw,48)[0]
    end=base+struct.unpack_from('<I',raw,base+16)[0]
    pos=(base+31)&~3
    active={}
    while pos<end and raw[pos:pos+2]!=b'\xff\xff':
        assert raw[pos:pos+2]==b'\xaa\x55'
        name_len,sz=struct.unpack_from('<II',raw,pos+36)
        name=raw[pos+60:pos+60+name_len-2].decode('utf-16le')
        start=pos+60+name_len
        if raw[pos+2]==0x3f and re.fullmatch(r'Boot(?:Order|[0-9A-Fa-f]{4})',name):
            active[name]=raw[start:start+sz]
        pos=(start+sz+3)&~3
    if 'BootOrder' not in active:return []
    result=[]
    for number, in struct.iter_unpack('<H',active['BootOrder']):
        raw=active[f'Boot{number:04X}']
        stop=next(i for i in range(6,len(raw)-1,2) if raw[i:i+2]==b'\x00\x00')
        result.append(raw[6:stop].decode('utf-16le'))
    return result
out={}
for name in ('refusal-1','accepted-1','idle','auto-refusal','refusal-2','accepted-2','auto-accepted'):
    d=root/name
    r=json.loads((d/'result.json').read_text())
    rec={v['stage']:v for v in r['snapshots']}
    trace=(d/'firmware.txt').read_text()
    assert r['exit']==0 and r['usb_before']==r['usb_after']==json.loads((root/'image.json').read_text())['usb_sha256']
    assert len(set(v['nvme_sha256'] for v in rec.values())|{digest((d/'internal.raw').read_bytes()),'16963acd2f53b44c46fd01314a7b40d9e08933fb9929091bc3b9315e272d364c'})==1
    for k,v in rec.items():
        buf=(d/(k+'-vars.fd')).read_bytes()
        assert digest(buf)==v['vars_sha256']
        sequence=boot_order(buf)
        if k=='before':assert sequence==[]
        else:
            assert len(sequence)==4 and 'NVMe' in sequence[0] and 'USB' in sequence[1] and sequence[2:]==['UiApp','EFI Internal Shell']
        for c in [v['usb_counters'],v['counters']['sentinel']]:
            assert not any(x for k,x in c.items() if k not in ('rd_operations','rd_bytes'))
    guest_shutdown=any(e.get('event')=='SHUTDOWN' and e['data']=={'guest':True,'reason':'guest-shutdown'} for e in r['events'])
    assert guest_shutdown==name.startswith(('accepted','auto-accepted'))
    manual='selected' in rec
    end=(d/'end-serial.txt').read_text()
    clean=lambda s:' '.join(re.sub(r'\x1b\[[\d;=?]*[A-Za-z]',' ',s).split())
    if manual:
        sel=(d/'selected-serial.txt').read_text()
        assert end.startswith(sel) and 'starting Boot0000 "UiApp"' in sel
        assert 'Boot Manager Menu' in clean(sel) and '/USB' in clean(sel).split('Device Path')[-1]
        e,s=rec['end'],rec['selected']
        assert e['vars_sha256']==s['vars_sha256']==rec['menu']['vars_sha256']
        assert e['counters']['sentinel']==s['counters']['sentinel']==rec['menu']['counters']['sentinel']
        assert (s['counters']['sentinel']['rd_operations'],s['counters']['sentinel']['rd_bytes'])==(48,359424)
        extra=end[len(sel):]
        if name.startswith('refusal'):
            assert extra.count('Press any key to continue...')==1 and 'Boot Manager Menu' in extra
            assert not trace and not re.search(r'^  pass ',end,re.M)
            assert (d/'selected.png').read_bytes()==(d/'end.png').read_bytes()
            assert not re.search(r'BdsDxe: starting Boot[^\n]* (?:from .*NVMe\(|"EFI Internal Shell")',extra)
        elif name.startswith('accepted'):
            assert 'owned-handoff' in trace and json.loads((root/'image.json').read_text())['measurement'] in end
            assert len(re.findall(r'^  pass ',end,re.M))==66
        else:
            assert (d/'selected.png').read_bytes()==(d/'end.png').read_bytes() and not trace and not extra.strip()
        assert e['usb_counters']['rd_operations']-s['usb_counters']['rd_operations']==(0 if name=='idle' else 29)
    if 'continued' in rec or name=='auto-refusal':
        x=rec.get('continued',rec['end'])
        serial=(d/(x['stage']+'-serial.txt')).read_text()
        portions=serial[len(end):] if 'continued' in rec else serial
        starts=[next(t for t in ('NVMe','USB','Shell') if t in m.group()) for m in re.finditer(r'BdsDxe: starting Boot[^\n]+',portions)]
        assert starts==['NVMe','USB','Shell'] and 'Shell>' in portions and portions.count(': Unsupported')==2
        if 'continued' in rec:assert x['counters']['sentinel']['rd_operations']-rec['end']['counters']['sentinel']['rd_operations']==10
    if name=='auto-accepted':
        assert 'KEYBOARD-CONTROL-READY' in trace and 'owned-handoff' not in trace
    out[name]={k:[s['counters']['sentinel']['rd_operations'],s['counters']['sentinel']['rd_bytes'],s['usb_counters']['rd_operations']] for k,s in rec.items()}
print(json.dumps(out,indent=2))

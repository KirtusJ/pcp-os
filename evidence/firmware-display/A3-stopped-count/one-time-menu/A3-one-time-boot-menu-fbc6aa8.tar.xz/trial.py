from pathlib import Path
import re,sys,time
from menu_vm import Guest,OPTICAL,sha
name,kind,flag=sys.argv[1:]
g=Guest(name,flag=='present')
def clean(s): return ' '.join(re.sub(r'\x1b\[[\d;=?]*[A-Za-z]',' ',s).split())
def wait(test,label,sec=25):OPTICAL['wait_for'](test,label,sec)
def persist(stage):
    g.capture(stage)
    (g.out/(stage+'-serial.txt')).write_text(g.serial())
def play():
    if g.rpc('query-status')['status']=='paused':g.rpc('cont')
try:
    if kind=='auto':
        if flag=='withheld':wait(lambda:'Shell>' in g.serial(),'automatic fallback to shell',35)
        else:wait(lambda:g.rpc('query-status')['status']=='shutdown','internal control shutdown',35)
        persist('end')
    else:
        deadline=time.monotonic()+12
        while 'Boot Maintenance Manager' not in g.serial() and time.monotonic()<deadline:
            g.key('f2')
        assert 'Boot Maintenance Manager' in g.serial() and 'starting Boot0000 "UiApp"' in g.serial()
        g.key('down');g.key('down');g.key('ret')
        wait(lambda:'Boot Manager Menu' in g.serial(),'one-time firmware menu')
        view=clean(g.serial()).split('Boot Manager Menu',1)[1]
        assert view.index('NVMe Ctrl')<view.index('USB HARDDRIVE')<view.index('EFI Internal Shell')
        persist('menu'); play()
        off=len(g.serial())
        g.key('down')
        wait(lambda:'Device Path' in g.serial()[off:] and '/USB' in clean(g.serial()[off:]),'USB selection highlight')
        persist('selected');play()
        if kind!='idle':
            off=len(g.serial())
            g.key('ret')
            if flag=='withheld':
                wait(lambda:'Press any key to continue...' in g.serial()[off:] and 'Boot Manager Menu' in g.serial()[off:],'return to drive picker')
            else:
                wait(lambda:g.rpc('query-status')['status']=='shutdown','USB kernel shutdown',40)
        if kind=='idle' or flag=='withheld':
            time.sleep(8)
            assert g.rpc('query-status')['status']=='running'
        persist('end')
        if kind=='continue':
            play()
            off=len(g.serial());g.key('esc')
            wait(lambda:'Boot Maintenance Manager' in g.serial()[off:],'return to firmware front page')
            off=len(g.serial());g.key('down');g.key('down')
            assert 'Continue' in g.serial()[off:]
            g.key('ret');wait(lambda:'Shell>' in g.serial(),'explicit Continue fallback',30)
            persist('continued')
    print(name,[(s['stage'],s['counters']['sentinel']['rd_operations'],s['usb_counters']['rd_operations']) for s in g.records],flush=True)
finally:g.end()

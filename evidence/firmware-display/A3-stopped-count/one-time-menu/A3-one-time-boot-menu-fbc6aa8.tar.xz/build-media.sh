#!/bin/bash
set -eu
rt="$(cd "$(dirname "$0")/.." && pwd)"
out="$rt/a3-onetime"
previous=/workspace/scratch/edecb50126f6/boot-audit/uefi-bios-regression
export CARGO_HOME="$previous/cargo" CARGO_NET_OFFLINE=true
export PATH="$rt/register-live/rust197/bin:$rt/register-live/rust197/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$previous/bin:$rt/root/usr/bin:$PATH"
export LD_LIBRARY_PATH="$rt/lib"
export PCPOS_KERNEL_STAGE="$rt/hp-admission-demo/kernel-stage"
cd "$rt/a3-onetime/source/PCP_OS_Rust/crates/pcpos-kernel"
PCPOS_KERNEL_FEATURES="" sh run.sh build
cp target/pcpos-kernel.elf32 "$out/kernel.elf32"
python3 -B "$out/make_usb.py"

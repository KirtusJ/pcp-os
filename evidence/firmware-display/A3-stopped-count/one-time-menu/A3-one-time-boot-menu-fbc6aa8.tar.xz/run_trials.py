from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,sys
here=Path(__file__).resolve().parent
jobs=[('refusal-1','menu','withheld'),('accepted-1','menu','present'),('idle','idle','withheld'),('auto-refusal','auto','withheld'),('refusal-2','continue','withheld'),('accepted-2','menu','present'),('auto-accepted','auto','present')]
def run(job):
    name,kind,flag=job
    with (here/(name+'.log')).open('w') as out:
        r=subprocess.run([here.parent/'desk-build/release/pcp-delegate',here/'tasks.redb','a3_'+name,'Measure a disposable OVMF guest, '+name,'--',sys.executable,'-B',here/'trial.py',*job],stdout=out,stderr=subprocess.STDOUT)
        print(name,r.returncode,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,jobs))

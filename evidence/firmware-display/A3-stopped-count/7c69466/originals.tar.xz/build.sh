#!/bin/bash
set -eu
here="$(cd "$(dirname "$0")/../register-live" && pwd)"
rt="$here/.."
previous=/workspace/scratch/edecb50126f6/boot-audit
export CARGO_HOME="$previous/uefi-bios-regression/cargo"
export PATH="$here/rust197/bin:$here/rust197/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$previous/uefi-bios-regression/bin:$rt/root/usr/bin:$PATH"
export LD_LIBRARY_PATH="$rt/lib"
export PCPOS_TESTER_CD_STAGE="$here/tester-stage"
export PCPOS_KERNEL_STAGE="$here/official-stage"
rustc -vV
python3 -B "$rt/hp-admission-src/examples/tester-cd/build.py" "$previous/loader" "$rt/hp-admission/cd"

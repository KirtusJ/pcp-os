"""Use the frozen checker and its normal guest commands with QMP carried over stdio."""
import difflib,sys
from pathlib import Path
here=Path(__file__).resolve().parent
path=here.parent/"hp-admission-src/examples/tester-cd/check_stopped_screen.py"
before=path.read_text()
src=before.replace('"unix:%s,server=on,wait=off" % sock','"stdio"').replace('stdout=subprocess.DEVNULL','stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True')
start=src.index('        end = time.monotonic() + 20\n        while not sock.exists():')
stop=src.index('        self.stream.readline()',start)
src=(src[:start]+src[stop:]).replace('self.stream.readline()', 'self.process.stdout.readline()').replace('self.stream.write(', 'self.process.stdin.write(').replace('self.stream.flush()', 'self.process.stdin.flush()')
assert 'self.stream' not in src
(here/'transport.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),src.splitlines(True),fromfile='source/check_stopped_screen.py',tofile='host/check_stopped_screen.py')))
sys.argv[0]=str(path)
exec(compile(src,str(path),'exec'),{'__file__':str(path),'__name__':'__main__'})

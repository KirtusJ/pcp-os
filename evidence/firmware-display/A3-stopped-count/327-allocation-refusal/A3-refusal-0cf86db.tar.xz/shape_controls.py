"""Change only the action area in four real frames to test the tracked checker."""
import json,sys
from pathlib import Path
import numpy as np
src,cases=map(lambda n:Path(n).resolve(),sys.argv[1:3])
sys.path.insert(0,str(src/'examples/firmware-owned-uefi'))
from refusal_screen import matches,line_shapes
ask='Press F10 to request power off.'
yes='Switch off? Enter switches off. Esc cancels.'
def raster(p):
    magic,size,depth,raw=p.read_bytes().split(b'\n',3)
    w,h=map(int,size.split())
    return np.frombuffer(raw,dtype=np.uint8).reshape(h,w,3),b'\n'.join((magic,size,depth))+b'\n'
def bands(a):
    rows=np.flatnonzero((a!=a[0,0]).any(axis=(1,2)))
    return np.split(rows,np.flatnonzero(np.diff(rows)!=1)+1)
out={}
for name,expected,other in [('refused',ask,'confirm'),('confirm',yes,'refused'),('cancelled',ask,'confirm'),('confirm-again',yes,'refused')]:
    frame,header=raster(cases/(name+'.ppm'))
    prior,_=raster(cases/(other+'.ppm'))
    lines=bands(frame);other_lines=bands(prior)
    assert len(lines)==len(other_lines)==4
    last=lines[-1]; other_action=prior[other_lines[-1]]
    after=frame.copy()
    y=last[-1]+10
    assert (after[y:y+len(other_action)]==frame[0,0]).all()
    after[y:y+len(other_action)]=other_action
    wrong=frame.copy()
    wrong[last]=frame[0,0]
    vals={}
    for label,a in [('original',frame),('action erased',wrong),('both actions visible',after)]:
        raw=header+a.tobytes()
        vals[label]={'accepted':bool(matches(raw,expected)),'lines':len(line_shapes(raw))}
    assert vals['original']['accepted'] and not vals['action erased']['accepted']
    assert vals['both actions visible']['lines']==5
    out[name]=vals
print(json.dumps(out,indent=2))

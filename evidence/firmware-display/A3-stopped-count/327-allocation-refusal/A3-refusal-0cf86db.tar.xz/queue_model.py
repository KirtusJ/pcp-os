"""Compile the actual firmware refusal loop against a small deterministic input queue."""
from pathlib import Path
import json, subprocess,sys,tempfile
begin=r"""
#include <stdbool.h>
#include <setjmp.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
typedef unsigned long UINTN;
typedef unsigned long EFI_STATUS;
typedef wchar_t CHAR16;
typedef bool BOOLEAN;
typedef struct { unsigned ScanCode; unsigned UnicodeChar; } EFI_INPUT_KEY;
#define TRUE 1
#define FALSE 0
#define EFI_SUCCESS 0
#define EFI_NOT_READY 2
#define EFI_ERROR(s) ((s)!=0)
#define SCAN_F10 20
#define SCAN_ESC 23
#define CHAR_CARRIAGE_RETURN 13
#define EfiResetShutdown 2
#define uefi_call_wrapper(fn,n,...) (fn)(__VA_ARGS__)
typedef struct Out { EFI_STATUS (*ClearScreen)(struct Out*); EFI_STATUS (*OutputString)(struct Out*,CHAR16*); } SIMPLE_TEXT_OUTPUT_INTERFACE;
typedef struct In { EFI_STATUS (*Reset)(struct In*,BOOLEAN); EFI_STATUS (*ReadKeyStroke)(struct In*,EFI_INPUT_KEY*); void *WaitForKey; } SIMPLE_INPUT_INTERFACE;
typedef struct { EFI_STATUS (*SetWatchdogTimer)(UINTN,UINTN,UINTN,void*); EFI_STATUS (*WaitForEvent)(UINTN,void**,UINTN*); } EFI_BOOT_SERVICES;
typedef struct { void (*ResetSystem)(UINTN,EFI_STATUS,UINTN,void*); } RUNTIME;
typedef struct { EFI_BOOT_SERVICES *BootServices; SIMPLE_INPUT_INTERFACE *ConIn; SIMPLE_TEXT_OUTPUT_INTERFACE *ConOut; RUNTIME *RuntimeServices; } EFI_SYSTEM_TABLE;
static jmp_buf stop;
static const char *which; static unsigned head,tail,batch,resets,cancelled,power,why;
static int screen; static char keys[32];
static void halt(void) __attribute__((noreturn));
static void halt(void){longjmp(stop,3);}
static void value(const char *s, EFI_STATUS n){(void)s;(void)n;}
static void word(const char *s){(void)s;}
static EFI_STATUS watchdog(UINTN n,UINTN code,UINTN size,void *p){return strcmp(which,"watchdog-error")==0;}
static EFI_STATUS clear(SIMPLE_TEXT_OUTPUT_INTERFACE*o){screen=0;return 0;}
static EFI_STATUS output(SIMPLE_TEXT_OUTPUT_INTERFACE*o,CHAR16*s){
 if(wcsstr(s,L"could not start")) {why++;screen=1;}
 if(wcsstr(s,L"Press F10")){screen=2;}
 if(wcsstr(s,L"Switch off?")){screen=3;if(strcmp(which,"display-error")==0)return 1;}
 return 0;
}
static EFI_STATUS reset(SIMPLE_INPUT_INTERFACE*i,BOOLEAN extended){
 resets++;if(resets==2 && strcmp(which,"reset-error")==0)return 1;
 cancelled+=tail-head;head=tail;return 0;
}
static EFI_STATUS read_key(SIMPLE_INPUT_INTERFACE*i,EFI_INPUT_KEY*k){
 if(head==tail)return EFI_NOT_READY;
 char c=keys[head++];k->ScanCode=c=='F'?SCAN_F10:c=='X'?SCAN_ESC:0;k->UnicodeChar=c=='E'?13:0;return 0;
}
static void push(const char*s){while(*s)keys[tail++]=*s++;}
static EFI_STATUS wait_keys(UINTN n,void**event,UINTN*at){
 if(head==tail){
   if(batch++==0){
     if(strcmp(which,"enter-before")==0)push("EF");
     else if(strcmp(which,"queued-enter")==0 || strcmp(which,"queued-then-fresh")==0)push("FE");
     else push("F");
   } else if(batch==2 && (strcmp(which,"fresh-enter")==0 || strcmp(which,"queued-then-fresh")==0))push("E");
   else if(batch==2 && strcmp(which,"cancel-then-enter")==0)push("XE");
   else longjmp(stop,2);
 }
 *at=0;return 0;
}
static void poweroff(UINTN op,EFI_STATUS s,UINTN n,void*p){power++;longjmp(stop,1);}
"""
end=r"""
int main(int argc,char**argv){
 which=argv[1];SIMPLE_TEXT_OUTPUT_INTERFACE o={clear,output};
 SIMPLE_INPUT_INTERFACE i={reset,read_key,&i};RUNTIME rt={poweroff};
 EFI_BOOT_SERVICES bs={watchdog,wait_keys};EFI_SYSTEM_TABLE st={&bs,strcmp(which,"no-input")==0?NULL:&i,&o,&rt};
 int done=setjmp(stop);
 if(!done)allocation_refusal(&st);
 printf("%d %d %u %u %u\n",done,screen,resets,cancelled,power);return 0;
}
"""
source=Path(sys.argv[1]).read_text()
body=source[source.index('static EFI_STATUS refusal_message'):source.index('static int matches(')]
cases=['queued-enter','enter-before','fresh-enter','queued-then-fresh','cancel-then-enter','reset-error','display-error','watchdog-error','no-input']
with tempfile.TemporaryDirectory() as tmp:
    d=Path(tmp);(d/'m.c').write_text(begin+body+end)
    subprocess.run(['cc','-O2',str(d/'m.c'),'-o',str(d/'m')],check=True)
    out={}
    for c in cases:
        status,screen,resets,drained,off=map(int,subprocess.check_output([d/'m',c],text=True).split())
        out[c]={'result':{1:'shutdown',2:'waiting',3:'halted'}[status],'last_screen':{1:'manual power',2:'F10 prompt',3:'confirmation'}[screen],'input_resets':resets,'discarded':drained,'shutdown_requests':off}
print(json.dumps(out,indent=2))

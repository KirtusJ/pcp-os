import sys,json
from pathlib import Path
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here/'src/examples/firmware-owned-uefi'))
from usb_trial import trial,allocation_refusal_trial
rt=here.parent
name=sys.argv[1]
fw=rt/'root/usr/share/OVMF'
args=[str(rt/'bin/qemu-system-x86_64'),fw/'OVMF_CODE_4M.fd',fw/'OVMF_VARS_4M.fd',here/'stock/usb.img',json.loads((here/'image.json').read_text()),(here/'guests'/name).resolve()]
if name=='refusal':allocation_refusal_trial(*args)
else:
    video,mem=name.rsplit('-',1)
    trial(*args,int(mem),video)
print(name,'completed')

"""Verify the archived nine revised guests, the queue observations and figure controls."""
import hashlib,json,sys
from pathlib import Path
h=Path(sys.argv[1]).resolve()
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ('std-128','std-256','virtio-vga-128','ramfb-128','ramfb-256'):
    g=h/'guests'/n
    r=read(g/'result.json');serial=(g/'serial.txt').read_text()
    assert r['passed'] and r['exit']==0 and r['self_tests']==72 and r['shutdown']=={'reason':'guest-shutdown','guest':True}
    assert len([l for l in serial.splitlines() if l.startswith('  pass ')])==72 and 'ALL SELF-TESTS PASS.' in serial
    assert not any(any(i['counter_deltas']['sentinel'].values()) for i in r['intervals'])
r=read(h/'guests/refusal/result.json')
assert r['passed'] and not any(r['interval']['counter_deltas']['sentinel'].values())
want=[True,False,False]
for target,expected in [('controls.json',want),('previous-controls.json',[True,False,True])]:
    controls=read(h/target);assert len(controls)==4
    assert all([v[k]['accepted'] for k in ('original','action erased','both actions visible')]==expected for v in controls.values())
for d in sorted((h/'guests').glob('extra-*')):
    r=read(d/'audit.json')
    frames=r['frames'];assert all(row[-1]==sha(d/(str(i)+'-screen.png')) for i,row in enumerate(frames))
    assert not any(any(s['counters']['sentinel'].values()) for s in r['snapshots'])
    guest_shutdown=[e for e in r['events'] if e['event']=='SHUTDOWN' and e['data']['guest']]
    if 'absent' in d.name:
        assert len(frames)==2 and frames[0][-1]==frames[1][-1] and not guest_shutdown
    else:
        assert len(frames)==15 and len(guest_shutdown)==1
        groups={}
        for _,prompt,_,_,frame in frames:groups.setdefault(prompt,set()).add(frame)
        assert len(groups)==2 and len(set.union(*groups.values()))==2 and all(len(v)==1 for v in groups.values())
q=read(h/'current-queue.json');p=read(h/'previous-queue.json')
assert p['queued-enter']['shutdown_requests']==1
assert q['queued-enter']['result']=='waiting' and q['queued-enter']['discarded']==1 and q['queued-enter']['shutdown_requests']==0
for k in ('fresh-enter','queued-then-fresh'):assert q[k]['shutdown_requests']==1
for k in ('enter-before','cancel-then-enter'):assert q[k]['shutdown_requests']==0 and q[k]['result']=='waiting'
for k in ('no-input','watchdog-error','reset-error','display-error'):
    assert q[k]['last_screen']=='manual power' and q[k]['result']=='halted' and not q[k]['shutdown_requests']
print('9 revised guest records, 32 extra frames, 4 original and 8 altered prompt cases, 9 modeled input cases verified')

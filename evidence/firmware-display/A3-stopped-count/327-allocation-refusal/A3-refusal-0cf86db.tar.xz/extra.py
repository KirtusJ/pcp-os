"""Observe each key at a refused boot and an unattended guest with no keyboard."""
from pathlib import Path
import hashlib,json,sys,subprocess,time
h=Path(__file__).resolve().parent;rt=h.parent
sys.path.insert(0,str(h/'src/examples/firmware-owned-uefi'))
from usb_trial import usb_command,OPTICAL
from usb_observer import capture
video,keyboard=sys.argv[1:3]
p=(h/'guests'/('extra-'+video+'-'+keyboard)).resolve();p.mkdir()
fw=rt/'root/usr/share/OVMF'
volume=h/'stock/usb.img'
args=usb_command(str(rt/'bin/qemu-system-x86_64'),fw/'OVMF_CODE_4M.fd',fw/'OVMF_VARS_4M.fd',volume,p,64,video)
args[args.index('-machine')+1]='q35,i8042=off'
if keyboard=='usb':args+=['-device','usb-kbd,id=keys,bus=xhci.0']
first='Press F10 to request power off.'
ask='Switch off? Enter switches off. Esc cancels.'
serial=lambda:(p/'serial.txt').read_text(errors='replace')
records=[]; snapshots=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with (p/'stderr.txt').open('wb') as err,subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        mon=OPTICAL['Monitor'](vm);rpc=mon.call;rpc('qmp_capabilities')
        inventory=rpc('human-monitor-command',**{'command-line':'info usb'})
        assert ('QEMU USB Keyboard' in inventory)==(keyboard=='usb')
        snapshots.append(capture(rpc,p,'before'));rpc('cont')
        OPTICAL['wait_for'](lambda:first in serial(),'refusal message',40)
        def info(key,prompt,occurrences):
            if key:
                mon.key(key);time.sleep(.27)
            OPTICAL['wait_for'](lambda:serial().count(prompt)>=occurrences,'expected action',8)
            assert rpc('query-status')['status']=='running'
            frame=p/(str(len(records))+'-screen.png')
            rpc('screendump',filename=str(frame),format='png')
            records.append((key,prompt,serial().count(first),serial().count(ask),sha(frame)))
        info(None,first,1)
        if keyboard=='usb':
            for k in ('ret','esc','q','p','y','n'):info(k,first,1)
            info('f10',ask,1)
            for k in ('f10','q','y','n'):info(k,ask,1)
            info('esc',first,2)
            info('ret',first,2)
            info('f10',ask,2)
            assert not any(e.get('event')=='SHUTDOWN' for e in mon.events)
            mon.key('ret')
            OPTICAL['wait_for'](lambda:rpc('query-status')['status']=='shutdown','confirmed shutdown',20)
            assert [e['data'] for e in mon.events if e.get('event')=='SHUTDOWN']==[{'reason':'guest-shutdown','guest':True}]
        else:
            time.sleep(10)
            info(None,first,1)
            assert 'refusal-power-confirmed' not in (p/'firmware.txt').read_text()
            rpc('stop')
        snapshots.append(capture(rpc,p,'end'))
        rpc('quit');vm.wait(timeout=12)
        assert vm.returncode==0 and not serial().count('  pass ')
        (p/'audit.json').write_text(json.dumps(dict(args=args,frames=records,snapshots=snapshots,events=mon.events,usb=sha(volume),keyboard=inventory),indent=2))
        print(video,keyboard,'completed',len(records),'frames')
    finally:
        if vm.poll() is None:vm.kill();vm.wait()

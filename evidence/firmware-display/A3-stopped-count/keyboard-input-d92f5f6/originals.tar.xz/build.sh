#!/bin/bash
set -eu
here="$(cd "$(dirname "$0")" && pwd)"
rt="$here/.."
previous=/workspace/scratch/edecb50126f6/boot-audit/uefi-bios-regression
export CARGO_HOME="$previous/cargo" CARGO_NET_OFFLINE=true
export PATH="$rt/register-live/rust197/bin:$rt/register-live/rust197/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$previous/bin:$rt/root/usr/bin:$PATH"
export LD_LIBRARY_PATH="$rt/lib"
export PCPOS_KERNEL_STAGE="$here/kernel-stage"
export PCPOS_KERNEL_FEATURES=no-key-replay-demo
cd "$rt/hp-screen-source/PCP_OS_Rust/crates/pcpos-kernel"
rustc -vV
sh run.sh build
cp target/pcpos-kernel.elf32 "$here/kernel.elf32"
python3 -B tools/measure.py "$here/kernel.elf32"

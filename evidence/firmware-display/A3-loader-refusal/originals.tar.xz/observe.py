"""Observe one exact guarded removable USB in QEMU, varying only available RAM."""
import hashlib,json,sys,subprocess,time
from pathlib import Path
here=Path(__file__).resolve().parent
runtime=here.parent
source=runtime/"hp-screen-source"
sys.path.insert(0,str(source/"examples/firmware-owned-uefi"))
from usb_trial import usb_command, OPTICAL
from usb_observer import capture, compare
from image import digest
ram=int(sys.argv[1]);out=here/(str(ram)+"MiB");out.mkdir()
volume=runtime/"gop-check/stock/usb.img"
expected=json.loads((runtime/"gop-check/image.json").read_text())
firmware=runtime/"root/usr/share/OVMF"
code=firmware/"OVMF_CODE_4M.fd";template=firmware/"OVMF_VARS_4M.fd"
assert digest(volume)==expected["usb_sha256"]
cmd=usb_command(str(runtime/"bin/qemu-system-x86_64"),code,template,volume,out,ram,"std")
r={"memory_mib":ram,"usb_sha256":digest(volume),"efi_sha256":expected["efi_sha256"],"loader_blob":"638be9eb9e15a139495f3e8a4093b1961c0f107f","ovmf_code":digest(code),"vars_template":digest(template),"keys":[]}
serial,trace=out/"serial.txt",out/"firmware.txt"
def read(path):return path.read_text(errors="replace") if path.exists() else ""
with (out/"stderr.txt").open("wb") as err, subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
    try:
        mon=OPTICAL["Monitor"](guest);rpc=mon.call;rpc("qmp_capabilities")
        stick=next(b for b in rpc("query-block") if b.get("device")=="stick")
        assert stick["inserted"]["ro"] and stick["removable"]
        before=capture(rpc,out,"before")
        rpc("cont")
        deadline=time.monotonic()+65
        while time.monotonic()<deadline:
            status=rpc("query-status")["status"]
            if status=="shutdown" or "desktop: " in read(serial):break
            time.sleep(.25)
        if "desktop: " in read(serial):
            assert "owned-handoff" in read(trace) and expected["measurement"]+" (measured; equal" in read(serial)
            r["outcome"]="desktop; F10 then Enter"
            time.sleep(.4);mon.key("f10");r["keys"].append("f10");time.sleep(.7);mon.key("ret");r["keys"].append("ret")
            OPTICAL["wait_for"](lambda:rpc("query-status")["status"]=="shutdown","guest requested shutdown",25)
        elif status=="shutdown":
            r["outcome"]="guest shutdown before any key"
        else:
            r["outcome"]="time limit before desktop or shutdown"
            rpc("stop")
        status=rpc("query-status")["status"]
        end=capture(rpc,out,"end")
        r["snapshots"]=[before,end]
        r["changes"]=compare(out,before,end)
        r["stick_counters"]=next(x["stats"] for x in rpc("query-blockstats") if x.get("device")=="stick")
        r["final_status"]=status;r["events"]=mon.events
        r["allocation"]=[i for i in read(trace).splitlines() if i.startswith("allocation=")]
        r["refusal"]="handoff-refused" in read(trace)
        r["owned_before_write"]="owned-before-write" in read(trace)
        r["kernel_started"]="PCP OS kernel " in read(serial)
        r["usb_still_matches"]=digest(volume)==expected["usb_sha256"]
        assert r["usb_still_matches"]
        rpc("screendump",filename=str(out/"end.png"),format="png")
        if r["refusal"]:
            assert r["allocation"] and r["allocation"]!=["allocation=0000000000000000"] and status=="shutdown" and not r["keys"] and not r["owned_before_write"] and not r["kernel_started"]
            assert any(e.get("event")=="SHUTDOWN" and e["data"].get("guest") for e in mon.events)
        if r["keys"]:
            assert r["owned_before_write"] and r["kernel_started"] and "ALL SELF-TESTS PASS." in read(serial)
        print(r["memory_mib"],r["outcome"],r["allocation"],r["refusal"],flush=True)
    finally:
        (out/"receipt.json").write_text(json.dumps(r,indent=2)+"\n")
        if guest.poll() is None:guest.kill()
        guest.wait()

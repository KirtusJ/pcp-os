"""Repeat the three observed outcomes, keeping a picture before each owner action."""
from pathlib import Path
import sys
base=Path(__file__).resolve().parent
src=(base/"observe.py").read_text()
src=src.replace('out=here/(str(ram)+"MiB")','out=here/(str(ram)+"MiB-repeat")')
key='            time.sleep(.4);mon.key("f10");r["keys"].append("f10");time.sleep(.7);mon.key("ret");r["keys"].append("ret")'
assert src.count(key)==1
src=src.replace(key,'''            time.sleep(.75)
            rpc("screendump",filename=str(out/"home.png"),format="png")
            mon.key("f10");r["keys"].append("f10");time.sleep(.7)
            rpc("screendump",filename=str(out/"confirmation.png"),format="png")
            mon.key("ret");r["keys"].append("ret")''')
test='            assert r["owned_before_write"] and r["kernel_started"] and "ALL SELF-TESTS PASS." in read(serial)'
assert src.count(test)==1
src=src.replace(test,'''            assert r["owned_before_write"] and r["kernel_started"]
            if ram==80:
                assert "memory for programs: 0 frames" in read(serial) and "2 SELF-TEST(S) FAILED" in read(serial)
                assert "it is in SAFE and starts no program" in read(serial)
            else:
                assert ram==128 and "ALL SELF-TESTS PASS." in read(serial)
        if ram==64: assert r["refusal"] and not r["keys"]
        r["matched_repeat_expectation"]=True''')
exec(compile(src,str(base/"observe.py"),'exec'),{'__file__':str(base/"observe.py"),'__name__':'__main__'})

"""Recover the two runs at each memory size using saved VM events, media bytes and display frames.

Use: python -B replay.py SOURCE ROOT
SOURCE is the 711a585af4f4a46ecb5ef3b03120b55dc92c2b1d checkout.
"""
from pathlib import Path
import hashlib,json,sys
from PIL import Image
import numpy as np
from read import rows,font
source,root=(Path(s).resolve() for s in sys.argv[1:])
sys.path.insert(0,str(source/"examples/firmware-owned-uefi"))
from usb_observer import compare
def sha(data): return hashlib.sha256(data).hexdigest()
table=font(source,1)
out={}
for ram in (64,80,128):
    outcomes=[]
    for suffix in ("","-repeat"):
        p=root/(str(ram)+"MiB"+suffix)
        r=json.loads((p/"receipt.json").read_text())
        trace=(p/"firmware.txt").read_text().splitlines()
        serial=(p/"serial.txt").read_text()
        assert r["usb_sha256"]=="d03b917354db7f549a8eefc33107d7cf74f0a27d0dfaa5ae40bfa01b7ba2527e" and r["usb_still_matches"]
        assert r["efi_sha256"]=="28a31b46fe9d6ff7b3087d7b69a49d499365d6d6a96bdeb2bee4dd9691cf4906"
        before,end=r["snapshots"]
        assert compare(p,before,end)==r["changes"]
        assert before["nvme_sha256"]==end["nvme_sha256"]==sha((root/"internal-control.raw").read_bytes())
        delta=r["changes"]["counter_deltas"]["sentinel"]
        assert not any(delta.values()),delta
        media=r["stick_counters"]
        assert media["rd_operations"]>0
        for key in ("wr_operations","wr_bytes","failed_wr_operations","invalid_wr_operations","flush_operations","unmap_operations"):
            assert media[key]==0
        assert r["changes"]["vars_bytes_changed"]==6047
        assert any(x.endswith("/BootOrder") for x in r["changes"]["variables_added"])
        assert "removable-vm" in trace and r["final_status"]=="shutdown"
        assert any(e["event"]=="SHUTDOWN" and e["data"]=={"guest":True,"reason":"guest-shutdown"} for e in r["events"])
        passes=sum(x.startswith("  pass ") for x in serial.splitlines())
        failures=sum(x.startswith("  FAIL ") for x in serial.splitlines())
        if ram==64:
            assert "allocation=800000000000000e" in trace and trace[-1]=="handoff-refused" and not r["keys"]
            assert "owned-handoff" not in trace and "owned-before-write" not in trace and "PCP OS kernel " not in serial
            assert passes==failures==0
            outcome="allocation refused; automatic guest shutdown"
        else:
            assert r["keys"]==["f10","ret"] and "allocation=0000000000000000" in trace and "owned-handoff" in trace
            assert "PCP OS kernel " in serial and "desktop: 1920x1080" in serial
            if ram==80:
                assert "memory for programs: 0 frames" in serial and failures==2
                assert "it is in SAFE and starts no program" in serial and "2 SELF-TEST(S) FAILED" in serial
                outcome="zero program frames; SAFE; two failed checks; confirmed shutdown"
            else:
                assert passes==72 and failures==0 and "ALL SELF-TESTS PASS." in serial
                outcome="72 passed; confirmed shutdown"
            if suffix:
                def visible(stem):
                    with Image.open(p/(stem+".png")) as im:
                        assert im.size==(1920,1080)
                        return " ".join(" ".join(rows(np.array(im.convert("RGB")),table,1)).split())
                home=visible("home");prompt=visible("confirmation")
                assert ("NOT VERIFIED: 2 of 40 self-tests failed." in home) if ram==80 else ("verified" in home)
                assert "Switch PCP OS off?" in prompt and "Enter switch off Esc go back" in prompt
        if suffix:assert r["matched_repeat_expectation"]
        outcomes.append({"result":outcome,"kernel_pass":passes,"kernel_fail":failures,"keys":r["keys"],"USB_reads":media["rd_operations"],"internal_media_requests":0,"OVMF_variable_bytes_changed":r["changes"]["vars_bytes_changed"]})
    assert outcomes[0]==outcomes[1]
    out[str(ram)+" MiB"]=dict(repetitions=2,**outcomes[0])
print(json.dumps(out,indent=2))

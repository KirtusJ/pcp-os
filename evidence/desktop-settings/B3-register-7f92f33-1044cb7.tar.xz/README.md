# B3 register renderer and checker review

B3 built the OS renderer at 7f92f3392361d78c06ce15bbdbd2f1973776922b (Rust tree cdbc2b2f758177fc9c5c504abef19b6b55d3074e). The subsequent 1044cb73d7d39eb9c58cd62bde27db02576a1fb3 changed only the hosted small-screen checker. Both checker versions are included. The distribution checkout for the guarded optical driver was 2abeead177d616582db7029561df2e10c95381eb. The public optical ISO and measured kernel are identified in guarded/image.json.

The unmodified guarded optical check passed the latest, earlier and restored register views, including contiguous historical sequence strips. The stopped and completed Surfbird tasks, F10 cancellation and final confirmation, normal guest shutdown and 72 self-tests are recorded. Five separate stock USB/OVMF profiles also passed: standard VGA at 128 and 256 MiB, virtio-vga at 128 MiB and RAMFB at 128 and 256 MiB. Each recorded the kernel measurement, F5, Esc, F10, guest shutdown, 72 checks and an unchanged internal test disk. The RAMFB addresses differ between the two RAM sizes.

Thirteen additional QEMU guests recorded fifteen frames each, including F5, newest/earlier/restored/first register pages, Programs, Settings, F10/Esc and F10/Enter. All passed, including native 1280×720, 1920×1080 and 2560×1440. For 42 events, 656 px across produces a wrapped full head and 664 px a marked table prefix. The full table title begins between the measured 1208 and 1216 px controls. The full visible prefix agreed with the independently captured F5 prefix up to the common length (at most 16 digits).

The earlier checker accepts a seven-digit head with two genuine dot glyphs at the three predominant sizes. The revised checker rejects those copies. At 320×200, 640×480 and 656×480, erasing the 64th digit in the wrapped head was accepted by both checkers. Their input joins the following event's sequence zero onto the 63 remaining digits. The controls modify copies of the original P6 pixels; the original screens show the full head. See revised.json for original and altered verdicts.

From the unpacked directory, use Python 3 and NumPy:

    sha256sum --quiet -c SHA256SUMS
    python3 -B readback.py fresh.json
    cmp fresh.json readback.json
    cp revised.json expected.json
    python3 -B revised_replay.py
    cmp expected.json revised.json

The independent tests reread the actual font, capture dimensions, original hashes, F5 prefix, F4 title and event number ranges. The USB archive includes the original firmware, serial and result logs plus the F10 frame for all five guests. Each USB receipt also records its unchanged medium, disk and variable-store observations. The stock optical samples are complete.

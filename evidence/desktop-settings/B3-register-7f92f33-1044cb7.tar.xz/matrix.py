from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,sys
d=Path(__file__).resolve().parent
modes=['320x200','640x480','656x480','664x480','1024x768','1160x768','1168x768','1176x768','1280x720','1920x1080','2560x1440']
def run(mode):
    args=[sys.executable,'-B',d/'guest.py',mode,'--name',mode,'--source',d/'source','--qemu','/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64']
    with (d/(mode+'.log')).open('w') as log:code=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT).returncode
    return mode,code
with ThreadPoolExecutor(max_workers=3) as workers:results=list(workers.map(run,modes))
print(results);sys.exit(any(code for _,code in results))

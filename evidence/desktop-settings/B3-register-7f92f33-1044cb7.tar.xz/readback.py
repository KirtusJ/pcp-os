"""Independently test whole versus marked partial register heads from native guest pixels."""
import argparse,ast,hashlib,json,re
from pathlib import Path
import numpy as np
import pixels as px
from power import read_dialog
root=Path(__file__).resolve().parent
def lines(im):
    return [px.row(im,n,1).rstrip() for n in range(im.shape[0]//20)]
def picture(d,name):
    return px.image((d/(name+'.ppm')).read_bytes())
def entry(d):
    r=json.loads((d/'result.json').read_text())
    assert r['active']==list(map(int,d.name.split('x')))
    for n,h in r['frames'].items():
        raw=(d/(n+'.ppm')).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==h and list(px.image(raw).shape[1::-1])==r['active']
    f=r['frames'];assert f['register-restored']==f['register-latest']
    assert all(f[n]==f['home'] for n in ('after-register','after-verify','after-programs','after-settings','cancelled'))
    assert f['confirmed-prompt']==f['power']
    assert r['exit']==0 and r['shutdown']==dict(guest=True,reason='guest-shutdown') and r['final_checks']==72
    raw=(d/'power.ppm').read_bytes()
    power=read_dialog(raw,px.alph[1])
    assert power['warning'] and power['actions']
    ver=''.join(''.join(lines(picture(d,'verify'))).split())
    v=re.search(r'Register:(\d+)events,head([0-9a-f]{16})\.\.\.',ver)
    assert v and 'VERIFICATION' in ver,(d.name,ver)
    count,observed=v.groups();count=int(count)
    first=lines(picture(d,'register-first'));latest=lines(picture(d,'register-latest'))
    title=next(row.strip() for row in first if 'REGISTER:' in row)
    assert str(count)+' events' in title and 'intact' in title
    width,height=r['active']
    narrow=width//10-4<62
    fixed=len(f"THE KERNEL'S REGISTER: {count} events, chain intact, head ")
    full=narrow or width//10-4>=fixed+64
    if narrow:
        before_event=first[:next(i for i,s in enumerate(first) if re.match(r'^\s*0 WORKSPACE_CREATED',s))]
        head=re.search(r'head([0-9a-f]{64})$',''.join(''.join(before_event).split()))[1]
        assert any(re.match(r'^\s*0 WORKSPACE_CREATED',s) for s in first)
    else:
        head=title.split('head ')[1]
        assert ('..' not in head) if full else head.endswith('..')
        assert re.fullmatch(r'[0-9a-f]{64}',head) if full else len(title)==width//10-4
        assert any(row.strip()=='seq  time                  actor     kind                 what' for row in latest)
        seq=lambda rows:[int(m[1]) for row in rows if (m:=re.match(r'^\s*(\d+)\s+\d{4}-',row))]
        begin,end=seq(first),seq(latest)
        assert begin==list(range(len(begin))) and end==list(range(count-len(end),count))
    h=head.removesuffix('..')
    assert h[:min(len(h),16)]==observed[:min(len(h),16)]
    return dict(size=r['active'],events=count,home_restored=True,whole_head=full,displayed_head=head,
                first_page_differs=f['register-first']!=f['register-latest'],f5_prefix=observed,checks=72)
def controls():
    checker=root/'source/examples/tester-cd/check_small_screens.py'
    tree=ast.parse(checker.read_text())
    patterns=[node.args[0].value for node in ast.walk(tree) if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='search' and len(node.args)>1 and isinstance(node.args[1],ast.Name) and node.args[1].id=='register']
    assert len(patterns)==2
    src=picture(root/'guests/1024x768','register-first')
    ln=lines(src)[1]
    left=10*ln.index('..')
    dots=src[20:40,left:left+20].copy()
    results={}
    for mode in ['1280x720','1920x1080','2560x1440']:
        im=picture(root/'guests'/mode,'register-first').copy()
        orig=lines(im)[1]
        start=orig.index('head ')+5+7
        end=len(orig)
        im[20:40,10*start:10*end]=im[20,0].copy()
        im[20:40,10*start:10*start+20]=dots
        after=lines(im);title=after[1].strip()
        assert re.fullmatch(r".+head [0-9a-f]{7}\.\.",title)
        register=''.join(''.join(after).split())
        accepted=all(re.search(p,register) is not None for p in patterns)
        assert accepted and not re.search(r'head [0-9a-f]{64}$',title)
        results[mode]=dict(candidate_T4_accepts=accepted,whole_head=False,title=title)
    return results
p=argparse.ArgumentParser();p.add_argument('out',type=Path);a=p.parse_args()
records={g.name:entry(g) for g in sorted((root/'guests').iterdir())}
result={'modes':records,'controls':controls()}
a.out.write_text(json.dumps(result,indent=2)+'\n')
print(len(records),'native boots; three truncated-head controls accepted by candidate T4')

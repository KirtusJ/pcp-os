"""Read each selection, then check that the two result rows and two access rows survive at 320×200."""
import argparse
from pathlib import Path
import re
import hashlib
import json
import numpy as np
from pixels import image, decode

root=Path(__file__).resolve().parent
panel=np.array([0x18,0x36,0x4f])
def verdict(frame, expected):
    rows=decode(frame)
    marked=[]
    for n,t in enumerate(rows):
        if not re.fullmatch(r'\s*\??entry-0[1-8]\.elf', t):continue
        found=re.search(r'entry-0[1-8]\.elf',t)
        area=frame[n*20:(n+1)*20,10*found.start():10*found.end()]
        if np.all(area==panel,axis=2).mean()>.5:
            marked.append((found.group(),n))
    text=' '.join(s.strip() for s in rows if s.strip())
    message=''.join(''.join(s.split()) for s in rows)
    return {'selection':len(marked)==1 and marked[0][0]==expected,
            'marked_rows':marked,'verification':any(s.strip() in ('Verified at start: all 71 self-tests passed.','Verified: all 71 self-tests','Verified: all 71') for s in rows),
            'access':'Access: console, display, keyboard, files and store' in text,
            'keys':'Up/Down choose Enter open D details R register P off' in ' '.join(text.split()),
            'message':bool(re.search(r'entry-08\.elfendedDONE:exit0after[0-9]+s\.',message)),
            'rows':rows}
out={}
for folder in sorted((root/'guests').iterdir()):
    note=json.loads((folder/'result.json').read_text())
    for f,digest in note['frames'].items():
        assert hashlib.sha256((folder/(f+'.ppm')).read_bytes()).hexdigest()==digest
    serial=(folder/'serial.txt').read_text()
    assert note['exit']==0 and note['final_checks']==72 and note['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    assert note['measure']+' (measured; equal' in serial and 'entry-08.elf ended DONE: exit 0' in serial
    assert len([l for l in serial.splitlines() if l.startswith('  pass ')])==72
    def check(label,num,done):
        v=verdict(image(folder/(label+'.ppm')),f'entry-{num:02}.elf')
        assert all(v[k] for k in ['selection','verification','access','keys']) and v['message']==done,(label,v)
        return v
    check('first',1,False)
    for i in range(2,9):check('choose-'+str(i),i,False)
    last=check('last-after-exit',8,True)
    prev=check('previous-after-exit',7,True)
    again=check('last-reselected',8,True)
    assert last==again
    out[folder.name]={'last_after_exit':last,'previous_after_exit':prev,'all_8_choices_read':True,'final_checks':72}
frame=image(root/'guests/320x200/last-after-exit.ppm')
observed={}
for n,expected in [(4,'message'),(5,'message'),(6,'access'),(7,'access')]:
    altered=frame.copy(); altered[20*n:20*(n+1)]=frame[0,0]
    v=verdict(altered,'entry-08.elf')
    missing=[k for k in ('selection','verification','access','keys','message') if not v[k]]
    assert missing==[expected],(n,missing)
    observed[n]=missing
out['erased_rows_320x200']=observed
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('report',type=Path);args=parser.parse_args()
args.report.write_text(json.dumps(out,indent=2)+'\n')
print(f'Passed 24 program selections and 3 completed-task read-backs; all four individual line erasures detected.')

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys,subprocess
d=Path(__file__).resolve().parent
modes='320x200 320x220 320x240 320x260 320x280 320x480 344x200 352x200 352x220 352x240 640x200 640x220 640x480 752x480 760x460 760x480 776x480 784x480 800x600 1024x768'.split()
def run(mode):
    with (d/(mode+'.log')).open('w') as log:
        code=subprocess.run([sys.executable,'-B',d/'guest.py',mode,*sys.argv[1:]],stdout=log,stderr=subprocess.STDOUT).returncode
    return mode,code
with ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(run,modes))
print(results)
if any(code for _,code in results):raise SystemExit(1)

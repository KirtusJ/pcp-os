"""Replay the native dialogs and the stock optical/USB results, including the failed 1024px register gate."""
from pathlib import Path
import ast,hashlib,json,runpy,subprocess,sys,tempfile
import numpy as np
from check import read_dialog, screen

d=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
if (d/'SHA256SUMS').is_file():
    subprocess.run(['sha256sum','--quiet','-c','SHA256SUMS'],cwd=d,check=True)
with tempfile.TemporaryDirectory() as temp:
    for script,report in [('check.py','readback.json'),('controls.py','controls.json')]:
        out=Path(temp)/report
        subprocess.run([sys.executable,'-B',d/script,d/'guests',d/'inputs/font.rs',out],check=True)
        assert out.read_bytes()==(d/report).read_bytes()
font=(d/'inputs/font.rs').read_text()
table=ast.literal_eval('['+font.split(' = [',1)[1].split('];',1)[0]+']')
alphabet={np.packbits(np.asarray(c)>0).tobytes():chr(32+i) for i,c in enumerate(table)}
inputs=load(d/'inputs/receipt.json')
for mode,obs in load(d/'readback.json').items():
    dr=d/'guests'/mode;n=load(dr/'result.json');log=(dr/'serial.txt').read_text()
    assert n['head']==inputs['source_commit'] and n['measure']==inputs['kernel_measurement']
    assert n['measure']+' (measured; equal' in log and sum(l.startswith('  pass ') for l in log.splitlines())==72
assert len(load(d/'readback.json'))==20
usb=d/'usb-trial'
ui=load(usb/'image.json')
assert ui['experiment_commit']==inputs['source_commit'] and ui['experiment_dirty'] is False
body=['The register is closed and verified first. Files of this session that were','not saved by a program are lost.']
for mode in ['128','256','ramfb-128','ramfb-256','virtio-vga']:
    dr=usb/mode
    v=load(dr/'result.json')
    assert v['passed'] and v['self_tests']==72 and v['exit']==0 and v['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    assert v['usb_sha256_after']==ui['usb_sha256']
    f=(dr/'power.ppm').read_bytes(); out=read_dialog(f,alphabet)
    assert out['layout']=='roomy' and out['warning'] and out['actions'] and out['lines'][5:7]==body
    assert ui['measurement']+' (measured; equal' in (dr/'serial.txt').read_text()
reg=runpy.run_path(str(d/'public_regions.py'))
for variant,expected in [('guarded-control',True),('guarded-details',False)]:
    dr=d/variant/'session'
    f=(dr/'register-latest.ppm').read_bytes()
    assert reg['has_regions'](f,[reg['REGISTER_FOOTER']])
    assert reg['has_regions'](f,[reg['LATEST_ROWS']]) is expected
    w,h,rows=screen(f,alphabet)
    assert (w,h)==(1024,768)
    vs=load(d/variant/'image.json')
    if not expected:assert vs['measurement']==inputs['kernel_measurement']
    log=(dr/'serial.txt').read_text()
    assert vs['measurement']+' (measured; equal' in log
    assert 'surf.elf ended DONE' in log and 'surf.elf ended STOPPED' in log
    if expected:
        assert '17 ' in rows[3] and '48 ' in rows[34]
        assert (dr/'qemu-exit.txt').read_text().strip()=='0'
        assert (dr/'after-register.ppm').read_bytes()==(dr/'power-cancelled.ppm').read_bytes()
        assert len(load(dr/'register.json')['tasks'])==2 and sum(l.startswith('  pass ') for l in log.splitlines())==72
    else:
        assert '34 ' in rows[5] and 'TimeoutError: register-latest' in (d/'guarded-details.log').read_text()
print('20 complete native dialogs, 16 detected erasures, 5 USB profiles. The previous optical kernel passed. The new optical capture matches the footer and fails the pinned latest-row column.')

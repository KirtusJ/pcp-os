"""Read the warning and both actions from a #314 candidate's original QEMU pixels."""
import argparse
import ast
import hashlib
import json
from pathlib import Path

import numpy as np


def screen(ppm, alphabet):
    magic, size, level, raw = ppm.split(b'\n',3)
    width, height = map(int,size.split())
    if magic != b'P6' or level != b'255' or len(raw) != 3*width*height:
        raise ValueError('incomplete P6')
    image = np.frombuffer(raw,dtype=np.uint8).reshape(height,width,3)
    lines = []
    for y in range(0,height-height%20,20):
        chars = []
        for x in range(0,width-width%10,10):
            cell = image[y:y+20,x:x+10]
            mask = np.any(cell != cell[0,0],axis=2)
            chars.append(alphabet.get(np.packbits(mask).tobytes(),'?'))
        lines.append(''.join(chars).strip())
    return width, height, lines


def read_dialog(ppm, alphabet):
    width, height, lines = screen(ppm,alphabet)
    keys = ['Enter switch off','Esc go back']
    both = '    '.join(keys)
    expected = ('The register is closed and verified first. '
                'Files of this session that were not saved by a program are lost.')
    if lines[1]=='POWER OFF' and lines[3]=='Switch PCP OS off?':
        layout='roomy'
        body=lines[5:-2]
        actions=(lines[-2]==both)
    elif lines[0]=='POWER OFF' and lines[1]=='Switch PCP OS off?':
        layout='compact'
        if lines[-1]==both:
            body=lines[2:-1]
            actions=True
        else:
            body=lines[2:-2]
            actions=(lines[-2:]==keys)
    else:
        return {'width':width,'height':height,'lines':lines,'layout':None,'warning':False,'actions':False}
    return {'width':width,'height':height,'lines':lines,'layout':layout,
            'warning':' '.join(l for l in body if l)==expected,'actions':actions}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('guest_root',type=Path);p.add_argument('font',type=Path);p.add_argument('report',type=Path)
    args=p.parse_args()
    font=ast.literal_eval('['+args.font.read_text().split(' = [',1)[1].split('];',1)[0]+']')
    alphabet={np.packbits(np.asarray(row)>0).tobytes(): chr(32+i) for i,row in enumerate(font)}
    observations={}
    for guest in sorted(args.guest_root.iterdir()):
        r=json.loads((guest/'result.json').read_text()); digests={}
        for name in ('home','power','cancelled','confirmed-prompt'):
            raw=(guest/(name+'.ppm')).read_bytes()
            digest=hashlib.sha256(raw).hexdigest()
            if digest!=r['frames'][name]:raise ValueError(f'{guest.name}: changed {name}')
            digests[name]=digest
        obs=read_dialog((guest/'power.ppm').read_bytes(),alphabet)
        obs['restored_home']=digests['home']==digests['cancelled']
        obs['reopened_same_prompt']=digests['power']==digests['confirmed-prompt']
        obs['intended_keys']=r['key_log']==['f10','esc','f10','ret']
        obs['clean_shutdown']=(r['final_checks']==72 and r['exit']==0
                               and r['shutdown']=={'guest':True,'reason':'guest-shutdown'})
        observations[guest.name]=obs
    args.report.write_text(json.dumps(observations,indent=2)+'\n')
    return all(all(o[k] for k in ('layout','warning','actions','restored_home','reopened_same_prompt','intended_keys','clean_shutdown'))
               for o in observations.values()) and bool(observations)


if __name__=='__main__':
    raise SystemExit(0 if main() else 1)

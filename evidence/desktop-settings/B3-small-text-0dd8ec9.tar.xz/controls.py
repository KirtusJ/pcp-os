from pathlib import Path
import argparse,ast,json
import numpy as np
from check import read_dialog, screen

def erased(raw,alphabet,term):
    w,h,rows=screen(raw,alphabet)
    matching=[n for n,s in enumerate(rows) if term in s]
    assert len(matching)==1,(term,rows)
    n=matching[0];col=2+rows[n].index(term)
    header,shape,depth,pixels=raw.split(b'\n',3)
    image=np.frombuffer(pixels,dtype=np.uint8).reshape(h,w,3).copy()
    image[n*20:(n+1)*20,col*10:(col+len(term))*10]=image[n*20,0].copy()
    return b'\n'.join([header,shape,depth,image.tobytes()])
def main():
    p=argparse.ArgumentParser();p.add_argument('guests',type=Path);p.add_argument('font',type=Path);p.add_argument('report',type=Path)
    a=p.parse_args(); t=a.font.read_text()
    tab=ast.literal_eval('['+t.split(' = [',1)[1].split('];',1)[0]+']')
    alphabet={np.packbits(np.asarray(c)>0).tobytes():chr(32+i) for i,c in enumerate(tab)}
    results={}
    for size in ['320x200','352x200','640x480','800x600']:
        raw=(a.guests/size/'power.ppm').read_bytes();orig=read_dialog(raw,alphabet)
        assert orig['warning'] and orig['actions']
        trials={}
        for text,k in [('not','warning'),('lost.','warning'),('Enter switch off','actions'),('Esc go back','actions')]:
            r=read_dialog(erased(raw,alphabet,text),alphabet)
            other='actions' if k=='warning' else 'warning'
            assert not r[k] and r[other] and r['layout']==orig['layout'],(size,text,r)
            trials[text]={key:r[key] for key in ['layout','warning','actions']}
        results[size]=trials
    a.report.write_text(json.dumps(results,indent=2)+'\n');print('16 independent pixel erasures detected.')
if __name__=='__main__':main()

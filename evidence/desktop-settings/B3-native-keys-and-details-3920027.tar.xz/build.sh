set -eu
d=$1
kit=/workspace/scratch/edecb50126f6/boot-audit/uefi-bios-regression
export PATH="$kit/toolchain/bin:$kit/toolchain/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$PATH" CARGO_HOME="$kit/cargo" CARGO_NET_OFFLINE=true PCPOS_KERNEL_STAGE="$d/stage"
k="$d/source/PCP_OS_Rust/crates/pcpos-kernel"
sh "$k/run.sh" build
cp "$k/target/pcpos-kernel.elf32" "$d/inputs/kernel.elf32"
python3 "$k/tools/measure.py" "$d/inputs/kernel.elf32" > "$d/inputs/measurement"
nm -Cn "$d/stage/crates/pcpos-kernel/target/x86_64-unknown-none/release/pcpos-kernel" | rg ' pcpos_kernel::(dev::keyboard_byte|session::draw_home|session::draw_desktop|ui::clear)$'

"""Measure actual guest writes during each input window in a stopped-frame QEMU desktop trial."""
from pathlib import Path
import hashlib,json,mmap,re,runpy,struct,subprocess,sys,time
import numpy as np
import pixels

root=Path(__file__).resolve().parent
revision, mode = sys.argv[1:3]
width,height=map(int,mode.split('x'))
src=root/revision
out=root/'guests'/(revision+'-'+mode);out.mkdir(parents=True,exist_ok=False)
v=Path('/workspace/scratch/15ccefba7c7d/validation')
opt=runpy.run_path(str(src/'source/examples/optical-disk-check/check.py'))
elf=src/'inputs/kernel.elf32'
measurement=(src/'inputs/measurement').read_text().strip()
debug=src/'stage/crates/pcpos-kernel/target/x86_64-unknown-none/release/pcpos-kernel'
symbols=subprocess.check_output(['nm','-Cn',debug],text=True).splitlines()
def sym(name):
    matches=[l.split()[0] for l in symbols if l.endswith(' pcpos_kernel::'+name)]
    assert len(matches)==1;return matches[0]
layout=struct.Struct('<42Q')
probe='session::draw_home' if revision!='1c56a70' else 'ui::clear'
state=out/'trace-state.bin';state.write_bytes(bytes(layout.size))
plugin=root.parent/'second-change-314/trace/video_trace.so'
serial=out/'serial.txt'
cmd=[str(v/'bin/qemu-system-x86_64'),'-machine','pc','-accel','tcg','-cpu','max','-m','256M','-smp','1','-nic','none','-display','none','-vga','none','-device','VGA,vgamem_mb=64','-qmp','stdio','-monitor','none','-no-reboot','-S','-kernel',str(elf),'-initrd','rdesk.elf','-append',f'desktop={mode} image={measurement}','-serial','file:'+str(serial),'-plugin',f'file={plugin},state={state},kbd={sym("dev::keyboard_byte")},clear={sym(probe)}']
(out/'rdesk.elf').symlink_to(root/'inputs/rdesk.elf')
record={'revision':revision,'mode':mode,'argv':cmd,'measurement':measurement,'kernel_sha256':hashlib.sha256(elf.read_bytes()).hexdigest(),'intervals':[], 'entry_probe':probe, 'entry_address':sym(probe)}
with state.open('r+b') as fd, mmap.mmap(fd.fileno(),layout.size) as shared, (out/'stderr.txt').open('wb') as err, subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
 try:
    mon=opt['Monitor'](vm);rpc=mon.call;rpc('qmp_capabilities');rpc('cont')
    opt['wait_for'](lambda:serial.exists() and f'desktop: {mode} at 1x UI scale' in serial.read_text(errors='replace'),'measured native desktop',100)
    time.sleep(.5);rpc('stop')
    boot=serial.read_text(errors='replace')
    base=int(re.search(r'display: Bochs, '+mode+r', 2 page\(s\), \d+ KiB of its memory mapped at (0x[0-9a-f]+)',boot)[1],16)
    page=width*height*4
    def frame(label):
        dest=out/(label+'.ppm');rpc('screendump',filename=str(dest));raw=dest.read_bytes()
        im=pixels.image(raw);assert im.shape==(height,width,3)
        return im,hashlib.sha256(raw).hexdigest()
    im,digest=frame('home')
    def interval(label,key,observe_title=False):
        global im,digest
        # Follow a high-contrast, lit pixel near the top. Record its exact RGB and location.
        x,y=0,0
        if observe_title:
            area=im[20:80,20:min(width,420)].astype(np.int32)
            diff=np.sum((area-im[0,0].astype(np.int32))**2,axis=2)
            sy,sx=np.unravel_index(diff.argmax(),diff.shape)
            x,y=20+int(sx),20+int(sy)
        before=int.from_bytes(bytes(im[y,x]),'big')
        shared[:]=layout.pack(1,base,page,base+4*(y*width+x),before,*([0]*37))
        rpc('cont')
        if key:mon.key(*(key if isinstance(key,tuple) else (key,)))
        # Permit one full redraw on slow traced guests. Read the shared count until the guest is quiescent.
        time.sleep(.45)
        last=None;quiet=0
        for _ in range(180):
            values=layout.unpack(shared[:])
            now=values[5:10]
            if (not key or values[7]>=2) and now==last:
                quiet+=1
                if quiet>=3:break
            else:quiet=0
            last=now;time.sleep(.09)
        else:raise ValueError(f'{label} never settled: {values[5:10]}')
        rpc('stop')
        values=layout.unpack(shared[:]);shared[:8]=bytes(8)
        current,dt=frame(label)
        after=int.from_bytes(bytes(current[y,x]),'big')
        record['intervals'].append(dict(label=label,key=key,stores_front=values[5],stores_back=values[6],keyboard_bytes=values[7],entry_calls=values[8],pixel=[x,y],before_rgb=before,after_rgb=after,guest_last_rgb=values[4]&0xffffff,changes=values[9],rgb_sequence=list(values[10:10+min(32,values[9])]),unchanged=dt==digest,sha256=dt))
        assert after==(values[4]&0xffffff),(label,hex(before),hex(after),hex(values[4]),values[5:10])
        im,digest=current,dt
    interval('home-idle',None,True)
    interval('home-letter-p','p',True)
    interval('home-letter-r','r',True)
    if revision!='1c56a70':
        interval('home-open-F5','f5',True)
        interval('home-return-F5','esc',True)
        interval('home-open-F10','f10',True)
        interval('home-cancel-F10','esc',True)
    interval('open-programs','spc')
    interval('programs-idle',None,True)
    interval('programs-letter-p','p',True)
    interval('programs-letter-d','d',True)
    if revision!='1c56a70':
        interval('programs-open-F5','f5',True)
        interval('programs-return-F5','esc',True)
        interval('programs-open-F10','f10',True)
        interval('programs-cancel-F10','esc',True)
    interval('leave-programs','esc')
    interval('power','f10')
    rpc('cont');mon.key('ret');vm.wait(timeout=60)
    log=serial.read_text(errors='replace')
    record.update(exit=vm.returncode,checks=sum(l.startswith('  pass ') for l in log.splitlines()))
    assert record['checks']==72 and record['exit']==0 and 'ALL SELF-TESTS PASS.' in log
 finally:
    if vm.poll() is None:vm.kill();vm.wait()
    (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print([(k['label'],k['stores_front'],k['changes']) for k in record['intervals']])

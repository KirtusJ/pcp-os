"""Read narrow Details and drive the plain compatibility list at the exact width boundary."""
from pathlib import Path
import hashlib,json,re,runpy,subprocess,sys,time
import pixels
root=Path(__file__).resolve().parent
rev,mode=sys.argv[1:3]
src=root/rev
w,h=map(int,mode.split('x'))
g=src/'widget'/mode
g.mkdir(parents=True)
program1='resident-desktop-alpha-with-a-name-longer-than-one-small-row.elf'
program2='surfbird-demo.elf'
file1='inventory-file-with-a-name-longer-than-one-small-row.txt'
(g/program1).symlink_to(root.parent/'second-change-314/inputs/rdesk.elf')
(g/program2).symlink_to(root.parent/'second-change-314/62c24cc/hosted-cases/files/surf.elf')
(g/file1).write_bytes(b'Native Details file field independent check.\n')
fixtures={n:hashlib.sha256((g/n).read_bytes()).hexdigest() for n in (program1,program2,file1)}
monitor=runpy.run_path(str(src/'source/examples/optical-disk-check/check.py'))
measure=(src/'inputs/measurement').read_text().strip()
serial=g/'serial.txt'
cmd=['/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64','-machine','pc','-accel','tcg','-cpu','max','-m','256M','-smp','1','-display','none','-nic','none','-vga','none','-device','VGA,vgamem_mb=64','-qmp','stdio','-monitor','none','-no-reboot','-kernel',str(src/'inputs/kernel.elf32'),'-initrd',','.join(fixtures),'-append',f'desktop={mode} image={measure}','-serial','file:'+str(serial)]
r={'revision':rev,'mode':mode,'measurement':measure,'fixtures':fixtures,'argv':cmd,'captures':{}}
with (g/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=g,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
 try:
    m=monitor['Monitor'](vm);m.call('qmp_capabilities')
    monitor['wait_for'](lambda:serial.exists() and f'desktop: {mode} at 1x UI scale' in serial.read_text(errors='replace'),'native mode',70)
    time.sleep(.35)
    def key(*keys):
        m.key(*keys);time.sleep(.23)
    def frame(label):
        p=g/(label+'.ppm');prior=None
        for _ in range(35):
            m.call('screendump',filename=str(p));raw=p.read_bytes()
            if raw==prior:break
            prior=raw;time.sleep(.08)
        else:raise ValueError(label+' unsettled')
        im=pixels.image(raw)
        assert im.shape==(h,w,3)
        rows=[pixels.row(im,i,1).rstrip() for i in range(h//20)]
        sha=hashlib.sha256(raw).hexdigest()
        r['captures'][label]=sha
        (g/(label+'.txt')).write_text('\n'.join(rows)+'\n')
        return rows,sha
    home,home_sha=frame('home')
    def switch_session(prefix):
        key('f2')
        rows,_=frame(prefix+'-settings')
        assert any('SETTINGS' in v for v in rows)
        for _ in range(4):key('down')
        key('ret')
        rows,_=frame(prefix+'-choice')
        assert any('Session' in v for v in rows)
        key('esc')
    switch_session('on')
    on,marked=frame('widget-on')
    assert marked!=home_sha
    complete='Session files | cleared at power-off'
    expected=complete if w//10-4>=len(complete) else 'Files last until power-off'
    assert any(row.strip()==expected for row in on),(mode,on,expected)
    switch_session('off')
    off,back=frame('widget-off')
    assert back==home_sha and not any(row.strip()==expected for row in off)
    r.update(widget=expected)
    key('f10');frame('power');key('ret');vm.wait(timeout=50)
    log=serial.read_text();r.update(exit=vm.returncode,checks=sum(x.startswith('  pass ') for x in log.splitlines()))
    assert vm.returncode==0 and r['checks']==72 and 'ALL SELF-TESTS PASS.' in log
 finally:
    if vm.poll() is None:vm.kill();vm.wait()
    (g/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(mode,r['widget'],len(r['captures']),r['checks'])

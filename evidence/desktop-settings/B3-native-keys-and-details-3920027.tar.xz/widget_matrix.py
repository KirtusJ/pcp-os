import concurrent.futures,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent
def run(mode):
    with (r/sys.argv[1]/('widget-'+mode+'.log')).open('w') as f:
        rc=subprocess.run([sys.executable,'-B',r/'widget_guest.py',sys.argv[1],mode],stdout=f,stderr=subprocess.STDOUT).returncode
    return mode,rc
with concurrent.futures.ThreadPoolExecutor(3) as e:
    result=list(e.map(run,['320x480','392x480','400x480','640x480']))
print(result);sys.exit(any(rc for _,rc in result))

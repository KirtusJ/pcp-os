"""Read narrow Details and drive the plain compatibility list at the exact width boundary."""
from pathlib import Path
import hashlib,json,re,runpy,subprocess,sys,time
import pixels
root=Path(__file__).resolve().parent
rev,mode=sys.argv[1:3]
src=root/rev
w,h=map(int,mode.split('x'))
g=src/'details'/mode
g.mkdir(parents=True)
program1='resident-desktop-alpha-with-a-name-longer-than-one-small-row.elf'
program2='surfbird-demo.elf'
file1='inventory-file-with-a-name-longer-than-one-small-row.txt'
(g/program1).symlink_to(root.parent/'second-change-314/inputs/rdesk.elf')
(g/program2).symlink_to(root.parent/'second-change-314/62c24cc/hosted-cases/files/surf.elf')
(g/file1).write_bytes(b'Native Details file field independent check.\n')
fixtures={n:hashlib.sha256((g/n).read_bytes()).hexdigest() for n in (program1,program2,file1)}
monitor=runpy.run_path(str(src/'source/examples/optical-disk-check/check.py'))
measure=(src/'inputs/measurement').read_text().strip()
serial=g/'serial.txt'
cmd=['/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64','-machine','pc','-accel','tcg','-cpu','max','-m','256M','-smp','1','-display','none','-nic','none','-vga','none','-device','VGA,vgamem_mb=64','-qmp','stdio','-monitor','none','-no-reboot','-kernel',str(src/'inputs/kernel.elf32'),'-initrd',','.join(fixtures),'-append',f'desktop={mode} image={measure}','-serial','file:'+str(serial)]
r={'revision':rev,'mode':mode,'measurement':measure,'fixtures':fixtures,'argv':cmd,'captures':{}}
with (g/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=g,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
 try:
    m=monitor['Monitor'](vm);m.call('qmp_capabilities')
    monitor['wait_for'](lambda:serial.exists() and f'desktop: {mode} at 1x UI scale' in serial.read_text(errors='replace'),'native mode',70)
    time.sleep(.35)
    def key(*keys):
        m.key(*keys);time.sleep(.23)
    def frame(label):
        p=g/(label+'.ppm');prior=None
        for _ in range(35):
            m.call('screendump',filename=str(p));raw=p.read_bytes()
            if raw==prior:break
            prior=raw;time.sleep(.08)
        else:raise ValueError(label+' unsettled')
        im=pixels.image(raw)
        assert im.shape==(h,w,3)
        rows=[pixels.row(im,i,1).rstrip() for i in range(h//20)]
        sha=hashlib.sha256(raw).hexdigest()
        r['captures'][label]=sha
        (g/(label+'.txt')).write_text('\n'.join(rows)+'\n')
        return rows,sha
    home,home_sha=frame('home')
    key('spc');list_rows,list_sha=frame('programs')
    assert list_sha!=home_sha
    key('ctrl','d');rows,first=frame('details-0');assert first!=list_sha
    if w//10<96:
        all_rows=[];last=None
        for i in range(80):
            if i:
                key('down');rows,sha=frame('details-'+str(i))
            else:sha=first
            if sha==last:break
            last=sha
            assert 'DETAILS' in [x.strip() for x in rows] and any(x.strip().endswith('Esc back') for x in rows)
            roomy=len(rows)>=14
            start,per=(3,len(rows)-6) if roomy else (1,len(rows)-2)
            page=rows[start:start+per]
            if all_rows:
                overlap=next((n for n in range(min(len(page),len(all_rows)),0,-1) if all_rows[-n:]==page[:n]),0)
                assert overlap and overlap<len(page)
                all_rows.extend(page[overlap:])
            else:all_rows=list(page)
            if not any('Up/Down scroll' in x for x in rows):break
        else:raise ValueError('unbounded pages')
        flat=''.join(x.strip() for x in all_rows)
        fields=[];items=iter(enumerate(all_rows))
        for pos,line in items:
            if line.strip()!='SHA-256':continue
            run=''
            for following in all_rows[pos+1:]:
                if not re.fullmatch('[a-f0-9]+',following.strip()):break
                run+=following.strip()
            fields.append(run)
        # Both executable modules also appear as loader files. Verify each named field in its section.
        program_rows=all_rows.index(next(x for x in all_rows if x.strip()=='PROGRAMS'))
        file_rows=all_rows.index(next(x for x in all_rows if x.strip()=='FILES FROM THE LOADER'))
        machine_rows=all_rows.index(next(x for x in all_rows if x.strip()=='MACHINE'))
        assert fields==[fixtures[program1],fixtures[program2],fixtures[program1],fixtures[program2],fixtures[file1]]
        for section,start,end in [([program1,program2],program_rows,file_rows),([program1,program2,file1],file_rows,machine_rows)]:
            section_text=''.join(x.strip() for x in all_rows[start:end])
            boundary=0
            for name in section:
                where=section_text.index(name,boundary)
                digestpos=section_text.index('SHA-256'+fixtures[name],where)
                boundary=digestpos+len('SHA-256')+64
        for name,checksum in fixtures.items():
            assert name in flat and flat.index(name)<flat.index(checksum) and 'SHA-256' in flat[flat.index(name):flat.index(checksum)]
        assert all(x in flat for x in ['PROGRAMS','FILES FROM THE LOADER','MACHINE'])
        r.update(presentation='narrow text',fields=fields,lines=all_rows)
        key('esc');assert frame('back-to-programs')[1]==list_sha
    else:
        assert any('Parrot Council Protocol' in x for x in rows)
        r['presentation']='plain list'
        key('r');reg,_=frame('plain-r');assert any('REGISTER' in x for x in reg)
        key('esc');assert frame('plain-after-r')[1]==first
        key('p');power,_=frame('plain-p');assert any('POWER OFF' in x for x in power)
        key('esc');assert frame('plain-after-p')[1]==first
        key('d');assert frame('back-to-programs')[1]==list_sha
    key('esc');assert frame('back-home')[1]==home_sha
    key('f10');frame('power');key('ret');vm.wait(timeout=50)
    log=serial.read_text();r.update(exit=vm.returncode,checks=sum(x.startswith('  pass ') for x in log.splitlines()))
    assert vm.returncode==0 and r['checks']==72 and 'ALL SELF-TESTS PASS.' in log
 finally:
    if vm.poll() is None:vm.kill();vm.wait()
    (g/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(mode,r['presentation'],len(r['captures']),r['checks'])

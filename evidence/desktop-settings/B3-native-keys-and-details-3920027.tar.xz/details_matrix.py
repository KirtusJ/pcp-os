import concurrent.futures,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent
def run(mode):
    with (r/sys.argv[1]/('details-'+mode+'.log')).open('w') as f:
        rc=subprocess.run([sys.executable,'-B',r/'details_guest.py',sys.argv[1],mode],stdout=f,stderr=subprocess.STDOUT).returncode
    return mode,rc
with concurrent.futures.ThreadPoolExecutor(3) as e:
    result=list(e.map(run,['320x200','640x480','952x480','960x480','1280x720','1920x1080','2560x1440']))
print(result);sys.exit(any(rc for _,rc in result))

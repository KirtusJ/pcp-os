"""Replay B3's original QEMU frames and interval observations for the third small-display change."""
from pathlib import Path
import hashlib,json,re
import pixels

root=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
normal={"guest":True,"reason":"guest-shutdown"}
def image(folder,label):
    return (folder/(label+'.ppm')).read_bytes()
def guest(folder):
    r=read(folder/'result.json')
    serial=(folder/'serial.txt').read_text()
    assert r['exit']==0 and r['checks']==72
    assert sum(l.startswith('  pass ') for l in serial.splitlines())==72
    assert 'ALL SELF-TESTS PASS.' in serial and r['measurement'] in serial
    assert 'desktop: '+r['mode']+' at 1x UI scale' in serial
    return r
def replay_trace(folder):
    r=guest(folder);cut=r['revision']=='3920027'
    if cut:assert r['entry_probe']=='session::draw_home'
    home=image(folder,'home');prev=home;seen={}
    for e in r['intervals']:
        name=e['label'];raw=image(folder,name);a=pixels.image(prev);b=pixels.image(raw)
        assert [b.shape[1],b.shape[0]]==list(map(int,r['mode'].split('x')))
        x,y=e['pixel']
        assert int.from_bytes(bytes(a[y,x]),'big')==e['before_rgb']
        assert int.from_bytes(bytes(b[y,x]),'big')==e['guest_last_rgb']==e['after_rgb']
        assert (prev==raw)==e['unchanged'] and sha(raw)==e['sha256']
        assert e['stores_back']==0
        if e['key']:assert e['keyboard_bytes']>=2
        if name.endswith('-idle'):
            assert e['keyboard_bytes']==0
            if not cut and r['mode']=='2560x1440' and name=='home-idle':
                # The initial old Home frame was taken during its first paint.
                assert not e['unchanged'] and e['stores_front']==102680
            else:
                assert e['unchanged'] and e['stores_front']==0
        if '-letter-' in name:
            assert e['unchanged']
            if cut:assert e['stores_front']==e['entry_calls']==e['changes']==0
            else:
                assert e['stores_front']>0
                if r['mode'] in ('320x200','640x480'):
                    assert e['changes']>=2 and e['rgb_sequence'][-1]==e['before_rgb'] and any(c!=e['before_rgb'] for c in e['rgb_sequence'])
        if cut and name in ('home-return-F5','home-cancel-F10'):
            assert e['entry_calls']==1 and e['stores_front']>0 and raw==home
        if cut and name in ('programs-return-F5','programs-cancel-F10'):
            assert e['stores_front']>0 and raw==image(folder,'open-programs')
        seen[name]=e;prev=raw
    return {k:{'front':e['stores_front'],'back':e['stores_back'],'entry_calls':e.get('entry_calls',e.get('clear_calls'))} for k,e in seen.items() if '-letter-' in k or '-return-' in k or '-cancel-' in k}

def read_details(folder):
    r=guest(folder);fields=r['fixtures'];names=list(fields)
    rows_list=[]
    for label,expected in r['captures'].items():
        raw=image(folder,label);im=pixels.image(raw)
        assert sha(raw)==expected and list(im.shape[1::-1])==list(map(int,r['mode'].split('x')))
        rows=[pixels.row(im,i,1) for i in range(im.shape[0]//20)]
        assert rows==(folder/(label+'.txt')).read_text().splitlines()
        if re.fullmatch('details-[0-9]+',label) and r['presentation']=='narrow text':
            assert 'DETAILS' in [l.strip() for l in rows]
            assert any(l.strip().endswith('Esc back') for l in rows)
            roomy=len(rows)>=14
            rows_list.append(rows[3:len(rows)-3] if roomy else rows[1:-1])
    assert image(folder,'home')==image(folder,'back-home') and image(folder,'programs')==image(folder,'back-to-programs')
    if r['presentation']=='plain list':
        assert image(folder,'details-0')==image(folder,'plain-after-p')==image(folder,'plain-after-r')
        assert 'POWER OFF' in (folder/'plain-p.txt').read_text() and 'REGISTER' in (folder/'plain-r.txt').read_text()
        return 'plain list, R / P / D'
    joined=[]
    for rows in rows_list:
        if not joined:joined.extend(rows);continue
        n=next(n for n in range(min(len(rows),len(joined)),0,-1) if joined[-n:]==rows[:n])
        joined.extend(rows[n:])
    assert joined==r['lines']
    hdr=lambda t:next(i for i,line in enumerate(joined) if line.strip()==t)
    offsets=[hdr(t) for t in ('PROGRAMS','FILES FROM THE LOADER','MACHINE')]
    sizes=read(root/'fixtures.json')
    for section,start,stop in ((names[:2],offsets[0],offsets[1]),(names,offsets[1],offsets[2])):
        text=''.join(x.strip() for x in joined[start:stop])
        prior=0
        for name in section:
            n=sizes[name]['bytes']
            assert fields[name]==sizes[name]['sha256']
            field=name+str((n+1023)//1024)+' KiBSHA-256'+fields[name]
            prior=text.index(field,prior)+len(field)
        assert text.count('SHA-256')==len(section)
    return 'five size and complete digest fields with three distinct source files'

def read_widget(folder):
    r=guest(folder);w,h=map(int,r['mode'].split('x'))
    full='Session files | cleared at power-off'
    expected=full if w//10-4>=len(full) else 'Files last until power-off'
    assert r['widget']==expected
    for label,digest in r['captures'].items():
        raw=image(folder,label);assert sha(raw)==digest
        im=pixels.image(raw);assert im.shape==(h,w,3)
        rows=[pixels.row(im,i,1) for i in range(h//20)]
        assert rows==(folder/(label+'.txt')).read_text().splitlines()
        if label=='widget-on':assert [l.strip() for l in rows].count(expected)==1
    assert image(folder,'home')==image(folder,'widget-off')!=image(folder,'widget-on')
    return expected

def media(base):
    optical=base/'guarded/session'
    assert (optical/'qemu-exit.txt').read_text().strip()=='0'
    assert normal in [x['data'] for x in read(optical/'power-events.json') if x['event']=='SHUTDOWN']
    assert [x['outcome'] for x in read(optical/'register.json')['tasks']]==['DONE','STOPPED']
    assert image(optical,'register-latest')==image(optical,'register-restored')!=image(optical,'register-earlier')
    assert image(optical,'after-register')==image(optical,'power-cancelled') and image(optical,'power-prompt')==image(optical,'power-prompt-confirm')
    assert read(base/'guarded/image.json')['measurement'] in (optical/'serial.txt').read_text()
    usb=base/'usb-build';receipt=read(usb/'fixtures/image.json');out={}
    for g in sorted((usb/'results').iterdir()):
        r=read(g/'result.json');serial=(g/'serial.txt').read_text()
        assert receipt['measurement'] in serial and 'USB' in r['firmware_boot_device']
        assert r['passed'] and r['self_tests']==72 and r['exit']==0 and r['shutdown']==normal
        assert r['usb_sha256_after']==receipt['usb_sha256'] and r['snapshots'][0]['nvme_sha256']==r['nvme_sha256_after_quit']
        for delta in r['intervals']:
            assert delta['nvme_bytes_preserved'] and delta['counter_deltas']['sentinel']['wr_operations']==0
        w,h=map(int,re.search(r'^desktop: (\d+)x(\d+) at',serial,re.M).groups())
        assert all(pixels.image(f.read_bytes()).shape==(h,w,3) for f in g.glob('*.ppm'))
        out[g.name]=[w,h]
    assert len(out)==5
    return out

if __name__=='__main__':
    data={'traces':{p.name:replay_trace(p) for p in sorted((root/'guests').iterdir())},
          'details':{p.name:read_details(p) for p in sorted((root/'3920027/details').iterdir())},
          'widgets':{p.name:read_widget(p) for p in sorted((root/'3920027/widget').iterdir())},
          'usb':media(root/'3920027')}
    assert len(data['traces'])==10 and len(data['details'])==7 and len(data['widgets'])==4
    print(json.dumps(data,sort_keys=True,indent=2))

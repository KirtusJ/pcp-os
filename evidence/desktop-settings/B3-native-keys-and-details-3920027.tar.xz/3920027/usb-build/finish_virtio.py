import json,sys
from pathlib import Path
d=Path(__file__).resolve().parent
sys.path.insert(0,str(d/'source/examples/firmware-owned-uefi'))
from usb_trial import trial
v=Path('/workspace/scratch/15ccefba7c7d/validation');fw=v/'pkg/root/usr/share/OVMF'
data=trial(str(v/'bin/qemu-system-x86_64'),fw/'OVMF_CODE_4M.fd',fw/'OVMF_VARS_4M.fd',d/'fixtures/usb.img',json.loads((d/'fixtures/image.json').read_text()),d/'results/virtio-vga-128',128,'virtio-vga')
assert data['passed'] and data['self_tests']==72 and data['exit']==0
for p in sorted((d/'results').glob('*/result.json')):
 r=json.loads(p.read_text());print(p.parent.name,r['passed'],r['self_tests'],r['exit'])

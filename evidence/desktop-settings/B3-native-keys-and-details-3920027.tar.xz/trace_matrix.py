import concurrent.futures,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent
def run(mode):
    with (r/sys.argv[1]/('trace-'+mode+'.log')).open('w') as f:
        status=subprocess.run([sys.executable,'-B',r/'letters_trace.py',sys.argv[1],mode],stdout=f,stderr=subprocess.STDOUT).returncode
    return mode,status
with concurrent.futures.ThreadPoolExecutor(3) as e:
    result=list(e.map(run,['1280x720','320x200','640x480','1920x1080','2560x1440']))
print(result);sys.exit(any(rc for _,rc in result))

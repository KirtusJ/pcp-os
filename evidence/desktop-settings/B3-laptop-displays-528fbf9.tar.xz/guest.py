"""Capture an F10 cancellation and confirmed shutdown in one measured QEMU guest."""
from pathlib import Path
import argparse
import hashlib
import json
import re
import runpy
import subprocess
import time

root=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('mode')
p.add_argument('--vram',type=int,default=64)
p.add_argument('--scale',type=int,choices=(1,2))
p.add_argument('--name',required=True)
p.add_argument('--source',type=Path,required=True)
p.add_argument('--input',type=Path,default=root/'inputs')
p.add_argument('--output',type=Path,default=root/'guests')
p.add_argument('--qemu',type=Path,required=True)
a=p.parse_args()
src=a.source.resolve()
opt=runpy.run_path(str(src/'examples/optical-disk-check/check.py'))
out=a.output.resolve()/a.name
out.mkdir(parents=True,exist_ok=False)
inputs=a.input.resolve()
receipt=json.loads((inputs/'receipt.json').read_text())
kernel=inputs/'kernel.elf32'
app=inputs/'rdesk.elf'
def sha(data):return hashlib.sha256(data).hexdigest()
assert sha(kernel.read_bytes())==receipt['on_disc']['kernel.elf32']['sha256']
assert sha(app.read_bytes())==receipt['on_disc']['rdesk.elf']['sha256']
serial=out/'serial.txt'
measurement=receipt['kernel_measurement']
cmd=[str(a.qemu.resolve()),'-machine','pc','-accel','tcg','-cpu','max','-m','256M','-smp','1','-nic','none','-display','none','-vga','none','-device',f'VGA,vgamem_mb={a.vram}','-qmp','stdio','-monitor','none','-no-reboot','-kernel',str(kernel),'-initrd','rdesk.elf','-append',f'desktop={a.mode} image={measurement}' + (f' ui_scale={a.scale}' if a.scale else ''),'-serial','file:'+str(serial)]
(out/'rdesk.elf').symlink_to(app)
record={'mode':a.mode,'name':a.name,'requested_scale':a.scale,'vram_mib':a.vram,'head':receipt['source_commit'],'measure':measurement,'argv':cmd,'key_log':[],'frames':{}}
def readlog():return serial.read_text(errors='replace') if serial.exists() else ''
with (out/'stderr.txt').open('wb') as err:
    vm=subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
    try:
        mon=opt['Monitor'](vm)
        mon.call('qmp_capabilities')
        def key(name):
            mon.key(name)
            record['key_log'].append(name)
            time.sleep(.17)
        def frame(label):
            path=out/(label+'.ppm')
            previous=None
            for _ in range(22):
                mon.call('screendump',filename=str(path))
                buf=path.read_bytes()
                if buf==previous:
                    record['frames'][label]=sha(buf)
                    return
                previous=buf
                time.sleep(.075)
            raise ValueError('unstable or wrong-size '+label)
        pattern=r'desktop: (\d+)x(\d+) at (\d+)x UI scale'
        opt['wait_for'](lambda:bool(re.search(pattern,readlog())),'initial desktop',50)
        w,h,sc=map(int,re.search(pattern,readlog()).groups())
        record['active']=[w,h];record['applied_scale']=sc
        time.sleep(.25)
        frame('home')
        key('spc');frame('programs')
        key('esc');frame('after-programs')
        key('f2');frame('settings')
        key('esc');frame('after-settings')
        key('f10')
        frame('power')
        key('esc')
        frame('cancelled')
        assert record['frames']['home'] == record['frames']['cancelled']
        key('f10')
        frame('confirmed-prompt')
        assert record['frames']['power'] == record['frames']['confirmed-prompt']
        key('ret')
        end=time.monotonic()+35
        while vm.poll() is None and time.monotonic()<end:
            time.sleep(.1)
        vm.wait(timeout=3)
        while not any(e.get('event')=='SHUTDOWN' for e in mon.events):
            mon.events.append(mon.read())
        record['shutdown']=next(e['data'] for e in mon.events if e.get('event')=='SHUTDOWN')
        record['exit']=vm.returncode
        log=readlog()
        record['final_checks']=sum(line.startswith('  pass ') for line in log.splitlines())
        assert measurement+' (measured; equal' in log and 'ALL SELF-TESTS PASS.' in log
        assert record['final_checks']==72 and record['exit']==0 and record['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    finally:
        if vm.poll() is None:vm.kill();vm.wait()
        (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(a.mode,len(record['frames']),record['final_checks'])

# B3 display and scale read-back for issue 321

B3 booted Z3's working OS revision 528fbf977ae368e782cbbb85921a186c3ee368f1. The native Bochs series contains twelve guests plus one 1280×720 predecessor control from 0dd8ec98d39736883ab39d08f08fa772ddf3cbf6. Each traversed Programs, Settings, F10, Esc, F10 and Enter. Each produced eight P6 captures, returned to the identical Home after each cancellation and shut down with 72 checks. In the 720p Programs panel the final ink moved from x=675 to x=585, with the right edge at x=659. The requested 720p, 1080p and 1440p guests with 64 MiB video memory produced those native dimensions. At 1080p and 1440p, explicit 2× produced the plain program list. See report.json for the VRAM and scale controls and for every request and actual scanout.

The second series uses the same unmodified, read-only USB image for all fourteen Q35/OVMF virtio-vga boots. Seven start with stock variables and a requested EDID. Seven additionally start with a fresh variable-store copy containing OVMF's own PlatformConfig preferred resolution, the two UINT32 values written by its setup form. The USB and OVMF code bytes were held fixed. See firmware/preference.py and the upstream OvmfPkg/PlatformDxe/PlatformConfig.c and .h files in tianocore/edk2 tag edk2-stable202502.

With EDID alone all seven produced 1280×800. With the preference present, 720p and 1080p produced native, matching screenshots. The 1366×768 kernel report and 5,464-byte firmware pitch disagreed with QEMU's 1360×768 P6. The unmodified test timed out while reading Home. The 1920×1200, 2560×1440, 2880×1800 and 3840×2160 preferences all produced 800×600 on this firmware and adapter configuration. The other thirteen USB trials finished with 72 checks and normal guest shutdown. These are virtual machines. Physical laptop results are outstanding.

To replay the evidence with Python 3 and NumPy:

    sha256sum --quiet -c SHA256SUMS
    python3 -B read_pixels.py native-repeat.json
    cmp report.json native-repeat.json
    python3 -B firmware/check.py firmware-repeat.json
    cmp firmware/results.json firmware-repeat.json

The receipts and raw frames, including failed frames, are archived. Rebuilding new guests requires the reviewed OS source, QEMU, OVMF, the Rust toolchain and the normal firmware-owned USB fixture. The guest launch scripts retain the original invocation paths in their run records.

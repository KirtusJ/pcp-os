"""Replay the ordinary USB trial using one disposable OVMF display preference per guest."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys
import uuid

import trials

root = trials.root
usb = trials.usb
validation = Path('/workspace/scratch/15ccefba7c7d/validation')
firmware = validation / 'pkg/root/usr/share/OVMF'
out = root / 'firmware' / 'preferred'
out.mkdir(exist_ok=True)
modes = ['1366x768','1280x720','1920x1080','2560x1440','1920x1200','2880x1800','3840x2160']

def template(mode):
    width, height = map(int, mode.split('x'))
    raw = bytearray((firmware/'OVMF_VARS_4M.fd').read_bytes())
    volume_header, = struct.unpack_from('<H',raw,0x30)
    start = (volume_header + 28 + 3) & ~3
    assert uuid.UUID(bytes_le=bytes(raw[volume_header:volume_header+16])) == uuid.UUID('aaf32c78-947b-439a-a180-2e144ec37792')
    name = ('PlatformConfig'+chr(0)).encode('utf-16-le')
    data = struct.pack('<II',width,height)
    vendor = uuid.UUID('7235c51c-0c80-4cab-87ac-3b084a6304b1').bytes_le
    header = struct.pack('<HBBIQ16sIII16s',0x55aa,0x3f,0,7,0,bytes(16),0,len(name),len(data),vendor)
    record = header + name + data
    assert start == 100 and all(byte == 255 for byte in raw[start:start+len(record)])
    raw[start:start+len(record)] = record
    dest = out / (mode+'.fd')
    dest.write_bytes(raw)
    return dest

def run(mode):
    dest = template(mode)
    fixtures = root/'usb-build/fixtures'
    image = json.loads((fixtures/'image.json').read_text())
    ordinary = usb.usb_command
    width,height = map(int,mode.split('x'))
    def choose(*args):
        cmd = ordinary(*args)
        cmd[cmd.index('virtio-vga')] = f'virtio-vga,edid=on,xres={width},yres={height}'
        return cmd
    usb.usb_command = choose
    result = usb.trial(str(validation/'bin/qemu-system-x86_64'),firmware/'OVMF_CODE_4M.fd',dest,
                       fixtures/'usb.img',image,out/mode,256,'virtio-vga')
    print(mode,result['loader_display'], 'passed',result['passed'])

if __name__ == '__main__':
    if len(sys.argv)>1: run(sys.argv[1])
    else:
        def worker(mode):
            with (out/(mode+'.log')).open('w') as log:
                return mode,subprocess.run([sys.executable,'-B',__file__,mode],stdout=log,stderr=subprocess.STDOUT).returncode
        with ThreadPoolExecutor(max_workers=2) as pool: results=list(pool.map(worker,modes))
        print(results)
        sys.exit(any(code for _,code in results))

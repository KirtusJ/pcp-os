"""Exercise the ordinary USB trial's virtio-vga path with a requested native mode advertised by EDID."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import sys
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'source/examples/firmware-owned-uefi'))
import usb_trial as usb
import subprocess

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--mode')
    args=p.parse_args()
    if args.mode is None:
        modes=['1366x768','1280x720','1920x1080','2560x1440','1920x1200','2880x1800','3840x2160']
        def run(mode):
            with (root/'firmware'/(mode+'.log')).open('w') as log:
                return mode,subprocess.run([sys.executable,'-B',__file__,'--mode',mode],stdout=log,stderr=subprocess.STDOUT).returncode
        with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,modes))
        print(results);return int(any(code for _,code in results))
    width,height=map(int,args.mode.split('x'))
    ordinary=usb.usb_command
    def with_edid(*args):
        cmd=ordinary(*args)
        pos=cmd.index('virtio-vga')
        cmd[pos]=f'virtio-vga,edid=on,xres={width},yres={height}'
        return cmd
    usb.usb_command=with_edid
    v=Path('/workspace/scratch/15ccefba7c7d/validation')
    fw=v/'pkg/root/usr/share/OVMF'
    fixtures=root/'usb-build/fixtures'
    image=json.loads((fixtures/'image.json').read_text())
    usb.trial(str(v/'bin/qemu-system-x86_64'),fw/'OVMF_CODE_4M.fd',fw/'OVMF_VARS_4M.fd',
              fixtures/'usb.img',image,root/'firmware'/args.mode,256,'virtio-vga')
    return 0
if __name__=='__main__':raise SystemExit(main())

"""Compare serial geometry, firmware scanline pitch and raw QEMU geometry for all requested modes."""
import hashlib,json,re,sys
from pathlib import Path
d=Path(__file__).resolve().parent
image=json.loads((d/'image.json').read_text())
records={}
modes=['1280x720','1366x768','1920x1080','1920x1200','2560x1440','2880x1800','3840x2160']
for name,folder in [('edid',d),('preferred',d/'preferred')]:
 for mode in modes:
    f=folder/mode
    r=json.loads((f/'result.json').read_text());s=(f/'serial.txt').read_text()
    active=re.search(r'^display: Loader, (\d+x\d+), 1 page\(s\)',s,re.M)[1]
    trace=(f/'firmware.txt').read_text()
    pitch=int(re.search(r'^console_pitch=(\w+)$',trace,re.M)[1],16)
    home=(f/'home.ppm').read_bytes();header,widthheight,depth,pixels=home.split(b'\n',3)
    w,h=map(int,widthheight.split());assert header==b'P6' and depth==b'255' and len(pixels)==3*w*h
    actual=f'{w}x{h}'
    if name=='edid':assert active==actual=='1280x800'
    elif mode=='1366x768': assert active==mode and actual=='1360x768' and pitch==5464
    elif mode in ('1280x720','1920x1080'):assert active==actual==mode
    else: assert active==actual=='800x600'
    if r['passed']:
        assert r['usb_sha256_after']==image['usb_sha256'] and r['self_tests']==72 and r['exit']==0
        assert r['shutdown']==dict(guest=True,reason='guest-shutdown') and image['measurement'] in s
        assert (f/'home-after-verification.ppm').read_bytes()==home
    else:
        assert mode=='1366x768' and name=='preferred' and 'TimeoutError: waiting for home framebuffer' in (folder/(mode+'.log')).read_text()
    records[name+'/'+mode]=dict(kernel=active,qemu=actual,firmware_pitch_bytes=pitch,home_sha256=hashlib.sha256(home).hexdigest(),passed=r['passed'])
Path(sys.argv[1]).write_text(json.dumps(records,indent=2)+'\n')

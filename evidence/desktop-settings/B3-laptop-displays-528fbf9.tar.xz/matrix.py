from pathlib import Path
import subprocess,sys
from concurrent.futures import ThreadPoolExecutor
root=Path(__file__).resolve().parent
q='/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64'
trials=[('1280x720',64,None),('1366x768',64,None),('1920x1080',64,None),('2560x1440',64,None),
        ('2560x1440',64,2),('2560x1440',16,None),('1920x1200',64,None),('2880x1800',64,None),
        ('3840x2160',128,None),('1920x1080',64,2),('1280x720',64,2),('1360x768',64,None)]
def run(t):
    mode,vram,scale=t
    name=f'{mode}-{vram}m-'+('default' if scale is None else f'{scale}x')
    args=[sys.executable,'-B',root/'guest.py',mode,'--name',name,'--source',root/'source','--qemu',q,'--vram',str(vram)]
    if scale:args+=['--scale',str(scale)]
    with (root/(name+'.log')).open('w') as log:
        result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
    return name,result.returncode
with ThreadPoolExecutor(max_workers=3) as workers:
    results=list(workers.map(run,trials))
print(results)
raise SystemExit(int(any(v for _,v in results)))

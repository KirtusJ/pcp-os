"""Verify original screenshots and exercise the exact Details checker against four field deletions."""
import ast,hashlib,json,re,sys
from pathlib import Path
import pixels
root=Path(__file__).resolve().parent
src=root/'source/examples/tester-cd/check_small_screens.py'
tree=ast.parse(src.read_text())
fns=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'merged_lines','details_sections','details_problems'}]
env={'re':re};exec(compile(ast.Module(fns,[]),str(src),'exec'),env)
group=root/'hosted-cases'
outcomes=json.loads((group/'outcome.json').read_text())['outcomes']
receipt=json.loads((group/'iso/receipt.json').read_text());names=['alpha.elf','bravo.elf']
facts=json.loads((root/'facts.json').read_text());report={}
for name in names:
    payload=(root/'inputs'/name).read_bytes()
    assert [str((len(payload)+1023)//1024)+' KiB',hashlib.sha256(payload).hexdigest()] == facts[name]
assert facts[names[0]][1]!=facts[names[1]][1]
for outcome in outcomes:
    d=group/('run-'+str(outcome['group']))
    checked=json.loads((d/'result.json').read_text())
    assert outcome['exit']==0 and not checked['problems'] and checked==outcome['results']
    for mode,case in checked['results'].items():
        assert mode not in report and case['exit_code']==0
        target=d/mode;serial=(target/'serial.txt').read_text();assert receipt['kernel_measurement'] in serial
        if mode.startswith('failed-'):assert '1 SELF-TEST(S) FAILED' in serial and 'it is in SAFE and starts no program' in serial
        else:assert 'ALL SELF-TESTS PASS.' in serial
        w,h=map(int,mode.removeprefix('failed-').split('x'));frames={}
        for p in sorted(target.glob('*.ppm')):
            raw=p.read_bytes();im=pixels.image(raw);assert im.shape==(h,w,3)
            frames[p.stem]=hashlib.sha256(raw).hexdigest()
        report[mode]={'frames':frames,'controls':[]}
        detail=sorted((p for p in target.glob('details-*.ppm') if re.fullmatch(r'details-\d+',p.stem)),key=lambda p:int(p.stem.split('-')[1]))
        if not detail:continue
        seen=[];last=None
        for p in detail:
            if last==frames[p.stem]:continue
            last=frames[p.stem];im=pixels.image(p.read_bytes())
            seen.append([pixels.row(im,i,1) for i in range(h//20)])
        lines=env['merged_lines'](seen)
        assert not env['details_problems'](lines,facts)
        for section,end in [('PROGRAMS','FILES FROM THE LOADER'),('FILES FROM THE LOADER','MACHINE')]:
            a,b=lines.index(section),lines.index(end);part=lines[a+1:b]
            for name in names:
                start=part.index(name);label=part.index('SHA-256',start);idx=label+1
                while idx+1<len(part) and re.fullmatch('[a-f0-9]+',part[idx+1]):idx+=1
                assert re.fullmatch('[a-f0-9]+',part[idx])
                damaged=list(lines);pos=a+1+idx;damaged[pos]=damaged[pos][:-1]
                problems=env['details_problems'](damaged,facts)
                assert any(section in e and name in e for e in problems),(section,name,problems)
                report[mode]['controls'].append([section,name,problems])
assert len(report)==15 and sum(len(case['controls']) for case in report.values())==16
print(json.dumps(report,sort_keys=True,indent=2))

# Director B3 — the third small-display checker

Commit 17f6b30fda94fd217823bc0437e905d420aa1cc4 changes the checker alone relative to the tested kernel 39200277158b3b6c5d6d3b9fda9f62463768ab37. QEMU booted the source-built measured kernel for all 13 ordinary geometries and two deliberately failed starts. The original repository checker, the adapted script and the transformation are included. The adaptation uses QMP over standard I/O and partitions the original cases over four workers. The two fixtures have distinct hashes. The second is the original demo with a single zero byte appended as the checker specifies. Each original P6, the decoded lines, serial log, group decisions and launch information are included.

For each of the four short 320-pixel geometries, the offline replay reads the Details pages from their original pixels, reconstructs the scrolled lines with the exact repository functions and then removes the last digit of each program digest in each section separately. All four intact reconstructions pass. The checker must identify each damaged section and file in turn for the replay to pass. These 16 offline controls edit decoded fields after glyph recognition. The distinct long loader filenames, underlying render transitions, optical reader and five USB boot profiles are in the companion B3-native-keys-and-details-3920027 archive.

Extract the archive and use Python 3 and NumPy.

    sha256sum --quiet -c SHA256SUMS
    python3 -B replay.py > repeat.json
    cmp expected.json repeat.json

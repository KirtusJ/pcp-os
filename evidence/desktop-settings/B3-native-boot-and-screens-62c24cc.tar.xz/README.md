# Director B3 — native boot and display checks

PCP OS issue 314, working commit 62c24cc2a76bc35bdf12b7ad40302c524f045b50. P6 files are original QEMU frames. Each collection has its own image receipt, QEMU arguments, serial output and outcomes. All guests were emulated. The guarded optical guest and five OVMF USB guests booted through firmware. The screen trials used QEMU direct boot with full-sized, native frames.

## Replay

Extract the archive on Linux. With Python 3.9 or later and NumPy, run the following from the extracted directory.

    sha256sum --quiet -c SHA256SUMS
    python3 -B replay.py
    python3 -B field_replay.py repeated.json
    cmp field.json repeated.json

Fourteen independent F5 guests cover 320×200, 640×480, 800×600, 1024×768, 1280×720, 1920×1080 and 2560×1440. At each geometry one start verified the kernel and another deliberately supplied one wrong digit. The failed guest displayed “Programs are disabled.” Enter left the six-event register and all 64 digits of its head unchanged. The failed guest refused the program, reported one expected self-test failure and shut down. The seven verified guests finished 72 checks. The offline field replay tests 21 groups of captured F5 pages, including each failed guest before and after Enter. The original 320×200 pages have a partial run of 56 followed by a whole 64-digit head. Erasing the last visible digit on every complete field, introducing a conflicting whole head with the same first 16 digits, and changing a digit on the partial page all fail the current checker.

The repository screen checker ran its 13 ordinary geometries and both deliberate failures once each. Its input carrier held the measured kernel and published Surfbird. The adapted runner uses standard input and output for QMP because filesystem sockets are unavailable here. It partitions the original cases across four processes. Both the original checker and the exact adapted version are included.

Five stock Q35 USB boots exercised standard VGA at 128 and 256 MiB, virtio-vga at 128 MiB, and RAMFB at 128 and 256 MiB. The fixed-address EFI build has a different image measurement from the BIOS and direct-boot builds. Each path matches its own source-built image receipt. The 1024×768 guarded BIOS optical run includes the original register footer and historical sequence-number regions, a completed and a stopped program, and cancel then confirm on the power screen. That fixture opens power with P from Details. The direct-boot suite exercises F10. The framebuffer write observer and its captures are in the companion B3-framebuffer-writes-62c24cc archive.

"""Read complete F5 fields in native frames and compare the register around Enter on a failed start."""
from pathlib import Path
import hashlib,json,re,runpy,subprocess,sys,time
import pixels
root=Path(__file__).resolve().parent;revision=sys.argv[3] if len(sys.argv)>3 else 'e749600';src=root/revision;mode,kind=sys.argv[1:3];failed=kind=='failed'
g=(root/'verification' if revision=='e749600' else src/'verification')/(kind+'-'+mode);g.mkdir(parents=True,exist_ok=False)
v=Path('/workspace/scratch/15ccefba7c7d/validation');el=src/'inputs/kernel.elf32'
expected=(src/'inputs/measurement').read_text().strip()
named=expected[:-1]+('0' if expected[-1]!='0' else '1') if failed else expected
opt=runpy.run_path(str(src/'source/examples/optical-disk-check/check.py'))
(g/'rdesk.elf').symlink_to(root/'inputs/rdesk.elf');serial=g/'serial.txt'
cmd=[str(v/'bin/qemu-system-x86_64'),'-machine','pc','-accel','tcg','-cpu','max','-m','256M','-smp','1','-nic','none','-display','none','-vga','none','-device','VGA,vgamem_mb=64','-qmp','stdio','-monitor','none','-no-reboot','-kernel',str(el),'-initrd','rdesk.elf','-append',f'desktop={mode} image={named}','-serial','file:'+str(serial)]
r={'revision':revision,'mode':mode,'kind':kind,'measurement':expected,'named':named,'argv':cmd,'frames':{}}
def log():return serial.read_text(errors='replace') if serial.exists() else ''
with (g/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=g,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
 try:
    mon=opt['Monitor'](vm);rpc=mon.call;rpc('qmp_capabilities')
    opt['wait_for'](lambda:f'desktop: {mode} at 1x UI scale' in log(),'startup',70);time.sleep(.25)
    def key(k):mon.key(k);time.sleep(.22)
    def capture(label):
        p=g/(label+'.ppm');previous=None
        for _ in range(30):
            rpc('screendump',filename=str(p));raw=p.read_bytes()
            if previous==raw:break
            previous=raw;time.sleep(.09)
        else:raise RuntimeError(label+' unstable')
        image=pixels.image(raw)
        assert 'x'.join(map(str,image.shape[1::-1]))==mode
        rows=[pixels.row(image,i,1).strip() for i in range(image.shape[0]//20)]
        r['frames'][label]=hashlib.sha256(raw).hexdigest()
        return rows
    def verify(label):
        pages=[];key('f5');prev=None
        for n in range(24):
            nm=f'{label}-{n}';rows=capture(nm);h=r['frames'][nm]
            if h==prev:break
            pages.append(rows);prev=h
            if not any('Up/Down scroll' in l for l in rows):break
            key('down')
        else:raise RuntimeError('F5 did not stop scrolling')
        whole=set();prefixes=set();counts=set();partial=set()
        for rows in pages:
            joined=' '.join(' '.join(rows).split())
            for count,short in re.findall(r'Register: (\d+) events, head ([0-9a-f]{16})\.\.\.',joined):
                counts.add(int(count));prefixes.add(short)
            for i,line in enumerate(rows):
                if not line.startswith('The whole head'):continue
                label='The whole head of the register\'s chain:'
                text=line;j=i+1
                while text!=label and j<len(rows) and label.startswith(text+' '):
                    text+=' '+rows[j];j+=1
                if text!=label:continue
                digits=''
                while j<len(rows) and re.fullmatch(r'[0-9a-f]+',rows[j]):digits+=rows[j];j+=1
                if len(digits)==64:whole.add(digits)
                elif digits:partial.add(digits)
        assert len(whole)==len(prefixes)==len(counts)==1,(mode,whole,prefixes,counts)
        full=next(iter(whole));assert {full[:16]}==prefixes and all(full.startswith(n) for n in partial)
        key('esc')
        return {'count':next(iter(counts)),'head':full,'prefixes_seen':[len(n) for n in sorted(partial)],'pages':len(pages)}
    capture('home')
    r['before']=verify('f5-before')
    if failed:
        key('ret');rows=capture('failed-programs')
        assert any('Programs are disabled.' in l for l in rows),(mode,rows)
        key('ret');after=capture('after-enter')
        r['visible_disabled']=[l for l in rows if 'disabled.' in l]
        r['refusal']=[l for l in after if 'Not started:' in l]
        key('esc');capture('after-programs')
        r['after']=verify('f5-after')
        assert r['before']['head']==r['after']['head'] and r['before']['count']==r['after']['count']
        assert not re.search(r'^starting rdesk\.elf|^rdesk\.elf ended',log().split('desktop: ',1)[-1],re.M)
    key('f10');capture('power');key('ret');vm.wait(timeout=55)
    r['exit']=vm.returncode;r['serial_final']=next(l for l in log().splitlines() if l.startswith('kernel register:'))
    r['checks']=sum(l.startswith('  pass ') for l in log().splitlines())
    if not failed:assert r['checks']==72 and 'ALL SELF-TESTS PASS.' in log()
 finally:
    if vm.poll() is None:vm.kill();vm.wait()
    (g/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(r['mode'],r['kind'],r['before'],r.get('after'),r['exit'])

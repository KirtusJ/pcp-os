"""Run the actual F5 field predicate on native pages and on independent changes to their pixels."""
import ast,hashlib,json,re,sys
from pathlib import Path
import pixels
root=Path(__file__).resolve().parent
def predicate(checker):
    tree=ast.parse(checker.read_text()); env={'re':re}
    chosen=[]
    for n in tree.body:
        if isinstance(n,ast.Assign) and getattr(n.targets[0],'id',None)=='LABEL':chosen.append(n)
        if isinstance(n,ast.FunctionDef) and n.name in ('whole_heads','joined'):chosen.append(n)
    exec(compile(ast.Module(chosen,[]),str(checker),'exec'),env)
    fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='text_trial')
    start=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and getattr(n.targets[0],'id',None)=='heads')
    finish=next(i for i in range(start+1,len(fn.body)) if isinstance(fn.body[i],ast.If))
    code=compile(ast.Module(fn.body[start:finish+1],[]),str(checker),'exec')
    def run(pages):
        found=[];ctx=dict(env,verification_rows=pages,verification=[env['joined'](p) for p in pages],found=found)
        exec(code,ctx);return not found
    return run
old=predicate(root/'e749600/source/examples/tester-cd/check_small_screens.py')
current=predicate(root/'62c24cc/source/examples/tester-cd/check_small_screens.py')
def read(im):return [pixels.row(im,i,1) for i in range(im.shape[0]//20)]
def hex_field(rows):
    target="The whole head of the register's chain:"
    for i,line in enumerate(rows):
        if not line.strip().startswith('The whole head'):continue
        actual=line.strip();j=i+1
        while actual!=target and j<len(rows) and target.startswith(actual+' '):
            actual+=' '+rows[j].strip();j+=1
        if actual!=target:continue
        positions=[]
        while j<len(rows) and re.fullmatch('[0-9a-f]+',rows[j].strip()):
            for col,c in enumerate(rows[j]):
                if c!=' ':positions.append((j,col,c))
            j+=1
        return positions
    return []
def mutant(im,coords,index,erase):
    im=im.copy();y,x,letter=coords[index];target=im[20*y:20*(y+1),10*x:10*(x+1)]
    if erase:target[:]=im[20*y,0]
    else:
        oy,ox,_=next(c for c in coords if c[-1]!=letter)
        target[:]=im[20*oy:20*(oy+1),10*ox:10*(ox+1)].copy()
    return read(im)
def source_group(d):
    r=json.loads((d/'result.json').read_text());mode=r['mode']
    hashes=r['frames'];out={}
    rlog=(d/'serial.txt').read_text()
    assert r['exit']==0 and r['measurement'] in rlog and f'desktop: {mode} at 1x UI scale' in rlog
    if r['kind']=='failed':
        assert r['named']!=r['measurement'] and r['before']['head']==r['after']['head'] and r['before']['count']==r['after']['count']==6
        assert 'FAIL the running image measures as the value the loader named' in rlog
        assert not re.search(r'^starting rdesk\.elf|^rdesk\.elf ended',rlog.split('desktop: ',1)[-1],re.M)
        assert r['visible_disabled']
    else:assert r['checks']==72 and 'ALL SELF-TESTS PASS.' in rlog
    for section in ('before','after') if r['kind']=='failed' else ('before',):
        names=[k for k in hashes if k.startswith('f5-'+section+'-')]
        frames=[];seen=set()
        for name in names:
            raw=(d/(name+'.ppm')).read_bytes();h=hashlib.sha256(raw).hexdigest();assert h==hashes[name]
            if h in seen:continue
            seen.add(h);frames.append(pixels.image(raw))
        pages=[read(im) for im in frames]; fields=[hex_field(rows) for rows in pages]
        full=[i for i,v in enumerate(fields) if len(v)==64];short=[i for i,v in enumerate(fields) if 0<len(v)<64]
        assert full and current(pages)
        outcomes={'original':{'e749600':old(pages),'62c24cc':True},'complete_head':r[section]['head'],'partial_lengths':[len(fields[i]) for i in short]}
        assert all(''.join(x[-1] for x in fields[i])==r[section]['head'] for i in full)
        erased=[mutant(frames[i],field,-1,True) if len(field)==64 else rows for i,(rows,field) in enumerate(zip(pages,fields))]
        assert not current(erased) and len(hex_field(erased[full[0]]))==63
        outcomes['erase_every_complete_final_digit']=False
        i=full[0];other=mutant(frames[i],fields[i],24,False)
        assert hex_field(other)[24][-1]!=fields[i][24][-1] and not current(pages+[other])
        outcomes['two_full_heads_same_visible_prefix']=False
        if short:
            i=short[0];variant=list(pages);variant[i]=mutant(frames[i],fields[i],min(20,len(fields[i])-1),False)
            assert not current(variant);outcomes['conflicting_partial_page']=False
            assert mode=='320x200' and not old(pages)
        out[section]=outcomes
    return out
results={p.name:source_group(p) for p in sorted((root/'62c24cc/verification').iterdir()) if p.is_dir()}
assert len(results)==14
Path(sys.argv[1]).write_text(json.dumps(results,sort_keys=True,indent=2)+'\n')
print('14 native guests; 21 sets of F5 pages; final digits, conflicting full and partial fields tested')

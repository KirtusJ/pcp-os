"""Check native pixels, files, image receipts, and VM results in the B3 evidence archive."""
from pathlib import Path
import hashlib, json, re
import pixels

root = Path(__file__).resolve().parent
base = root / "62c24cc"
digest = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(path.read_text())
def expect_image(frame, mode):
    raw = frame.read_bytes()
    im = pixels.image(raw)
    assert list(im.shape[1::-1]) == list(map(int, mode.split("x"))), frame
    return im
def verify_record(folder):
    record = load(folder / "result.json")
    for name, expected in record["frames"].items():
        frame = folder / (name + ".ppm")
        assert digest(frame.read_bytes()) == expected
        im = expect_image(frame, record["mode"])
        if name == "failed-programs":
            assert any("Programs are disabled." in pixels.row(im, line, 1)
                       for line in range(im.shape[0] // 20)), folder
    return len(record["frames"])

verification = base / "verification"
counts = {"independent_frames": sum(verify_record(p) for p in verification.iterdir() if p.is_dir())}
small = base / "hosted-cases"
receipt = load(small / "iso/receipt.json")
normal = set((small / "geometries").read_text().splitlines())
cases = {}
for group in load(small / "outcome.json")["outcomes"]:
    path = small / ("run-" + str(group["group"]))
    original = load(path / "result.json")
    assert group["exit"] == 0 and original == group["results"] and original["problems"] == []
    for name, events in original["results"].items():
        assert name not in cases and events["exit_code"] == 0, name
        mode = name.removeprefix("failed-")
        serial = (path / name / "serial.txt").read_text()
        assert receipt["kernel_measurement"] in serial, name
        if name.startswith("failed-"):
            assert "1 SELF-TEST(S) FAILED" in serial and "it is in SAFE and starts no program" in serial
        else:
            assert "ALL SELF-TESTS PASS." in serial
        frames = list((path / name).glob("*.ppm"))
        assert frames
        for f in frames:
            expect_image(f, mode)
        cases[name] = len(frames)
assert set(cases) == normal | {"failed-320x200", "failed-640x480"} and len(cases) == 15
counts.update(native_screen_cases=len(cases), native_screen_frames=sum(cases.values()))

usb = base / "usb-build"
fixture = load(usb / "fixtures/image.json")
profiles = []
for folder in sorted((usb / "results").iterdir()):
    data = load(folder / "result.json")
    assert data["passed"] and data["self_tests"] == 72 and data["exit"] == 0
    assert data["shutdown"] == {"guest": True, "reason": "guest-shutdown"}
    assert "USB" in data["firmware_boot_device"] and data["usb_sha256_after"] == fixture["usb_sha256"]
    serial = (folder / "serial.txt").read_text()
    assert fixture["measurement"] in serial
    mode = re.search(r"^desktop: (\d+x\d+) at", serial, re.M).group(1)
    for interval in data["intervals"]:
        assert interval["nvme_bytes_preserved"] and interval["counter_deltas"]["sentinel"]["wr_operations"] == 0
    assert data["nvme_sha256_after_quit"] == data["snapshots"][0]["nvme_sha256"]
    for frame in folder.glob("*.ppm"):
        expect_image(frame, mode)
    profiles.append(folder.name)
assert profiles == ["ramfb-128", "ramfb-256", "std-128", "std-256", "virtio-vga-128"]
counts["usb_profiles"] = profiles
guarded = base / "guarded/session"
assert (guarded / "qemu-exit.txt").read_text().strip() == "0"
assert any(e["event"] == "SHUTDOWN" and e["data"] == {"guest":True,"reason":"guest-shutdown"}
           for e in load(guarded / "power-events.json"))
serial = (guarded / "serial.txt").read_text()
assert load(guarded.parent / "image.json")["measurement"] in serial
assert "ALL SELF-TESTS PASS." in serial and "surf.elf ended DONE" in serial and "surf.elf ended STOPPED" in serial
assert [t["outcome"] for t in load(guarded / "register.json")["tasks"]] == ["DONE","STOPPED"]
for frame in guarded.glob("*.ppm"):
    expect_image(frame, "1024x768")
for left, right in [("register-latest","register-restored"),("after-stop","after-register"),("after-register","power-cancelled"),("power-prompt","power-prompt-confirm")]:
    assert (guarded / (left+".ppm")).read_bytes() == (guarded / (right+".ppm")).read_bytes()
assert (guarded/"register-earlier.ppm").read_bytes() != (guarded/"register-latest.ppm").read_bytes()
print(json.dumps(counts,sort_keys=True))

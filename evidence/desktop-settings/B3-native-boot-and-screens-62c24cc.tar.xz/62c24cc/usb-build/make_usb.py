"""Build the tracked USB recipe with the installed Linux EFI toolchain prefix."""
import argparse
import json
import os
from pathlib import Path
import subprocess

p = argparse.ArgumentParser(description=__doc__)
for name in ('source','prefix','distribution','output'):
    p.add_argument(name, type=Path)
a = p.parse_args()
s = a.source.resolve()
k = s/'PCP_OS_Rust/crates/pcpos-kernel'
usb = s/'examples/firmware-owned-uefi'
prefix = a.prefix.resolve()
target = a.output.resolve()
os.environ['PATH'] = f"{prefix}/bin:{prefix}/sbin:" + os.environ['PATH']
os.environ['LD_LIBRARY_PATH'] = str(prefix/'lib/x86_64-linux-gnu')
source = (usb/'image.py').read_text()
source = source.replace('/usr/include/efi',str(prefix/'include/efi')).replace('/usr/lib',str(prefix/'lib'))
context = {'__name__':'usb_recipe'}
exec(compile(source,str(usb/'image.py'),'exec'),context)
receipt = context['make'](a.distribution.resolve(),k/'target/pcpos-kernel.elf32',k/'tools/measure.py',target,usb,usb_vm=True)
receipt['build'] = 'Locally built 62c24cc2a76bc35bdf12b7ad40302c524f045b50 with repository load-base.patch and the installed GNU EFI prefix'
(target/'image.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt['elf_sha256'],receipt['measurement'],receipt['usb_sha256'])

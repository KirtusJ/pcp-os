from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,sys
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'source/examples/firmware-owned-uefi'))
from usb_trial import trial
v=Path('/workspace/scratch/15ccefba7c7d/validation');fw=v/'pkg/root/usr/share/OVMF'
out=root/'results';out.mkdir(exist_ok=True)
modes=[('std',128),('std',256),('virtio-vga',128),('ramfb',128),('ramfb',256)]
def run(arg):
 video,ram=arg
 result=trial(str(v/'bin/qemu-system-x86_64'),fw/'OVMF_CODE_4M.fd',fw/'OVMF_VARS_4M.fd',root/'fixtures/usb.img',json.loads((root/'fixtures/image.json').read_text()),out/(video+'-'+str(ram)),ram,video)
 return (video,ram,result['passed'],result['exit'],result['self_tests'],result.get('framebuffer_address'))
with ThreadPoolExecutor(max_workers=2) as workers: result=list(workers.map(run,modes))
assert all(z[2:5]==(True,0,72) for z in result)
assert result[-1][-1]!=result[-2][-1]
print(result,flush=True)

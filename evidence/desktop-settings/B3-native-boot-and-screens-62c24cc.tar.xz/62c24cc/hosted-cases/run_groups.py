from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,os,subprocess,sys
root=Path(__file__).resolve().parent
cases=(root/'geometries').read_text().splitlines()
groups=[cases[i::4] for i in range(4)]
q='/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64'
def run(i):
    out=root/f'run-{i}'
    with (root/f'run-{i}.log').open('w') as log:
        code=subprocess.run([sys.executable,'-B',root/'source/examples/tester-cd/stdio_check.py',root/'iso',out,'--qemu',q],env=dict(os.environ,B3_GEOMETRIES=','.join(groups[i])),stdout=log,stderr=subprocess.STDOUT).returncode
    return i,code,json.loads((out/'result.json').read_text())
with ThreadPoolExecutor(max_workers=4) as p:results=list(p.map(run,range(4)))
record={'groups':groups,'outcomes':[dict(group=i,exit=rc,results=r) for i,rc,r in results]}
(root/'outcome.json').write_text(json.dumps(record,indent=2)+'\n')
print([(i,rc,r['problems']) for i,rc,r in results],flush=True)
sys.exit(any(rc or r['problems'] for _,rc,r in results))

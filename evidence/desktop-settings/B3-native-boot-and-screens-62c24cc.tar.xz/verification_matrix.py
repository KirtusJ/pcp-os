from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,sys
r=Path(__file__).resolve().parent
revision=sys.argv[1] if len(sys.argv)>1 else 'e749600'
logdir=r if revision=='e749600' else r/revision
cases=[(m,k) for m in ['320x200','640x480','800x600','1024x768','1280x720','1920x1080','2560x1440'] for k in ['verified','failed']]
def run(t):
    m,k=t
    with (logdir/(k+'-'+m+'.log')).open('w') as f:code=subprocess.run([sys.executable,'-B',r/'verification_guest.py',m,k,revision],stdout=f,stderr=subprocess.STDOUT).returncode
    return m,k,code
with ThreadPoolExecutor(max_workers=3) as e:out=list(e.map(run,cases))
print(out);sys.exit(any(x[-1] for x in out))

"""Independent pixel reader for the Programs guidance plate, Settings and the native power dialog."""
import argparse
import ast
import hashlib
import json
from pathlib import Path

import numpy as np

root=Path(__file__).resolve().parent
plate=np.array([0x10,0x28,0x3f],dtype=np.uint8)
soft=np.array([0x9f,0xb4,0xc8],dtype=np.uint32)
one=ast.literal_eval('['+(root/'inputs/font.rs').read_text().split(' = [',1)[1].split('];',1)[0]+']')
fonts={1:np.array(one,dtype=np.uint8).reshape(95,20,10),
       2:np.fromfile(root/'inputs/font-2x.bin',dtype=np.uint8).reshape(95,40,20)}
alph={s:{np.packbits(c>0).tobytes():chr(i+32) for i,c in enumerate(tbl)} for s,tbl in fonts.items()}
flat1=((plate.astype(np.uint32)*(255-fonts[1].astype(np.uint32)[...,None])+soft*fonts[1].astype(np.uint32)[...,None]+127)//255).astype(np.uint8)
exact={c.tobytes():chr(32+i) for i,c in enumerate(flat1)}
def sha(b):return hashlib.sha256(b).hexdigest()
def image(b):
    magic,size,depth,raw=b.split(b'\n',3);w,h=map(int,size.split())
    assert magic==b'P6' and depth==b'255' and len(raw)==3*w*h
    return np.frombuffer(raw,dtype=np.uint8).reshape(h,w,3)
def row(im,n,z):
    cw,ch=10*z,20*z
    tile=im[n*ch:(n+1)*ch,:im.shape[1]//cw*cw]
    cells=tile.reshape(ch,-1,cw,3).transpose(1,0,2,3)
    mask=np.any(cells!=cells[:,:1,:1],axis=3)
    return ''.join(alph[z].get(np.packbits(c).tobytes(),'?') for c in mask).rstrip()
def programs(im):
    band=np.all(im[113]==plate,axis=1)
    ends=np.flatnonzero(np.diff(np.r_[False,band,False]))
    spans=[(int(l),int(r)) for l,r in zip(ends[::2],ends[1::2]) if r-l>=400 and l>0 and r<im.shape[1]]
    assert len(spans)==1,spans
    a,b=spans[0];start=a-1+20
    chars=[]
    for x in range(start,im.shape[1]-9,10):
        char=exact.get(im[120:140,x:x+10].tobytes())
        if char is None:break
        chars.append(char)
    line=''.join(chars).rstrip()
    assert line in ('Choose one. Each runs with only what it is granted.','Choose one to start. Each runs with only what it is granted.'),repr(line)
    pix=im[120:140,start:start+10*len(line)]
    ink_x=np.nonzero(np.any(pix!=plate,axis=2))[1]
    end=start+int(ink_x.max())
    return {'guidance':line,'plate_left':a-1,'plate_right_inclusive':b,'last_ink_x':end,'ink_clearance_px':b-end}
def read_guest(g,old=False):
    r=json.loads((g/'result.json').read_text())
    isconsole=r['applied_scale']==2
    out={}
    for label,digest in r['frames'].items():
        data=(g/(label+'.ppm')).read_bytes()
        assert sha(data)==digest
        im=image(data)
        assert list(im.shape[1::-1])==r['active']
        z=r['applied_scale']
        if label=='programs':
            if isconsole:
                lines=[row(im,n,z) for n in (1,3,5,6)]
                assert any('Verified at start: all 71 self-tests passed.' in l for l in lines),lines
                assert any('rdesk.elf' in l for l in lines),lines
                out['programs']={'presentation':'plain','lines':lines}
            else:
                info=programs(im);assert (info['ink_clearance_px']<0)==old,info
                out['programs']={'presentation':'graphical',**info}
        elif label=='settings':
            assert row(im,1,z).strip()=='SETTINGS' and row(im,im.shape[0]//(20*z)-2,z).strip().endswith('Esc back')
        elif label=='power':
            rows=[row(im,n,z).strip() for n in (1,3,5,6,im.shape[0]//(20*z)-2)]
            assert rows==['POWER OFF','Switch PCP OS off?','The register is closed and verified first. Files of this session that were','not saved by a program are lost.','Enter switch off    Esc go back'], rows
        elif label=='home' and isconsole:
            assert 'PCP OS | DESKTOP' in row(im,1,z)
    frames=r['frames']
    assert all(frames[label]==frames['home'] for label in ['cancelled','after-programs','after-settings'])
    assert frames['power']==frames['confirmed-prompt']
    assert r['key_log']==['spc','esc','f2','esc','f10','esc','f10','ret']
    assert r['final_checks']==72 and r['exit']==0 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    serial=(g/'serial.txt').read_text()
    assert r['measure']+' (measured; equal' in serial and sum(l.startswith('  pass ') for l in serial.splitlines())==72
    out.update({k:r[k] for k in ('mode','active','requested_scale','applied_scale','vram_mib','head','final_checks','exit')})
    return out
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('out',type=Path);a=p.parse_args()
    report={g.name:read_guest(g) for g in sorted((root/'guests').iterdir())}
    g=root/'controls/old-1280x720';report[g.name]=read_guest(g,True)
    a.out.write_text(json.dumps(report,indent=2)+'\n')
    for name,r in report.items():print(name,r['active'],r['applied_scale'],r['programs'].get('ink_clearance_px',r['programs']['presentation']))

set -eu
d=$(cd "$(dirname "$0")" && pwd)
cd "$d"
sha256sum --quiet -c SHA256SUMS
fresh=$(mktemp -d)
trap 'rm -rf "$fresh"' EXIT
python3 -B analyze.py guests inputs/font.rs "$fresh/settings.json" > "$fresh/settings.log"
cmp settings.json "$fresh/settings.json"
python3 -B readback.py --report "$fresh/summary.json"
cmp summary.json "$fresh/summary.json"

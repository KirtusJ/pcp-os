"""Capture stable Settings and Home frames around ordinary keyboard selections, actual program selection and execution in one QEMU boot."""
from pathlib import Path
import argparse
import hashlib
import json
import runpy
import subprocess
import time

root=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('mode')
p.add_argument('--source',type=Path,required=True)
p.add_argument('--input',type=Path,default=root/'inputs')
p.add_argument('--output',type=Path,default=root/'guests')
p.add_argument('--qemu',type=Path,required=True)
p.add_argument('--console-only',action='store_true')
a=p.parse_args()
src=a.source.resolve()
opt=runpy.run_path(str(src/'examples/optical-disk-check/check.py'))
out=a.output.resolve()/(a.mode+('-console' if a.console_only else ''))
out.mkdir(parents=True,exist_ok=False)
inputs=a.input.resolve()
receipt=json.loads((inputs/'receipt.json').read_text())
kernel=inputs/'kernel.elf32'
app=inputs/'rdesk.elf'
def sha(data):return hashlib.sha256(data).hexdigest()
assert sha(kernel.read_bytes())==receipt['on_disc']['kernel.elf32']['sha256']
assert sha(app.read_bytes())==receipt['on_disc']['rdesk.elf']['sha256']
serial=out/'serial.txt'
measurement=receipt['kernel_measurement']
cmd=[str(a.qemu.resolve()),'-machine','pc','-accel','tcg','-cpu','max','-m','256M','-smp','1','-nic','none','-display','none','-vga','std','-qmp','stdio','-monitor','none','-no-reboot','-kernel',str(kernel),'-initrd','alpha.elf,bravo.elf','-append',f'desktop={a.mode} image={measurement}' + (' grant=none' if a.console_only else ''),'-serial','file:'+str(serial)]
for name in ('alpha.elf','bravo.elf'):
    (out/name).symlink_to(app)
record={'mode':a.mode,'head':receipt['source_commit'],'measure':measurement,'argv':cmd,'key_log':[],'frames':{}}
def readlog():return serial.read_text(errors='replace') if serial.exists() else ''
with (out/'stderr.txt').open('wb') as err:
    vm=subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
    try:
        mon=opt['Monitor'](vm)
        mon.call('qmp_capabilities')
        def key(name):
            mon.key(name)
            record['key_log'].append(name)
            time.sleep(.17)
        def frame(label):
            path=out/(label+'.ppm')
            previous=None
            for _ in range(22):
                mon.call('screendump',filename=str(path))
                buf=path.read_bytes()
                if buf==previous and buf.split(b'\n',2)[1]==a.mode.replace('x',' ').encode():
                    record['frames'][label]=sha(buf)
                    return
                previous=buf
                time.sleep(.075)
            raise ValueError('unstable or wrong-size '+label)
        def choose(index):
            key('f2')
            for _ in range(index):key('down')
        opt['wait_for'](lambda:'desktop: '+a.mode+' at 1x UI scale' in readlog(),'initial desktop',50)
        time.sleep(.22)
        key('spc'); frame('program-alpha')
        key('down'); frame('program-bravo')
        key('up'); frame('program-alpha-return')
        key('down'); frame('program-bravo-return')
        assert record['frames']['program-alpha'] == record['frames']['program-alpha-return']
        assert record['frames']['program-bravo'] == record['frames']['program-bravo-return']
        if a.console_only:
            mon.key('ctrl','p'); record['key_log'].append('ctrl+p'); time.sleep(.2)
            key('esc'); key('down'); frame('home-pinned')
        else:
            key('ret')
            opt['wait_for'](lambda:'PARROTS READY' in readlog(),'Queue Desk startup',30)
            key('esc')
            opt['wait_for'](lambda:'bravo.elf ended DONE: exit 0' in readlog(),'Queue Desk completion',30)
            key('esc');frame('home-initial')
            # Both bar and dock are radio choices. Start each capture with the opposite form selected.
            for index,name in [(1,'dock'),(0,'bar')]:
                choose(index);frame(name+'-before');key('ret');frame(name+'-after')
                key('esc');frame(name+'-home')
                choose(index);frame(name+'-reopened');key('esc')
            for index,name in [(2,'recent'),(3,'machine'),(4,'session')]:
                choose(index);frame(name+'-off')
                key('ret');frame(name+'-on');key('esc');frame(name+'-home-on')
                choose(index);frame(name+'-reopened');key('ret');frame(name+'-off-again')
                key('esc');frame(name+'-home-off')
        key('f10');frame('power');key('ret')
        end=time.monotonic()+35
        while vm.poll() is None and time.monotonic()<end:
            time.sleep(.1)
        vm.wait(timeout=3)
        while not any(e.get('event')=='SHUTDOWN' for e in mon.events):
            mon.events.append(mon.read())
        record['shutdown']=next(e['data'] for e in mon.events if e.get('event')=='SHUTDOWN')
        record['exit']=vm.returncode
        log=readlog()
        record['final_checks']=sum(line.startswith('  pass ') for line in log.splitlines())
        assert measurement+' (measured; equal' in log and 'ALL SELF-TESTS PASS.' in log
        assert record['final_checks']==72 and record['exit']==0 and record['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    finally:
        if vm.poll() is None:vm.kill();vm.wait()
        (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(a.mode,len(record['frames']),record['final_checks'])

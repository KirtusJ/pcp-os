import ast
from pathlib import Path
import numpy as np
table=ast.literal_eval('['+(Path(__file__).resolve().parent/'inputs/font.rs').read_text().split(' = [',1)[1].split('];',1)[0]+']')
glyphs={np.packbits(np.asarray(row)>0).tobytes():chr(i+32) for i,row in enumerate(table)}
panel=bytes.fromhex('18364f')
def image(path):
    h,shape,maxval,raw=path.read_bytes().split(b'\n',3)
    width,height=map(int,shape.split())
    assert h==b'P6' and maxval==b'255' and len(raw)==width*height*3
    return np.frombuffer(raw,dtype=np.uint8).reshape(height,width,3)
def decode(frame):
    h,w,_=frame.shape
    cells=frame[:h//20*20,:w//10*10].reshape(h//20,20,w//10,10,3).transpose(0,2,1,3,4)
    rows=[]
    for line in cells:
        row=[]
        for cell in line:
            flat=cell.reshape(200,3)
            # All genuine text here has untouched background in the first pixel.
            # Use the most frequent color if the cell is a mixed or entirely graphic cell.
            top=flat[0]
            if np.count_nonzero(np.all(flat==top,axis=1))<100:
                values,counts=np.unique(flat,axis=0,return_counts=True)
                top=values[np.argmax(counts)]
            mask=np.any(flat!=top,axis=1)
            row.append(glyphs.get(np.packbits(mask).tobytes(),'?'))
        rows.append(''.join(row).rstrip())
    return rows
def change(x,y):
    mask=np.any(x!=y,axis=2); yy,xx=np.where(mask)
    return {'pixels':int(mask.sum()),'box':None if not len(xx) else [int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)]}

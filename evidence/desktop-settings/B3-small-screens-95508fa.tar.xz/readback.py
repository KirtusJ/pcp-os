"""Check the visible selected program, startup status, access disclosure and footer in each native guest."""
import argparse
import hashlib
import json
from pathlib import Path
from pixels import decode, image
import numpy as np

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--report', type=Path, default=root/'summary.json')
args = parser.parse_args()
highlight = np.array([0x18,0x36,0x4f])
default_access = 'Access: console, display, keyboard, files and store'

def selected_names(frame, rows):
    chosen = []
    for n,line in enumerate(rows):
        for name in ('alpha.elf','bravo.elf'):
            if name not in line: continue
            col = line.index(name)
            tile = frame[n*20:n*20+20, col*10:(col+len(name))*10]
            if np.all(tile == highlight, axis=2).mean() > .5:
                chosen.append(name)
    return chosen

def program(frame, name, console=False):
    rows=decode(frame)
    stripped=[r.strip() for r in rows]
    access='Access: console only' if console else default_access
    body=' '.join(r for r in stripped if r)
    keys=' '.join(body.split())
    return {
        'visible_selection': selected_names(frame,rows) == [name],
        'status': any(s in ('Verified at start: all 71 self-tests passed.',
                            'Verified: all 71 self-tests','Verified: all 71') for s in stripped),
        'access': access in body,
        'actions': 'Up/Down choose Enter open D details R register P off' in keys,
        'rows': stripped
    }

def erase_line(frame, substring):
    out=frame.copy()
    rows=decode(out)
    n=next(i for i,r in enumerate(rows) if substring in r)
    out[n*20:(n+1)*20]=out[n*20,0].copy()
    return out

programs=[]
for d in sorted((root/'guests').iterdir()):
    r=json.loads((d/'result.json').read_text())
    serial=(d/'serial.txt').read_text()
    assert r['exit']==0 and r['final_checks']==72 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    assert r['measure']+' (measured; equal' in serial and 'ALL SELF-TESTS PASS.' in serial
    assert sum(l.startswith('  pass ') for l in serial.splitlines())==72
    console=d.name.endswith('-console')
    if console:
        assert any('bravo.elf' in s for s in decode(image(d/'home-pinned.ppm')))
    else:
        assert 'bravo.elf ended DONE: exit 0' in serial
    for filename,digest in r['frames'].items():
        assert hashlib.sha256((d/(filename+'.ppm')).read_bytes()).hexdigest()==digest
    assert r['frames']['program-alpha'] != r['frames']['program-bravo']
    assert r['frames']['program-alpha'] == r['frames']['program-alpha-return']
    assert r['frames']['program-bravo'] == r['frames']['program-bravo-return']
    for base in ('alpha','bravo'):
        frame=image(d/('program-'+base+'.ppm'))
        data=program(frame,base+'.elf',console)
        assert all(data[k] for k in ('visible_selection','status','access','actions')), (d.name,base,data)
        programs.append({'mode':d.name,'program':base+'.elf',**data})
controls={}
frame=image(root/'guests/320x200/program-bravo.ppm')
for word,key in [('bravo.elf','visible_selection'),('Verified','status'),('Access:','access'),('Enter open','actions')]:
    reading=program(erase_line(frame,word),'bravo.elf')
    absent=[k for k in ('visible_selection','status','access','actions') if not reading[k]]
    assert absent==[key],(word,absent)
    controls[word]=absent
settings=json.loads((root/'settings.json').read_text())
for t in settings:
    assert t['before_row'] is not None and t['before_row']==t['after_row'] and t['settings_change']['pixels']>0,t
    for lines in (t['settings_before'],t['settings_after']):
        assert any(row.strip() in ('Up/Down  Enter set  Esc back','Up/Down choose    Enter set    Esc back') for row in lines), t
    if t['choice'] in ('recent','machine','session'):
        assert t['restored_settings'] and t['restored_home'] and t['home_change']['pixels']>0,t
modes={i['mode'] for i in settings}
assert len(modes)==14 and len(settings)==5*len(modes) and len(programs)==32
result={'settings_choices':len(settings),'widget_toggles':sum(t['choice'] in ('recent','machine','session') for t in settings),
        'programs':programs,'program_controls':controls,'modes':sorted(modes),'frame_count':sum(1 for f in (root/'guests').glob('*/*.ppm'))}
args.report.write_text(json.dumps(result,indent=2)+'\n')
print('Settings',result['settings_choices'],'widgets',result['widget_toggles'],'program selections',len(programs),'guests',len(programs)//2,'frames',result['frame_count'])

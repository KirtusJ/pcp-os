from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess
import sys
root=Path(__file__).resolve().parent
opts=sys.argv[1:]
modes='320x200 320x220 320x240 320x260 320x280 320x480 640x220 640x240 640x260 640x280 640x480 800x600 400x280 416x280 320x200-console 320x240-console'.split()
def run(mode):
    args=[sys.executable,'-B',root/'guest.py',mode.removesuffix('-console'),*opts]
    if mode.endswith('-console'):args.append('--console-only')
    with (root/(mode+'.log')).open('w') as log:
        code=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT).returncode
    return mode,code
with ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(run,modes))
print(results)
if any(code for mode,code in results):raise SystemExit(1)

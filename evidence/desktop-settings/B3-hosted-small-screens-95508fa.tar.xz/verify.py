from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import runpy
import subprocess
import sys
import tempfile

d=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
subprocess.run(['sha256sum','--quiet','-c','SHA256SUMS'],cwd=d,check=True)
read=runpy.run_path(str(d/'reader/build.py'))['read_back']
measure=runpy.run_path(str(d/'reader/measure.py'))['measure']
ids=json.loads((d/'artifact-identities.json').read_text())
for v,variant in [('','standard'),('-queue-desk','queue')]:
    report=json.loads((d/('report'+v+'.json')).read_text())
    name='unpublished-tester-cd'+v
    file=d/(name+'.zip')
    assert 'sha256:'+sha(file.read_bytes())==ids[name]['digest']
    with ZipFile(file) as z:raw=z.read('pcp-os-tester.iso')
    rec=json.loads((d/'receipts'/(variant+'.json')).read_text())
    assert rec['source_commit']==report['source_commit']=='95508fa4f8ebed03a7a798a717f9996c9b3cba05' and not rec['uncommitted_changes']
    assert sha(raw)==report['iso_sha256']==rec['iso_sha256'] and len(raw)==rec['iso_bytes']
    members=read(raw)
    assert set(members)==set(rec['on_disc']) and len(members)==report['members']
    assert all(sha(b)==rec['on_disc'][n]['sha256'] and len(b)==rec['on_disc'][n]['bytes'] for n,b in members.items())
    assert measure(members['kernel.elf32'])==rec['kernel_measurement']==report['kernel_measurement']
    if variant=='standard': continue
    for p in (d/'returned-list/guests').glob('*/result.json'):
        data=json.loads(p.read_text())
        assert data['measure']==rec['kernel_measurement'] and data['head']==rec['source_commit']
        old=json.loads((d/'local-guest-receipts'/(p.parent.name+'.json')).read_text())
        assert old['frames']==data['frames'] and len(data['frames'])==13
std=json.loads((d/'report.json').read_text())
z=json.loads((d/'ci/small-screens-result.json').read_text())
assert not z['problems'] and len(z['results'])==9
assert all(m['exit_code']==0 and len(m['settings'])==5 for m in z['results'].values())
assert sum('programs' in m for m in z['results'].values())==5
count=0
for mode,record in std['pixels'].items():
    for remote,local in [('settings-0','bar-after'),('settings-0-set','bar-after'),('settings-1','dock-before'),('settings-1-set','dock-after')]:
        a=(d/'ci'/mode/(remote+'.ppm')).read_bytes();b=(d/'local-settings'/mode/(local+'.ppm')).read_bytes()
        assert sha(a)==record[remote]['hosted'] and sha(b)==record[remote]['b3'] and (a==b)==record[remote]['same']
        count+=a==b
assert count==std['matches'] and std['compared']==36
with tempfile.TemporaryDirectory() as temp:
    out=Path(temp)/'result.json'
    subprocess.run([sys.executable,'-B',d/'returned-list/verify.py',out],check=True)
    assert out.read_bytes()==(d/'returned-list/result.json').read_bytes()
print('Checked 2 hosted media inventories, 9 Settings and 5 Programs CI modes,',count,'of 36 matching Settings frames and 39 of 39 identical B3 guest frames.')

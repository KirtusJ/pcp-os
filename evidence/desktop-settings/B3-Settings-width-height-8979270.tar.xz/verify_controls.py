"""Verify five native crossed-geometry controls with the same evidence reader."""
from pathlib import Path
import json
import subprocess
import sys
import tempfile
d=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as tmp:
    dst=Path(tmp)/'report.json'
    subprocess.run([sys.executable,'-B',d/'analyze.py',d/'controls',d/'font.rs',dst],check=True,stdout=subprocess.DEVNULL)
    assert dst.read_bytes()==(d/'control-results.json').read_bytes()
rows=json.loads((d/'control-results.json').read_text())
assert len(rows)==25
expected={('640x220','recent'),('640x220','session'),('640x240','machine'),('640x260','session')}
seen={(x['mode'],x['choice']) for x in rows if x['settings_change']['pixels']==0}
assert seen==expected
for x in rows:
    hidden=(x['mode'],x['choice']) in expected
    assert (x['before_row'] is None)==hidden and (x['after_row'] is None)==hidden
    assert ('Esc back' in x['settings_after'][-2])==x['mode'].startswith('640x')
    if x['choice'] in ('bar','dock'):
        assert x['settings_change']['pixels']==254
    else:
        assert x['restored_settings'] and x['restored_home'] and x['home_change']['pixels']>0
        assert x['settings_change']['pixels']==(0 if hidden else 196)
for g in (d/'controls').iterdir():
    r=json.loads((g/'result.json').read_text()); s=(g/'serial.txt').read_text()
    assert r['measure']+' (measured; equal' in s and 'rdesk.elf ended DONE: exit 0' in s
    assert sum(z.startswith('  pass ') for z in s.splitlines())==r['final_checks']==72
    assert 'ALL SELF-TESTS PASS.' in s and r['exit']==0 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
print('Five guests, 25 pairs, four unchanged widget frames, complete Esc hint at 640 pixels, and clean shutdowns verified.')

"""Separate the effect of footer position from the effect of 320-pixel text clipping."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,sys
d=Path(__file__).resolve().parent
def run(mode):
    with (d/(mode+'-control.log')).open('w') as f:
        r=subprocess.run([sys.executable,'-B',d/'guest.py',mode,'--output',d/'controls',*sys.argv[1:]],stdout=f,stderr=subprocess.STDOUT)
    return mode,r.returncode
with ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(run,('640x220','640x240','640x260','640x280','320x480')))
for mode,code in results:print(mode,code)
if any(code for _,code in results):raise SystemExit(1)

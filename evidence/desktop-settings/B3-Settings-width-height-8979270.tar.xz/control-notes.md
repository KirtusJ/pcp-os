# B3 native Settings controls for width and height

Five fresh guests used the same hosted kernel and Queue Desk as the seven original Settings trials. Four guests doubled the width to 640 while holding height at 220, 240, 260 or 280. A complementary guest retained a width of 320 and raised the height to 480. This separates a footer that covers a choice row from the horizontally clipped Esc hint.

The four 640-wide guests showed the full footer, including Esc back. At heights 220, 240 and 260, the same widget toggles as on the 320-wide screen still changed zero Settings pixels. At 640×240, the memory widget's complete Settings screen was identical after Enter while Home showed its memory line. At 640×260 the same happened for the Session widget, and Home displayed its file-lifetime text. At 320×480 all three widgets visibly changed by 196 pixels, while the footer still ended at Enter set.

All five guests completed a real Queue Desk session, tested both radio choices, enabled and disabled the three widgets in isolation, and powered off with 72 checks. For the original hosted ISO and additional provenance see B3-native-settings-8979270.tar.xz at edb3b3cc6bebe2e718a8945b64a182f7a47f55a6. After extraction run sha256sum -c SHA256SUMS and python3 -B verify_controls.py. The pixel reader requires NumPy.

/* Read-only QEMU observer for the two Bochs desktop pages and one selected label pixel. */
#include "qemu-plugin.h"
#include <fcntl.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

QEMU_PLUGIN_EXPORT int qemu_plugin_version = QEMU_PLUGIN_VERSION;

struct observation {
    uint64_t active, base, page_bytes, pixel, pixel_value;
    uint64_t stores0, stores1, key_bytes, clears, color_changes, colors[32];
};
static struct observation *window;
static uint64_t key_pc, clear_pc;

static void entered(unsigned int cpu, void *field) {
    (void)cpu;
    if (window->active) ++*(uint64_t *)field;
}
static void store(unsigned int cpu, qemu_plugin_meminfo_t info, uint64_t va, void *unused) {
    (void)cpu; (void)unused;
    if (!window->active) return;
    struct qemu_plugin_hwaddr *hw = qemu_plugin_get_hwaddr(info, va);
    if (!hw) return;
    uint64_t addr = qemu_plugin_hwaddr_phys_addr(hw);
    unsigned int size = 1u << qemu_plugin_mem_size_shift(info);
    if (addr + size <= window->base || addr >= window->base + 2 * window->page_bytes) return;
    if (addr < window->base + window->page_bytes) ++window->stores0;
    if (addr + size > window->base + window->page_bytes) ++window->stores1;
    if (addr + size <= window->pixel || addr >= window->pixel + 4 || size > 16) return;

    qemu_plugin_mem_value v = qemu_plugin_mem_get_value(info);
    uint64_t low = 0, high = 0;
    switch (v.type) {
        case QEMU_PLUGIN_MEM_VALUE_U8: low=v.data.u8; break;
        case QEMU_PLUGIN_MEM_VALUE_U16: low=v.data.u16; break;
        case QEMU_PLUGIN_MEM_VALUE_U32: low=v.data.u32; break;
        case QEMU_PLUGIN_MEM_VALUE_U64: low=v.data.u64; break;
        case QEMU_PLUGIN_MEM_VALUE_U128: low=v.data.u128.low; high=v.data.u128.high; break;
        default: return;
    }
    uint32_t before = window->pixel_value, after = before;
    for (unsigned i=0; i<size; ++i) {
        if (addr+i < window->pixel || addr+i >= window->pixel+4) continue;
        unsigned shift = (unsigned)(addr+i-window->pixel)*8;
        uint8_t b = (i<8 ? low : high) >> (8*(i%8));
        after=(after & ~(UINT32_C(255)<<shift)) | ((uint32_t)b<<shift);
    }
    if ((after & 0xffffff) != (before & 0xffffff)) {
        if (window->color_changes<32) window->colors[window->color_changes] = after & 0xffffff;
        ++window->color_changes;
    }
    window->pixel_value=after;
}
static void translate(qemu_plugin_id_t id, struct qemu_plugin_tb *tb) {
    (void)id;
    size_t count=qemu_plugin_tb_n_insns(tb);
    for (size_t n=0;n<count;++n) {
        struct qemu_plugin_insn *insn=qemu_plugin_tb_get_insn(tb,n);
        uint64_t pc=qemu_plugin_insn_vaddr(insn);
        if (pc==key_pc || pc==clear_pc)
            qemu_plugin_register_vcpu_insn_exec_cb(insn,entered,QEMU_PLUGIN_CB_NO_REGS,
                pc==key_pc ? &window->key_bytes : &window->clears);
        qemu_plugin_register_vcpu_mem_cb(insn,store,QEMU_PLUGIN_CB_NO_REGS,QEMU_PLUGIN_MEM_W,NULL);
    }
}
QEMU_PLUGIN_EXPORT int qemu_plugin_install(qemu_plugin_id_t id,const qemu_info_t *info,int argc,char **argv) {
    if (!info->system_emulation || argc!=3) return -1;
    if (strncmp(argv[0],"state=",6) || strncmp(argv[1],"kbd=",4) || strncmp(argv[2],"clear=",6)) return -1;
    int fd=open(argv[0]+6,O_RDWR);
    if (fd<0) return -1;
    struct stat st;
    if (fstat(fd,&st)!=0 || st.st_size!=sizeof(*window)) {close(fd);return -1;}
    window=mmap(NULL,sizeof(*window),PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
    close(fd);
    if (window==MAP_FAILED) return -1;
    key_pc=strtoull(argv[1]+4,NULL,16);
    clear_pc=strtoull(argv[2]+6,NULL,16);
    if (!key_pc || !clear_pc) return -1;
    qemu_plugin_register_vcpu_tb_trans_cb(id,translate);
    return 0;
}

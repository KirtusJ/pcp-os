/* The QEMU public header only needs these opaque pointer types for APIs this observer does not use. */
typedef struct _GArray GArray;
typedef struct _GByteArray GByteArray;

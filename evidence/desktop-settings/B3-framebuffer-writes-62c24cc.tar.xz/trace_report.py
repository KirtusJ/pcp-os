"""Replay the QEMU store counters against the exact input intervals and the settled original frames."""
from pathlib import Path
import hashlib,json,sys
import pixels
root=Path(__file__).resolve().parent
records={}
for path in sorted((root/'guests').glob('*/result.json')):
    r=json.loads(path.read_text()); mode=r['mode']; d=path.parent
    assert r['checks']==72 and r['exit']==0
    log=(d/'serial.txt').read_text()
    assert r['measurement']+' (measured; equal' in log and f'desktop: {mode} at 1x UI scale' in log
    assert sum(s.startswith('  pass ') for s in log.splitlines())==72
    def rgb(im,xy):
        x,y=xy
        return int.from_bytes(bytes(im[y,x]),'big')
    raw=(d/'home.ppm').read_bytes();last=pixels.image(raw)
    digest=hashlib.sha256(raw).hexdigest()
    phases={}
    for k in r['intervals']:
        label=k['label'];raw=(d/(label+'.ppm')).read_bytes();cur=pixels.image(raw)
        assert k['sha256']==hashlib.sha256(raw).hexdigest() and k['unchanged']==(digest==k['sha256'])
        assert list(cur.shape[1::-1])==list(map(int,mode.split('x')))
        assert k['before_rgb']==rgb(last,k['pixel']) and k['after_rgb']==rgb(cur,k['pixel'])==k['guest_last_rgb']
        if k['key']:assert k['keyboard_bytes']>=2
        assert k['stores_back']==0
        if label in ('register-idle','settings-idle'):
            assert k['keyboard_bytes']==k['stores_front']==k["changes"]==0
        if label in ('register-ignored','register-boundary-down','settings-ignored','settings-boundary-up'):
            assert k['unchanged']
            if r['revision']=='previous':
                assert k['clear_calls']==1 and k['stores_front']>0 and k['rgb_sequence']==[0x10283f,k['before_rgb']]
            else:assert k['clear_calls']==k['stores_front']==k['changes']==0
        if label=='settings-apply-current' and r['revision']!='62c24cc':
            assert k['unchanged'] and k['clear_calls']==1 and k['stores_front']>0 and k['rgb_sequence']==[0x10283f,k['before_rgb']]
        if r['revision']=='62c24cc' and label in ('settings-apply-current','settings-reapply-dock','settings-reapply-bar'):
            assert k['unchanged'] and k['clear_calls']==k['stores_front']==k['changes']==0
        if label in ('settings-select-dock','settings-select-bar'):
            assert not k['unchanged'] and k['clear_calls']==1 and k['stores_front']>0
        if label=='settings-next':assert not k['unchanged'] and k['stores_front']>0 and k['clear_calls']==1
        if label!='register-home' and label!='settings-home' and not label.startswith('open-') and label!='power':
            phases[label]={'stores_page0':k['stores_front'],'stores_page1':k['stores_back'],'keyboard_bytes':k['keyboard_bytes'],'clear_calls':k['clear_calls'],'color_changes':k['changes'],'settled_equal':k['unchanged']}
        last=cur;digest=k['sha256']
    assert r['revision'] not in ('previous','e749600') or len(phases)==9
    records[d.name]=phases
assert len(records)==16
Path(sys.argv[1]).write_text(json.dumps(records,indent=2,sort_keys=True)+'\n')
print(len(records),'unmodified-kernel QEMU guests replayed')

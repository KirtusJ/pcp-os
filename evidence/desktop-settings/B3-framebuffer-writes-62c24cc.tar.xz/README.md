# Did the desktop repaint between two identical pictures?

B3 traced stores made by a single emulated CPU during keyboard input on unmodified PCP OS kernels. The QEMU TCG observer watches physical addresses in the two active Bochs framebuffer pages. Every interval starts and ends with the VM stopped. The observer also counts the guest keyboard-byte and clear-function entries and reconstructs changes to one title pixel from the data stored there. The RGB value agrees with QEMU's screenshot before and after every interval. The trace is a record of guest CPU writes. Perceptibility on a physical panel was not measured.

At 1280×720 the previous renderer made 1,225,600 page-zero stores after X in the register and 990,200 after X in Settings. Both title pixels went from their foreground colour to the background and back. Both settled pictures remained byte-identical. The intermediate renderer stopped those ignored-key redraws but still repainted when Enter reapplied the existing bar. At 62c24cc2a76bc35bdf12b7ad40302c524f045b50, reapplying the bar or dock produced zero writes, as did the tested ignored letters and boundary arrows. Choosing a different setting produced a visible state change and a full redraw. All five sizes passed, including 1280×720, 1920×1080 and 2560×1440. The other sizes were 320×200 and 640×480. Sixteen guests completed 72 self-tests and shut down normally.

The previous binary comes from 7f92f339, whose Rust tree is the same as 16b42f45. There is one intermediate 2c27f91 guest and five each on 7f92f339, e749600 and 62c24cc. The output retains each original P6, serial, command, per-interval count, event sequence and measured ELF digest. An instruction may perform more than one pixel write; the reported unit is an observed CPU store. Page 1 received no writes in these UI trials.

To replay the raw evidence with Python 3 and NumPy:

    sha256sum --quiet -c SHA256SUMS
    python3 -B trace_report.py repeated.json
    cmp repeated.json trace.json

The observer never writes guest memory. Its shared file carries host-side counters and observations. It uses QEMU's public plugin API version 4 from qemu/qemu v10.0.0, include/qemu/qemu-plugin.h, Git blob 3a850aa2166ab63dae6552d0ce32ce06dffe41c8. The included GLib declarations are used only for the two unrelated opaque types in that header. Compile on Linux with:

    gcc -std=c11 -O2 -Wall -Wextra -Werror -fPIC -shared -Itrace/include trace/video_trace.c -o trace/video_trace.so

For a fresh instrumented guest, trace_guest.py records the original toolchain and workspace layout. builds.json gives the source commit, ELF SHA-256, measured image and the two function entry addresses. The QEMU command line is in each guest's result.json. The display base comes from the actual guest serial log and each interval uses width × height × 4 bytes per page.

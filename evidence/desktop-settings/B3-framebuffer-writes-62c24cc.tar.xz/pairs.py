from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
variants=sys.argv[1:]
cases=[(v,m) for m in ('1280x720','320x200','640x480','1920x1080','2560x1440') for v in variants]
def run(pair):
    v,m=pair
    with (root/(v+'-'+m+'.log')).open('w') as f:code=subprocess.run([sys.executable,'-B',root/'trace_guest.py',v,m],stdout=f,stderr=subprocess.STDOUT).returncode
    return v,m,code
with ThreadPoolExecutor(max_workers=3) as ex:rows=list(ex.map(run,cases))
print(rows);sys.exit(any(x[-1] for x in rows))

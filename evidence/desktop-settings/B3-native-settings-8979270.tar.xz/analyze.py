"""Independently read native P6 colors, Settings selection and state, and same-boot Home changes."""
import argparse
import ast
import collections
import hashlib
import json
from pathlib import Path
import numpy as np

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('guests',type=Path)
p.add_argument('font',type=Path)
p.add_argument('report',type=Path)
a=p.parse_args()
table=ast.literal_eval('['+a.font.read_text().split(' = [',1)[1].split('];',1)[0]+']')
glyphs={np.packbits(np.asarray(row)>0).tobytes():chr(i+32) for i,row in enumerate(table)}
panel=bytes.fromhex('18364f')
def image(path):
    h,shape,maxval,raw=path.read_bytes().split(b'\n',3)
    width,height=map(int,shape.split())
    assert h==b'P6' and maxval==b'255' and len(raw)==width*height*3
    return np.frombuffer(raw,dtype=np.uint8).reshape(height,width,3)
def decode(frame):
    h,w,_=frame.shape
    cells=frame[:h//20*20,:w//10*10].reshape(h//20,20,w//10,10,3).transpose(0,2,1,3,4)
    rows=[]
    for line in cells:
        row=[]
        for cell in line:
            flat=cell.reshape(200,3)
            # All genuine text here has untouched background in the first pixel.
            # Use the most frequent color if the cell is a mixed or entirely graphic cell.
            top=flat[0]
            if np.count_nonzero(np.all(flat==top,axis=1))<100:
                values,counts=np.unique(flat,axis=0,return_counts=True)
                top=values[np.argmax(counts)]
            mask=np.any(flat!=top,axis=1)
            row.append(glyphs.get(np.packbits(mask).tobytes(),'?'))
        rows.append(''.join(row).rstrip())
    return rows
def change(x,y):
    mask=np.any(x!=y,axis=2); yy,xx=np.where(mask)
    return {'pixels':int(mask.sum()),'box':None if not len(xx) else [int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)]}
choices=[('bar','A bar across the screen'),('dock','A dock in the middle'),('recent','Recent activity'),('machine','This machine'),('session','Session')]
results=[]
for d in sorted(a.guests.iterdir()):
    if not d.is_dir():continue
    r=json.loads((d/'result.json').read_text())
    assert r['exit']==0 and r['final_checks']==72 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    cache={}
    def load(name):
        f=d/(name+'.ppm');sha=hashlib.sha256(f.read_bytes()).hexdigest();assert sha==r['frames'][name]
        if sha not in cache:
            im=image(f); cache[sha]=(im,decode(im))
        return cache[sha]
    initial,initial_rows=load('home-initial')
    assert any('PCP OS | DESKTOP' in row for row in initial_rows)
    assert any('Switch PCP OS off?' in row for row in load('power')[1])
    for index,(key,label) in enumerate(choices):
        radio=index<2
        before,br=load(key+('-before' if radio else '-off'))
        after,ar=load(key+('-after' if radio else '-on'))
        reopened,rr=load(key+'-reopened')
        assert '  SETTINGS' in ar and np.array_equal(after,reopened)
        marker0,marker1=('( )','(o)') if radio else ('[  ]','[on]')
        def selected(im,rows,marker):
            for n,l in enumerate(rows):
                pos=l.find(label)
                if pos<0 or marker not in l[:pos]:continue
                area=im[n*20:n*20+20,pos*10:(pos+len(label))*10]
                if np.all(area==np.frombuffer(panel,dtype='u1'),axis=2).mean()>.5:
                    return n
            return None
        bsel=selected(before,br,marker0); asel=selected(after,ar,marker1)
        home,home_rows=load(key+('-home' if radio else '-home-on'))
        home_diff=change(initial,home)
        home_added=[x.strip() for x in home_rows if x and x not in initial_rows]
        x={'mode':r['mode'],'choice':key,'before_row':bsel,'after_row':asel,'settings_change':change(before,after),'home_change':home_diff,'home_added':home_added,'settings_before':br,'settings_after':ar}
        if not radio:
            again,_=load(key+'-off-again'); home_off,_=load(key+'-home-off')
            x['restored_settings']=bool(np.array_equal(before,again))
            x['restored_home']=bool(np.array_equal(initial,home_off))
        results.append(x)
a.report.write_text(json.dumps(results,indent=2)+'\n')
for row in results:
    print(row['mode'],row['choice'],row['before_row'],row['after_row'],row['settings_change']['pixels'],row['home_change']['pixels'],row['home_added'])

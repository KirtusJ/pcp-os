from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,zipfile
root=Path(__file__).resolve().parent
def sha(buf):return hashlib.sha256(buf).hexdigest()
inp=root/'inputs';receipt=json.loads((inp/'receipt.json').read_text())
assert receipt['source_commit']=='9da817367f8a7493d333f88dc1bc12444f4ebb45' and not receipt['uncommitted_changes']
assert sha((inp/'queue.zip').read_bytes())=='90122b82e6946a68d421726c06e867309d1080576a2cfcb594aa5cfc423b2a76'
with zipfile.ZipFile(inp/'queue.zip') as z:assert sha(z.read('pcp-os-tester.iso'))==receipt['iso_sha256']
for file in ('kernel.elf32','rdesk.elf'):assert sha((inp/file).read_bytes())==receipt['on_disc'][file]['sha256']
assert len(list((root/'guests').glob('*/*.ppm')))==196
with tempfile.TemporaryDirectory() as tmp:
    actual=Path(tmp)/'actual.json'
    subprocess.run([sys.executable,'-B',root/'analyze.py',root/'guests',inp/'font.rs',actual],check=True,stdout=subprocess.DEVNULL)
    assert actual.read_bytes()==(root/'result.json').read_bytes()
data=json.loads((root/'result.json').read_text())
assert len(data)==35
zeros={('320x200','machine'),('320x200','session'),('320x220','recent'),('320x220','session'),('320x240','machine'),('320x260','session')}
assert {(row['mode'],row['choice']) for row in data if row['settings_change']['pixels']==0}==zeros
for row in data:
    invisible=(row['mode'],row['choice']) in zeros
    assert (row['before_row'] is None)==invisible and (row['after_row'] is None)==invisible
    if row['choice'] in ('bar','dock'):
        assert row['settings_change']['pixels']==254
    else:
        assert row['restored_settings'] and row['restored_home']
        assert row['home_change']['pixels']>0
        assert row['settings_change']['pixels']==(0 if invisible else 196)
for d in (root/'guests').iterdir():
    serial=(d/'serial.txt').read_text();r=json.loads((d/'result.json').read_text())
    assert receipt['kernel_measurement']+' (measured; equal' in serial
    assert 'rdesk.elf ended DONE: exit 0' in serial and 'ALL SELF-TESTS PASS.' in serial
    assert sum(line.startswith('  pass ') for line in serial.splitlines())==r['final_checks']==72
    assert r['exit']==0 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
print('Verified 196 native P6 frames, 35 choice/geometry pairs, six invisible widget changes, and seven clean guest shutdowns.')

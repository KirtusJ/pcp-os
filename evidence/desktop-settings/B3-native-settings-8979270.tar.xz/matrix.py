from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys
d=Path(__file__).resolve().parent
common=sys.argv[1:]
def boot(mode):
    with (d/(mode+'.log')).open('w') as stream:
        result=subprocess.run([sys.executable,'-B',d/'guest.py',mode,*common],stdout=stream,stderr=subprocess.STDOUT)
    return mode,result.returncode
with ThreadPoolExecutor(max_workers=3) as p:
    results=list(p.map(boot,['320x220','320x240','320x260','320x200','320x280','640x480','800x600']))
for r in results:print(*r)
if any(code for _,code in results):raise SystemExit(1)

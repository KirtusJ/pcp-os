"""Check exact firmware scanout on QEMU's MMIO-only Bochs display with 64 MiB of video memory."""
from concurrent.futures import ThreadPoolExecutor
import json, subprocess, sys
from pathlib import Path
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent))
import preference as pref
usb=pref.usb

def run(mode):
    w,h=map(int,mode.split('x'))
    ordinary=usb.usb_command
    def chosen(q,c,t,v,o,r,video):
        args=ordinary(q,c,t,v,o,r,video)
        args[args.index('virtio-vga')]=f'bochs-display,vgamem=64M,edid=on,xres={w},yres={h}'
        return args
    usb.usb_command=chosen
    f=pref.root/'usb-build/fixtures'
    image=json.loads((f/'image.json').read_text())
    # The stock virtio-vga test path requires a validated single-page loader framebuffer.
    r=usb.trial(str(pref.validation/'bin/qemu-system-x86_64'),pref.firmware/'OVMF_CODE_4M.fd',
                here.parent/'preferred'/(mode+'.fd'),f/'usb.img',image,here/mode,256,'virtio-vga')
    assert 'bochs-display' in ' '.join(r['argv'])
    print(mode,r['loader_display'],r['passed'])

if len(sys.argv)>1:run(sys.argv[1])
else:
    def worker(mode):
        with (here/(mode+'.log')).open('w') as log:
            return mode,subprocess.run([sys.executable,'-B',__file__,mode],stdout=log,stderr=subprocess.STDOUT).returncode
    with ThreadPoolExecutor(max_workers=3) as w: r=list(w.map(worker,pref.modes))
    print(r)
    sys.exit(any(x[1] for x in r))

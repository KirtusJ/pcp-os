"""Read Programs and Settings from the active firmware display, cross-checking both encoders at 1366 px."""
from pathlib import Path
from PIL import Image
import hashlib,json,sys
here=Path(__file__).resolve().parent
sys.path.insert(0,str(here.parent));import preference as pref
sys.path.insert(0,str(pref.root));import read_pixels as pixels
usb=pref.usb
mode=sys.argv[1] if len(sys.argv)>1 else '1366x768'
wanted_w,wanted_h=map(int,mode.split('x'))
ordinary_usb=usb.usb_command
def cmd(*args):
    args=ordinary_usb(*args);args[args.index('virtio-vga')]=f'bochs-display,vgamem=64M,edid=on,xres={wanted_w},yres={wanted_h}';return args
usb.usb_command=cmd
mon=usb.OPTICAL['Monitor']
original_call=mon.call
def capture(self,name,**kwargs):
    if name!='screendump':return original_call(self,name,**kwargs)
    out=Path(kwargs['filename']);native=out.with_suffix('.qemu-ppm');png=out.with_suffix('.png')
    running=original_call(self,'query-status')['status']=='running'
    if running:original_call(self,'stop')
    try:
        result=original_call(self,'screendump',filename=str(native),format='ppm')
        original_call(self,'screendump',filename=str(png),format='png')
    finally:
        if running:original_call(self,'cont')
    ppm=native.read_bytes();magic,geom,depth,raw=ppm.split(b'\n',3);w,h=map(int,geom.split())
    with Image.open(png) as im:
        assert im.size==(w,h) and im.mode=='RGB';rgb=im.tobytes()
    if len(raw)==3*w*h:assert raw==rgb
    else:
        stride=(3*w+3)//4*4
        assert len(raw)==stride*h
        for i in range(h):
            assert raw[i*stride:i*stride+3*w]==rgb[i*3*w:(i+1)*3*w]
            assert raw[i*stride+3*w:(i+1)*stride]==bytes(stride-3*w)
    assert magic==b'P6' and depth==b'255'
    out.write_bytes(b'\n'.join((magic,geom,depth,rgb)));return result
if mode=='1366x768':mon.call=capture
screens=usb.OPTICAL['DesktopScreens']
verification=screens.verification
def extra(self,prefix):
    def programs(rows, frame):
        try:
            note=pixels.programs(pixels.image(frame))
            return note['ink_clearance_px']>=0
        except (AssertionError,IndexError): return False
    self.monitor.key('spc');self.wait_frame('programs',programs)
    self.monitor.key('esc');self.home('after-programs')
    self.monitor.key('f2');self.wait('settings', lambda rows: any(s.strip()=='SETTINGS' for s in rows))
    self.monitor.key('esc');self.home('after-settings')
    for name in ('after-programs','after-settings'):
        assert (self.directory/(name+'.ppm')).read_bytes()==(self.directory/'home.ppm').read_bytes()
    verification(self,prefix)
screens.verification=extra
f=pref.root/'usb-build/fixtures'
r=usb.trial(str(pref.validation/'bin/qemu-system-x86_64'),pref.firmware/'OVMF_CODE_4M.fd',
            here.parent/'preferred'/(mode+'.fd'),f/'usb.img',json.loads((f/'image.json').read_text()),(here/'paired-1366' if mode=='1366x768' else here/('full-'+mode)),256,'virtio-vga')
print(r['loader_display'],r['passed'],r['self_tests'],r['exit'])

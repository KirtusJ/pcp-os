"""Replay the Q35 firmware trials against the actual image dimensions and USB receipt."""
from pathlib import Path
from PIL import Image
import hashlib,json,re,sys
import numpy as np
import pixels as px
root=Path(__file__).resolve().parent
modes=['1280x720','1366x768','1920x1080','1920x1200','2560x1440','2880x1800','3840x2160']
usb=json.loads((root/'inputs/image.json').read_text())
def run(mode, full):
    sub=('paired-1366' if mode=='1366x768' else 'full-'+mode) if full else mode
    d=root/sub;w,h=map(int,mode.split('x'));raw=(d/'home.ppm').read_bytes()
    r=json.loads((d/'result.json').read_text())
    s=(d/'serial.txt').read_text()
    assert any(x.startswith('bochs-display,vgamem=64M') for x in r['argv'])
    assert re.search(r'^display: Loader, '+mode+r', 1 page\(s\)',s,re.M)
    assert re.search(r'^desktop: '+mode+' at 1x UI scale',s,re.M)
    trace=(d/'firmware.txt').read_text()
    pitch=int(re.search(r'console_pitch=([0-9a-f]+)',trace)[1],16)
    assert pitch>=w*4
    assert raw.split(b'\n',3)[:3]==[b'P6',f'{w} {h}'.encode(),b'255']
    if not full and mode=='1366x768':
        assert len(raw.split(b'\n',3)[3])==4100*h and not r['passed']
        assert 'TimeoutError: waiting for home framebuffer' in (root/(mode+'.log')).read_text()
        return {'stock_pass':False,'kernel_and_qemu_header':mode,'raw_rgb_row_bytes':4100}
    assert r['usb_sha256_after']==usb['usb_sha256'] and r['self_tests']==72 and r['exit']==0 and r['passed']
    assert r['shutdown']==dict(guest=True,reason='guest-shutdown')
    assert (d/'home-after-verification.ppm').read_bytes()==raw
    obs={'kernel_and_qemu':mode,'firmware_pitch':pitch,'scale':1,'checks':72,'passed':True}
    if full:
        assert all((d/(label+'.ppm')).read_bytes()==raw for label in ('after-programs','after-settings'))
        progs=px.image((d/'programs.ppm').read_bytes());assert list(progs.shape[1::-1])==[w,h]
        obs['programs']=px.programs(progs);assert obs['programs']['ink_clearance_px']>=0
        assert px.row(px.image((d/'settings.ppm').read_bytes()),1,1).strip()=='SETTINGS'
        if mode=='1366x768':
            saved={}
            for p in d.glob('*.png'):
                with Image.open(p) as im:rgb=im.tobytes();assert im.size==(w,h) and im.mode=='RGB'
                q=p.with_suffix('.qemu-ppm').read_bytes().split(b'\n',3)[3]
                pp=p.with_suffix('.ppm').read_bytes().split(b'\n',3)[3]
                arr=np.frombuffer(q,dtype='u1').reshape(h,4100)
                assert (arr[:,4098:]==0).all() and arr[:,:4098].tobytes()==rgb==pp
                saved[p.stem]=hashlib.sha256(rgb).hexdigest()
            assert len(saved)==8
            obs['eight_paired_image_digests']=saved
    return obs
results={f'{mode}/{kind}':run(mode,kind=='full') for mode in modes for kind in ['stock','full']}
Path(sys.argv[1]).write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
print('Verified seven native sizes, the stock 1366 PPM failure, and all eight PNG/PPM pixel pairs.')

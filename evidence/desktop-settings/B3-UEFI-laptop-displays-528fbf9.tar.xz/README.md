# Firmware-owned graphical desktop from 720p to 4K

On OS 528fbf977ae368e782cbbb85921a186c3ee368f1, B3 booted the same read-only USB using Q35, stock OVMF, and the MMIO-only QEMU bochs-display with 64 MiB of video memory, one preferred mode per disposable OVMF variable store. The kernel used the firmware's single-page framebuffer. All seven requested sizes were native: 1280×720, 1366×768, 1920×1080, 1920×1200, 2560×1440, 2880×1800 and 3840×2160. The original receipt's video field names the stock virtio-vga code path that requires a validated loader framebuffer. Its QEMU argv identifies the actual adapter.

Six of the seven ordinary USB trials passed. At 1366×768 the unmodified trial timed out at Home: QEMU wrote 4100 bytes per PPM row, two more than the 4098 RGB bytes declared by its P6 header. This differs from the virtio-vga trial in the preceding archive, where the QEMU scanout itself was 1360×768. For the repeated native 1366×768 guest, QEMU provided both PNG and PPM from the same stopped frame. The 4098 image bytes on every row matched the PNG, and both trailing bytes on each row were zero. The USB trial consumed a P6 reconstructed from the PNG. All eight surfaces retain QEMU's original PNG, original padded PPM, and reconstructed P6.

Seven extended boots checked Home, Programs, Settings, F5, return to Home, F10, and confirmed guest shutdown with 72 self-tests. All defaulted to 1×. The Programs guidance fit its plate at every native size. See results.json for measured ink clearance in pixels. These results establish virtual firmware coverage; physical laptop observations remain open.

From the unpacked folder, use Python 3 with Pillow and NumPy:

    sha256sum --quiet -c SHA256SUMS
    python3 -B check.py repeat.json
    cmp results.json repeat.json

Boot and capture scripts retain the original workspace layout. For new guest runs, the OS, optical-disk checker, OVMF and the measured USB fixture are needed. The original QEMU commands and frame/firmware evidence are archived.

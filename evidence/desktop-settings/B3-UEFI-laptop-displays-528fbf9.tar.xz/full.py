from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,sys
here=Path(__file__).resolve().parent
modes=['1280x720','1920x1080','2560x1440','1920x1200','2880x1800','3840x2160']
def run(mode):
 with (here/('full-'+mode+'.log')).open('w') as f:
    return mode,subprocess.run([sys.executable,'-B',here/'paired_capture.py',mode],stdout=f,stderr=subprocess.STDOUT).returncode
with ThreadPoolExecutor(max_workers=2) as p: results=list(p.map(run,modes))
print(results);sys.exit(any(code for _,code in results))

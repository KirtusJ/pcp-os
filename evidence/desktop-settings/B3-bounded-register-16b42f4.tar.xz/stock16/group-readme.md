# Final register-field checker at 16b42f4518af3b90dc41cfc734b96b8b7ca64459

The sole Git blob changed since B3's reviewed 7f92f339 renderer is examples/tester-cd/check_small_screens.py. Its reviewed Git blob is ffe5ee26ed2250ea71eba78773fc0361f22a5b02. The Rust tree is cdbc2b2f758177fc9c5c504abef19b6b55d3074e. Both the guarded optical and firmware-owned USB recipe trees retain their reviewed identities. The preceding B3 archive supplies the original 13 native register captures and both earlier checker versions.

Download the B3-register-7f92f33-1044cb7.tar.xz archive from OS evidence commit a3f54ed82e3491a996fa1313487d1457d612e5b5, extract it into an empty working directory, then unpack this supplement there. To replay the damaged-field verdicts with Python 3 and NumPy:

    sha256sum --quiet -c SHA256SUMS
    cp bounded.json expected-bounded.json
    python3 -B bounded_replay.py
    cmp expected-bounded.json bounded.json

B3 used the exact T4 statements on original register captures and on deliberate changes to their pixels. The final checker accepted all 13 originals and rejected eight controls: seven digits followed by two dots at 720p, 1080p and 1440p; a missing final digit directly before event zero on three narrow displays; one missing digit of a marked title prefix at two intermediate widths.

B3 also ran all 13 settings, programs and text-screen cases from the candidate's checker in live QEMU guests. The unmodified runner could not open a filesystem QMP socket in this host; the launch logs are included. The local copy uses QEMU's standard input and output for QMP and distributes the published cases over four processes. The case definitions, framebuffer reader, input actions, timings and acceptance predicates are identical to the candidate. A test-only Rock Ridge carrier supplied the measured OS kernel and original distribution Surfbird to the checker's normal direct-boot entry point. The carrier was read back before use. The firmware and guarded optical delivery paths were booted separately in the preceding archive.

The four result files, original P6s, decoded screen text, serial logs and SHA256 digests cover all 13 native dimensions. The case suite terminates each supervised guest after its UI checks. The separate 13 original B3 guests confirmed power-off and 72 final self-tests.

"""Create a copy of the stock screen check using QMP stdio; split existing cases across four workers."""
from pathlib import Path
import ast,sys
root=Path(__file__).resolve().parent
src=root/'source/examples/tester-cd/check_small_screens.py'
s=src.read_text()
s=s.replace('"unix:%s,server=on,wait=off" % sock','"stdio"')
s=s.replace('cwd=folder, stdout=subprocess.DEVNULL,','cwd=folder, text=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE,')
start=s.index('        end = time.monotonic() + 20');end=s.index('        def rpc(',start)
s=s[:start]+s[end:]
s=s.replace('stream.write(','guest.stdin.write(').replace('stream.flush()','guest.stdin.flush()').replace('stream.readline()','guest.stdout.readline()')
tree=ast.parse(s)
main=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='main')
loop=next(x for x in main.body if isinstance(x,ast.For) and isinstance(x.target,ast.Tuple) and x.target.elts[0].id=='mode')
items=ast.literal_eval(loop.iter)
lines=s.splitlines(True); first=loop.body[0].lineno-1
lines.insert(first,'        if mode not in __import__("os").environ["B3_GEOMETRIES"].split(","): continue\n')
(src.parent/'stdio_check.py').write_text(''.join(lines))
(root/'geometries').write_text('\n'.join(m[0] for m in items)+'\n')

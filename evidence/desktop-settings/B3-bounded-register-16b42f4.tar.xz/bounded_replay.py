"""Run the exact T4 statements against original and damaged QEMU register pages."""
from pathlib import Path
import ast,json,re,hashlib,sys
import pixels as px
root=Path(__file__).resolve().parent
def image(d):return px.image(d.read_bytes()).copy()
def rows(im):return [px.row(im,n,1).rstrip() for n in range(im.shape[0]//20)]
def extract(file):
    fn=next(n for n in ast.parse(file.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='text_trial')
    begin=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign) and getattr(n.targets[0],'id',None) in ('register','register_pages'))
    stop=next(i for i in range(begin+1,len(fn.body)) if isinstance(fn.body[i],ast.If) and isinstance(fn.body[i].test,ast.Name) and fn.body[i].test.id=='graphic')
    return compile(ast.Module(fn.body[begin:stop],[]),str(file),'exec')
old=extract(root/'source/examples/tester-cd/check_small_screens.py')
new=extract(root/'bounded-checker.py')
def verdict(code,mode,pages):
    found=[];env=dict(mode=mode,pages=lambda *args:pages,re=re,found=found)
    exec(code,env);return not found
def status(mode,frames):
    pages=[rows(f) for f in frames]
    return dict(parent=verdict(old,mode,pages),candidate=verdict(new,mode,pages))
def actual(d):return [image(d/(n+'.ppm')) for n in ('register-latest','register-up','register-first')]
out={}
for d in sorted((root/'guests').iterdir()):
    k=d.name;frames=actual(d);res=out[k]={'original':status(k,frames)}
    assert res['original']==dict(parent=True,candidate=True),(k,res)
    if k in ('1280x720','1920x1080','2560x1440'):
        medium=actual(root/'guests/1024x768')[0]
        x=10*rows(medium)[1].index('..');dots=medium[20:40,x:x+20]
        for im in frames:
            title=rows(im)[1];start=title.index('head ')+5+7
            im[20:40,10*start:10*len(title)]=im[20,0].copy()
            im[20:40,10*start:10*start+20]=dots
        res['seven_digits_dots']=status(k,frames)
        assert res['seven_digits_dots']==dict(parent=True,candidate=False)
    if k in ('320x200','640x480','656x480'):
        short=[]
        for im in frames:
            r=rows(im)
            matches=[j for j,line in enumerate(r) if re.fullmatch(r'\s*[0-9a-f]+\s*',line) and j+1<len(r) and re.match(r'^\s*0 WORKSPACE_CREATED',r[j+1])]
            mod=im.copy()
            for j in matches:
                col=len(r[j].rstrip())-1; mod[j*20:(j+1)*20,col*10:(col+1)*10]=im[j*20,0].copy()
            short.append(mod)
        first=rows(short[-1])
        start=next(i for i,l in enumerate(first) if 'head ' in l)
        end=next(i for i,l in enumerate(first) if '0 WORKSPACE_CREATED' in l)
        digits=''.join(''.join(first[start:end]).split()).split('head',1)[1]
        assert len(digits)==63 and re.fullmatch('[0-9a-f]{63}',digits)
        res['one_missing_digit_before_sequence_zero']=status(k,short)
        assert res['one_missing_digit_before_sequence_zero']==dict(parent=True,candidate=False)
        print(k,len(digits),res['one_missing_digit_before_sequence_zero'],flush=True)
    if k in ('1024x768','1208x768'):
        for im in frames:
            title=rows(im)[1];end=title.index('..')
            im[20:40,(end-1)*10:end*10]=im[20,0].copy()
        res['short_marked_prefix']=status(k,frames)
        # The test removes a single final digit, retaining the genuine terminal dots.
        assert not res['short_marked_prefix']['candidate']
(root/'bounded.json').write_text(json.dumps(out,indent=2)+'\n')

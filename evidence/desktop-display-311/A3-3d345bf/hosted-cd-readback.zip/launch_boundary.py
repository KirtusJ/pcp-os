"""Read compact Home at pin capacity and exercise its ordinary Enter action."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import time

p = argparse.ArgumentParser(description=__doc__)
for field in ('source', 'kernel', 'program', 'qemu', 'out'):
    p.add_argument(field, type=Path)
p.add_argument('--revision', required=True)
p.add_argument('--geometry', choices=['320x200','640x480'], required=True)
args = p.parse_args()
source, kernel, program, qemu, out = (getattr(args, k).resolve() for k in ('source', 'kernel', 'program', 'qemu', 'out'))
out.mkdir()
digest = lambda data: hashlib.sha256(data).hexdigest()
sha = digest(program.read_bytes())
opt = runpy.run_path(str(source/'examples/optical-disk-check/check.py'))
reader = opt['SCREEN']
glyphs = reader['kernel_glyphs']()
decode = runpy.run_path(str(source/'examples/tester-cd/check_compact_pins.py'))['read']
measure = runpy.run_path(str(source/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](kernel.read_bytes())
def filename(n, suffix):
    return ('matching-prefix-'*8)[:n-5] + suffix + '.elf'
names = [filename(63,'A'), filename(32,'B'), filename(33,'C'), filename(64,'D')]
for name in names:
    shutil.copyfile(program, out/name)
serial = out/'serial.log'
command = [str(qemu),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','256M','-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel',str(kernel),'-append','desktop='+args.geometry+' image='+measure,'-initrd',','.join(names)]
record = dict(source=args.revision,kernel_sha256=digest(kernel.read_bytes()),measurement=measure,program_sha256=sha,program_bytes=program.stat().st_size,names=names,command=command,keys=[],frames={},launches={})
with (out/'stderr.txt').open('wb') as err, subprocess.Popen(command,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
    try:
        monitor=opt['Monitor'](guest)
        monitor.call('qmp_capabilities')
        def key(*codes):
            monitor.key(*codes)
            record['keys'].append(codes)
            time.sleep(.31)
        def capture(label):
            path=out/(label+'.ppm')
            prev=None
            for _ in range(35):
                monitor.call('screendump',filename=str(path))
                frame=path.read_bytes()
                if prev==frame: break
                prev=frame
                time.sleep(.14)
            else: raise RuntimeError('unstable '+label)
            rows=decode(frame,glyphs)
            (out/(label+'.txt')).write_text('\n'.join(rows)+'\n')
            record['frames'][label]=digest(frame)
            return rows
        def log():
            return serial.read_text(errors='replace') if serial.exists() else ''
        opt['wait_for'](lambda: 'desktop: '+args.geometry in log() and measure+' (measured; equal' in log(), 'measured desktop',45)
        time.sleep(.5)
        capture('initial')
        key('spc')
        for i in range(len(names)):
            if i:key('down')
            key('ctrl','p')
        key('esc')
        key('down')
        def check_place(index):
            name=names[index]
            label=f'pin-{index+1}-{len(name)}B'
            rows=capture(label+'-before')
            recorded_facts=f'{(program.stat().st_size+1023)//1024} KiB   SHA-256 {sha[:16]}...'
            last_list=max(i for i,row in enumerate(rows) if row.strip().startswith(('PINNED ','Programs')))
            end=next(i for i,row in enumerate(rows) if 'KiB' in row and 'SHA-256' in row)
            pieces=[row.strip() for row in rows[last_list+1:end] if row.strip() and row.strip()!='Enter starts']
            actual_name=''.join(pieces)
            identity=actual_name==name
            cut=len(log())
            key('ret')
            def started():
                recent=log()[cut:]
                return 'could not be started:' in recent or 'PARROTS READY' in recent
            opt['wait_for'](started,'outcome for '+name,20)
            recent=log()[cut:]
            if 'PARROTS READY' in recent:
                outcome='ran'
                capture(label+'-running')
                key('esc')
                opt['wait_for'](lambda: name+' ended DONE: exit 0' in log()[cut:], 'program exit',20)
            else:
                outcome='refused'
            after=capture(label+'-after')
            identified=f'starting {name} ({program.stat().st_size} bytes, SHA-256 {sha})' in log()[cut:]
            record['launches'][label]=dict(name=name,card_matches=identity,name_rows=len(pieces),visible_name=actual_name,visible_facts=rows[end].strip(),visible_status=rows[4].strip(),expected_facts=recorded_facts,full_facts=rows[end].strip()==recorded_facts,footer=rows[-2].strip(),pin_count=sum('PINNED ' in r for r in rows),outcome=outcome,selected_bytes_confirmed=identified,home_unchanged=(record['frames'][label+'-before']==record['frames'][label+'-after']),result_log=[l for l in log()[cut:].splitlines() if name in l or 'PARROTS READY' in l])
        for i in range(len(names)):
            if i:key('down')
            check_place(i)
        key('f10');capture('power');key('ret')
        while not any(x.get('event')=='SHUTDOWN' for x in monitor.events):monitor.events.append(monitor.read())
        record['shutdown']=next(x['data'] for x in monitor.events if x.get('event')=='SHUTDOWN')
        record['qemu_exit']=guest.wait(timeout=8)
        record['serial_verdict']=log().splitlines()[-1]
        record['pass_lines']=sum(l.startswith('  pass ') for l in log().splitlines())
    finally:
        if guest.poll() is None:guest.kill();guest.wait()
        (out/'observations.json').write_text(json.dumps(record,indent=2)+'\n')
print({k:(v['card_matches'],v['outcome'],v['home_unchanged']) for k,v in record['launches'].items()},record.get('serial_verdict'))

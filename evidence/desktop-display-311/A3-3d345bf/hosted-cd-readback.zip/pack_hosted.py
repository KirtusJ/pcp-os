from hashlib import sha256
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json
import runpy

sha = lambda data: sha256(data).hexdigest()
root = Path('.')
source = '3d345bf68df5b64cf8345dfa6754c7d98046b01d'
with ZipFile('ci-plain.zip') as evidence, ZipFile('ci-disc.zip') as disc:
    assert sha(Path('ci-plain.zip').read_bytes()) == '55ea6f26b67daf66ef305fb0b4efd5b6580ebdb68d96a23292afc6f7c68bdb06'
    assert sha(Path('ci-disc.zip').read_bytes()) == '73f9e78872490a55ea3d2fae7fcbae10b5c5d2572a117a7a2877cda286da1715'
    receipt = json.loads(evidence.read('first/receipt.json'))
    image = disc.read('pcp-os-tester.iso')
    assert receipt['source_commit'] == source and receipt['iso_sha256'] == sha(image)
    build = runpy.run_path('src/examples/tester-cd/build.py')
    kernel = build['read_back'](image)['kernel.elf32']
    assert kernel == evidence.read('evidence/compact-pins/boot/kernel.elf32') == Path('ci-kernel.elf32').read_bytes()
    summary = json.loads(evidence.read('evidence/compact-pins/summary.json'))
    assert summary['passed'] and not summary['problems'] and summary['programs'] == 14
    folder = 'https://github.com/KirtusJ/pcp-os/actions/runs/44903207380'
    verdict = dict(source=source,workflow=folder,evidence_artifact=folder+'/artifacts/14706654131',disc_artifact=folder+'/artifacts/14706634172',
                   iso_sha256=sha(image),kernel_sha256=sha(kernel),measurement=receipt['kernel_measurement'],hosted_result=summary,independent_guests={})
    with ZipFile('hosted-cd-readback.zip','w',ZIP_DEFLATED,compresslevel=7) as z:
        for name in evidence.namelist():
            if name=='first/receipt.json' or ('compact-pins/' in name and name.endswith(('.txt','.json'))):
                z.writestr('hosted/'+name,evidence.read(name))
        for mode in ('320x200','640x480'):
            out=Path('ci-'+mode)
            data=json.loads((out/'observations.json').read_bytes())
            assert data['measurement']==receipt['kernel_measurement']==summary['kernel_measurement']
            assert data['kernel_sha256']==sha(kernel) and data['qemu_exit']==0
            verdict['independent_guests'][mode]={}
            for launch in data['launches'].values():
                verdict['independent_guests'][mode][len(launch['name'].encode())]={k:launch[k] for k in ('outcome','visible_name','visible_facts','home_unchanged')}
            for f in out.iterdir():
                if f.suffix in ('.log','.txt','.json','.ppm'): z.write(f)
        z.write('launch_boundary.py')
        z.write('pack_hosted.py')
        Path('hosted-cd-readback.json').write_text(json.dumps(verdict, indent=2)+'\n')
        z.write('hosted-cd-readback.json')
with ZipFile('hosted-cd-readback.zip') as archive: assert archive.testzip() is None
print(sha(Path('hosted-cd-readback.zip').read_bytes()),Path('hosted-cd-readback.zip').stat().st_size)
for mode,launches in verdict['independent_guests'].items():
    print(mode, {n:x['outcome'] for n,x in launches.items()})

from pathlib import Path
from hashlib import sha256
import json,runpy
root=Path(__file__).resolve().parent
read=runpy.run_path(str(root/'src/examples/tester-cd/check_compact_pins.py'))['read']
glyphs=runpy.run_path(str(root/'src/examples/tester-cd/check.py'))['kernel_glyphs']()
h=lambda x:sha256(x).hexdigest()
kernel=h((root/'kernel.elf32').read_bytes())
expected_measure=(root/'measurement').read_text().strip()
rev='3d345bf68df5b64cf8345dfa6754c7d98046b01d'
summary={'commit':rev,'tree':(root/'tree').read_text().strip(),'kernel_build':'Local unmodified sources from git archive of this commit','kernel_sha256':kernel,'kernel_measurement':expected_measure,'compact':{},'widgets':{},'graphical':{}}
for arm in ['compact','tiny']:
 d=root/arm;r=json.loads((d/'observations.json').read_text());log=(d/'serial.log').read_text()
 assert r['source']==rev and r['kernel_sha256']==kernel and r['measurement']==expected_measure and expected_measure+' (measured; equal' in log
 assert 'ALL SELF-TESTS PASS.' in log and r['qemu_exit']==0 and r['shutdown']['guest'] and r['pass_lines']==72
 for key,want in r['frames'].items(): assert h((d/(key+'.ppm')).read_bytes())==want
 for label,v in r['launches'].items():
  before=(d/(label+'-before.ppm')).read_bytes()
  after=(d/(label+'-after.ppm')).read_bytes()
  assert before==after
  rows=read(before,glyphs)
  filename=v['name']; count=len(filename.encode())
  assert any(v['visible_facts']==row.strip() for row in rows)
  if arm=='compact':
   a=next(i for i,row in enumerate(rows) if row.strip()=='Enter starts')+1
   b=next(i for i,row in enumerate(rows) if row.strip()==v['expected_facts'])
   assert ''.join(row.strip() for row in rows[a:b])==filename and v['full_facts']
  else:
   assert rows[6].strip()=='matching-prefix-matching-p..' and rows[7].strip()=='53 KiB   SHA-256 46f4bbd5e..'
  assert f"starting {filename} ({r['program_bytes']} bytes, SHA-256 {r['program_sha256']})" in log
  if count==32: assert filename+' ended DONE: exit 0' in log and 'PARROTS READY' in log
  else: assert filename+' could not be started: the program could not be admitted as a task' in log
  summary['compact'].setdefault(arm,{})[count]={'name':filename,'visible_name':v['visible_name'],'visible_facts':v['visible_facts'],'outcome':v['outcome'],'home_before_and_after_sha256':h(before)}
d=root/'widget-run';r=json.loads((d/'result.json').read_text());assert r['kernel_sha256']==kernel and r['exit']==0 and r['passes']==72
frame=(d/'widgets-seven.ppm').read_bytes();assert h(frame)==r['frames']['widgets-seven']; rows=read(frame,glyphs)
sessions=[row.strip() for row in rows if 'DONE program-02.elf' in row];assert len(sessions)==3
assert any('memory ' in row for row in rows) and any('Session files | cleared at power-off' in row for row in rows)
assert sum(line.startswith('program-02.elf ended DONE: exit 0') for line in (d/'serial.txt').read_text().splitlines())==3
summary['widgets']={'status':rows[4].strip(),'recent_sessions':sessions,'memory':next(row.strip() for row in rows if 'memory ' in row),'files':next(row.strip() for row in rows if 'Session files' in row),'frame_sha256':h(frame)}
d=root/'graphics/observed-pins';r=json.loads((d/'result.json').read_text());assert r['source']==rev and r['kernel_sha256']==kernel and r['exit_code']==0 and r['final_passes']==72
serial=(d/'serial.txt').read_text()
for index,(name,marker) in enumerate(zip(['sharedprefixA.elf','sharedprefixB.elf','shoredprefixC.elf'],['alpha','bravo','charlie'])):
 assert serial.count('entered '+marker)==2 and serial.count(name+' ended DONE: exit 0')==2
 for form in ['bar','dock']:
  k=f'{form}-selected-{index}'; dfile=d/(k+'.ppm')
  assert h(dfile.read_bytes())==r['files'][dfile.name]
  summary['graphical'][k]={'name':name,'program_sha256':r['programs'][name],'frame_sha256':r['files'][dfile.name]}
(root/'focused-readback.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Verified four guest runs, eight compact Enter outcomes, six graphical launches and three widget history entries.')

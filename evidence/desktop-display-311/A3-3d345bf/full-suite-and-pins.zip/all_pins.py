"""Select, launch and return from all fourteen pinned programs in one diskless guest."""
import argparse
from pathlib import Path
import hashlib
import json
import re
import runpy
import shutil
import subprocess
import time

p=argparse.ArgumentParser(description=__doc__)
for x in ('source','kernel','apps','out','qemu'):p.add_argument(x,type=Path)
p.add_argument('mode',choices=['320x200','640x480'])
a=p.parse_args()
root,kernel,apps,out,qemu=(getattr(a,x).resolve() for x in ('source','kernel','apps','out','qemu'))
out.mkdir()
s=runpy.run_path(str(root/'examples/tester-cd/check_compact_pins.py'))
Mon=runpy.run_path(str(root/'examples/optical-disk-check/check.py'))['Monitor']
glyph=s['CHECK']['kernel_glyphs']()
measure=runpy.run_path(str(root/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](kernel.read_bytes())
serial=out/'serial.log'
sha=lambda b:hashlib.sha256(b).hexdigest()
programs=[]
for i in range(14):
    name=f'program-{i+1:02}.elf'
    orig,marker=[('sharedprefixA.elf','alpha'),('sharedprefixB.elf','bravo'),('shoredprefixC.elf','charlie')][i%3]
    data=(apps/orig).read_bytes()
    (out/name).write_bytes(data)
    programs.append((name,marker,sha(data),len(data)))
args=[str(qemu),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','128M','-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel',str(kernel),'-append','desktop='+a.mode+' image='+measure,'-initrd',','.join(x[0] for x in programs)]
report=dict(commit='3d345bf68df5b64cf8345dfa6754c7d98046b01d',measurement=measure,kernel_sha256=sha(kernel.read_bytes()),command=args,selection=[],keys=[])
with (out/'stderr.txt').open('wb') as err,subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,cwd=out) as g:
    try:
        m=Mon(g);m.call('qmp_capabilities')
        def log():return serial.read_text(errors='replace') if serial.exists() else ''
        def wait(test):
            end=time.monotonic()+16
            while not test():
                if time.monotonic()>=end:raise TimeoutError(log()[-550:])
                time.sleep(.04)
        def key(*codes):
            m.key(*codes);report['keys'].append(codes);time.sleep(.23)
        def snap(label):
            path=out/(label+'.ppm');m.call('screendump',filename=str(path));b=path.read_bytes()
            rows=s['read'](b,glyph)
            (out/(label+'.txt')).write_text('\n'.join(rows)+'\n')
            return rows,sha(b)
        wait(lambda:'desktop: '+a.mode in log() and measure+' (measured; equal' in log())
        time.sleep(.6);key('spc')
        for i in range(14):
            if i:key('down')
            key('ctrl','p')
        key('esc')
        for i,(name,marker,digest,nbytes) in enumerate(programs,1):
            key('down')
            label=f'pin-{i:02}'
            rows,before=snap(label)
            facts=f'{(nbytes+1023)//1024} KiB   SHA-256 {digest[:16]}...'
            problems=s['home_problems'](rows,i,15,facts,a.mode=='640x480')
            # The repo's supplied oracle requires the complete footer and chosen short name.
            if problems:raise AssertionError((i,problems,rows))
            cut=len(log());key('ret')
            wait(lambda:'entered '+marker in log()[cut:])
            key('esc')
            wait(lambda:name+' ended DONE: exit 0' in log()[cut:])
            recent=log()[cut:]
            assert f'starting {name} ({nbytes} bytes, SHA-256 {digest})' in recent
            assert sum(l.startswith('entered ') for l in recent.splitlines())==1
            time.sleep(.15)
            returned,after=snap(label+'-return')
            assert before==after and rows==returned
            report['selection'].append(dict(place=i+1,name=name,marked_program=marker,sha256=digest,range=rows[4].strip(),returned_frame_sha256=after))
        key('f10');key('ret')
        while not any(e.get('event')=='SHUTDOWN' for e in m.events):m.events.append(m.read())
        report['shutdown']=next(e['data'] for e in m.events if e.get('event')=='SHUTDOWN')
        report['exit']=g.wait(timeout=8)
        report['pass_lines']=sum(l.startswith('  pass ') for l in log().splitlines())
        assert report['pass_lines']==72 and report['exit']==0 and report['shutdown']=={'guest':True,'reason':'guest-shutdown'} and 'ALL SELF-TESTS PASS.' in log()
    finally:
        if g.poll() is None:g.kill();g.wait()
        (out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
print(len(report['selection']), 'pin launches and returns', a.mode)

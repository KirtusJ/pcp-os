from hashlib import sha256,file_digest
from pathlib import Path
import json,tarfile,lzma,io,zipfile
here=Path(__file__).resolve().parent
def digest(p):
    with p.open('rb') as f:return file_digest(f,'sha256').hexdigest()
suite=here/'full'
raw=json.loads((suite/'results.json').read_bytes())
failed=[]
checks_total=passing_checks=passing_groups=0
for g in raw['results']:
    verdicts=[c['ok'] for c in g['checks']]
    assert all(type(v) is bool for v in verdicts) and g['ok']==all(verdicts)
    passing_groups+=g['ok'];checks_total+=len(verdicts);passing_checks+=sum(verdicts)
    for c in g['checks']:
        if not c['ok']:failed.append({'group':g['test'],'assertion':c['check'],'detail':c['detail']})
assert passing_groups==raw['passed'] and raw['tests']==len(raw['results']) and checks_total==raw['checks']
assert any('240 seconds' in g['test'] for g in raw['results'])
assert digest(here/'kernel.elf32')==raw['kernel_sha256']
assert digest(here/'programs/doom.elf')==raw['doom_sha256']
assert all(digest(here/'data'/f)==h for f,h in raw['game_data'].items())
exit_status=int((here/'suite.exit').read_text())
assert exit_status==(1 if failed else 0)
repo='https://github.com/KirtusJ/pcp-os'
head='3d345bf68df5b64cf8345dfa6754c7d98046b01d'
sums={'source':head,'tree':(here/'tree').read_text().strip(),'kernel_sha256':raw['kernel_sha256'],'kernel_measurement':(here/'measurement').read_text().strip(),
      'kernel_origin':'Unmodified git archive of this commit, locally built with the tracked run.sh build command. Compiler and build log included.',
      'qemu':raw['emulator'],'command':'PCPOS_ADAPTER_CHECKOUT="$PWD/src" python3 -u run_stdio.py "$PWD/kernel.elf32" "$PWD/programs" "$PWD/data" "$PWD/full"',
      'suite_selection':'All tests. No quick argument; PCPOS_TESTS_ONLY unset. QMP stdio transport diff included.',
      'start':(here/'start').read_text().strip(),'end':(here/'stop').read_text().strip(),'exit':exit_status,
      'groups_passed':passing_groups,'groups_total':raw['tests'],'assertions_passed':passing_checks,'assertions_total':checks_total,
      'failed_assertions':failed,'native_results_sha256':digest(suite/'results.json'),
      'separate_launcher_attempt':'Before the counted run, a QEMU installation exited while looking for efi-e1000.rom. Its guest serials were empty. The failed launcher log is retained.'}
assert 'exception 14' in (suite/'playdemo/serial.log').read_text()
for mode in ['320x200','640x480']:
    f=here/('all-'+mode)/'result.json'
    if f.is_file():
        j=json.loads(f.read_text());sums.setdefault('pin_runs',{})[mode]={'selected_and_returned':len(j['selection']),'exit':j.get('exit'),'startup_and_shutdown_checks':j.get('pass_lines')}
(here/'native-readback.json').write_text(json.dumps(sums,indent=2)+'\n')
files=[here/f for f in ['full.log','native-readback.json','inputs.sha256','measurement','tree','start','stop','suite.exit','pack_native.py','qmp-transport.diff','run_stdio.py','compiler.txt','build.log','src/PCP_OS_Rust/crates/pcpos-kernel/tests/run_tests.py','first-launch/full.log','first-launch/full/alone_max/qemu.stderr']]
files.extend(p for p in suite.rglob('*') if p.is_file() and (p.name in ('serial.log','qemu.stderr','results.json') or p.suffix=='.png'))
files.append(here/'all_pins.py')
for mode in ['320x200','640x480']:
    d=here/('all-'+mode)
    files.extend(p for p in d.iterdir() if p.suffix in ('.txt','.log','.json'))
    for label in ('pin-01.ppm','pin-14.ppm'):
        if (d/label).exists():files.append(d/label)
wavs={str(p.relative_to(here)):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in suite.glob('*/sound.wav')}
archive=here/'full-suite-and-pins.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for f in files:z.write(f,f.relative_to(here).as_posix())
    z.writestr('audio-capture-hashes.json',json.dumps(wavs,indent=2)+'\n')
    z.writestr('SHA256SUMS',''.join(digest(f)+'  '+f.relative_to(here).as_posix()+'\n' for f in files))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(passing_groups,len(raw['results']),passing_checks,checks_total,exit_status,len(failed),digest(archive))

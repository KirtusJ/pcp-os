"""Read a compact Home at 2x from its actual font atlas."""
import argparse
import hashlib
import json
import runpy
import shutil
import subprocess
import time
from pathlib import Path

import numpy as np

parser = argparse.ArgumentParser()
for arg in ("source", "kernel", "first_app", "last_app", "output"):
    parser.add_argument(arg, type=Path)
parser.add_argument("--qemu", default="qemu-system-x86_64")
args = parser.parse_args()
src = args.source.resolve()
out = args.output.resolve()
out.mkdir()
kernel = args.kernel.resolve()
base = src / "PCP_OS_Rust/crates/pcpos-kernel"
opt = runpy.run_path(str(src / "examples/optical-disk-check/check.py"))
sha = lambda data: hashlib.sha256(data).hexdigest()
measurement = runpy.run_path(str(base / "tools/measure.py"))["measure"](kernel.read_bytes())
font = np.frombuffer((base / "src/font-2x.bin").read_bytes(), dtype="u1").reshape(95, 40, 20).astype(np.int32)
assert not font[:, 0, 0].any()
lookup = {}
# Use precisely the coverage that survives each foreground/background blend.
for fg in [0xf2f7fc, 0x9fb4c8, 0x41bad7, 0x8fe0c2, 0xf08a72, 0xe3a24b]:
    for bg in [0x10283f, 0x18364f]:
        rgb = lambda color: np.array([color >> 16, (color >> 8) & 255, color & 255])
        f, b = rgb(fg), rgb(bg)
        visible = np.any(((255 - font[...,None]) * b + font[...,None] * f) // 255 != b, axis=-1)
        for i, mask in enumerate(visible):
            lookup[np.packbits(mask).tobytes()] = chr(i + 32)

names = [f"program-{i:02}.elf" for i in range(1, 14)]
for name in names:
    shutil.copyfile(args.last_app if name == names[10] else args.first_app, out / name)
first_digest = sha(args.first_app.read_bytes())[:16]
last_digest = sha(args.last_app.read_bytes())[:16]
assert first_digest != last_digest
serial = out / "serial.txt"
cmd = [args.qemu, "-machine", "pc", "-accel", "tcg", "-cpu", "qemu64", "-m", "256M", "-vga", "std",
       "-nic", "none", "-display", "none", "-monitor", "none", "-qmp", "stdio", "-serial", f"file:{serial}",
       "-kernel", str(kernel), "-append", f"desktop=1280x960 ui_scale=2 image={measurement}", "-initrd", ",".join(names)]
meta = dict(source_revision=subprocess.check_output(["git","-C",str(src),"rev-parse","HEAD"],text=True).strip(),
            kernel_sha256=sha(kernel.read_bytes()), measurement=measurement,
            first_digest=first_digest, last_digest=last_digest, frames={}, inputs=[])
with (out/"stderr.txt").open("wb") as err:
    vm = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, cwd=out, stderr=err)
    try:
        monitor = opt["Monitor"](vm)
        monitor.call("qmp_capabilities")
        def key(*keys):
            monitor.key(*keys)
            meta["inputs"].append(list(keys))
            time.sleep(.35)
        def capture(label):
            p = out / (label+".ppm")
            monitor.call("screendump", filename=str(p))
            data=p.read_bytes()
            assert data.startswith(b"P6\n1280 960\n255\n")
            _,_,_,raw=data.split(b"\n",3)
            cells=np.frombuffer(raw,dtype="u1").reshape(24,40,64,20,3).transpose(0,2,1,3,4)
            mask=np.any(cells!=cells[:,:,:1,:1,:],axis=-1)
            rows=["".join(lookup.get(np.packbits(cell).tobytes(),"?") for cell in row).rstrip() for row in mask]
            (out/(label+".txt")).write_text("\n".join(rows))
            meta["frames"][label]=dict(sha256=sha(data), first_digest=any(first_digest in r for r in rows),
                    last_digest=any(last_digest in r for r in rows), footer=rows[-2])
            return rows
        opt["wait_for"](lambda: serial.exists() and "desktop: 1280x960 at 2x UI scale" in serial.read_text(),"2x compact Home",45)
        time.sleep(.7)
        assert "PCP OS | DESKTOP" in capture("home")[1]
        key("spc")
        for index,name in enumerate(names):
            if index:
                key("down")
            key("ctrl","p")
            if index in (11,12):
                refusal = capture(f"refused-{index+1}")
                assert " ".join(" ".join(refusal[-4:-2]).split()) == "Not pinned: the desktop has room for 11 pinned program(s) on this display. Take one out first.", refusal[-4:-2]
            if index == 0:
                key("esc"); key("down")
                assert any(first_digest in r for r in capture("one"))
                key("spc")
        key("esc")
        first_rows = capture("capacity-first")
        assert sum("PINNED program-" in v for v in first_rows)==11
        assert first_rows[19].strip() == names[0] and first_digest in first_rows[20], first_rows
        for _ in range(12):
            key("down")
        last_rows = capture("capacity-last")
        assert last_rows[19].strip() == names[10] and last_digest in last_rows[20] and "53 KiB" in last_rows[20], last_rows
        assert last_rows[-2].strip() == "Up/Down choose   Enter open   F1 keys   F10 off"
        key("f10"); question=capture("question")
        assert any("Switch PCP OS off?" in r for r in question)
        key("esc"); capture("cancel")
        assert meta['frames']['cancel']['sha256']==meta['frames']['capacity-last']['sha256']
        key("backspace"); capture("after-unpin")
        key("f10"); time.sleep(.3); key("ret")
        while not any(e.get("event")=="SHUTDOWN" for e in monitor.events):
            monitor.events.append(monitor.read())
        meta["exit"]=vm.wait(timeout=15)
        meta["shutdown"]=next(e['data'] for e in monitor.events if e.get("event")=="SHUTDOWN")
        log=serial.read_text()
        meta["pass_count"]=sum(line.startswith("  pass ") for line in log.splitlines())
        assert meta["pass_count"]==72 and meta["exit"]==0 and measurement+" (measured; equal" in log and "ALL SELF-TESTS PASS." in log
    finally:
        if vm.poll() is None: vm.kill(); vm.wait()
        (out/"result.json").write_text(json.dumps(meta,indent=2)+"\n")
print(json.dumps(meta["frames"]))

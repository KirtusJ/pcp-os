"""Read the power prompt and exercise Escape and a fresh Enter in a diskless QEMU guest."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import runpy
import subprocess
import time
from zipfile import ZipFile

root = Path(__file__).resolve().parent
src = root / 'source'
compact = runpy.run_path(str(src / 'examples/tester-cd/check_compact_pins.py'))
opt = runpy.run_path(str(src / 'examples/optical-disk-check/check.py'))
glyphs = compact['CHECK']['kernel_glyphs']()
digest = lambda data: sha256(data).hexdigest()
commit = '19496d2d5813eecd8f6279eec48152a3e4e49593'
warnings = ['The register is closed and verified first. Files of this session that were',
            'not saved by a program are lost.', 'Enter switch off    Esc go back']
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('mode', choices=['prepare','320x200','640x480','800x600'])
parser.add_argument('--qemu', default='qemu-system-x86_64')
args = parser.parse_args()
mode = args.mode
if mode == 'prepare':
    with ZipFile(root/'cd.zip') as cd, ZipFile(root/'ci.zip') as ci:
        receipt = json.loads(ci.read('first/receipt.json'))
        assert receipt['source_commit'] == commit and not receipt['uncommitted_changes']
        image = cd.read('pcp-os-tester.iso')
        assert digest(image) == receipt['iso_sha256']
        contents = compact['BUILD']['read_back'](image)
        kernel = contents['kernel.elf32']
        assert kernel == ci.read('evidence/compact-pins/boot/kernel.elf32')
        for name in ('kernel.elf32', 'surf.elf'):
            (root/name).write_bytes(contents[name])
        assert runpy.run_path(str(src/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](kernel)==receipt['kernel_measurement']
        (root/'receipt.json').write_bytes(ci.read('first/receipt.json'))
        for mode in ('320x200','640x480'):
            frame=ci.read('evidence/compact-pins/'+mode+'/power-question.ppm')
            rows=compact['read'](frame,glyphs)
            assert rows == ci.read('evidence/compact-pins/'+mode+'/power-question.txt').decode().splitlines()
            (root/('hosted-'+mode+'.ppm')).write_bytes(frame)
    raise SystemExit(0)
folder=root/mode
folder.mkdir()
serial=folder/'serial.txt'
receipt=json.loads((root/'receipt.json').read_bytes())
cmd=[args.qemu,'-machine','pc','-accel','tcg','-cpu','qemu64','-m','256M','-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel','kernel.elf32','-append','desktop='+mode+' image='+receipt['kernel_measurement'],'-initrd','surf.elf']
with (folder/'stderr.txt').open('wb') as err, subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,cwd=root) as g:
    try:
        mon=opt['Monitor'](g)
        mon.call('qmp_capabilities')
        opt['wait_for'](lambda: serial.exists() and ('desktop: '+mode in serial.read_text(errors='replace')), 'requested desktop mode', 40)
        time.sleep(.45)
        def capture(label):
            p=folder/(label+'.ppm')
            mon.call('screendump', filename=str(p))
            frame=p.read_bytes()
            assert frame.split(b'\n',3)[1].decode().replace(' ','x')==mode
            rows=compact['read'](frame,glyphs)
            (folder/(label+'.txt')).write_text('\n'.join(rows)+'\n')
            return frame,rows
        home,_=capture('home')
        mon.key('f10'); time.sleep(.35)
        prompt,rows=capture('question')
        assert 'POWER OFF' in rows[1] and 'Switch PCP OS off?' in rows[3]
        mon.key('esc'); time.sleep(.35)
        restored,_=capture('cancel')
        assert home==restored
        mon.key('f10'); time.sleep(.35)
        second,_=capture('question-again')
        assert prompt==second
        mon.key('ret')
        g.wait(timeout=15)
        while not any(e['event']=='SHUTDOWN' for e in mon.events):
            mon.events.append(mon.read())
        shutdown=next(e['data'] for e in mon.events if e['event']=='SHUTDOWN')
        log=serial.read_text(errors='replace')
        count=sum(s.startswith('  pass ') for s in log.splitlines())
        assert g.returncode==0 and shutdown=={'guest':True,'reason':'guest-shutdown'} and count==72
        assert receipt['kernel_measurement']+' (measured; equal' in log
        lines=[rows[5].strip(),rows[6].strip(),rows[-2].strip()]
        result=dict(source=commit,command=cmd,mode=mode,visible=lines,complete=[a==b for a,b in zip(lines,warnings)],expected=warnings,kernel_sha256=digest((root/'kernel.elf32').read_bytes()),screen_sha256=digest(prompt),unchanged_on_cancel=home==restored,shutdown=shutdown,exit=g.returncode,checks=count)
        if mode!='800x600':
            result['identical_to_hosted_frame']=prompt==(root/('hosted-'+mode+'.ppm')).read_bytes()
        (folder/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        print(mode,lines,result['complete'])
    finally:
        if g.poll() is None:g.kill();g.wait()

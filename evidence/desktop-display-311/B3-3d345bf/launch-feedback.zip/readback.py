"""Decode the original pre/post Enter P6s for both kernels with the source's native font."""
import hashlib,json,re,runpy,sys
from pathlib import Path

base=Path(sys.argv[1]).resolve()
repo=Path(sys.argv[2]).resolve()
reader=runpy.run_path(str(repo/'examples/tester-cd/check_compact_pins.py'))
glyphs=reader['CHECK']['kernel_glyphs']()
summary={}
for phase,geometry in [('baseline','320x200'),('baseline','640x480'),('candidate','320x200'),('candidate','320x480'),('candidate','640x480')]:
    case=base/(phase+'-'+geometry);record=json.loads((case/'report.json').read_text());log=(case/'serial.txt').read_text()
    assert record['passes']==72 and record['exit']==0 and record['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    assert sum(s.startswith('  pass ') for s in log.splitlines())==72 and record['measurement']+' (measured; equal to the value the loader named)' in log
    assert log.count('PARROTS READY')==1
    rows={}
    for length in (33,32,63,64):
        name=record['cases'][str(length)]['name'];assert len(name)==length
        b=(case/f'before-{length}.ppm').read_bytes();a=(case/f'after-{length}.ppm').read_bytes()
        pre=reader['read'](b,glyphs);post=reader['read'](a,glyphs)
        assert (case/f'after-{length}.txt').read_text().splitlines()==post
        assert pre[1]==post[1] and 'PCP OS | DESKTOP' in post[1]
        assert pre[3]==post[3] and post[3].strip().startswith('Verified at start: all 71')
        assert post[-2]==pre[-2]=='  '+('Up/Down choose   Enter open   F1 keys   F10 off' if geometry.startswith('640') else 'Enter open  F1 keys  F10 off')
        if length==32:
            assert b==a and name+' ended DONE' in log
        else:
            assert name+' could not be started: the program could not be admitted as a task' in log
            if phase=='baseline': assert a==b and not any('Not started:' in r for r in post)
            else:
                diff=[i for i,(x,y) in enumerate(zip(pre,post)) if x!=y]
                assert len(diff)==1 and 'Not started: ' in post[diff[0]]
                width=int(a.split(b'\n',2)[1].split()[0])
                pixels_a=a.split(b'\n',3)[3];pixels_b=b.split(b'\n',3)[3]
                stride=width*3*20;k=diff[0]
                assert pixels_a[:k*stride]==pixels_b[:k*stride] and pixels_a[(k+1)*stride:]==pixels_b[(k+1)*stride:]
                if geometry=='320x200':assert k==2 and 'Not started: not admitted' in post[2]
                elif geometry=='320x480':assert post[k].strip()=='Not started: not admitted'
                else:assert post[k].strip()=='Not started: the program could not be admitted as a task'
        if phase=='candidate':
            idx=next(i for i,r in enumerate(post) if r.startswith('  53 KiB   SHA-256'))
            if geometry.startswith('640'): assert post[idx].strip()=='53 KiB   SHA-256 '+record['application'][:16]+'...'
            else: assert post[idx].strip()=='53 KiB   SHA-256 '+record['application'][:9]+'..'
            if geometry=='320x200':
                assert post[5].strip().startswith('PINNED '+name[:10]) and post[6].strip()=='..'+name[-26:] and idx==7
            else:
                # Name rows are contiguous between the caption and the facts.
                start=next(i for i,x in enumerate(post) if x.strip()=='Enter starts' or x.strip().startswith('Not started:'))+1
                assert ''.join(x.strip() for x in post[start:idx])==name
        rows[str(length)]={'result':record['cases'][str(length)]['outcome'],'home_identical':a==b,
                           'feedback':[r[7:] if geometry=='320x200' else r.strip() for r in post if 'Not started:' in r],
                           'footer':post[-2].strip()}
    summary[phase+'-'+geometry]={'measured':record['measurement'],'cases':rows,'self_tests':72,'guest_shutdown':True}
print(json.dumps(summary,indent=2))

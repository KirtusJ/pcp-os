# Compact Home feedback on the 3d345bf desktop

This is a local reference patch for the PCP OS source at `3d345bf68df5b64cf8345dfa6754c7d98046b01d`. It changes [session.rs](candidate-source/PCP_OS_Rust/crates/pcpos-kernel/src/session.rs) in that checkout. The kernel still refuses the same nonadmitted tasks. Compact Home uses its caption row for the selected program's last refusal. If that row has no room, the refusal appears beside the emblem on row 2.

Some long names exceed the available height. On compact Home only, the highlighted list still shows the beginning. The abbreviated identity row now shows the name's ending after two dots. This applies to refused and unrefused selected pins whose name overflows its allocated rows. Ordinary full names retain their rendering. A host-side check compiles the candidate’s exact truncation, wrapping, suffix and reason expressions with multi-byte names, including a combining mark. The name operations count and iterate Rust `char` values; the width check using byte lengths compares only a fixed ASCII error message. The kernel's existing UI renders unsupported characters as a question mark. Truncation does not promise that all possible names or digests appear distinct.

Two baseline QEMU/TCG boots and three patched boots used the same 54,256-byte Queue Desk ELF under four matching-prefix aliases. Enter was tested for 33, 32, 63 and 64 bytes in that order. The 32-byte alias opened Queue Desk, emitted PARROTS READY and returned DONE on Escape. Serial recorded admission refusals for the other three names. Baseline Home stayed byte-identical after each refusal at 640×480 and 320×200.

The patch gives the full native admission reason at 640×480 and the shorter “Not started: not admitted” at 320×480 and 320×200. Independent P6 readback shows that when refusal appeared, all pixel rows except the feedback row stayed byte-identical. At 320×200 the keys stayed on row 8, the selected program's distinct A/C/D suffix stayed on row 6, and row 7 kept its size and visibly abbreviated digest. These were Linux QEMU 10.0.13 boots with no disks or NIC. All five guests recorded 72 passing self-tests and requested shutdown with exit 0.

## Replay from a new checkout

Run the following commands from the extracted evidence directory on a system with Git, Python 3, QEMU x86-64/SeaBIOS and a Rust kernel toolchain. To rebuild, the source's [kernel build script](baseline-source/PCP_OS_Rust/crates/pcpos-kernel/run.sh) needs Rust sources, Cargo, ld.lld and GNU objcopy. The recorded builds used rustc 1.100.0. The supplied baseline and candidate ELF files allow replay without rebuilding. Directory names below are relative to the extracted archive; use fresh names when repeating a test.

```sh
git clone https://github.com/KirtusJ/pcp-os.git baseline-source
git -C baseline-source checkout --detach 3d345bf68df5b64cf8345dfa6754c7d98046b01d
git -C baseline-source worktree add --detach ../candidate-source 3d345bf68df5b64cf8345dfa6754c7d98046b01d
git -C candidate-source apply --check ../reference.patch
git -C candidate-source apply ../reference.patch
python3 -IB readback.py . baseline-source > reproduced-readback.json
cmp verification.json reproduced-readback.json
python3 -IB check_unicode.py candidate-source > reproduced-unicode.txt
cmp unicode-readback.txt reproduced-unicode.txt
```

Use the retained executables to repeat the VM sessions. Each command writes a new directory containing raw P6s, font-decoded rows, serial output, QEMU arguments, digests and result JSON.

```sh
for mode in 320x200 640x480; do
  python3 -IB measure_ui.py baseline "$mode" --source baseline-source --out "replay/baseline-$mode"
done
for mode in 320x200 320x480 640x480; do
  python3 -IB measure_ui.py candidate "$mode" --source candidate-source --out "replay/candidate-$mode"
done
python3 -IB readback.py replay baseline-source
```

To build both executables afresh, run the commands below. Then add `--kernel rebuilt-baseline.elf32` or `--kernel rebuilt-candidate.elf32` to the corresponding replay command. Each build uses a private staging directory. A different compiler installation or stage path can change the resulting binary hash; the driver measures the actual ELF and checks that same measurement in the guest.

```sh
sh build.sh baseline-source rebuilt-baseline.elf32
sh build.sh candidate-source rebuilt-candidate.elf32
```

The stored build and replay are a reference for review. No repository branch or pull request was updated.

"""Compile the candidate's actual compact text expressions for host-side Unicode checks."""
import argparse
from pathlib import Path
import re
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('source', type=Path)
parser.add_argument('--rustc', default='rustc')
args = parser.parse_args()
session = (args.source / 'PCP_OS_Rust/crates/pcpos-kernel/src/session.rs').read_text()
def extract(pattern):
    match = re.search(pattern, session, re.M | re.S)
    if match is None:
        raise ValueError(f'Expected code missing: {pattern}')
    return match.group(0)
cut = extract(r'^fn cut\(.*?^\}')
wrapped = extract(r'^fn wrapped\(.*?^\}')
skip = extract(r'let skip = p\.name\.chars\(\).*?;')
suffix = extract(r'format!\("\.\.\{\}", p\.name\.chars\(\)\.skip\(skip\)\.collect::<String>\(\)\)')
why = extract(r'let why = if reason == "the program.*?else \{ reason \};')
rust = r'''
struct Entry { name: String }
fn suffix(p: &Entry, across: usize) -> String { SKIP; SUFFIX }
fn message(reason: &str, room: usize) -> String { WHY cut(&format!("Not started: {}", why), room) }
fn main() {
    let name = format!("{}{}{}", "前缀🦜é⚓".repeat(7), "e\u{301}", "臨界🦜Z.elf");
    let p = Entry { name };
    assert!(p.name.len() > p.name.chars().count());
    for room in [25, 28, 32] {
        let rendered = suffix(&p, room);
        assert!(rendered.starts_with("..") && rendered.ends_with("臨界🦜Z.elf"));
        assert_eq!(rendered.chars().count(), room);
        let expected: Vec<char> = p.name.chars().rev().take(room - 2).collect();
        assert_eq!(rendered.chars().rev().take(room - 2).collect::<Vec<_>>(), expected);
        let lines = wrapped(&p.name, room);
        assert_eq!(lines.concat(), p.name);
        assert!(lines.iter().all(|line| line.chars().count() <= room));
        let clipped = cut(&p.name, room);
        assert_eq!(clipped, format!("{}..", p.name.chars().take(room - 2).collect::<String>()));
        assert_eq!(message("the program could not be admitted as a task", room), "Not started: not admitted");
        assert_eq!(message("多言語🦜", room), "Not started: 多言語🦜");
    }
    assert_eq!(message("the program could not be admitted as a task", 70),
               "Not started: the program could not be admitted as a task");
    println!("PASS: compact name suffix, wrapping, truncation and refusal reason at 25, 28, 32 cells; full admission reason at 70");
}
'''.replace('SKIP;', skip).replace('SUFFIX', suffix).replace('WHY', why)
with tempfile.TemporaryDirectory() as temp:
    directory = Path(temp)
    source = directory / 'unicode.rs'
    executable = directory / 'unicode'
    source.write_text(cut + '\n' + wrapped + '\n' + rust)
    subprocess.run([args.rustc, str(source), '-o', str(executable)], check=True)
    subprocess.run([str(executable)], check=True)

#!/bin/sh
# Build the supplied source tree and copy its freestanding ELF32 to a new file.
set -eu
if [ "$#" != 2 ]; then
    echo "usage: sh build.sh SOURCE_CHECKOUT NEW_OUTPUT.elf32" >&2
    exit 2
fi
source_dir=$(cd "$1" && pwd)
output=$2
if [ -e "$output" ]; then
    echo "output already exists: $output" >&2
    exit 1
fi
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT
kernel="$source_dir/PCP_OS_Rust/crates/pcpos-kernel"
PCPOS_KERNEL_STAGE="$stage" PCPOS_KERNEL_FEATURES= sh "$kernel/run.sh" build
cp "$kernel/target/pcpos-kernel.elf32" "$output"

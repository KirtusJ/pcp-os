"""Drive the same four Queue Desk aliases from compact Home, with original P6s."""
import argparse,hashlib,json,runpy,shutil,subprocess,sys,time
from pathlib import Path

base=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('phase',choices=('baseline','candidate'))
parser.add_argument('geometry',choices=('320x200','320x480','640x480'))
parser.add_argument('--source',type=Path,required=True,help='PCP OS source checkout for the kernel-font readers')
parser.add_argument('--kernel',type=Path,help='defaults to the retained ELF for this phase')
parser.add_argument('--program',type=Path,default=base/'rdesk.elf')
parser.add_argument('--qemu',default=shutil.which('qemu-system-x86_64') or 'qemu-system-x86_64')
parser.add_argument('--out',type=Path,required=True,help='new case directory')
args=parser.parse_args()
source=args.source.resolve()
phase,geometry=args.phase,args.geometry
out=args.out.resolve();out.mkdir(parents=True,exist_ok=False)
kernel=(args.kernel or base/(phase+'.elf32')).resolve()
prog=args.program.resolve()
emulator=shutil.which(args.qemu)
if not emulator:parser.error('cannot locate '+args.qemu)
emulator=str(Path(emulator).resolve())
def name(n,mark):return ('matching-prefix-'*5)[:n-5]+mark+'.elf'
names=[name(33,'A'),name(32,'B'),name(63,'C'),name(64,'D')]
for n in names: shutil.copyfile(prog,out/n)
sha=lambda b:hashlib.sha256(b).hexdigest()
measure=runpy.run_path(str(source/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](kernel.read_bytes())
optic=runpy.run_path(str(source/'examples/optical-disk-check/check.py'))
read=runpy.run_path(str(source/'examples/tester-cd/check_compact_pins.py'))['read']
font=optic['SCREEN']['kernel_glyphs']()
serial=out/'serial.txt';log=lambda: serial.read_text(errors='replace') if serial.exists() else ''
args=[emulator,'-machine','pc','-accel','tcg','-m','256M','-cpu','qemu64','-nic','none',
 '-vga','std','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel',str(kernel),
 '-append','desktop='+geometry+' image='+measure,'-initrd',','.join(names)]
record={'revision':'3d345bf68df5b64cf8345dfa6754c7d98046b01d','phase':phase,'geometry':geometry,'argv':args,
 'measurement':measure,'elf':sha(kernel.read_bytes()),'application':sha(prog.read_bytes()),'cases':{}}
with (out/'stderr.txt').open('wb') as err:
 vm=subprocess.Popen(args,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
 try:
  q=optic['Monitor'](vm);q.call('qmp_capabilities')
  def key(*codes):q.key(*codes);time.sleep(.24)
  def snap(label):
   path=out/(label+'.ppm'); prior=None
   for i in range(20):
    q.call('screendump',filename=str(path));f=path.read_bytes()
    if prior==f:break
    prior=f;time.sleep(.11)
   else:raise RuntimeError('unstable '+label)
   lines=read(f,font);(out/(label+'.txt')).write_text('\n'.join(lines)+'\n');return lines
  optic['wait_for'](lambda:'desktop: '+geometry in log() and measure+' (measured; equal' in log(),'desktop',45)
  time.sleep(.3);key('spc')
  for i,n in enumerate(names):
   if i:key('down')
   key('ctrl','p')
  key('esc')
  for i,n in enumerate(names):
   key('down');before=snap('before-'+str(len(n)));offset=len(log());key('ret')
   optic['wait_for'](lambda:'could not be started:' in log()[offset:] or 'PARROTS READY' in log()[offset:],'entry',20)
   outcome='ran' if 'PARROTS READY' in log()[offset:] else 'refused'
   if outcome=='ran':
    key('esc');optic['wait_for'](lambda:'ended DONE' in log()[offset:],'task end',20)
   after=snap('after-'+str(len(n)))
   rec={'name':n,'outcome':outcome,'byte_identical':(out/('before-'+str(len(n))+'.ppm')).read_bytes()==(out/('after-'+str(len(n))+'.ppm')).read_bytes(),
        'feedback':[row.strip() for row in after if 'Not started' in row or 'not admitted' in row or 'admission refused' in row],
        'before':before,'after':after}
   record['cases'][len(n)]=rec
   assert (outcome=='ran')==(len(n)==32)
  key('f10');snap('power');key('ret')
  status=vm.wait(timeout=30)
  while not any(e['event']=='SHUTDOWN' for e in q.events):q.events.append(q.read())
  record['exit']=status;record['shutdown']=next(e['data'] for e in q.events if e['event']=='SHUTDOWN')
  record['passes']=sum(s.startswith('  pass ') for s in log().splitlines())
  assert status==0 and record['passes']==72
 finally:
  if vm.poll() is None:vm.kill();vm.wait()
  (out/'report.json').write_text(json.dumps(record,indent=2)+'\n')
print(phase,geometry,[(k,v['outcome'],v['feedback'],v['byte_identical']) for k,v in record['cases'].items()],flush=True)

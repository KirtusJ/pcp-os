"""Verify the original withdrawn kernel's one-pin and 13-pin screen pair."""
import hashlib
import json
from pathlib import Path
import runpy
import sys

source, old, payload, filename=map(Path,sys.argv[1:])
rep=runpy.run_path(str(Path(__file__).with_name("check_identities.py")))
native=runpy.run_path(str(source/"examples/tester-cd/check_compact_pins.py"))
glyphs=native["CHECK"]["kernel_glyphs"]()
data=payload.read_bytes()
expected=json.loads((old/"result.json").read_bytes())
digest=hashlib.sha256(data).hexdigest()
assert digest==expected["program_sha256"]
programs=[(f"program-{i:02}.elf",len(data),digest) for i in range(1,14)]
result={}
for file,count in [("one-selected.ppm",1),("full-selected.ppm",13)]:
    frame=(old/file).read_bytes();rows=native["read"](frame,glyphs)
    assert hashlib.sha256(frame).hexdigest()==expected["frames"][Path(file).stem]
    try:
        rep["check_frame"](frame,rows,programs,0,count,"640x480"); why=None
    except AssertionError as error:
        why=str(error)
    assert (why is None) if count==1 else (why.startswith("('identity',") and "118 KiB" in why),why
    result[file]=dict(frame_sha256=hashlib.sha256(frame).hexdigest(),passed=why is None,reason=why,decoded=rows)
filename.write_text(json.dumps(result,indent=2)+"\n")
print([(n,x["passed"],x["reason"]) for n,x in result.items()])

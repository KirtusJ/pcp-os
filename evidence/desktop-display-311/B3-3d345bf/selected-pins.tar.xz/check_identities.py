"""Check the compact Home selection independently against two real executable files."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import runpy
import subprocess
import time

PANEL = bytes.fromhex("18364f")
WIDE_KEYS = "Up/Down choose   Enter open   F1 keys   F10 off"
NARROW_KEYS = "Enter open  F1 keys  F10 off"
sha = lambda data: hashlib.sha256(data).hexdigest()


def cut(text, room):
    return text if len(text) <= room else text[:room-2] + ".."


def check_frame(frame, rows, programs, chosen, count, mode):
    name, size, digest = programs[chosen]
    wide = mode == "640x480"
    width, height = map(int, mode.split("x"))
    head, dimensions, depth, rgb = frame.split(b"\n", 3)
    assert (head, dimensions, depth, len(rgb)) == (b"P6", f"{width} {height}".encode(), b"255", 3*width*height)
    across = width // 10 - 4
    keys = len(rows)-2
    assert rows[keys].strip() == (WIDE_KEYS if wide else NARROW_KEYS), ("keys", rows)
    note = re.fullmatch(r"  Places (\d+) to (\d+) of (\d+)", rows[4])
    if note:
        first, last, total = map(int, note.groups())
        assert total == count + 1
    else:
        first, last = 1, count + 1
        assert not rows[4].strip(), rows[4]
    slot = chosen + 2
    assert first <= slot <= last <= count+1
    labels = ["Programs"] + [cut("PINNED " + n, min(across,42)) for n,_,_ in programs[:count]]
    list_rows = list(range(5, 5+last-first+1))
    assert [rows[r].strip() for r in list_rows] == labels[first-1:last]
    markers = []
    for row in range(5,keys):
        pos = 3*((row*20+2)*width+21)
        if rgb[pos:pos+3] == PANEL:
            markers.append(row)
    assert markers == [5+slot-first], ("highlight", markers, slot)
    below = [s.strip() for s in rows[list_rows[-1]+1:keys] if s.strip()]
    facts = f"{(size+1023)//1024} KiB   SHA-256 {digest[:16]}..."
    if wide:
        expected = ["Enter starts", *[name[i:i+across] for i in range(0,len(name),across)], facts]
    else:
        expected = [cut(name,across), cut(facts,across)]
    assert below == expected, ("identity", below, expected)
    if wide:
        assert not rows[keys-1].strip(), ("blank before keys",rows)
    return dict(name=name,file_bytes=size,sha256=digest,visible_identity=below,footer=rows[keys].strip(),
                window=[first,last,count+1],highlight_row=markers[0],frame_sha256=sha(frame))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("source","kernel","surf","queue","qemu","output"):
        parser.add_argument(arg,type=Path)
    parser.add_argument("mode",choices=["320x200","640x480"])
    parser.add_argument("--same-ends", action="store_true", help="use identical bytes for the two 64-byte names")
    args=parser.parse_args(); src=args.source.resolve(); out=args.output.resolve(); out.mkdir()
    opt=runpy.run_path(str(src/"examples/optical-disk-check/check.py"))
    native=runpy.run_path(str(src/"examples/tester-cd/check_compact_pins.py"))
    glyphs=native["CHECK"]["kernel_glyphs"]()
    ker=args.kernel.resolve()
    measurement=runpy.run_path(str(src/"PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py"))["measure"](ker.read_bytes())
    prefix="program-"+"a"*51
    names=[prefix+"A.elf"]+[f"program-{n:02}.elf" for n in range(2,14)]+[prefix+"B.elf"]
    assert len(names[0])==len(names[-1])==64 and len(names)==14
    programs=[]
    for i,name in enumerate(names):
        data=(args.queue if i == 1 or (i == 13 and not args.same_ends) else args.surf).read_bytes()
        (out/name).write_bytes(data)
        programs.append((name,len(data),sha(data)))
    assert (programs[0][1:] == programs[-1][1:]) == args.same_ends
    serial=out/"serial.txt"; mode=args.mode
    cmd=[str(args.qemu.resolve()),"-machine","pc","-cpu","qemu64","-accel","tcg","-m","128M","-kernel",str(ker),
         "-append",f"image={measurement} desktop={mode}","-initrd",",".join(names),"-vga","std","-nic","none",
         "-display","none","-monitor","none","-qmp","stdio","-serial","file:"+str(serial)]
    record=dict(source=subprocess.check_output(["git","-C",src,"rev-parse","HEAD"],text=True).strip(),kernel_sha256=sha(ker.read_bytes()),
                kernel_measurement=measurement,mode=mode,programs=programs,command=cmd,keys=[],selections={},passed=False)
    with (out/"stderr.txt").open("wb") as err,subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
        try:
            q=opt["Monitor"](guest);q.call("qmp_capabilities")
            def key(*ks):
                q.key(*ks);record["keys"].append(ks);time.sleep(.26)
            def capture(label, match=None):
                f=out/(label+".ppm"); deadline=time.monotonic()+8; prev=None
                while time.monotonic()<deadline:
                    q.call("screendump",filename=str(f)); b=f.read_bytes(); rows=native["read"](b,glyphs)
                    if prev==b and (not match or any(match in line for line in rows)): break
                    prev=b;time.sleep(.1)
                else: raise ValueError((label,rows))
                (out/(label+".txt")).write_text("\n".join(rows)+"\n");return b,rows
            def profile(label,chosen,count):
                pic,rows=capture(label,"PCP OS | DESKTOP")
                record["selections"][label]=check_frame(pic,rows,programs,chosen,count,mode)
                return pic
            def waitlog(s):
                opt["wait_for"](lambda: serial.exists() and s in serial.read_text(errors="replace"),s,35)
            waitlog(f"desktop: {mode} at 1x UI scale");waitlog(measurement+" (measured; equal")
            assert all(f"file from the loader: {p} (" in serial.read_text() for p in names)
            key("spc");key("ctrl","p");key("esc");key("down")
            profile("single-first",0,1);key("spc")
            for i in range(1,14):key("down");key("ctrl","p")
            key("esc");profile("all-first",0,14)
            for chosen in range(1,14):
                key("down");before=profile(f"all-{chosen+1:02}",chosen,14)
            for ks, page in [(("f1",),"KEYS ON THE DESKTOP"),(("p",),"Switch PCP OS off?"),(("f10",),"Switch PCP OS off?")]:
                key(*ks);capture(ks[0]+"-view",page);key("esc");assert profile(ks[0]+"-esc-last",13,14)==before
            if args.same_ends:
                assert mode == "320x200"
                key("spc");capture("launcher-B")
                key("ctrl","d");capture("details-B")
                key("d")
                for _ in range(13):key("up")
                capture("launcher-A")
                key("ctrl","d");capture("details-A")
                key("esc");assert profile("after-details",13,14)==before
                from PIL import Image, ImageChops
                comparisons={}
                for a,b in [("all-first","all-14"),("launcher-A","launcher-B"),("details-A","details-B")]:
                    image1=Image.open(out/(a+".ppm")).convert("RGB")
                    image2=Image.open(out/(b+".ppm")).convert("RGB")
                    delta=ImageChops.difference(image1,image2)
                    differing=sum(pixel!=(0,0,0) for pixel in delta.getdata())
                    lines1=(out/(a+".txt")).read_text().splitlines();lines2=(out/(b+".txt")).read_text().splitlines()
                    comparisons[a+"_vs_"+b]=dict(differing_rgb_pixels=differing,exclusive_bbox=delta.getbbox(),
                        decoded_differences=[(i,x,y) for i,(x,y) in enumerate(zip(lines1,lines2)) if x!=y])
                home=comparisons["all-first_vs_all-14"]
                assert [i for i,x,y in home["decoded_differences"]]==[4]
                assert home["exclusive_bbox"][1]>=4*20 and home["exclusive_bbox"][3]<=5*20,home
                assert comparisons["launcher-A_vs_launcher-B"]["differing_rgb_pixels"]==0,comparisons
                record["same_bytes_comparisons"]=comparisons
            for i in range(12):key("up")
            short=profile("eligible-pin",1,14);key("ret");waitlog("PARROTS READY");capture("queue-running");key("esc")
            waitlog(names[1]+" ended DONE: exit 0");assert profile("queue-return",1,14)==short
            key("up");profile("returned-first",0,14)
            key("f10");capture("power","Switch PCP OS off?");key("ret")
            while not any(e.get("event")=="SHUTDOWN" for e in q.events):q.events.append(q.read())
            record["shutdown"]=next(e["data"] for e in q.events if e.get("event")=="SHUTDOWN")
            record["exit"]=guest.wait(timeout=10)
            lines=serial.read_text().splitlines();record["final_verdict"]=lines[-1];record["checks"]=sum(line.startswith("  pass ") for line in lines)
            assert record["exit"]==0 and record["shutdown"]=={"guest":True,"reason":"guest-shutdown"} and record["checks"]==72 and record["final_verdict"].startswith("ALL SELF-TESTS PASS.")
            record["passed"]=True
        finally:
            if guest.poll() is None:guest.kill();guest.wait()
            (out/"result.json").write_text(json.dumps(record,indent=2)+"\n")
    print(mode,record["passed"],record["selections"]["all-first"]["window"],record["selections"]["all-14"]["window"])


if __name__=="__main__": main()

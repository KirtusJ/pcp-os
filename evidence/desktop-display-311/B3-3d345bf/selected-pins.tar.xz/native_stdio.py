"""Run the source checker with QMP on stdio when AF_UNIX is unavailable."""
from pathlib import Path
import sys
source = Path(sys.argv.pop(1)).resolve()
entry = source / "examples/tester-cd/check_compact_pins.py"
original = entry.read_text()
begin = original.index("        end = time.monotonic() + 20")
end = original.index('        rpc("qmp_capabilities")', begin)
stdio = '''        adapter = runpy.run_path(str(HERE.parent/"optical-disk-check/check.py"))
        peer = adapter["Monitor"](guest)
        stream = guest.stdin
        def rpc(command, **arguments):
            return {"return": peer.call(command, **arguments)}
'''
active = original[:begin] + stdio + original[end:]
active = active.replace('"-qmp", "unix:%s,server=on,wait=off" % sock', '"-qmp", "stdio"')
active = active.replace('stdout=subprocess.DEVNULL', 'stdin=subprocess.PIPE, stdout=subprocess.PIPE')
exec(compile(active, str(entry), 'exec'), {'__file__': str(entry), '__name__': '__main__'})

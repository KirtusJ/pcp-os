"""Exercise seven compact Home pins, three completed Queue Desk tasks, all widgets, and keyboard navigation."""
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import subprocess
import time
import collections, inspect

import argparse
parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path, help="PCP OS checkout at the recorded revision")
parser.add_argument("kernel", type=Path, help="exact measured kernel ELF for the source commit")
parser.add_argument("program", type=Path, help="Queue Desk ELF with the SHA-256 recorded in result.json")
parser.add_argument("output", type=Path, help="fresh output directory")
parser.add_argument("--qemu", default="qemu-system-x86_64")
parser.add_argument("--mode", choices=["640x480","320x200"], required=True)
args = parser.parse_args()
src = args.source.resolve()
opt = runpy.run_path(str(src / 'examples/optical-disk-check/check.py'))
screen = opt['SCREEN']
glyphs = screen['kernel_glyphs']()
kernel = args.kernel.resolve()
measurement = runpy.run_path(str(src / 'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](kernel.read_bytes())
out = args.output.resolve()
out.mkdir()
geometry = args.mode
wide = geometry == '640x480'
first = 'program-01-' + 'A'*44 + '-TAIL.elf' if wide else 'queue.elf'
names = [first] + [f'program-{i:02}.elf' for i in range(2,8)]
reader = inspect.getsource(screen['read_screen']).replace('width < 640 or height < 480','width < 320 or height < 200')
ns = {'collections':collections}
exec(reader,ns)
for name in names:
    shutil.copyfile(args.program.resolve(), out / name)
serial = out / 'serial.txt'
cmd = [args.qemu, '-machine', 'pc', '-accel', 'tcg', '-cpu', 'qemu64', '-m', '256M', '-vga', 'std', '-nic', 'none', '-display', 'none', '-monitor', 'none', '-qmp', 'stdio', '-serial', 'file:'+str(serial), '-kernel', str(kernel), '-append', f'desktop={geometry} image={measurement}', '-initrd', ','.join(names)]
sha = lambda b: hashlib.sha256(b).hexdigest()
source = subprocess.check_output(['git','-C',src,'rev-parse','HEAD'],text=True).strip()
assert source == '3d345bf68df5b64cf8345dfa6754c7d98046b01d'
meta = dict(kernel_sha256=sha(kernel.read_bytes()), source=source, program_sha256=sha((out/names[0]).read_bytes()), measurement=measurement, frames={}, keys=[], argv=cmd)
with (out/'stderr.txt').open('wb') as err:
    vm = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, cwd=out, stderr=err)
    try:
        monitor = opt['Monitor'](vm)
        monitor.call('qmp_capabilities')
        def key(*keys):
            monitor.key(*keys)
            meta['keys'].append(list(keys))
            time.sleep(0.45)
        def capture(label):
            path = out / (label+'.ppm')
            monitor.call('screendump', filename=str(path))
            frame=path.read_bytes()
            rows=ns['read_screen'](frame,glyphs)
            meta['frames'][label]=sha(frame)
            (out/(label+'.txt')).write_text('\n'.join(rows))
            return rows
        opt['wait_for'](lambda: serial.exists() and ('desktop: '+geometry+' at 1x UI scale') in serial.read_text(), 'awaiting Home', 60)
        time.sleep(.5)
        capture('initial')
        key('spc')
        for i in range(len(names)):
            if i:key('down')
            key('ctrl','p')
        key('esc'); key('down')
        capture('seven-first-before-widgets')
        key('down')
        for at in range(3):
            key('ret')
            opt['wait_for'](lambda: serial.read_text().count('PARROTS READY')>at,'Queue Desk opened',15)
            key('esc')
            opt['wait_for'](lambda: serial.read_text().count('program-02.elf ended DONE: exit 0')>at,'Queue Desk returned',15)
        key('f2');key('down');key('down');key('ret');key('down');key('ret');key('down');key('ret');key('esc')
        key('up')
        capture('seven-first')
        key('up')
        capture('seven-programs')
        for i in range(7):
            key('down')
            capture('chosen-'+str(i+1))
        for i in range(6): key('up')
        full=capture('returned-first')
        if not wide:
            key('ret')
            opt['wait_for'](lambda: serial.read_text().count('PARROTS READY')==4,'selected queue.elf opened',15)
            key('esc')
            opt['wait_for'](lambda:'queue.elf ended DONE: exit 0' in serial.read_text(),'selected queue.elf returned',15)
            capture('after-queue')
        key('f10')
        q=capture('power')
        assert 'Switch PCP OS off?' in q[3],q
        key('ret')
        while not any(x.get('event')=='SHUTDOWN' for x in monitor.events):
            monitor.events.append(monitor.read())
        meta['shutdown']=next(x['data'] for x in monitor.events if x.get('event')=='SHUTDOWN')
        meta['exit']=vm.wait(timeout=20)
        meta['passes']=sum(x.startswith('  pass ') for x in serial.read_text().splitlines())
        meta['complete_digest_visible']=any(meta['program_sha256'][:16] in r for r in full)
        meta['all_pass']='ALL SELF-TESTS PASS.' in serial.read_text()
        assert meta['all_pass'] and meta['passes']==72 and meta['exit']==0 and meta['shutdown']=={'guest':True,'reason':'guest-shutdown'}
        print(meta['shutdown'],meta['exit'],meta['passes'],meta['complete_digest_visible'])
    finally:
        if vm.poll() is None:
            vm.kill(); vm.wait()
        (out/'result.json').write_text(json.dumps(meta,indent=2)+'\n')

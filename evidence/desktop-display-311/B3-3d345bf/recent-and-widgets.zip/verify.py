"""Read original QEMU frames, byte counts, font glyphs and selection highlight."""
import collections, hashlib, inspect, json, re, runpy, sys
from io import BytesIO
from pathlib import Path
from PIL import Image
source, folder = map(Path, sys.argv[1:3])
config = json.loads((folder/'result.json').read_text())
screen = runpy.run_path(str(source/'examples/tester-cd/check.py'))
glyphs = screen['kernel_glyphs']()
ns = {'collections':collections}
exec(inspect.getsource(screen['read_screen']).replace('width < 640 or height < 480','width < 320 or height < 200'), ns)
sha = lambda b: hashlib.sha256(b).hexdigest()
serial = (folder/'serial.txt').read_text()
assert f"{config['measurement']} (measured; equal to the value the loader named)" in serial
assert serial.count('program-02.elf ended DONE: exit 0')==3
assert config['all_pass'] and 'ALL SELF-TESTS PASS.' in serial
assert sum(line.startswith('  pass ') for line in serial.splitlines())==72
assert config['exit']==0 and config['shutdown']=={'guest':True,'reason':'guest-shutdown'}
all_rows={};image_bytes={}
for name,digest in config['frames'].items():
    data=(folder/(name+'.ppm')).read_bytes(); assert digest==sha(data)
    rows=ns['read_screen'](data,glyphs)
    assert '\n'.join(rows)==(folder/(name+'.txt')).read_text(),name
    all_rows[name]=rows;image_bytes[name]=data
geometry=Image.open(BytesIO(image_bytes['initial'])).size;wide=geometry==(640,480)
assert wide or geometry==(320,200)
assert f'desktop: {geometry[0]}x{geometry[1]} at 1x UI scale' in serial
names=['program-01-'+'A'*44+'-TAIL.elf' if wide else 'queue.elf']+[f'program-{i:02}.elf' for i in range(2,8)]
places=['Programs']+['PINNED '+n for n in names]
proof={}
for label,choice in [('seven-first',1),('seven-programs',0)]+[(f'chosen-{c}',c) for c in range(1,8)]:
    rows=all_rows[label];image=Image.open(BytesIO(image_bytes[label]))
    note=rows[4].strip()
    match=re.match(r'Places (\d+) to (\d+) of (\d+)',note)
    if match:
        first,end,total=map(int,match.groups());assert total==8
    else:
        assert note=='';first,end,total=1,8,8
    assert first<=choice+1<=end
    for row_nr,idx in enumerate(range(first-1,end),5):
        expected=places[idx];room=42 if wide else 28
        # The kernel reserves an extra column inside the compact pin row.
        actual=rows[row_nr].strip()
        if actual.endswith('..'):assert expected.startswith(actual[:-2])
        else:assert actual==expected,(label,row_nr,actual,expected)
        assert image.getpixel((21,row_nr*20+1)) == ((24,54,79) if idx==choice else (16,40,63)),(label,row_nr)
    body=[row.strip() for row in rows[5+(end-first+1):-2] if row.strip()]
    completion=[row for row in body if re.fullmatch(r'\d\d:\d\d:\d\d DONE program-02.elf',row)]
    if wide:
        assert len(completion)==3 and completion==sorted(completion)
        assert re.fullmatch(r'memory \d+ MiB, \d+ MiB free',body[-2]) and body[-1]=='Session files | cleared at power-off'
        assert body[-5:-2]==completion and not rows[-3].strip()
        if choice:
            assert body[0]=='Enter starts' and ''.join(body[1:-6])==names[choice-1] and body[-6]=='53 KiB   SHA-256 '+config['program_sha256'][:16]+'...'
        assert rows[-2].strip()=='Up/Down choose   Enter open   F1 keys   F10 off'
    else:
        assert ' | 5 wid..' in note and not completion
        if choice:assert body==[names[choice-1],'53 KiB   SHA-256 '+config['program_sha256'][:9]+'..'],(label,body)
        assert rows[-2].strip()=='Enter open  F1 keys  F10 off'
    proof[label]={'note':note,'choice':choice,'list_range':[first,end,total],'body':body,'keys':rows[-2].strip()}
assert image_bytes['seven-first']==image_bytes['returned-first']
if not wide: assert serial.count('queue.elf ended DONE: exit 0')==1
report={'geometry':geometry,'kernel_sha256':config['kernel_sha256'],'kernel_measurement':config['measurement'],'source':config['source'],'frame_count':len(config['frames']),'verified':proof,'guest_exit':config['exit'],'passes':config['passes']}
(folder/'independent-readback.json').write_text(json.dumps(report,indent=2)+'\n')
print(geometry,[(k,proof[k]['note']) for k in ('seven-first','seven-programs','chosen-7')],report['frame_count'],config['exit'],config['passes'])

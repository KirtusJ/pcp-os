# Seven pins and three completed tasks on compact Home

Source commit 3d345bf68df5b64cf8345dfa6754c7d98046b01d, tree 5f4d222650cc3c76293f632cfd70749313c06363. Extracted from the original hosted tester CD. See hosted-origin.json. Kernel ELF SHA-256 fb1a0e5902e5a4dfe84c85f3e791cc98ac6aa2389ac24c7ddbd1d165d5951a7e. Running measurement a35fd7a12fda8c92c4dfeb1c819082f2fe1d0272dbdb575c8bd29a52f44a047c. The same 54,256-byte Queue Desk binary was copied under seven ASCII names in each VM. All original frames, text decoded from the kernel font, input sequences, QEMU commands, serial logs, rendered selection highlights checked against the panel color, and the two original ELF inputs are included. The QEMU PC guests used a volatile store, TCG, no NIC and 256 MiB RAM.

At 640×480, the first name has 64 characters and wraps onto two lines. Queue Desk completed three separate tasks under the short name program-02.elf. Recent activity, This machine and Session were then enabled. For the first selection the status said “Places 1 to 5 of 8”; the list contained the highlighted entry, and the identity below it had the complete name and “53 KiB   SHA-256 46f4bbd5e4d754a7...”. Three DONE rows followed in chronological order, then memory and the session-files line, one blank row, and the full keyboard footer. The last pin displayed “Places 3 to 8 of 8”. Selecting Programs fit all eight places and all five widget lines without a range notice. The old f77 guest lost the third DONE row under the same seven-pin conditions; the original comparison is in the earlier B3 compact widget archive.

At 320×200, the first name is the actually executable queue.elf. The first pin's range and widget status were “Places 2 to 2 of 8 | 5 wid..”. All five widget lines had no room; the count 5 and a truncated label were visible. The selected pin, name (queue.elf), “53 KiB   SHA-256 46f4bbd5e..” (9 hex digits, ellipsis as two periods), and “Enter open  F1 keys  F10 off” occupied separate rows. The status reached “Places 8 to 8 of 8 | 5 wid..” at the final pin. The facts and widget explanation are visibly shortened at this resolution. After returning to the first pin, Enter launched queue.elf; it returned DONE/0 on Escape.

In each VM, all seven pin identities and highlights were followed using the ordinary Down key, with Programs counted as place one. Returning from the last pin to the first restored its complete framebuffer byte-for-byte. Both guests recorded 72 passing checks, the ALL SELF-TESTS PASS verdict and guest-requested shutdown with exit 0. These runs checked compact rendering and navigation. The long first filename in the 640×480 guest was selected but not launched. The graphical desktop and physical hardware were outside these runs.

To replay, use Python with Pillow, and QEMU x86-64 with TCG, PC/SeaBIOS and standard VGA. Set SOURCE to a checkout at the exact revision above. Use new output directories.

```sh
sha256sum -c SHA256SUMS
python3 -B replay.py "$SOURCE" inputs/kernel.elf32 inputs/queue.elf replay-640 --mode 640x480
python3 -B verify.py "$SOURCE" replay-640
python3 -B replay.py "$SOURCE" inputs/kernel.elf32 inputs/queue.elf replay-320 --mode 320x200
python3 -B verify.py "$SOURCE" replay-320
```

The emulator path can be supplied with --qemu. Emulator arguments in the receipts retain their original absolute paths. The verifier uses the same font and grid and accepts 320×200 by lowering only the original screen reader’s minimum geometry. Screens are native binary P6. Task timestamps can differ between VMs. The result field complete_digest_visible indicates whether all first 16 hex digits appear, so it is false at 320×200.

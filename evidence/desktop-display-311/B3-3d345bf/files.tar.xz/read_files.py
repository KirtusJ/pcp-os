"""Exercise F3 with ordinary files written inside a measured, diskless guest."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import struct
import subprocess
import time

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_program(out, count):
    assembly = ['.intel_syntax noprefix', '.text']
    for n in range(1, count + 1):
        assembly.extend([f'lea rdi, [rip + name{n}]', 'call save'])
    assembly.extend(['mov eax,60', 'xor edi,edi', 'syscall', 'save:',
                     'mov eax,2', 'mov esi,577', 'mov edx,420', 'syscall', 'test rax,rax', 'js failed',
                     'mov rdi,rax','mov eax,1','lea rsi,[rip + data]','mov edx,1024',
                     'syscall','cmp rax,1024','jne failed','mov eax,3','syscall','test rax,rax','jne failed',
                     'ret','failed:','mov eax,60','mov edi,1','syscall','data: .zero 1024'])
    for n in range(1,count+1):
        assembly.append(f'name{n}: .asciz "file{n:02d}.txt"')
    src = out / 'fixture.S'
    src.write_text('\n'.join(assembly)+'\n')
    subprocess.run(['as','--64',src,'-o',out/'fixture.o'],check=True)
    subprocess.run(['objcopy','-O','binary','-j','.text',out/'fixture.o',out/'fixture.bin'],check=True)
    raw = (out/'fixture.bin').read_bytes()
    size = 120 + len(raw)
    header = struct.pack('<16sHHIQQQIHHHHHH', b'\x7fELF\x02\x01\x01',3,62,1,120,64,0,0,64,56,1,0,0,0)
    (out/'files.elf').write_bytes(header + struct.pack('<IIQQQQQQ',1,5,0,0,0,size,size,4096) + raw)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for a in ('source','kernel','qemu','output'):
        p.add_argument(a, type=Path)
    p.add_argument('geometry')
    p.add_argument('count',type=int)
    args=p.parse_args()
    source,kernel,out=args.source.resolve(),args.kernel.resolve(),args.output.resolve()
    out.mkdir(parents=True)
    write_program(out,args.count)
    optical=runpy.run_path(str(source/'examples/optical-disk-check/check.py'))
    read=runpy.run_path(str(source/'examples/tester-cd/check_compact_pins.py'))['read']
    glyphs=optical['SCREEN']['kernel_glyphs']()
    measurement=runpy.run_path(str(source/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](kernel.read_bytes())
    serial=out/'serial.txt'
    cmd=[str(args.qemu.resolve()),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','128M','-nic','none','-vga','std','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel',str(kernel),'-append','desktop='+args.geometry+' image='+measurement,'-initrd','files.elf']
    case={'commit':subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip(),'measurement':measurement,'kernel_sha256':sha(kernel.read_bytes()),'count':args.count,'geometry':args.geometry,'argv':cmd,'frames':{}}
    with (out/'stderr.txt').open('wb') as err:
        guest=subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
        try:
            monitor=optical['Monitor'](guest)
            monitor.call('qmp_capabilities')
            def key(code):
                monitor.key(code)
                time.sleep(.27)
            def wait_log(s):
                optical['wait_for'](lambda:serial.exists() and s in serial.read_text(),s,25)
            def capture(name,expect):
                ppm=out/(name+'.ppm')
                previous=None
                end=time.monotonic()+8
                while time.monotonic()<end:
                    monitor.call('screendump',filename=str(ppm))
                    raw=ppm.read_bytes()
                    if raw==previous:
                        rows=read(raw,glyphs)
                        if any(expect in row for row in rows):
                            case['frames'][name]={'rows':rows,'sha256':sha(raw)}
                            return rows
                    previous=raw
                    time.sleep(.12)
                raise RuntimeError(f'{name}: {expect} absent; {read(raw,glyphs)}')
            wait_log('desktop: '+args.geometry)
            wait_log(measurement+' (measured; equal')
            capture('startup','PCP OS | DESKTOP')
            key('spc')
            key('ret')
            wait_log('files.elf ended DONE: exit 0')
            key('esc')
            capture('home','PCP OS | DESKTOP')
            key('f3')
            first=capture('first','FILES:')
            # The same launch supplies both the paged and returned views.
            for action,code in [('page-down','pgdn'),('up','up'),('page-up','pgup')]:
                key(code)
                capture(action,'FILES:')
            key('esc')
            capture('restored','PCP OS | DESKTOP')
            frames=case['frames']
            assert frames['home']['sha256']==frames['restored']['sha256']
            assert frames['first']['sha256']==frames['page-up']['sha256']
            height=int(args.geometry.split('x')[1])
            page=max(height//20-8,1)
            n=args.count
            for label,top in [('first',0),('page-down',min(page,max(n-page,0))),
                              ('up',max(0,min(page,max(n-page,0))-1)),('page-up',0)]:
                r=frames[label]['rows']
                names=[row.strip().split()[0] for row in r if row.strip().startswith('file')]
                expected=[f'file{i:02d}.txt' for i in range(top+1,min(top+page,n)+1)]
                assert names==expected,(label,names,expected)
                full=(f'FILES: showing {top+1} to {min(top+page,n)} of {n}, {n} KiB' if n else 'FILES: 0 file(s), 0 KiB')
                frames[label].update(full_heading=full,heading_complete=r[1].strip()==full,esc_visible='Esc back' in r[-2])
            key('f10')
            capture('power','Switch PCP OS off?')
            key('ret')
            while not any(e['event']=='SHUTDOWN' for e in monitor.events):
                monitor.events.append(monitor.read())
            case['shutdown']=next(e['data'] for e in monitor.events if e['event']=='SHUTDOWN')
            case['exit']=guest.wait(timeout=15)
            log=serial.read_text()
            case['passes']=sum(l.startswith('  pass ') for l in log.splitlines())
            assert case['shutdown']=={'guest':True,'reason':'guest-shutdown'} and case['exit']==0 and case['passes']==72 and 'ALL SELF-TESTS PASS.' in log
            print(args.geometry,n,case['frames']['first']['rows'][1],case['frames']['first']['rows'][-2],flush=True)
        finally:
            if guest.poll() is None:
                guest.kill()
                guest.wait()
            (out/'report.json').write_text(json.dumps(case,indent=2)+'\n')
if __name__=='__main__':
    main()

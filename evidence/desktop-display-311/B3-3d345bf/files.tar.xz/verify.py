"""Read every recorded P6 with the checkout's font and check the F3 verdicts."""
import hashlib
import json
from pathlib import Path
import runpy
import sys

root, checkout = (Path(p).resolve() for p in sys.argv[1:3])
optical = runpy.run_path(str(checkout / 'examples/optical-disk-check/check.py'))
font = optical['SCREEN']['kernel_glyphs']()
read = runpy.run_path(str(checkout / 'examples/tester-cd/check_compact_pins.py'))['read']
sha = lambda data: hashlib.sha256(data).hexdigest()
original = json.loads((root/'hosted-origin.json').read_text())
source = original['receipt']['source_commit']
assert source == '3d345bf68df5b64cf8345dfa6754c7d98046b01d'

def accepts(rows, a, b, n, paging):
    if n:
        headings = (f'FILES: showing {a} to {b} of {n}, {n} KiB', f'FILES: {a}-{b}/{n} | {n} KiB')
    else:
        headings = ('FILES: 0 file(s), 0 KiB',)
    keys = (('Up/Down, Page Up/Page Down move    Esc back', 'Up/Down PgUp/PgDn  Esc back') if paging else ('Esc back',))
    return rows[1].strip() in headings and rows[-2].strip() in keys

def erase_right(frame, row, col):
    magic, size, depth, bitmap = frame.split(b'\n',3)
    width, height = map(int,size.split())
    pixels = bytearray(bitmap)
    for y in range(row*20, (row+1)*20):
        start = y*width*3
        # Copy a blank background pixel from column zero, scanline by scanline.
        pixels[start+col*30:start+width*3] = bitmap[start:start+3] * (width-col*10)
    return b'\n'.join((magic,size,depth,bytes(pixels)))

for phase in ('hosted','reference'):
    for mode, n in [('320x200',0),('320x200',1),('320x200',3),('320x200',31),('640x480',3),('800x600',31)]:
        folder = root/f'{phase}-{mode}-{n}'
        case = json.loads((folder/'report.json').read_text())
        assert case['commit']==source and case['exit']==0 and case['shutdown']=={'guest':True,'reason':'guest-shutdown'}
        if phase=='hosted':
            assert case['kernel_sha256']==original['receipt']['on_disc']['kernel.elf32']['sha256']
            assert case['measurement']==original['receipt']['kernel_measurement']
        serial=(folder/'serial.txt').read_text()
        assert case['measurement']+' (measured; equal' in serial and 'files.elf ended DONE: exit 0' in serial
        assert 'ALL SELF-TESTS PASS.' in serial and sum(s.startswith('  pass ') for s in serial.splitlines())==case['passes']==72
        rows={}
        for key,v in case['frames'].items():
            raw=(folder/(key+'.ppm')).read_bytes()
            assert sha(raw)==v['sha256']
            rows[key]=read(raw,font)
            assert rows[key]==v['rows']
        assert case['frames']['restored']['sha256']==case['frames']['home']['sha256']
        assert case['frames']['first']['sha256']==case['frames']['page-up']['sha256']
        height=int(mode.split('x')[1])
        page=max(1,height//20-8)
        stop=min(page,max(n-page,0))
        for key, top in [('first',0),('page-down',stop),('up',max(stop-1,0)),('page-up',0)]:
            r=rows[key]
            first,last=top+1,min(n,top+page)
            assert [line.strip().split()[0] for line in r if line.strip().startswith('file')]==[f'file{i:02d}.txt' for i in range(first,last+1)]
            expect = phase=='reference' or mode!='320x200' or n==0
            assert accepts(r,first,last,n,n>page)==expect,(folder,key,r)
        if mode=='320x200' and n==31 and phase=='reference':
            original_p6=(folder/'first.ppm').read_bytes()
            for row,column in [(1,rows['first'][1].index('KiB')),(height//20-2,rows['first'][-2].index('Esc'))]:
                changed=read(erase_right(original_p6,row,column),font)
                assert not accepts(changed,1,2,31,True)
                assert accepts(rows['first'],1,2,31,True)
        print(phase,mode,n,rows['first'][1].strip(),'|',rows['first'][-2].strip(),flush=True)

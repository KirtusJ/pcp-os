"""Read compact Home with a full list and wrapped executable names."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import re
import subprocess
import time


def digest(data):
    return hashlib.sha256(data).hexdigest()


def long_name(size, edge):
    return (('identical-prefix-' * 18)[:size-6] + '-' + edge + '.elf')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path);p.add_argument('kernel',type=Path);p.add_argument('surf',type=Path);p.add_argument('queue',type=Path)
    p.add_argument('evidence',type=Path);p.add_argument('--qemu',default='qemu-system-x86_64');p.add_argument('--baseline',action='store_true')
    p.add_argument('--pins',type=int,default=10);p.add_argument('--short',action='store_true')
    p.add_argument('--longest',action='store_true',help='255/181-char display stress; two known register refusals are expected')
    args=p.parse_args(); source=args.source.resolve(); kernel=args.kernel.resolve(); out=args.evidence.resolve();out.mkdir()
    optical=runpy.run_path(str(source/'examples/optical-disk-check/check.py'));reader=optical['SCREEN'];glyphs=reader['kernel_glyphs']()
    measurement=runpy.run_path(str(source/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](kernel.read_bytes())
    end_sizes=(255,181) if args.longest else (64,63)
    n = args.pins
    names = [f'program-{i:02}.elf' for i in range(1,n+1)]
    if not args.short:
        names[0] = long_name(end_sizes[0],'A');names[-1] = long_name(end_sizes[1],'B')
    names.append('overflow-probe.elf')
    payloads=[(args.surf if i%2==0 and i!=n-1 else args.queue).read_bytes() for i in range(len(names))]
    for name,raw in zip(names,payloads): (out/name).write_bytes(raw)
    serial=out/'serial.txt';cmd=[str(Path(shutil.which(args.qemu)).resolve()),'-machine','pc','-accel','tcg','-cpu','qemu64','-smp','1','-m','256M','-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel',str(kernel),'-append','desktop=640x480 image='+measurement,'-initrd',','.join(names)]
    receipt={'baseline':args.baseline,'longest':args.longest,'capacity_test':n,'short_names':args.short,'source':subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip(), 'source_diff_sha256':digest(subprocess.check_output(['git','-C',source,'diff','HEAD'])), 'kernel_sha256':digest(kernel.read_bytes()),'measurement':measurement,'programs':[{ 'name':n,'bytes':len(raw),'sha256':digest(raw)} for n,raw in zip(names,payloads)], 'command':cmd,'keys':[],'frames':{},'profiles':{}}
    trace=out/'result.json'
    with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
        try:
            q=optical['Monitor'](guest);q.call('qmp_capabilities')
            def key(*ks):
                q.key(*ks);receipt['keys'].append(list(ks));time.sleep(.34)
            def await_log(line):
                optical['wait_for'](lambda:serial.exists() and line in serial.read_text(errors='replace'),line,30)
            def capture(label, heading=None):
                path=out/(label+'.ppm');end=time.monotonic()+8;prev=None
                while time.monotonic()<end:
                    q.call('screendump',filename=str(path));raw=path.read_bytes();rows=reader['read_screen'](raw,glyphs)
                    if (not heading or any(heading in r for r in rows)) and raw==prev: break
                    prev=raw;time.sleep(.15)
                else:raise TimeoutError(label+' '+str(heading))
                (out/(label+'.txt')).write_text('\n'.join(rows)+'\n');receipt['frames'][label]=digest(raw);return rows,raw
            def inspect(label,selected):
                rows,raw=capture(label,'PCP OS | DESKTOP');text=names[selected];data=payloads[selected];facts=f'{(len(data)+1023)//1024} KiB   SHA-256 {digest(data)[:16]}...'
                if '  Enter starts' in rows: begin=rows.index('  Enter starts')+1
                else: begin=len(rows)
                limit=len(rows)-2
                end=next((i for i in range(begin,limit) if rows[i].strip()==facts),limit)
                # Only the separate identity area counts. All name characters, the exact size and the digest must precede the footer.
                visible=''.join(line.strip() for line in rows[begin:end]);footer='  Up/Down choose   Enter open   F1 keys   F10 off'
                _,size,_,pixels=raw.split(b'\n',3);w,h=map(int,size.split()); marked=[]
                for i,row in enumerate(rows):
                    if not row.startswith('   PINNED '): continue
                    at=3*((i*20+2)*w+21)
                    if pixels[at:at+3]==bytes.fromhex('18364f'): marked.append(row.strip())
                raw_label='PINNED '+text;expected_label=raw_label if len(raw_label)<=42 else raw_label[:40]+'..'
                checks={'whole_name':visible==text,'size_and_hash':end<limit,'footer':rows[-2]==footer,'selected_highlight':marked==[expected_label], 'name_rows':end-begin,'visible_pin_labels':sum(r.startswith('   PINNED ') for r in rows)}
                range_line=next((r.strip() for r in rows if re.match(r'\s*Pins [0-9]+ to [0-9]+ of [0-9]+',r)),None)
                checks['pin_window']=range_line
                receipt['profiles'][label]=checks;return checks
            await_log('desktop: 640x480');await_log(measurement+' (measured; equal');logs=serial.read_text();assert all('file from the loader: '+n+' (' in logs for n in names),logs
            initial,_=capture('empty-home');assert 'PCP OS | DESKTOP' in initial[1]
            key('spc');key('ctrl','p');key('esc');key('down');inspect('single-first',0)
            key('spc')
            for i in range(1,n):
                key('down');key('ctrl','p')
                if i==n-2:
                    key('esc');inspect('near-capacity-first',0);key('spc')
            key('esc');inspect('at-capacity-first',0)
            key('spc');key('down');key('ctrl','p');show,_=capture('limit-refusal','Not pinned:');assert any(f'Not pinned: the desktop has room for {n} pinned program(s)' in line for line in show),show
            key('esc');again,_=capture('after-refusal','PCP OS | DESKTOP');assert sum('PINNED ' in r for r in again)==n and not any('overflow-probe' in r for r in again)
            for _ in range(n-1):key('down')
            inspect('at-capacity-last',n-1);before=receipt['frames']['at-capacity-last']
            key('f1');capture('keys-page','KEYS ON THE DESKTOP');key('esc');inspect('help-return',n-1);assert receipt['frames']['help-return']==before
            key('p');capture('compact-power-question','Switch PCP OS off?');key('esc');inspect('cancel-return',n-1);assert receipt['frames']['cancel-return']==before
            for _ in range(n-2):key('up')
            inspect('short-second',1);key('ret');await_log('PARROTS READY');capture('queue-running');key('esc');await_log('program-02.elf ended DONE: exit 0')
            inspect('returned-short-second',1);assert receipt['frames']['returned-short-second']==receipt['frames']['short-second']
            key('up');inspect('back-first',0);key('f10');rows,_=capture('power','Switch PCP OS off?');assert rows[3]=='  Switch PCP OS off?';key('ret')
            while not any(e.get('event')=='SHUTDOWN' for e in q.events): q.events.append(q.read())
            receipt['shutdown']=next(e['data'] for e in q.events if e['event']=='SHUTDOWN');receipt['exit']=guest.wait(timeout=20);assert receipt['exit']==0 and receipt['shutdown']=={'guest':True,'reason':'guest-shutdown'}
            log=serial.read_text();receipt['final_pass_lines']=sum(l.startswith('  pass ') for l in log.splitlines());receipt['final_verdict']=log.splitlines()[-1];receipt['artifact_refusals']=log.count('the register refused ARTIFACT_ADDED');assert receipt['final_pass_lines']==72
            assert (receipt['artifact_refusals']==2 and receipt['final_verdict']=='2 SELF-TEST(S) FAILED') if args.longest else receipt['artifact_refusals']==0 and receipt['final_verdict'].startswith('ALL SELF-TESTS PASS.')
            receipt['all_identities']=all(all(profile[k] for k in ('whole_name','size_and_hash','footer','selected_highlight')) for profile in receipt['profiles'].values());receipt['passed_expectation']=(not receipt['all_identities']) if args.baseline else receipt['all_identities']
            print('result',receipt['passed_expectation'],receipt['profiles'],flush=True)
            if not receipt['passed_expectation']:raise ValueError('unexpected compact identity result')
        finally:
            if guest.poll() is None:guest.kill();guest.wait()
            trace.write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__':main()

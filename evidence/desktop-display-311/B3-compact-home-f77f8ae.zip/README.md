# Compact Home guest regression

Source: KirtusJ/pcp-os f77f8aef17b2da9f69e2d6538af7868946b1d553. The included kernel was built from that clean revision with Rust 1.100.0. `records.json` gives its SHA-256 and measured identity. The 640x480 framebuffer PPMs are unmodified QEMU captures. Each result has the key transcript, exact image hashes and the final guest verdict.

On Linux with QEMU installed, from this unpacked directory, point SOURCE at a clean checkout of the revision above and run:

```sh
python3 -B check_capacity.py "$SOURCE" f77-10-wrapped/kernel.elf32 fixtures/surf.elf fixtures/queue.elf fresh-wrapped --pins 10
python3 -B check_capacity.py "$SOURCE" f77-11-short/kernel.elf32 fixtures/surf.elf fixtures/queue.elf fresh-short --pins 11 --short
```

Both commands create their own output directory. Each deliberately attempts one excess pin and checks the visible refusal before navigating to the last accepted one. The launcher confirmation and task launch use a normal, short filename.

"""Independently read the retained compact desktop images, serial logs and run outcomes."""
from pathlib import Path
from hashlib import sha256
import json
import runpy
import sys

if len(sys.argv) != 4:
    raise SystemExit('usage: verify_display.py SOURCE EXACT_DISPLAY PREVIOUS_DISPLAY')
source, exact, previous = map(Path, sys.argv[1:])
screen = runpy.run_path(str(source/'examples/tester-cd/check.py'))
glyphs = screen['kernel_glyphs']()
def verify(folder, revision, quantity):
    r = json.loads((folder/'observations.json').read_bytes())
    assert r['source']==revision
    serial = (folder/'serial.log').read_text()
    assert r['measurement'] + ' (measured; equal' in serial
    assert 'ALL SELF-TESTS PASS.' in serial
    assert sum(x.startswith('  pass ') for x in serial.splitlines()) == 72
    assert r['qemu_exit']==0 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    for label,h in r['frames'].items():
        assert sha256((folder/(label+'.ppm')).read_bytes()).hexdigest()==h
    def get(label):
        return screen['read_screen']((folder/(label+'.ppm')).read_bytes(),glyphs)
    facts = f"{(r['program_bytes']+1023)//1024} KiB   SHA-256 {r['program_sha256'][:16]}..."
    footer='Up/Down choose   Enter open   F1 keys   F10 off'
    cap_text=' '.join(row.strip() for row in get('capacity-response'))
    cap_text=' '.join(cap_text.split())
    if quantity == 10:
        assert 'Not pinned: the desktop has room for 10 pinned program(s) on this display. Take one out first.' in cap_text
    else:
        assert 'Not pinned: the desktop has room for 13 pinned program(s)' in cap_text
        assert 'Take one out first.' not in cap_text
    found={}
    for label,launch in r['launches'].items():
        name=launch['name']
        rows=get(label+'-before')
        assert sum(row.strip().startswith('PINNED ') for row in rows)==quantity
        assert rows[-2].strip()==footer
        start=next(i for i,row in enumerate(rows) if row.strip()=='Enter starts')+1
        visible=rows[start:-2]
        pieces=[name[i:i+60] for i in range(0,len(name),60)]
        fits=[row.strip() for row in visible[:len(pieces)+1]]==pieces+[facts]
        assert fits==launch['card_matches']
        assert fits==(quantity==10)
        assert f"starting {name} ({r['program_bytes']} bytes, SHA-256 {r['program_sha256']})" in serial
        assert (folder/(label+'-before.ppm')).read_bytes()==(folder/(label+'-after.ppm')).read_bytes()
        if len(name.encode('ascii'))==32:
            assert name+' ended DONE: exit 0' in serial and 'PARROTS READY' in serial
            assert (folder/(label+'-running.ppm')).is_file()
            found[len(name)]='ran and exited 0'
        else:
            assert name+' could not be started: the program could not be admitted as a task' in serial
            assert name+' ended DONE' not in serial
            found[len(name)]='refused, same Home framebuffer'
    assert set(found)=={32,33,63,64}
    return found
for folder,rev,n in [(exact,'f77f8aef17b2da9f69e2d6538af7868946b1d553',10),(previous,'04a2954c5296cce90106d32d2d358392a3271efa',13)]:
    print(rev,verify(folder,rev,n))

/* 31 files with distinct verified content bytes and one 101-character name. */
static long call(long n, long a, long b, long c) {
    __asm__ volatile("syscall" : "+a"(n) : "D"(a), "S"(b), "d"(c) : "rcx","r11","memory");
    return n;
}
static void finish(int code) { call(60, code, 0, 0); for (;;) {} }
static volatile unsigned readback_count;
static void run(void) __attribute__((used));
static void run(void) {
    static const char *const names[] = {
        "f001",
        "f002",
        "f003",
        "f004",
        "f005",
        "f006",
        "f007",
        "f008",
        "f009",
        "f010",
        "f011",
        "f012",
        "f013",
        "f014",
        "f015",
        "f016-AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcontinuation-of-f016-BBBBBBBBBBBBBBBBBBBBBBBend-of-f016-Z",
        "f017",
        "f018",
        "f019",
        "f020",
        "f021",
        "f022",
        "f023",
        "f024",
        "f025",
        "f026",
        "f027",
        "f028",
        "f029",
        "f030",
        "f031",
    };
    for (int i = 0; i < 31; i++) {
        const char *name = names[i];
        int len = 0;
        while (name[len]) len++;
        char value = (char)(i + 1);
        long fd = call(2, (long)name, 65, 0);
        if (fd < 0 || call(1, fd, (long)&value, 1) != 1 || call(3, fd, 0, 0) != 0) finish(11);
        fd = call(2, (long)name, 0, 0);
        char actual = 0;
        if (fd < 0 || call(0, fd, (long)&actual, 1) != 1 || actual != value || call(3, fd, 0, 0) != 0) finish(12);
        readback_count++;
        call(1, 1, (long)"readback ", 9);
        call(1, 1, (long)name, len);
        call(1, 1, (long)"\n", 1);
    }
    finish(readback_count == 31 ? 0 : 15);
}
__asm__(".global _start\n.text\n_start:\n and $-16,%rsp\n call run\n ud2\n");

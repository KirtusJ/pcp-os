/* A temporary user-mode fixture for PCP OS public console, keyboard and store syscalls. */
static long call(long n, long a, long b, long c) {
    __asm__ volatile("syscall" : "+a"(n) : "D"(a), "S"(b), "d"(c) : "rcx","r11","memory");
    return n;
}
static void log_text(const char *s, int count) { call(1,1,(long)s,count); }
static long open_name(const char *s, int flags) { return call(2,(long)s,flags,0); }
static void finish(int code) { call(60,code,0,0); for (;;) {} }
static volatile int complete;
static void run(void) __attribute__((used));
static void run(void) {
#ifdef FILE_COUNT
    for (int i=1;i<=FILE_COUNT;i++) {
        char name[]="f000";
        name[2]='0'+i/10; name[3]='0'+i%10;
        long fd=open_name(name,65);
        if (fd < 0 || call(1,fd,(long)"x",1)!=1 || call(3,fd,0,0)!=0) finish(9);
        fd=open_name(name,0);
        char value=0;
        if (fd<0 || call(0,fd,(long)&value,1)!=1 || value!='x' || call(3,fd,0,0)!=0) finish(10);
        log_text("created/read ",13); log_text(name,4); log_text("\n",1);
    }
#else
    log_text("entered " MARK "\n", sizeof("entered " MARK "\n")-1);
    long kb=open_name("/dev/kbd",2048);
    if(kb<0) finish(11);
    unsigned char ev[2]={0};
    while(call(0,kb,(long)ev,2)!=2 || ev[0]!=1 || (ev[1]&1)!=0) {
        const long t[2]={0,10000000}; call(35,(long)t,0,0);
    }
    log_text("Esc " MARK "\n", sizeof("Esc " MARK "\n")-1);
#endif
    complete=1;
    finish(0);
}
__asm__(".global _start\n.text\n_start:\n and $-16,%rsp\n call run\n ud2\n");

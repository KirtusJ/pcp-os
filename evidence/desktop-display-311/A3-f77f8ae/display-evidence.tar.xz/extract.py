from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile
import json,runpy
root=Path(__file__).resolve().parent
digest=lambda b:sha256(b).hexdigest()
with ZipFile(root/'tester-cd-evidence-queue-desk.zip') as z:
 receipt=z.read('first/receipt.json')
 (root/'media-receipt.json').write_bytes(receipt)
 media=json.loads(receipt)
assert media['source_commit']=='f77f8aef17b2da9f69e2d6538af7868946b1d553' and media['source_tree']==(root/'tree').read_text().strip() and media['uncommitted_changes'] is False
with ZipFile(root/'unpublished-tester-cd-queue-desk.zip') as z:
 cd=z.read('pcp-os-tester.iso');assert digest(cd)==media['iso_sha256']
 files=runpy.run_path(str(root/'source/examples/tester-cd/build.py'))['read_back'](cd)
 for filename in ['kernel.elf32','rdesk.elf','surf.elf']:
  data=files[filename];assert digest(data)==media['on_disc'][filename]['sha256']
  (root/filename).write_bytes(data)
 measure=runpy.run_path(str(root/'source/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](files['kernel.elf32'])
 assert measure==media['kernel_measurement']
 (root/'measurement').write_text(measure+'\n')
 print('kernel',digest(files['kernel.elf32']),'measurement',measure)

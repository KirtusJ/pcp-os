"""Check the suite totals from individual assertions and preserve the native evidence."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent
suite = root/'full'
result = json.loads((suite/'results.json').read_bytes())
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()
assert result['kernel_sha256']==sha(root/'kernel.elf32')
assert result['doom_sha256']==sha(root/'programs/doom.elf')
assert all(sha(root/'data'/name)==expected for name,expected in result['game_data'].items())
groups=result['results']
checks=[(g['test'],c) for g in groups for c in g['checks']]
failed=[dict(group=group, assertion=c['check'],detail=c.get('detail')) for group,c in checks if not c['ok']]
assert all(g['ok']==all(c['ok'] for c in g['checks']) for g in groups)
assert len(groups)==result['tests'] and len(checks)==result['checks']
passing_groups=sum(g['ok'] for g in groups)
assert passing_groups==result['passed'] and any('240 seconds' in g['test'] for g in groups)
status=int((root/'suite.exit').read_text())
assert status==(1 if failed else 0)
textlog=(root/'full.log').read_text()
assert all(g['test'] in textlog for g in groups)
raw_serials=sorted(suite.glob('*/serial.log'))
raw=[s.read_text(errors='replace') for s in raw_serials]
playdemo=(suite/'playdemo/serial.log').read_text()
media=json.loads((root/'media-receipt.json').read_bytes())
assert json.loads((root/'single/receipt.json').read_bytes())['on_disc']['kernel.elf32']['sha256']==result['kernel_sha256']
report=dict(source=media['source_commit'],source_tree=media['source_tree'],kernel_sha256=result['kernel_sha256'],kernel_measurement=media['kernel_measurement'],
            origin='GitHub Actions run 44901276095, both tester CDs',
            start=(root/'start').read_text().strip(),end=(root/'stop').read_text().strip(),
            command='PCPOS_ADAPTER_CHECKOUT="$PWD/source" python3 -u run_stdio.py "$PWD/kernel.elf32" "$PWD/programs" "$PWD/data" "$PWD/full"',
            suite_mode='full, with PCPOS_TESTS_ONLY unset and no quick argument', native_groups=[passing_groups,len(groups)],
            assertions=[len(checks)-len(failed),len(checks)],exit=status,failed=failed,serial_files=len(raw_serials),
            demo_outcomes=[l for l in playdemo.splitlines() if l.startswith('doom.elf ended ')],
            soak_outcomes=[l for l in (suite/'soak/serial.log').read_text().splitlines() if l.startswith('doom.elf ended ')],
            results_sha256=sha(suite/'results.json'),emulator=result['emulator'])
(root/'full-suite-readback.json').write_text(json.dumps(report,indent=2)+'\n')
archive=root/'full-suite.zip'
items={f.relative_to(root).as_posix(): f for f in suite.rglob('*') if f.is_file() and (f.name in ('serial.log','qemu.stderr','results.json') or f.suffix=='.png')}
for path in ['full-suite-readback.json','pack_suite.py','full.log','inputs.sha256','measurement','start','stop','suite.exit','qmp-transport.diff','run_stdio.py','media-receipt.json','single/receipt.json','media-origins.json','source/PCP_OS_Rust/crates/pcpos-kernel/tests/run_tests.py']:
 items[path]=root/path
waves={f.relative_to(root).as_posix():{'sha256':sha(f),'bytes':f.stat().st_size} for f in sorted(suite.glob('*/sound.wav'))}
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=7) as z:
 for n,f in sorted(items.items()):z.write(f,n)
 z.writestr('audio-capture-hashes.json',json.dumps(waves,indent=2)+'\n')
 z.writestr('SHA256SUMS',''.join(sha(f)+'  '+n+'\n' for n,f in sorted(items.items())))
with ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({k:report[k] for k in ('native_groups','assertions','exit','serial_files')}),archive.stat().st_size,sha(archive))

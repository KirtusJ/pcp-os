"""Verify the five direct-guest records against their raw P6, serial and optional previous frames."""
from pathlib import Path
from hashlib import sha256
import json, re, runpy, sys
from PIL import Image

root=Path(__file__).resolve().parent
src=Path(sys.argv[1]).resolve()
old=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else None
get=lambda p:json.loads(p.read_bytes());sha=lambda b:sha256(b).hexdigest()
reader=runpy.run_path(str(src/'examples/tester-cd/check.py'))
font=reader['kernel_glyphs']();font_cache={}
receipt=get(root/'pin/inputs/identities.json')
assert receipt['kernel']==sha((root/'pin/inputs/kernel.elf32').read_bytes())
measure=runpy.run_path(str(src/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure']
assert receipt['measurement']==measure((root/'pin/inputs/kernel.elf32').read_bytes())
checks={}
def rows(path,txt):
    raw=path.read_bytes();o=sha(raw)
    if o not in font_cache:font_cache[o]=reader['read_screen'](raw,font)
    result=font_cache[o]
    assert '\n'.join(result)+'\n'==txt.read_text()
    return result
def validate_runtime(folder):
    r=get(folder/'result.json');data=(folder/'serial.txt').read_bytes();log=data.decode('ascii').splitlines()
    assert r['source']==receipt['commit'] and r['measurement']==receipt['measurement'] and r['kernel_sha256']==receipt['kernel']
    assert any(r['measurement']+' (measured; equal to the value the loader named)' in l for l in log)
    assert r['exit_code']==0 and sum(l.startswith('  pass ') for l in log)==72 and any('ALL SELF-TESTS PASS.' in l for l in log) and not any(l.startswith('  FAIL') for l in log)
    assert any(e.get('event')=='SHUTDOWN' and e.get('data')=={'guest':True,'reason':'guest-shutdown'} for e in r['events'])
    return r,log
for g in ('640x480','800x600','1024x768','1920x1080'):
    folder=root/('files-'+g);r,log=validate_runtime(folder)
    assert r['case']=='wrapped' and r['geometry']==g and r['fixture_sha256']==sha((root/'files.elf').read_bytes())
    assert [l for l in log if l.startswith('starting files.elf ')]==[f"starting files.elf ({(root/'files.elf').stat().st_size} bytes, SHA-256 {r['fixture_sha256']})"]
    assert sum(l.startswith('files.elf ended DONE: exit 0 ') for l in log)==1
    names=['audit-'+'A'*180+'X','audit-'+'A'*180+'Y','budit-'+'A'*180+'X']
    assert r['files']==names and all(f'{name}={i}' in log for i,name in enumerate(names,1))
    rr={f.stem:rows(f,f.with_suffix('.txt')) for f in folder.glob('*.ppm')}
    assert (folder/'home.ppm').read_bytes()==(folder/'returned.ppm').read_bytes()
    assert {'POWER OFF','Switch PCP OS off?','Enter switch off    Esc go back'}<={l.strip() for l in rr['power']}
    cap=int(g.split('x')[0])//10-20
    tokens=[([name[i:i+cap],'1','KiB'] if i==0 else [name[i:i+cap]]) for name in names for i in range(0,len(name),cap)]
    assert [s.split() for s in rr['files'][4:4+len(tokens)]]==tokens
    assert rr['files'][1].strip()=='FILES: showing 1 to 3 of 3, 1 KiB'
    h=sha((folder/'files.ppm').read_bytes());assert r['screen_or_row_hashes']==[h]
    z=dict(geometry=g,name_columns=cap,lines_per_187_byte_name=(187+cap-1)//cap,
           f3_sha256=h,files_verified=len(names),p6_count=len(rr),serial_sha256=sha((folder/'serial.txt').read_bytes()),guest_shutdown=True,exit_code=0,checks=72)
    if old:z['f3_byte_identical_to_86546ce']=h==sha((old/('draft-files-'+g)/'files.ppm').read_bytes())
    checks[g]=z
d=root/'pin/observed-pins';r,log=validate_runtime(d)
assert r['files']=={p.name:sha(p.read_bytes()) for p in d.iterdir() if p.suffix in ('.ppm','.txt')}
rr={p.stem:rows(p,p.with_suffix('.rows.txt')) for p in d.glob('*.ppm')}
names=['sharedprefixA.elf','sharedprefixB.elf','shoredprefixC.elf']
markers=['alpha','bravo','charlie']
assert all(any(names[i][:16] in s and r['programs'][names[i]][:16] in s for s in rr[f'launcher-{i}']) for i in range(3))
assert [sum('pinned to the desktop' in s for s in rr[f'pinned-{i}']) for i in range(3)]==[1,2,3]
launches=[]; label_hashes={}; previous_pin_equal={}
for form in ('bar','dock'):
    crops=[]
    for i,(n,marker) in enumerate(zip(names,markers)):
        f=root/'pin/inputs'/n;h=sha(f.read_bytes());assert h==r['programs'][n]==receipt['programs'][n]
        for label in (f'{form}-selected-{i}',f'{form}-returned-{i}'):
            page=rr[label]
            assert any(n in s for s in page) and any(f'SHA-256 {h[:16]}...' in s and '9 KiB' in s for s in page) and any('Enter starts' in s for s in page)
            assert not any(other in s for other in names if other!=n for s in page)
            assert any('sharedpref..' in s and 'shoredpref..' in s for s in page)
        at=(10+(i+1)*190+50,1040) if form=='bar' else ((1920-(4*140+20))//20*10+10+(i+1)*140+10,1020)
        left,top=at;box=(left,top,left+120,top+20); fn=f'{form}-selected-{i}'
        with Image.open(d/(fn+'.ppm')) as im: crop=sha(im.crop(box).tobytes())
        assert crop==r['results'][fn]['label_rgb_sha256']
        if old:
            with Image.open(old/'pin312/observed-pins'/(fn+'.ppm')) as im:previous_pin_equal[fn]=crop==sha(im.crop(box).tobytes())
        crops.append(crop)
        assert log.count(f'starting {n} ({f.stat().st_size} bytes, SHA-256 {h})')==2
        assert log.count('entered '+marker)==log.count('Esc '+marker)==2
        assert sum(l.startswith(n+' ended DONE: exit 0 ') for l in log)==2
        launches.append(n)
    assert crops[0]==crops[1]!=crops[2];label_hashes[form]=crops
assert [s.split(' ')[1] for s in log if s.startswith('starting ') and any(n in s for n in names)]==launches
assert {'POWER OFF','Switch PCP OS off?','Enter switch off    Esc go back'}<={s.strip() for s in rr['question']}
pins=dict(geometry='1920x1080',launch_order=launches,elf_sha256=r['programs'],short_label_rgb_sha256=label_hashes,
          full_name_and_size_and_digest_before_launch_and_after_return=True,prior_86546ce_crop_matches=previous_pin_equal,
          p6_count=len(rr),serial_sha256=sha((d/'serial.txt').read_bytes()),guest_shutdown=True,exit_code=0,checks=72)
report=dict(source=receipt['commit'],kernel_sha256=receipt['kernel'],measurement=receipt['measurement'],
            source_cd=receipt['build_url'],runs=5,files=checks,pins=pins)
(root/'readback.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))

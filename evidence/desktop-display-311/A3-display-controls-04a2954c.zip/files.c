/* Three distinct equal-length filenames and three different one-byte contents. */
static long call(long n, long a, long b, long c) {
    __asm__ volatile("syscall" : "+a"(n) : "D"(a), "S"(b), "d"(c) : "rcx","r11","memory");
    return n;
}
static void finish(int code) { call(60, code, 0, 0); for (;;) {} }
static volatile unsigned readback_count;
static void run(void) __attribute__((used));
static void run(void) {
    char name[188] = "audit-";
    for (int i = 6; i < 186; i++) name[i] = 'A';
    for (int action = 0; action < 2; action++) {
        for (int i = 0; i < 3; i++) {
            name[0] = i == 2 ? 'b' : 'a';
            name[186] = i == 1 ? 'Y' : 'X';
            char value = '1' + i;
            long fd = call(2, (long)name, action == 0 ? 65 : 0, 0);
            if (fd < 0) finish(11);
            if (action == 0) {
                if (call(1, fd, (long)&value, 1) != 1) finish(12);
            } else {
                char actual = 0;
                if (call(0, fd, (long)&actual, 1) != 1 || actual != value) finish(13);
                readback_count++;
                call(1, 1, (long)name, 187); call(1, 1, (long)"=", 1);
                call(1, 1, (long)&actual, 1); call(1, 1, (long)"\n", 1);
            }
            if (call(3, fd, 0, 0) != 0) finish(14);
        }
    }
    finish(readback_count == 3 ? 0 : 15);
}
__asm__(".global _start\n.text\n_start:\n and $-16,%rsp\n call run\n ud2\n");

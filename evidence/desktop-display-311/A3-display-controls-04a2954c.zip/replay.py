"""Reproduce the three-file F3 display case against a supplied PCP OS kernel."""
import argparse
import hashlib
import json
import runpy
import subprocess
import time
from pathlib import Path

p = argparse.ArgumentParser()
for name in ('source', 'kernel', 'program', 'qemu', 'output'):
    p.add_argument(name, type=lambda path: Path(path).resolve())
p.add_argument('geometry')
p.add_argument('--fixed', action='store_true')
p.add_argument('--count', type=int, choices=[23,31])
a = p.parse_args()
a.output.mkdir(parents=True, exist_ok=False)
opt = runpy.run_path(str(a.source / 'examples/optical-disk-check/check.py'))
screen = runpy.run_path(str(a.source / 'examples/tester-cd/check.py'))
glyphs = screen['kernel_glyphs']()
measure = runpy.run_path(str(a.source / 'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure']
kernel = a.kernel.read_bytes()
ident = measure(kernel)
serial = a.output / 'serial.txt'
width, height = map(int, a.geometry.split('x'))
args = [str(a.qemu), '-machine','pc','-accel','tcg','-cpu','qemu64','-m','128M',
        '-kernel',str(a.kernel),'-initrd',a.program.name,'-append',f'image={ident} desktop={a.geometry}',
        '-vga','std','-display','none','-nic','none','-serial','file:'+str(serial),
        '-monitor','none','-qmp','stdio','-no-reboot']
sha = lambda data: hashlib.sha256(data).hexdigest()
def until(fn, label):
    end = time.monotonic() + 45
    while True:
        value = fn()
        if value: return value
        if time.monotonic() >= end: raise RuntimeError(label)
        time.sleep(.2)
names = [start + 'udit-' + 'A'*180 + last for start,last in [('a','X'),('a','Y'),('b','X')]]
with (a.output/'stderr.txt').open('wb') as err, subprocess.Popen(args, cwd=a.program.parent, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err) as vm:
    try:
        monitor = opt['Monitor'](vm)
        monitor.call('qmp_capabilities')
        def press(key):
            monitor.key(key)
            time.sleep(.4)
        def frame(tag, predicate):
            path = a.output/(tag+'.ppm')
            def capture():
                monitor.call('screendump', filename=str(path))
                data = path.read_bytes()
                if not data.startswith(f'P6\n{width} {height}\n255\n'.encode()): return False
                rows = screen['read_screen'](data,glyphs)
                if rows and predicate(rows,data):
                    (a.output/(tag+'.txt')).write_text('\n'.join(rows)+'\n')
                    return rows,data
            return until(capture, tag)
        until(lambda: serial.exists() and 'desktop: '+a.geometry in serial.read_text(), 'startup')
        time.sleep(.7)
        press('spc')
        frame('launcher', lambda rows,data:any(a.program.name in row for row in rows))
        press('ret')
        until(lambda: a.program.name+' ended DONE: exit 0' in serial.read_text(),'fixture')
        press('esc')
        time.sleep(.8)
        _,home=frame('home',lambda rows,data:any('Programs' in row for row in rows) and any('F1 keys' in row for row in rows) and not any(a.program.name in row and ('SHA-256' in row or row.strip().endswith(a.program.name)) for row in rows))
        press('f3')
        cap=width//10-20
        hashes=[]
        if a.count:
            names=[f'f{i:03}' for i in range(1,a.count+1)]
            def page(top):
                visible=names[top:top+a.count-1]
                def matches(rows,data):
                    return (f'FILES: showing {top+1} to {top+len(visible)} of {a.count},' in rows[1]
                            and 'Page Up/Page Down' in rows[-2] and all(
                            row.strip().split() == [name,'1','KiB'] for row,name in zip(rows[4:],visible)))
                return matches
            _,original=frame('first', page(0))
            for k,top in [('down',1),('up',0),('pgdn',1),('pgup',0)]:
                press(k)
                _,view=frame('after-'+k,page(top))
                assert (view==original)==(top==0)
                hashes.append(sha(view))
        elif a.fixed:
            parts=[(name[i:i+cap],i==0) for name in names for i in range(0,len(name),cap)]
            def reads_all(rows,data):
                if 'FILES: showing 1 to 3 of 3,' not in rows[1]: return False
                for row,(piece,start) in zip(rows[4:],parts):
                    if row.strip().split() != ([piece,'1','KiB'] if start else [piece]): return False
                return True
            rows,files=frame('files', reads_all)
            hashes.append(sha(files))
        else:
            rows,files=frame('files',lambda rows,data:'FILES: 3 file(s)' in rows[1] and rows[6].strip().startswith(names[2][:cap]))
            assert [row.strip().split() for row in rows[4:7]] == [[name[:cap],'1','KiB'] for name in names]
            stride=width*20*3
            pixels=files.split(b'\n',3)[3]
            hashes=[sha(pixels[i*stride:(i+1)*stride]) for i in (4,5,6)]
            assert hashes[0]==hashes[1]!=hashes[2]
        press('esc')
        frame('returned',lambda rows,data:data==home)
        press('f10')
        frame('power',lambda rows,data:rows[1].strip()=='POWER OFF' and 'Enter switch off' in rows[-2])
        press('ret')
        while not any(e['event']=='SHUTDOWN' for e in monitor.events):
            msg=monitor.read()
            if 'event' in msg: monitor.events.append(msg)
        assert vm.wait(timeout=25)==0
        assert any(e['event']=='SHUTDOWN' and e['data']=={'guest':True,'reason':'guest-shutdown'} for e in monitor.events)
        log=serial.read_text()
        if a.count:
            assert all('created/read '+name in log for name in names)
        else:
            assert all((name+'='+str(i)) in log for i,name in enumerate(names,1))
        assert ident+' (measured; equal' in log and 'ALL SELF-TESTS PASS.' in log
        passes=sum(l.startswith('  pass ') for l in log.splitlines())
        assert passes==72
        record=dict(geometry=a.geometry,clip=cap,screen_or_row_hashes=hashes,files=names,case='overflow' if a.count else ('wrapped' if a.fixed else 'clipped'),
                    home_restored=True,checks=passes,exit_code=vm.returncode,events=monitor.events,argv=args,
                    source=subprocess.check_output(['git','-C',a.source,'rev-parse','HEAD'],text=True).strip(),
                    fixture_sha256=sha(a.program.read_bytes()),kernel_sha256=sha(kernel),measurement=ident)
        (a.output/'result.json').write_text(json.dumps(record,indent=2)+'\n')
        print(a.geometry,cap,passes)
    finally:
        if vm.poll() is None: vm.kill(); vm.wait()

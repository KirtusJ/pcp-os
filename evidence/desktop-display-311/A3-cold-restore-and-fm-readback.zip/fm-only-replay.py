from pathlib import Path
import hashlib,json,runpy,subprocess,time
root=Path(__file__).resolve().parent
checker=runpy.run_path(str(root.parent/'integrated307/examples/tester-cd/check.py'))
monitor=runpy.run_path(str(root.parent/'integrated307/examples/optical-disk-check/check.py'))['Monitor']
builder=runpy.run_path(str(root.parent/'integrated307/examples/tester-cd/build.py'))
measurement=runpy.run_path(str(root.parent/'integrated307/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure']
glyphs=checker['kernel_glyphs']()
iso=root/'final.iso'
image=iso.read_bytes()
members=builder['read_back'](image)
scratch=root/'profile-inputs';scratch.mkdir(exist_ok=True)
for key in ['kernel.elf32','surf.elf']:(scratch/key).write_bytes(members[key])
digest=hashlib.sha256(members['surf.elf']).hexdigest()
for tag,options,expected in [('fm-only','',['display','keyboard','sound','loader files','store'])]:
 out=root/('direct-'+tag);out.mkdir();log=out/'serial.txt'
 cmdline=('image='+measurement(members['kernel.elf32'])+' desktop=1280x720 '+options).strip()
 cmd=[str(root.parent/'emulator/qemu-system-x86_64'),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','128M','-kernel','kernel.elf32','-initrd','surf.elf','-append',cmdline,'-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(log),'-audiodev','none,id=snd0','-device','adlib,audiodev=snd0','-no-reboot']
 with (out/'stderr.txt').open('wb') as err:
  q=subprocess.Popen(cmd,cwd=scratch,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
  try:
   m=monitor(q);m.call('qmp_capabilities')
   end=time.monotonic()+50
   while time.monotonic()<end:
    text=log.read_text(errors='replace') if log.exists() else ''
    if 'leaves no memory behind' in text:break
    time.sleep(.1)
   assert sum(l.startswith('  pass ') for l in text.splitlines())==71
   assert 'sound: no device this kernel drives' in text and 'music: an FM synthesiser of the AdLib kind answered' in text
   def screen(name,accept):
    path=out/(name+'.ppm');end=time.monotonic()+30
    while time.monotonic()<end:
     m.call('screendump',filename=str(path));f=path.read_bytes();r=checker['read_screen'](f,glyphs)
     if r and accept(r):return f,r
     time.sleep(.1)
    raise AssertionError(name)
   home,_=screen('home',lambda r: 'Programs' in r[-2])
   m.key('spc')
   check=lambda r: checker['selected_entry_visible'](r,1280,'surf.elf',digest,expected)
   frame,rows=screen('launcher',check)
   row=next(i for i,l in enumerate(rows) if '> surf.elf ' in l)
   damaged=None
   assert not checker['selected_entry_visible'](rows,1280,'surf.elf',digest,[p for p in expected if p!='sound'])
   actual,width,sound=checker['launcher_boot_profile'](text)
   assert actual.split()==['kernel.elf32',*cmdline.split()] and (width,sound)==(1280,True)
   assert tuple(expected)==checker['launcher_grants'](sound=sound,command_line=actual,digest=digest)
   m.key('esc');screen('restored',lambda r:'Programs' in r[-2])
   m.key('f10');screen('power',lambda r:'POWER OFF' in r[1] and 'Esc go back' in r[-2]);m.key('ret')
   rc=q.wait(timeout=25);serial=log.read_text();assert rc==0 and sum(l.startswith('  pass ') for l in serial.splitlines())==72
   info=dict(profile=tag,source='3e86beb1ee17fad2f3d61c95b9d5dd017fb6c755',kernel_measurement=measurement(members['kernel.elf32']),argv=cmd,permissions=expected,grant_row=rows[row+1].strip(' ?'),width=1280,height=720,sha256=hashlib.sha256(frame).hexdigest(),control_rejected=True,qemu_exit=rc,startup=71,final=72)
   (out/'result.json').write_text(json.dumps(info,indent=2)+'\n');print(tag,info['grant_row'],rc,flush=True)
  finally:
   if q.poll() is None:q.kill();q.wait()

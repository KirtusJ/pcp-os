"""Read every page of the last pin with two-digit place numbers and different hidden widget counts."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import runpy
import subprocess
import time

parser = argparse.ArgumentParser(description=__doc__)
for name in ("source", "kernel", "program", "receipt", "qemu", "out"):
    parser.add_argument(name, type=Path)
parser.add_argument('--pins',type=int,choices=(14,16),default=14)
parser.add_argument('--length',type=int,choices=(64,255),default=64)
args = parser.parse_args()
source, kernel, program, receipt, qemu, out = (
    getattr(args, name).resolve() for name in ("source", "kernel", "program", "receipt", "qemu", "out")
)
out.mkdir()
metadata = json.loads(receipt.read_text())
data = program.read_bytes()
digest = sha256(data).hexdigest()
assert metadata["inputs"]["rdesk.elf"]["sha256"] == digest
assert metadata["inputs"]["kernel.elf32"]["sha256"] == sha256(kernel.read_bytes()).hexdigest()
measurement = metadata["kernel_measurement"]
guest_tools = runpy.run_path(str(source / "examples/optical-disk-check/check.py"))
glyphs = guest_tools["SCREEN"]["kernel_glyphs"]()
decode = runpy.run_path(str(source / "examples/tester-cd/check_compact_pins.py"))["read"]
long_name = "a"*30 + "B" + ("abcdefghijklmnopqrstuvwxyz"*9)[:args.length-35] + ".elf"
assert len(long_name)==args.length
pages_total = (len(long_name)+27)//28
names = [f"desk-{i:02}.elf" for i in range(1,args.pins)] + [long_name]
for name in names:
    (out / name).write_bytes(data)
serial = out / "serial.log"
def read_serial():
    return serial.read_text(errors="replace") if serial.exists() else ""
cmd = [str(qemu), "-machine", "pc", "-accel", "tcg", "-cpu", "qemu64",
       "-m", "256M", "-vga", "std", "-nic", "none", "-display", "none", "-monitor", "none",
       "-qmp", "stdio", "-serial", "file:"+str(serial), "-kernel", str(kernel),
       "-append", "desktop=320x200 image="+measurement, "-initrd", ",".join(names)]
cases = {}
with (out/"stderr.txt").open("wb") as err, subprocess.Popen(cmd, cwd=out, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err) as guest:
    try:
        monitor = guest_tools["Monitor"](guest)
        monitor.call("qmp_capabilities")
        def key(*keys):
            monitor.key(*keys)
            time.sleep(.32)
        def screen(tag):
            path = out / (tag+".ppm")
            last = None
            for _ in range(25):
                monitor.call("screendump", filename=str(path))
                frame = path.read_bytes()
                if frame == last:
                    break
                last = frame
                time.sleep(.25)
            else:
                raise ValueError("Screen did not settle: "+tag)
            rows = decode(frame, glyphs)
            (out/(tag+".txt")).write_text("\n".join(rows)+"\n")
            return dict(hash=sha256(frame).hexdigest(), status=rows[4].strip(), name=rows[6].strip(), facts=rows[7].strip(), keys=rows[-2].strip(), last_row=rows[-1].strip())
        guest_tools["wait_for"](lambda: "desktop: 320x200" in read_serial() and measurement+" (measured; equal" in read_serial(), "verified boot", 45)
        time.sleep(.6)
        key("spc")
        for i in range(len(names)):
            if i: key("down")
            key("ctrl", "p")
        key("esc")
        for _ in names:
            key("down")
        for count,menu_row in [(0,None), (1,3), (2,4)]:
            if menu_row is not None:
                key("f2")
                for _ in range(menu_row): key("down")
                key("ret")
                key("esc")
            pages = []
            for i in range(pages_total):
                if i: key("right")
                pages.append(screen(f"{count}-long-{i+1}"))
            assert "".join(page["name"] for page in pages) == long_name
            assert all(digest[:14] in page["facts"] for page in pages)
            key("up")
            short = screen(f"{count}-short")
            assert short["name"] == names[-2]
            key("down")
            cases[str(count)] = dict(pages=pages, short=short)
        key("f10")
        key("ret")
        exit_code = guest.wait(timeout=20)
        assert exit_code == 0
        verdict=read_serial().splitlines()[-1]
        refused_record="register refused ARTIFACT_ADDED" in read_serial()
        if args.length==64:
            assert verdict.startswith("ALL SELF-TESTS PASS.") and not refused_record
        else:
            assert verdict=="1 SELF-TEST(S) FAILED" and refused_record
    finally:
        if guest.poll() is None:
            guest.kill()
            guest.wait()
same = [a["hash"]==b["hash"] for a,b in zip(cases["1"]["pages"],cases["2"]["pages"])]
outcome = dict(source=metadata["source_commit"],tree=metadata["source_tree"],command=cmd,program_sha256=digest,cases=cases,
               pins=args.pins,name_length=args.length,guest_verdict=verdict,register_refused_artifact=refused_record,identical_pages=same,short_control_different=cases["1"]["short"]["hash"]!=cases["2"]["short"]["hash"],exit_code=exit_code)
(out/"observations.json").write_text(json.dumps(outcome,indent=2)+"\n")
print(json.dumps({k:[x["status"] for x in v["pages"]]+[v["short"]["status"]] for k,v in cases.items()}),same)

"""Read real compact Programs frames against adjacent heights and the console-only grant control."""
from pathlib import Path
import hashlib, json, runpy, shutil, subprocess, sys, time
root=Path(__file__).resolve().parent
fixture=root/'queue'
meta=json.loads((fixture/'receipt.json').read_text())
kernel=fixture/'kernel.elf32'
assert hashlib.sha256(kernel.read_bytes()).hexdigest()==meta['inputs']['kernel.elf32']['sha256']
opt=runpy.run_path(str(root/'src/examples/optical-disk-check/check.py'))
decode=runpy.run_path(str(root/'src/examples/tester-cd/check_compact_pins.py'))['read']
glyphs=opt['SCREEN']['kernel_glyphs']()
qemu=str(Path(sys.argv[1]).resolve())
base=root/'programs-rows';base.mkdir()
results=[]
for size,grant in [('320x200','normal'),('320x220','normal'),('320x240','normal'),('320x260','normal'),('640x480','normal'),('320x200','none'),('320x240','none')]:
    out=base/(size+'-'+grant);out.mkdir()
    for name in ['alpha.elf','bravo.elf']:shutil.copyfile(fixture/'rdesk.elf',out/name)
    tail='desktop='+size+' image='+meta['kernel_measurement']+(' grant=none' if grant=='none' else '')
    cmd=[qemu,'-machine','pc','-accel','tcg','-cpu','qemu64','-m','256M','-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(out/'serial.log'),'-kernel',str(kernel),'-append',tail,'-initrd','alpha.elf,bravo.elf']
    def log():return (out/'serial.log').read_text(errors='replace') if (out/'serial.log').is_file() else ''
    with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
        try:
            mon=opt['Monitor'](guest);mon.call('qmp_capabilities')
            def key(*v):
                mon.key(*v);time.sleep(.42)
            def capture(label):
                path=out/(label+'.ppm');last=None
                for _ in range(30):
                    mon.call('screendump',filename=str(path));raw=path.read_bytes()
                    if raw==last:break
                    last=raw;time.sleep(.25)
                else:raise ValueError('unstable '+label)
                rows=decode(raw,glyphs)
                (out/(label+'.txt')).write_text('\n'.join(rows)+'\n')
                return rows,hashlib.sha256(raw).hexdigest()
            opt['wait_for'](lambda:'desktop: ' in log() and meta['kernel_measurement']+' (measured; equal' in log(),'measured desktop',45)
            actual=next(l for l in log().splitlines() if l.startswith('desktop:'))
            time.sleep(.6)
            home,h=capture('home')
            key('spc'); first,ah=capture('alpha')
            key('down'); second,bh=capture('bravo')
            launched=False
            if grant=='normal':
                key('ret')
                opt['wait_for'](lambda:'PARROTS READY' in log(),'queue started',20)
                assert 'starting bravo.elf (' in log()
                launched=True
                key('esc');opt['wait_for'](lambda:'bravo.elf ended DONE: exit 0' in log(),'queue returned',20)
            key('f10');key('ret')
            exit_code=guest.wait(timeout=20)
            assert exit_code==0 and 'ALL SELF-TESTS PASS.' in log()
        finally:
            if guest.poll() is None:guest.kill();guest.wait()
    row=dict(size=size,actual=actual,grant=grant,home_verification=home[3].strip(),verification_row=second[3].strip(),program_row=second[5].strip(),permission_rows=[l.strip() for l in second if 'Access:' in l],first_visible=any('alpha.elf' in l for l in first),second_visible=any('bravo.elf' in l for l in second),selected_frames_identical=ah==bh,second_launched=launched,exit=exit_code,self_tests=sum(l.startswith('  pass ') for l in log().splitlines()),command=cmd)
    results.append(row)
    print(size,grant,row['verification_row'],row['program_row'],row['selected_frames_identical'],flush=True)
(base/'results.json').write_text(json.dumps(results,indent=2)+'\n')

"""Compare the compact Home F1 instructions to actual Right and Down key behavior."""
import json, runpy, hashlib, shutil, subprocess, sys, time
from pathlib import Path
root=Path(__file__).resolve().parent
qemu=str(Path(sys.argv[1]).resolve())
fixture=Path(sys.argv[2]).resolve()
measurement=json.loads((fixture/'receipt.json').read_text())['kernel_measurement']
opt=runpy.run_path(str(root/'src/examples/optical-disk-check/check.py'))
glyphs=opt['SCREEN']['kernel_glyphs']()
decode=runpy.run_path(str(root/'src/examples/tester-cd/check_compact_pins.py'))['read']
for size in ('320x200','800x600'):
    out=root/('help-'+size)
    out.mkdir()
    names=['a'*30+'A'+'z'*29+'.elf','short.elf']
    for name in names:shutil.copyfile(fixture/'rdesk.elf',out/name)
    cmd=[qemu,'-machine','pc','-accel','tcg','-cpu','qemu64','-m','256M','-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(out/'serial.log'),'-kernel',str(fixture/'kernel.elf32'),'-append','desktop='+size+' image='+measurement,'-initrd',','.join(names)]
    def log(): return (out/'serial.log').read_text(errors='replace') if (out/'serial.log').is_file() else ''
    with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
        try:
            mon=opt['Monitor'](guest);mon.call('qmp_capabilities')
            def key(*keys):
                mon.key(*keys);time.sleep(.42)
            def frame(label):
                path=out/(label+'.ppm')
                mon.call('screendump',filename=str(path))
                rows=decode(path.read_bytes(),glyphs)
                (out/(label+'.txt')).write_text('\n'.join(rows)+'\n')
                return rows
            opt['wait_for'](lambda:'desktop: '+size in log() and measurement+' (measured; equal' in log(),'measured desktop',45)
            time.sleep(.6)
            key('spc');key('ctrl','p');key('down');key('ctrl','p');key('esc');key('down')
            initial=frame('first-pin')
            key('f1')
            help_rows=frame('f1')
            assert any('KEYS ON THE DESKTOP' in l for l in help_rows)
            key('esc')
            key('right')
            right=frame('after-right')
            key('down')
            down=frame('after-down')
            if size=='320x200':
                assert 'Place 2/3 | name 1/3' in initial[4] and 'Place 2/3 | name 2/3' in right[4]
                assert down[6].strip()=='short.elf'
            else:
                assert any(names[0] in row for row in initial) and initial==right
                assert any(row.strip()=='short.elf' for row in down)
            key('f10');key('ret')
            code=guest.wait(timeout=20)
            assert code==0 and 'ALL SELF-TESTS PASS.' in log()
        finally:
            if guest.poll() is None:guest.kill();guest.wait()
    result=dict(mode=size,help_rows=[l.strip() for l in help_rows if 'Left/Right' in l or 'Up/Down' in l],same_after_right=initial==right,after_right_status=right[4].strip(),after_down_identity='short.elf',self_tests=sum(l.startswith('  pass ') for l in log().splitlines()),exit=code,command=cmd)
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(size,result['help_rows'],flush=True)

"""Validate original frames and reject copies with an independently erased identity or verification row."""
from pathlib import Path
import json,runpy
root=Path(__file__).resolve().parent
out=root/'programs-rows'
rows=json.loads((out/'results.json').read_text())
r={(x['size'],x['grant']):x for x in rows}
for item in rows:
    assert item['actual'].startswith('desktop: '+item['size']+' ') and item['exit']==0 and item['self_tests']==72
    if item['grant']=='normal':assert item['second_launched']
assert r['320x200','normal']['verification_row'].startswith('Access:') and r['320x200','normal']['second_visible']
assert r['320x200','none']['verification_row'].startswith('Access: console only') and '71 self' in r['320x200','none']['verification_row']
for grant in ('normal','none'):
    item=r['320x240',grant]
    assert item['program_row'].startswith('Access:') and not item['first_visible'] and not item['second_visible'] and item['selected_frames_identical']
for mode in ('320x220','320x260','640x480'):
    item=r[mode,'normal']
    assert item['first_visible'] and item['second_visible'] and item['verification_row'].startswith('Verified at start:') and not item['selected_frames_identical']
opt=runpy.run_path(str(root/'src/examples/optical-disk-check/check.py'))
decode=runpy.run_path(str(root/'src/examples/tester-cd/check_compact_pins.py'))['read']
glyphs=opt['SCREEN']['kernel_glyphs']()
raw=(out/'320x260-normal/bravo.ppm').read_bytes()
magic,size,depth,pixels=raw.split(b'\n',3)
w,h=map(int,size.split());stride=w*3*20
assert (w,h)==(320,260)
def check(frame):
    rr=decode(frame,glyphs)
    return {'verification':'Verified at start:' in rr[3],'selection':'bravo.elf' in rr[5]}
observed={'original':check(raw)}
assert all(observed['original'].values())
for label,line in [('verification',3),('selection',5)]:
    body=bytearray(pixels);body[line*stride:(line+1)*stride]=pixels[-stride:]
    frame=b'\n'.join((magic,size,depth,body))
    (out/('altered-erased-'+label+'.ppm')).write_bytes(frame)
    observed[label]=check(frame)
    assert not observed[label][label] and sum(observed[label].values())==1
(out/'altered-controls.json').write_text(json.dumps(observed,indent=2)+'\n')

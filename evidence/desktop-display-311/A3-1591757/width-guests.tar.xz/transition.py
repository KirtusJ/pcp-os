from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,sys
root=Path(__file__).resolve().parent
base=root.parent/'a3-1591757'
qemu=Path('/workspace/scratch/7c7df1723510/work/emulator/qemu-system-x86_64')
def run(c):
    w,p=c
    case=f'published-{w}-{p}-64'
    cmd=[str(base/'delegate-build/release/pcp-delegate'),str(root/'test.redb'),case,case,'--',sys.executable,str(root/'test_status.py'),str(base/'src'),str(base/'queue'),str(qemu),str(root/case),str(w),str(p),'64']
    with (root/(case+'.log')).open('wb') as output:
        code=subprocess.run(cmd,cwd=root,stdout=output,stderr=output).returncode
    print(case,code,flush=True)
    return code
with ThreadPoolExecutor(max_workers=3) as pool:
    codes=list(pool.map(run,[(528,2),(536,2),(552,16)]))
raise SystemExit(any(codes))

from pathlib import Path
import hashlib,json,runpy,shutil,subprocess
root=Path(__file__).resolve().parent
fixture=root/'patched';fixture.mkdir()
shutil.copyfile(root/'kernel.elf32',fixture/'kernel.elf32')
shutil.copyfile(root.parent/'a3-1591757/queue/rdesk.elf',fixture/'rdesk.elf')
def git(*args):return subprocess.check_output(['git','-C',str(root/'src'),*args],text=True).strip()
received=json.loads((root.parent/'a3-1591757/queue/receipt.json').read_text())
r=dict(source_commit=git('rev-parse','HEAD'),base_tree=git('rev-parse','HEAD^{tree}'),patch_git_blob=git('hash-object',str(root/'compact-status.patch')),patched_source_blob=git('hash-object','PCP_OS_Rust/crates/pcpos-kernel/src/session.rs'),provenance='Local comparison build of the published commit plus B3’s unmerged reference patch. Queue Desk came from the hosted tester CD for the base commit.',inputs={n:{'sha256':hashlib.sha256((fixture/n).read_bytes()).hexdigest()} for n in ('kernel.elf32','rdesk.elf')},kernel_measurement=runpy.run_path(str(root/'src/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure']((fixture/'kernel.elf32').read_bytes()))
assert r['inputs']['rdesk.elf']['sha256']==received['inputs']['rdesk.elf']['sha256']
(fixture/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')

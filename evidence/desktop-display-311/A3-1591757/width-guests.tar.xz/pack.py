from pathlib import Path
import json,hashlib,tarfile,shutil,re,runpy
root=Path(__file__).resolve().parent
base=root.parent/'a3-1591757'
sha=lambda v:hashlib.sha256(v).hexdigest()
opt=runpy.run_path(str(base/'src/examples/optical-disk-check/check.py'))
glyphs=opt['SCREEN']['kernel_glyphs']()
read=runpy.run_path(str(base/'src/examples/tester-cd/check_compact_pins.py'))['read']
rows=[]
files=[root/n for n in ['test_status.py','prepare.py','run_matrix.py','transition.py','compact-status.patch','patched/receipt.json','workers.json','matrix.log','transition.log','build_kernel.sh','compiler.txt','build.log','pack.py']]
shutil.copyfile(base/'queue/receipt.json',root/'published-CD-receipt.json')
files.append(root/'published-CD-receipt.json')
for fn in sorted(root.glob('*/result.json')):
    d=fn.parent;r=json.loads(fn.read_text())
    build=d.name.split('-')[0]
    if build not in ('published','reference'):continue
    width=int(r['geometry'].split('x')[0]);pins=r['pins'];n=r['length']
    records=[]
    for cnt,pages in r['cases'].items():
        assert len(pages)==r['pages']
        for i,v in enumerate(pages,1):
            f=d/f'widgets{cnt}-p{i}.ppm'
            raw=f.read_bytes()
            assert sha(raw)==v['frame']
            words=(d/f'widgets{cnt}-p{i}.txt').read_text().splitlines()
            assert words[4].strip()==v['status'] and words[-1].strip()==v['footer']
            if i==1 and cnt=='2':
                decoded=read(raw,glyphs)
                assert decoded[4].strip()==v['status'] and decoded[-1].strip()==v['footer']
            records.append(('Left/Right' in v['status']) or ('<-' in v['status'] and '->' in v['status']))
        assert ''.join(v['name'] for v in pages)==('a'*30+'B'+('abcdefghijklmnopqrstuvwxyz'*9)[:n-35]+'.elf')
    has=all(records)
    assert len(set(records))==1 and has is r['complete_hint_each_page']
    if build=='published':
        expected=(width in (432,536,560,640))
    else:expected=(width==320)
    assert has==expected,(d.name,has)
    serial=(d/'serial.log').read_text()
    failed='register refused ARTIFACT_ADDED' in serial
    assert failed==(n>64) and r['exit']==0
    assert (r['guest_verdict']=='1 SELF-TEST(S) FAILED' if failed else r['guest_verdict'].startswith('ALL SELF-TESTS PASS.'))
    assert r['refusal']['refusal']
    rows.append(dict(build=build,mode=r['geometry'],place=f'{pins+1}/{pins+1}',filename_bytes=n,pages=r['pages'],complete_directions=has,first_status=r['cases']['0'][0]['status'],last_status=r['cases']['0'][-1]['status'],counts=[r['cases'][str(i)][0]['footer'] for i in range(3)],normal_exit=r['exit']==0,guest_failed_checks=int(failed)))
    files.extend(f for f in d.iterdir() if f.suffix in ('.ppm','.txt','.json','.log'))
    files.append(root/(d.name+'.log'))
assert len(rows)==14
report=dict(source='15917575b9e205e9042da2840492751945f32fff',reference_patch_blob='2b22004fbe3bc87cdc98bc55eb32a78c701cd0c3',hosted_kernel=sha((base/'queue/kernel.elf32').read_bytes()),comparison_kernel=sha((root/'patched/kernel.elf32').read_bytes()),cases=rows,scope='QEMU emulated compact Home, 200 pixels high, English labels and the specified widths. The reference build is a local comparison; it is not a nominated head.')
(root/'width-readback.json').write_text(json.dumps(report,indent=2)+'\n')
files.append(root/'width-readback.json')
manifest=root/'SHA256SUMS'
manifest.write_text(''.join(sha(f.read_bytes())+'  '+str(f.relative_to(root))+'\n' for f in sorted(set(files))))
with tarfile.open(root/'width-guests.tar.xz','w:xz',preset=3) as t:
    for f in sorted(set(files+[manifest])):t.add(f,arcname=f.relative_to(root))
with tarfile.open(root/'width-guests.tar.xz') as t:
    for m in t:
        assert hashlib.file_digest(t.extractfile(m),'sha256').hexdigest()==sha((root/m.name).read_bytes())
print(len(rows),sum(r['complete_directions'] for r in rows),sha((root/'width-guests.tar.xz').read_bytes()))

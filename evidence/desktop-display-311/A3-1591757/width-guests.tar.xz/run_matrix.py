from pathlib import Path
import json,sys,subprocess,concurrent.futures
root=Path(__file__).resolve().parent
base=root.parent/'a3-1591757'
qemu=Path('/workspace/scratch/7c7df1723510/work/emulator/qemu-system-x86_64')
matrix=[('published',440,2,64),('reference',440,2,64),('published',432,2,64),('published',640,2,64),('reference',320,16,255),('reference',320,16,253),('reference',320,16,252),('published',320,16,253),('published',480,16,64),('published',560,16,64),('published',640,16,64)]
def run(case):
    build,width,pins,length=case
    label=f'{build}-{width}-{pins}-{length}'
    source,fixture=(base/'src',base/'queue') if build=='published' else (root/'src',root/'patched')
    cmd=[str(base/'delegate-build/release/pcp-delegate'),str(root/'test.redb'),label,label,'--',sys.executable,str(root/'test_status.py'),str(source),str(fixture),str(qemu),str(root/label),str(width),str(pins),str(length)]
    with (root/(label+'.log')).open('wb') as log:
        code=subprocess.run(cmd,stdout=log,stderr=log).returncode
    print(label,code,flush=True)
    return dict(case=label,exit=code)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,matrix))
(root/'workers.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(r['exit'] for r in results))

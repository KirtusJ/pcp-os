"""Calculate assertions from originals. Keep the signed-off cases separate from failures at the longer input."""
import sys,json
from pathlib import Path
from review_lib import root,source,tree,read,write,digest,files_in,tar
def bits(folder):
    return files_in(folder,{'.ppm','.txt','.log','.json'})
def grab(*names):
    return [root/n for n in names]
if sys.argv[1]=='boundary':
    result={}
    files=[]
    for mode in ['320x200','640x480','bar','dock']:
        folder='guest-'+mode
        r=read(folder+'/observations.json')
        assert r['qemu_exit']==0 and r['self_test_pass_lines']==72 and not r['failures']
        assert all(ok is True for _,ok in r['checks'])
        assert all(digest(root/folder/(label+'.ppm'))==expected for label,expected in r['frames'].items())
        assert [len(x['name']) for x in r['launches']]==[32,33,63,64,64]
        result[mode]=dict(checks=len(r['checks']),launches=r['launches'],self_tests=r['self_test_pass_lines'],exit=r['qemu_exit'])
        files+=bits(folder)
    write('launch-readback.json',dict(source=source,tree=tree,hosted_kernel_sha256=digest(root/'queue/kernel.elf32'),modes=result))
    files+=grab('guest_names.py','read_discs.py','artifacts.json','plain/receipt.json','queue/receipt.json','hosted-pins.json','launch-readback.json')
    tar('launch-guests.tar.xz',files)
elif sys.argv[1]=='widgets':
    results={}
    files=[]
    for zone in ['last14','last16','wide255','extended-255-local']:
        r=read(zone+'/observations.json');slots=r['pins']+1
        for cnt,c in r['cases'].items():
            n=int(cnt)
            assert c['short']['name']==f'desk-{slots-2:02}.elf'
            for page,actual in enumerate(c['pages'],1):
                original=root/zone/(cnt+'-long-'+str(page)+'.ppm')
                assert digest(original)==actual['hash']
                assert actual['keys']=='Enter open  F1 keys  F10 off'
                assert actual['last_row']==(f'{n} widget line(s) not shown' if n else '')
                content=f'Place {slots}/{slots} | name {page}/{len(c["pages"])} <- ->'
                if r['name_length']==64: assert actual['status']==content
                else: assert actual['status'].endswith('..') and '->' not in actual['status']
            if r['name_length']==64: assert r['guest_verdict'].startswith('ALL SELF-TESTS PASS.')
            else: assert r['register_refused_artifact'] and r['guest_verdict']=='1 SELF-TEST(S) FAILED'
        assert not any(r['identical_pages'])
        results[zone]=dict(pins=r['pins'],place=slots,length=r['name_length'],verdict=r['guest_verdict'],register_refused=r['register_refused_artifact'],exit=r['exit_code'],first_paged_row=r['cases']['1']['pages'][0]['status'],last_paged_row=r['cases']['1']['pages'][-1]['status'],last_rows_by_count={n:v['pages'][0]['last_row'] for n,v in r['cases'].items()})
        files+=bits(zone)
    write('widget-readback.json',dict(source=source,tree=tree,runs=results))
    files+=grab('widgets.py','queue/receipt.json','local-run-inputs.json','widget-readback.json')
    tar('widget-pages.tar.xz',files)
elif sys.argv[1]=='other':
    files=bits('programs-rows')+bits('help-320x200')+bits('help-800x600')+grab('help_keys.py','programs_rows.py','check_rows.py','queue/receipt.json')
    assert read('help-320x200/result.json')['same_after_right'] is False and read('help-800x600/result.json')['same_after_right'] is True
    assert 'choose among' in str(read('help-800x600/result.json')['help_rows'])
    tar('programs-and-help.tar.xz',files)
elif sys.argv[1]=='replay':
    r=read('replay-pins/summary.json')
    assert r['passed'] and not r['problems'] and r['results']['aliases-320x200']['hidden_widgets_row']=='2 widget line(s) not shown'
    assert r['kernel_measurement']==read('hosted-pins.json')['kernel_measurement']
    files=bits('replay-pins')+grab('replay.log','replay_stdio.py','replay-transport.diff','src/examples/tester-cd/check_compact_pins.py','worker-results.json','worker-status.json','launch_desktop.py','review_lib.py','pack_desktop.py')
    tar('replay-and-workers.tar.xz',files)

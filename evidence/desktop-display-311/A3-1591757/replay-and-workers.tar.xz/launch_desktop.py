import concurrent.futures
import json
from pathlib import Path
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
qemu='/workspace/scratch/7c7df1723510/work/emulator/qemu-system-x86_64'
fixture=root/'queue'
while not (fixture/'rdesk.elf').is_file():
    time.sleep(3)
src=str(root/'src')
kernel=str(fixture/'kernel.elf32')
elf=str(fixture/'rdesk.elf')
receipt=str(fixture/'receipt.json')
tasks=[]
for mode in ('320x200','640x480','bar','dock'):
    tasks.append((mode,[str(root/'guest_names.py'),src,kernel,elf,qemu,str(root/('guest-'+mode)),mode]))
for label,pins,length in [('last14',14,64),('last16',16,64),('wide255',16,255)]:
    tasks.append((label,[str(root/'widgets.py'),src,kernel,elf,receipt,qemu,str(root/label),'--pins',str(pins),'--length',str(length)]))
tasks.append(('help',[str(root/'help_keys.py'),qemu,str(fixture)]))
def run(task):
    label,args=task
    cmd=[str(root/'delegate-build/release/pcp-delegate'),str(root/'a3-desk.redb'),'qa-'+label,label,'--',sys.executable,*args]
    with (root/(label+'.worker.log')).open('wb') as log:
        status=subprocess.run(cmd,stdout=log,stderr=log,cwd=root).returncode
    print(label,status,flush=True)
    return dict(label=label,command=cmd,exit=status)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    out=list(pool.map(run,tasks))
(root/'worker-results.json').write_text(json.dumps(out,indent=2)+'\n')
raise SystemExit(any(row['exit'] for row in out))

set -eu
d=$(cd "$(dirname "$0")" && pwd)
kind=$1
shift
kernel="$d/hosted/kernel.elf32"
program="$d/hosted/rdesk.elf"
if [ "$kind" = local ]; then kernel="$d/local.elf32"; program="$d/../display-1591757/hosted/rdesk.elf"; fi
q=/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64
for s in "$@"; do
 w=${s%%-*}; rest=${s#*-}; len=${rest%-*}; pins=${rest##*-}
 python3 -IB "$d/drivers/width.py" "$d/source" "$kernel" "$program" "$d/$kind/$s" "$q" "$w" "$len" "$pins"
done

"""Verify recorded guest frames, their text, the hosted artifact receipt and the max-name control."""
import hashlib
import json
import re
import sys
from pathlib import Path
from PIL import Image, ImageChops

root=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent
hosted=root/'hosted'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rev='8642b2357531c4590fa2c23b32e424e34135515d'
receipt=read(hosted/'receipt.json')
assert receipt['source_commit']==rev and receipt['uncommitted_changes'] is False
origin=read(hosted/'origin.json')
assert receipt['source_tree']==origin['tree'] and origin['commit']==rev
for n in ['kernel.elf32','rdesk.elf','pcp-os-tester.iso']:
 p=hosted/n
 if p.is_file():assert sha(p)==(receipt['iso_sha256'] if n.endswith('iso') else receipt['on_disc'][n]['sha256'])
pin='a'*30+'A'+'z'*29+'.elf'
program=receipt['on_disc']['rdesk.elf']['sha256']
def widget(d,pins):
    m=read(d/'result.json')
    assert m['source']==rev and m['kernel_sha256']==receipt['on_disc']['kernel.elf32']['sha256'] and m['program_sha256']==program
    assert m['all_pass'] and m['passes']==72 and m['exit']==0 and m['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    assert (d/'serial.txt').read_text().count('program-02.elf ended DONE: exit 0')==3
    assert all(sha(d/(k+'.ppm'))==v for k,v in m['frames'].items())
    rows=lambda n:(d/(n+'.txt')).read_text().splitlines()
    with Image.open(d/'initial.ppm') as im: narrow=im.width==320
    if not narrow:
        for label,ch in [('a','A'),('b','B')]:
            page=rows(label+'-part-1');i=page.index('  Enter starts')+1
            assert ''.join(x.strip() for x in page[i:i+2])==pin.replace('A',ch)
            assert any(program[:16] in r for r in page)
            assert sum(' DONE program-02.elf' in r for r in page)==3
            assert any('memory ' in r for r in page) and any('Session files' in r for r in page)
    else:
        for short,count in [('one-widget-short',1),('five-widget-short',5)]:
            assert any(r.strip()==f'{count} widget line(s) not shown' for r in rows(short))
        for label,ch,place in [('a','A',2 if pins==7 else 13),('b','B',4 if pins==7 else 15)]:
            texts=[]
            for part in (1,2,3):
                one = (['one-widget-long','one-widget-long-p2','one-widget-long-p3'][part-1] if label=='a' else f'one-b-part-{part}')
                five=f'{label}-part-{part}'
                for name,count in [(one,1),(five,5)]:
                    row=rows(name)
                    assert row[4].strip()==f'Place {place}/{pins+1} | name {part}/3 <- ->'
                    assert row[7].strip()==f'53 KiB sha {program[:15]}..'
                    assert row[8].strip()=='Enter open  F1 keys  F10 off' and row[9].strip()==f'{count} widget line(s) not shown'
                with Image.open(d/(one+'.ppm')) as x,Image.open(d/(five+'.ppm')) as y:
                    bounds=ImageChops.difference(x,y).getbbox()
                assert bounds and bounds[1]>=180 and bounds[3]<=200
                texts.append(rows(five)[6].strip())
            assert ''.join(texts)==pin.replace('A',ch)
        for s in ['refused-a','refused-a-part-2','refused-a-part-1']:assert 'Not started: not admitted' in rows(s)[2]
        assert 'Not started' not in rows('short-after-refused-a')[2]
    for i in range(1,pins+1):
        r=rows(f'chosen-{i}')
        assert any('Enter open' in x for x in r)
        if narrow:assert f'Place {i+1}/{pins+1}' in r[4]
    return f'{d.name}: {pins} pins; three completed Queue Desk sessions'
for name,n in [('seven320',7),('seven640',7),('fourteen320',14)]:print(widget(hosted/name,n))
cases=[('320x200',n,1) for n in (0,1,3,31)]+[('800x600',23,1),('1024x768',31,1),('1280x720',31,1),('1280x960',31,2)]
for g,n,scale in cases:
    d=hosted/f'files-{g}-{n}-{scale}'
    j=read(d/'report.json')
    assert j['measurement']==receipt['kernel_measurement'] and j['kernel_sha256']==receipt['on_disc']['kernel.elf32']['sha256']
    assert j['commit']==rev and j['count']==n==j['unique_names_reached'] and j['ui_scale']==scale
    assert j['passes']==72 and j['exit']==0 and j['shutdown']['guest']
    assert all(sha(d/(k+'.ppm'))==v['sha256'] for k,v in j['frames'].items())
    assert j['frames']['home']['sha256']==j['frames']['restored']['sha256']
    print(d.name,n,'names reached; identical selected Home restored')

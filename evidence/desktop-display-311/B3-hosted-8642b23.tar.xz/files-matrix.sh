set -eu
d=$(cd "$(dirname "$0")" && pwd)
q=/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64
for test in 320x200-0-1 320x200-1-1 320x200-3-1 320x200-31-1 800x600-23-1 1024x768-31-1 1280x720-31-1 1280x960-31-2; do
    g=${test%%-*}; rest=${test#*-}; count=${rest%-*}; scale=${rest##*-}
    python3 -IB "$d/drivers/files.py" "$d/source" "$d/hosted/kernel.elf32" "$q" "$d/hosted/files-$test" "$g" "$count" --scale "$scale"
done

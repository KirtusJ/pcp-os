"""Check the downloaded tester-CD bytes and their measured payloads against the clean hosted receipt."""
import hashlib
import json
from pathlib import Path
import runpy
import sys

d=Path(__file__).resolve().parent
hosted=d/'hosted'
origin=json.loads((hosted/'origin.json').read_text())
receipt=json.loads((hosted/'receipt.json').read_text())
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
assert receipt['source_commit']==origin['commit']=='8642b2357531c4590fa2c23b32e424e34135515d'
assert receipt['uncommitted_changes'] is False
assert receipt['source_tree']==origin['tree']
for name,key in [('queue.zip','iso_zip_sha256'),('evidence.zip','evidence_zip_sha256')]:
    if (hosted/name).exists():assert sha(hosted/name)==origin[key]
for name in ['kernel.elf32','rdesk.elf','pcp-os-tester.iso']:
    if (hosted/name).exists():
        assert sha(hosted/name)==(receipt['iso_sha256'] if name.endswith('iso') else receipt['on_disc'][name]['sha256'])
measure=runpy.run_path(str(d/'source/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure']
if (hosted/'kernel.elf32').exists():
    assert measure((hosted/'kernel.elf32').read_bytes())==receipt['kernel_measurement']
print(receipt['source_commit'],receipt['source_tree'],receipt['on_disc']['kernel.elf32']['sha256'],receipt['kernel_measurement'])

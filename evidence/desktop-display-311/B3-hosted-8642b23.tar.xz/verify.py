"""Verify the published candidate, reference, full-screen captures and guest records."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
def run(*args):
    subprocess.run([sys.executable,'-IB',*map(str,args)],check=True)
run(root/'verify_origin.py')
receipt=json.loads((root/'hosted/receipt.json').read_text())
for variant in ('hosted','compatible','local'):
    for path in (root/variant).glob('*-*-*/result.json'):
        r=json.loads(path.read_text())
        assert r['program_sha256']==receipt['on_disc']['rdesk.elf']['sha256']
        if variant=='hosted':
            assert r['kernel_sha256']==receipt['on_disc']['kernel.elf32']['sha256'] and r['measurement']==receipt['kernel_measurement']
        if variant in ('hosted','local'):
            assert r['source_session_blob']=='8742a1a1af3c6881b74a1f2a31adb68006269e18'
        elif variant=='compatible':
            source=(root/'compatible/source/PCP_OS_Rust/crates/pcpos-kernel/src/session.rs').read_bytes()
            assert r['source_session_blob']==hashlib.sha1(f'blob {len(source)}\0'.encode()+source).hexdigest()
run(root/'verify_widths.py',root/'hosted',root/'source','candidate')
run(root/'verify_widths.py',root/'compatible',root/'source','compatible')
run(root/'verify_controls.py',root)
for mode in ('440-64-2','320-255-16'):
    d=root/'local'/mode
    r=json.loads((d/'result.json').read_text())
    assert r['exit']==0 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    for label,sha in r['frames'].items():
        assert hashlib.sha256((d/(label+'.ppm')).read_bytes()).hexdigest()==sha
        if label.startswith(('one-','off-')):
            ref=root/'hosted'/mode/(label+'.txt')
            assert (d/(label+'.txt')).read_text().splitlines()[4]==ref.read_text().splitlines()[4]
    print('Independent local build agrees on',mode)

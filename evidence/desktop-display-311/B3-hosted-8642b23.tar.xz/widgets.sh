set -eu
d=$(cd "$(dirname "$0")" && pwd)
for slot in seven320 fourteen320 seven640; do
 set --
 mode=320x200
 if [ "$slot" = fourteen320 ]; then set -- --fourteen; fi
 if [ "$slot" = seven640 ]; then mode=640x480; fi
 python3 -IB "$d/drivers/widgets.py" "$d/source" "$d/hosted/kernel.elf32" "$d/hosted/rdesk.elf" "$d/hosted/$slot" --qemu /workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64 --mode "$mode" "$@"
done

.intel_syntax noprefix
.text
lea rdi, [rip + name1]
call save
mov eax,60
xor edi,edi
syscall
save:
mov eax,2
mov esi,577
mov edx,420
syscall
test rax,rax
js failed
mov rdi,rax
mov eax,1
lea rsi,[rip + data]
mov edx,1024
syscall
cmp rax,1024
jne failed
mov eax,3
syscall
test rax,rax
jne failed
ret
failed:
mov eax,60
mov edi,1
syscall
data: .zero 1024
name1: .asciz "file01.txt"

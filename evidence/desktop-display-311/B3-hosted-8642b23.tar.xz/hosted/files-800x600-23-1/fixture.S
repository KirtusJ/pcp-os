.intel_syntax noprefix
.text
lea rdi, [rip + name1]
call save
lea rdi, [rip + name2]
call save
lea rdi, [rip + name3]
call save
lea rdi, [rip + name4]
call save
lea rdi, [rip + name5]
call save
lea rdi, [rip + name6]
call save
lea rdi, [rip + name7]
call save
lea rdi, [rip + name8]
call save
lea rdi, [rip + name9]
call save
lea rdi, [rip + name10]
call save
lea rdi, [rip + name11]
call save
lea rdi, [rip + name12]
call save
lea rdi, [rip + name13]
call save
lea rdi, [rip + name14]
call save
lea rdi, [rip + name15]
call save
lea rdi, [rip + name16]
call save
lea rdi, [rip + name17]
call save
lea rdi, [rip + name18]
call save
lea rdi, [rip + name19]
call save
lea rdi, [rip + name20]
call save
lea rdi, [rip + name21]
call save
lea rdi, [rip + name22]
call save
lea rdi, [rip + name23]
call save
mov eax,60
xor edi,edi
syscall
save:
mov eax,2
mov esi,577
mov edx,420
syscall
test rax,rax
js failed
mov rdi,rax
mov eax,1
lea rsi,[rip + data]
mov edx,1024
syscall
cmp rax,1024
jne failed
mov eax,3
syscall
test rax,rax
jne failed
ret
failed:
mov eax,60
mov edi,1
syscall
data: .zero 1024
name1: .asciz "file01.txt"
name2: .asciz "file02.txt"
name3: .asciz "file03.txt"
name4: .asciz "file04.txt"
name5: .asciz "file05.txt"
name6: .asciz "file06.txt"
name7: .asciz "file07.txt"
name8: .asciz "file08.txt"
name9: .asciz "file09.txt"
name10: .asciz "file10.txt"
name11: .asciz "file11.txt"
name12: .asciz "file12.txt"
name13: .asciz "file13.txt"
name14: .asciz "file14.txt"
name15: .asciz "file15.txt"
name16: .asciz "file16.txt"
name17: .asciz "file17.txt"
name18: .asciz "file18.txt"
name19: .asciz "file19.txt"
name20: .asciz "file20.txt"
name21: .asciz "file21.txt"
name22: .asciz "file22.txt"
name23: .asciz "file23.txt"

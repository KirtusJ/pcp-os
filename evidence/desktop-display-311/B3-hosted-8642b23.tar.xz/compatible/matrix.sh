set -eu
d=$(cd "$(dirname "$0")" && pwd)
for scenario in "$@"; do
  width=${scenario%%-*}; rest=${scenario#*-}; length=${rest%-*}; pins=${rest##*-}
  python3 -IB "$d/../drivers/width.py" "$d/source" "$d/kernel.elf32" "$d/../hosted/rdesk.elf" "$d/$scenario" /workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64 "$width" "$length" "$pins"
done

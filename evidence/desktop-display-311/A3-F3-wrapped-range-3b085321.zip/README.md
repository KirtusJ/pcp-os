# F3 range when a filename continues from the preceding page

A 640×480 direct-kernel QEMU guest created and reopened 31 files. The sixteenth filename takes three 44-column lines and starts on the first page’s last row. The 31 reopened names in the serial transcript match the body rows in order. Each fixture file holds one verified byte.

| Capture | Heading | Body |
|---|---|---|
| `first` | 1–16 of 31 | Begins with file 1 and ends on the first line of file 16. |
| `page-down` | 17–30 of 31 | Starts with the middle and end of file 16. The last row is file 30. |
| `down-at-end` | 17–31 of 31 | Starts with the end of file 16. The last row is file 31. |
| `up-to-full-name` | 16–29 of 31 | Displays all 101 characters of file 16 together. |
| `page-up` | 1–16 of 31 | Restores the original first-page pixels. |

The reported lower bound omits the visible file fragment at the top of a scrolled page. The display counts file-start lines when it derives the heading. Up can recover the complete filename. The recorded key sequence is Page Down, Down, Down at the boundary, Up, Up, Page Up. Esc returned the original Home pixels. The guest reported 71 startup passes, one final register pass, guest shutdown and QEMU exit 0.

The exact source was `3b085321a6d24142883133415a112dee260d423f`. The CD and build-receipt archives were checked against their published SHA-256 digests. The original ISO matched its receipt, the extracted ELF matched the receipt’s on-disc kernel hash, and the separately computed running-image measurement matched the serial transcript. The captured guest booted this kernel directly with `-kernel` plus a temporary user program via `-initrd`. This run used a volatile session store, QEMU 10.0.13 with TCG, 128 MiB, standard VGA, and no network or disk.

- [Tester CD build](https://github.com/KirtusJ/pcp-os/actions/runs/44897645699)
- [One-app tester CD artifact](https://github.com/KirtusJ/pcp-os/actions/runs/44897645699/artifacts/14704748262) · ZIP SHA-256 `bb66334f93fe4f3a7e4e0a7a9147bd99289a0d8c9dba89e3aaa9a29dcce1e99b`
- [Original build receipt in tester evidence](https://github.com/KirtusJ/pcp-os/actions/runs/44897645699/artifacts/14704499249) · ZIP SHA-256 `a0224fb316e51b1810a3311bec187208527ef0dab37e4257773a18814b03dd07`
- [F3 code at the observed commit](https://github.com/KirtusJ/pcp-os/blob/3b085321a6d24142883133415a112dee260d423f/PCP_OS_Rust/crates/pcpos-kernel/src/session.rs#L675-L691)

With the exact checkout at `src/`, verify and reproduce on Linux:

```sh
sha256sum --check SHA256SUMS
python3 observe.py "$(command -v qemu-system-x86_64)" repeat --source src
```

The observer captures after matching the complete 16-line body. It extracts the heading independently and preserves P6 and decoded rows. Its final assertions identify the observed behavior at this commit. To rebuild the benign guest fixture with GCC 14.2 and GNU ld 2.44:

```sh
gcc -Os -ffreestanding -fno-stack-protector -fno-asynchronous-unwind-tables -fpie -c wrapped.c -o wrapped.o
ld -T src/store/games/flux-rink/guest.ld --build-id=none -s -o wrapped.elf wrapped.o
```

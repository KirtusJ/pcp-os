"""Read F3 headers and body independently across a split filename, from actual QEMU P6 frames."""
import argparse, hashlib, json, re, runpy, subprocess, time
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('qemu', type=Path);p.add_argument('output',type=Path);p.add_argument('--source',type=Path,default=Path(__file__).resolve().parent/'src')
args=p.parse_args()
root=Path(__file__).resolve().parent
out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
screen=runpy.run_path(str(args.source/'examples/tester-cd/check.py'))
monitor_class=runpy.run_path(str(args.source/'examples/optical-disk-check/check.py'))['Monitor']
measure=runpy.run_path(str(args.source/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure']
sha=lambda data:hashlib.sha256(data).hexdigest()
font=screen['kernel_glyphs']()
names=json.loads((root/'names.json').read_text());assert len(names)==31
lines=[(index+1,part,chunk==0) for index,name in enumerate(names) for chunk,part in enumerate([name[i:i+44] for i in range(0,len(name),44)])]
serial=out/'serial.txt'
kernel=root/'kernel.elf32'; exe=root/'wrapped.elf'
receipt=json.loads((root/'receipt.json').read_text())
src_head=subprocess.check_output(['git','-C',str(args.source),'rev-parse','HEAD'],text=True).strip()
kernel_sha=sha(kernel.read_bytes());measurement=measure(kernel.read_bytes())
assert src_head==receipt['source_commit'] and measurement==receipt['kernel_measurement'] and kernel_sha==receipt['on_disc']['kernel.elf32']['sha256']
cmd=[str(args.qemu.resolve()),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','128M','-kernel',str(kernel),'-initrd',exe.name,'-append',f'image={measurement} desktop=640x480','-vga','std','-display','none','-nic','none','-serial','file:'+str(serial),'-monitor','none','-qmp','stdio','-no-reboot']
def until(fn,label):
    end=time.monotonic()+40
    while True:
        matches=fn()
        if matches:return matches
        if time.monotonic()>end:raise RuntimeError(label)
        time.sleep(.1)
with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        qmp=monitor_class(vm);qmp.call('qmp_capabilities')
        def key(code):
            qmp.key(code);time.sleep(.35)
        def capture(tag,predicate):
            f=out/(tag+'.ppm')
            def dump():
                qmp.call('screendump',filename=str(f))
                raw=f.read_bytes()
                if raw[:15]!=b'P6\n640 480\n255\n' or len(raw)!=640*480*3+15:return
                rows=screen['read_screen'](raw,font)
                if rows and predicate(rows,raw):
                    (out/(tag+'.rows.txt')).write_text('\n'.join(rows)+'\n')
                    return rows,raw
            return until(dump,tag)
        until(lambda:serial.exists() and 'desktop: 640x480' in serial.read_text(),'startup')
        time.sleep(.5);key('spc')
        capture('launcher',lambda r,b:any(exe.name in row for row in r))
        key('ret')
        until(lambda:'wrapped.elf ended DONE: exit 0' in serial.read_text(),'fixture')
        key('esc')
        _,home=capture('home',lambda r,b:any('F1 keys' in row for row in r) and not any('wrapped.elf' in row for row in r))
        key('f3')
        observations=[]
        def page(tag,top):
            expected=lines[top:top+16]
            wanted=[([part,'1','KiB'] if first else [part]) for _,part,first in expected]
            rows,raw=capture(tag,lambda r,b:r[1].strip().startswith('FILES:') and [line.strip().split() for line in r[4:20]]==wanted)
            m=re.fullmatch(r'  FILES: showing (\d+) to (\d+) of (\d+), 1 KiB',rows[1])
            assert m and int(m[3])==len(names) and 'Page Up/Page Down' in rows[-2]
            observations.append(dict(frame=tag,sha256=sha(raw),heading=rows[1].strip(),stated=[int(m[1]),int(m[2])],visible=[expected[0][0],expected[-1][0]],first_body_row=rows[4].strip(),last_body_row=rows[19].strip()))
            return raw
        first=page('first',0)
        key('pgdn');split=page('page-down',16)
        key('down');last=page('down-at-end',17)
        key('down');assert page('bottom-again',17)==last
        key('up');assert page('up-to-split',16)==split
        key('up');full=page('up-to-full-name',15)
        key('pgup');assert page('page-up',0)==first
        key('esc');capture('home-returned',lambda r,b:b==home)
        key('f10');capture('power',lambda r,b:r[1].strip()=='POWER OFF' and 'Enter switch off' in r[-2]);key('ret')
        while not any(e['event']=='SHUTDOWN' for e in qmp.events):
            msg=qmp.read()
            if 'event' in msg:qmp.events.append(msg)
        assert vm.wait(timeout=20)==0 and any(e.get('event')=='SHUTDOWN' and e.get('data')=={'guest':True,'reason':'guest-shutdown'} for e in qmp.events)
        log=serial.read_text()
        assert re.findall(r'^readback (.+)$',log,re.M)==names
        assert sum(l.startswith('  pass ') for l in log.splitlines())==72 and 'ALL SELF-TESTS PASS.' in log
        assert measurement+' (measured; equal to the value the loader named)' in log
        assert f'starting wrapped.elf ({exe.stat().st_size} bytes, SHA-256 {sha(exe.read_bytes())})' in log
        assert [o['stated'] for o in observations]==[[1,16],[17,30],[17,31],[17,31],[17,30],[16,29],[1,16]]
        assert [o['visible'] for o in observations]==[[1,16],[16,30],[16,31],[16,31],[16,30],[16,29],[1,16]]
        result=dict(source=src_head,kernel_sha256=kernel_sha,kernel_measurement=measurement,fixture_sha256=sha(exe.read_bytes()),fixture_exit=0,readback_count=len(names),checks=72,exit_code=vm.returncode,qmp_events=qmp.events,argv=cmd,geometry='640x480',page_rows=16,observations=observations,home_restored=True)
        (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps(observations,indent=2))
    finally:
        if vm.poll() is None: vm.kill();vm.wait()

set -eu
d=$(cd "$(dirname "$0")" && pwd)
z="$d/hosted"
q=/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64
case "$1" in
 seven640) exec python3 -IB "$d/drivers/widgets.py" "$d/source" "$z/kernel.elf32" "$z/rdesk.elf" "$z/seven640" --qemu "$q" --mode 640x480 ;;
 max-name) exec python3 -IB "$d/drivers/max-name.py" "$d/source" "$z/kernel.elf32" "$z/rdesk.elf" "$z/max-name" --qemu "$q" --mode 320x200 ;;
 programs) for h in 200 220 240 260; do python3 -IB "$d/drivers/programs.py" "$d/source" "$z/kernel.elf32" "$z/rdesk.elf" "$z/programs-$h" --qemu "$q" --mode "320x$h"; done ;;
esac

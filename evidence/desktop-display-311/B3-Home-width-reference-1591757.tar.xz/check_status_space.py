"""Exercise the reference kernel's actual Rust status selection over the declared input ranges."""
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

src=Path(sys.argv[1]).read_text()
code=src[src.index('            let status_line = |compact: bool|'):src.index('            if widgets_shown < widget_lines.len()',src.index('            let status_line = |compact: bool|'))]
rust='''
fn status(across:usize,list_rows:usize,places:usize,first:usize,place:usize,name_pages:usize,name_page:usize)->String {
'''+code+'''
    status
}
fn main(){
    let mut checked=0u64;
    for across in 28usize..=188 {
        let max_pages=255usize.div_ceil(across);
        for places in 2usize..=17 {
            for place in 1..places {
                for list_rows in 1..=places {
                    let first=(place+1).saturating_sub(list_rows);
                    for name_pages in 2..=max_pages {
                        for name_page in 0..name_pages {
                            let s=status(across,list_rows,places,first,place,name_pages,name_page);
                            assert!(s.len()<=across);
                            assert!(s.ends_with("Left/Right") || s.ends_with("<- ->"));
                            assert!(s.contains(&format!("name {}/{}",name_page+1,name_pages)) || s.contains(&format!("name part {} of {}",name_page+1,name_pages)));
                            if list_rows<places {
                                assert!(s.contains(&format!("Place {}/{}",place+1,places)) || s.contains(&format!("Places {} to {} of {}",first+1,first+list_rows,places)));
                            }
                            checked+=1;
                        }
                    }
                }
            }
        }
    }
    println!("{} status selections fit, with complete place, page and directions",checked);
}
'''
with TemporaryDirectory() as tmp:
    path=Path(tmp)/'check.rs'; path.write_text(rust)
    exe=path.with_suffix('')
    subprocess.run([os.environ.get('RUSTC','rustc'),'-O',str(path),'-o',str(exe)],check=True)
    subprocess.run([str(exe)],check=True)

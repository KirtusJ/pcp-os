"""Read every page of a pinned name on a user-selected native QEMU video mode."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import subprocess
import time

p=argparse.ArgumentParser(description=__doc__)
for key in ('source','kernel','program','output','qemu'):
    p.add_argument(key,type=Path)
for key in ('width','length','pins'):p.add_argument(key,type=int)
args=p.parse_args()
src=args.source.resolve();kernel=args.kernel.resolve();out=args.output.resolve();prog=args.program.resolve()
out.mkdir(parents=True,exist_ok=False)
opt=runpy.run_path(str(src/'examples/optical-disk-check/check.py'))
read=runpy.run_path(str(src/'examples/tester-cd/check_compact_pins.py'))['read']
glyphs=opt['SCREEN']['kernel_glyphs']()
measure=runpy.run_path(str(src/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](kernel.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
long_name=''.join(chr(97+(i//10)%26) for i in range(args.length-4))+'.elf'
names=[f'short-{n:02d}.elf' for n in range(1,args.pins)]+[long_name]
for name in names:shutil.copyfile(prog,out/name)
serial=out/'serial.txt'; width=args.width; room=width//10-4
pages=(len(long_name)+room-1)//room
cmd=[str(args.qemu.resolve()),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','256M','-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel',str(kernel),'-append',f'desktop={width}x200 image={measure}','-initrd',','.join(names)]
record=dict(kernel_sha256=sha(kernel),program_sha256=sha(prog),source_session_blob=subprocess.check_output(['git','hash-object',str(src/'PCP_OS_Rust/crates/pcpos-kernel/src/session.rs')],text=True).strip(),argv=cmd,keys=[],frames={},width=width,length=args.length,pins=args.pins,pages=pages,measurement=measure)
with (out/'stderr.txt').open('wb') as err:
    vm=subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
    try:
        mon=opt['Monitor'](vm);call=mon.call;call('qmp_capabilities')
        def key(*codes):
            mon.key(*codes);record['keys'].append(list(codes));time.sleep(.23)
        def capture(name):
            target=out/(name+'.ppm')
            prev=None
            for _ in range(15):
                call('screendump',filename=str(target));raw=target.read_bytes()
                if raw==prev:break
                prev=raw;time.sleep(.12)
            else:raise RuntimeError('no stable frame '+name)
            rows=read(raw,glyphs)
            (out/(name+'.txt')).write_text('\n'.join(rows))
            record['frames'][name]=sha(target)
            return rows
        opt['wait_for'](lambda:serial.exists() and f'desktop: {width}x200 at 1x UI scale' in serial.read_text(),'requested Home mode',45)
        capture('home');key('spc')
        for i in range(len(names)):
            if i:key('down')
            key('ctrl','p')
        key('esc')
        for _ in names:key('down')
        for state in ('off','one'):
            if state=='one':
                key('f2');key('down');key('down');key('down');key('ret');key('esc')
            parts=[]
            for part in range(1,pages+1):
                if part>1:key('right')
                rows=capture(f'{state}-{part:02d}');parts.append(rows[6].strip())
                assert 'Enter open' in rows[8] and prog and '53 KiB' in rows[7],rows
                if state=='one':assert any('1 widget line(s) not shown' in line for line in rows),rows
            assert ''.join(parts)==long_name
            for _ in range(pages-1):key('left')
        key('ret')
        opt['wait_for'](lambda:'could not be started:' in serial.read_text(),'refused Enter',12)
        assert 'Not started' in capture('refusal')[2]
        key('f10');assert 'Switch PCP OS off?' in capture('power')[3];key('ret')
        while not any(e.get('event')=='SHUTDOWN' for e in mon.events):mon.events.append(mon.read())
        record['shutdown']=next(e['data'] for e in mon.events if e.get('event')=='SHUTDOWN')
        record['exit']=vm.wait(timeout=15)
        log=serial.read_text()
        record['pass_lines']=sum(line.startswith('  pass ') for line in log.splitlines())
        record['clean']='ALL SELF-TESTS PASS.' in log
        assert record['exit']==0 and record['shutdown']=={'guest':True,'reason':'guest-shutdown'} and record['pass_lines']==72
        assert record['clean']==(args.length<=64)
        if args.length>64:assert 'the register refused ARTIFACT_ADDED' in log and '1 SELF-TEST(S) FAILED' in log
        print(width,args.length,args.pins,pages,record['clean'],flush=True)
    finally:
        if vm.poll() is None:vm.kill();vm.wait()
        (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')

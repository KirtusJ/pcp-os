# Home navigation at the label transition

The hosted baseline is 15917575b9e205e9042da2840492751945f32fff. Its tester-CD workflow and published SHA-256 digests are in hosted/origin.json. The reference kernel starts from this same source and applies reference/fit-paged-status.patch. Its source and ELF digest are recorded per guest. The patch selects a shorter phrase when the assembled row is too long; at the tightest width it removes spaces around the separator. Its status block matches byte-for-byte the one produced by the companion patch against 8642b23. This reference build is independent of Z3's candidate.

At 200 pixels high with two pins and a legal 64-byte name, directions on the hosted baseline were intact at widths 432, 536 and 640. At 440 both directions disappeared; at 480 and 528 part of the long-form instruction remained. With sixteen pins and a 255-byte name, directions were incomplete at 320, 440 and 552 and intact at 560. The reference preserved both directions on every page in both widget states at all ten configurations. Every run restored the full name by joining the visible parts, displayed the size and digest, visibly refused to start the selected long-name program, and powered off on guest request. Legal names yielded 72 pass lines and a clean summary. Names of 255 bytes yielded 72 pass lines and the artifact register reported one failed self-test because its limit is 64 bytes.

Run the following from this extracted directory. Python uses the bundled repository font and screen reader on each PPM.

    python3 verify_widths.py hosted source original
    python3 verify_widths.py reference source reference
    python3 check_status_space.py reference/source/PCP_OS_Rust/crates/pcpos-kernel/src/session.rs

The Rust check compiles the actual reference status-selection code and checks all page indices in its declared range. It varies the available character count from 28 to 188, total places from 2 to 17, each possible selected pin and list height, and every multi-page count up to that required for a 255-byte name on a single text row. This calculation supplements the 20 real QEMU guests.

For guest replay, extract kernel.elf32 and rdesk.elf from the Queue Desk tester ISO in hosted/origin.json. Run drivers/width.py with the checkout, kernel, Queue Desk executable, new output directory, QEMU executable, width, length, and number of pins in that order. For the reference, apply its patch to the baseline and run PCP_OS_Rust/crates/pcpos-kernel/run.sh build with the default feature set. The reference used a local Rust toolchain and a dedicated build stage.

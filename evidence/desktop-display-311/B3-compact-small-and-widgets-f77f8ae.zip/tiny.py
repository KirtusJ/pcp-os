"""Check the selected pin's identity at compact-display capacity."""
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import subprocess
import time
import inspect, collections, os

import argparse
parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path, help="PCP OS checkout at the recorded revision")
parser.add_argument("kernel", type=Path, help="measured kernel.elf32 extracted from its hosted tester CD")
parser.add_argument("program", type=Path, help="surf.elf with the SHA-256 recorded in result.json")
parser.add_argument("output", type=Path, help="fresh output directory")
parser.add_argument("--qemu", default="qemu-system-x86_64")
args = parser.parse_args()
src = args.source.resolve()
opt = runpy.run_path(str(src / 'examples/optical-disk-check/check.py'))
screen = opt['SCREEN']
glyphs = screen['kernel_glyphs']()
kernel = args.kernel.resolve()
measurement = runpy.run_path(str(src / 'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](kernel.read_bytes())
out = args.output.resolve()
out.mkdir()
geometry = os.environ['TINY_MODE']
width, height = map(int, geometry.split('x'))
# Preserve the kernel font-cell reader; its production gate deliberately only covers 640x480+.
read_source=inspect.getsource(screen['read_screen']).replace('width < 640 or height < 480','width < 320 or height < 200')
ns={'collections':collections};exec(read_source,ns)
count=max(2,height//20-10)-1
names=['queue.elf']+[f'q-{i}.elf' for i in range(2,count+1)]
for name in names:
    shutil.copyfile(args.program.resolve(), out / name)
serial = out / 'serial.txt'
cmd = [args.qemu, '-machine', 'pc', '-accel', 'tcg', '-cpu', 'qemu64', '-m', '256M', '-vga', 'std', '-nic', 'none', '-display', 'none', '-monitor', 'none', '-qmp', 'stdio', '-serial', 'file:'+str(serial), '-kernel', str(kernel), '-append', f'desktop={geometry} image={measurement}', '-initrd', ','.join(names)]
sha = lambda b: hashlib.sha256(b).hexdigest()
meta = dict(kernel_sha256=sha(kernel.read_bytes()), source={'541c0ecea03db58b6987312e6e99800f1935803792ffb034ddd03f6db61a3090': '04a2954c5296cce90106d32d2d358392a3271efa', 'ef76e0d80e97e1d9a1c111d0cfe634b4c6c081b8c59e0241285390f66b86fa79': 'f77f8aef17b2da9f69e2d6538af7868946b1d553', '3cf4b2aed35e9e9879898d13677de4b6342b6d4b74c66742c3c3f4c92069bceb': '04a2954c5296cce90106d32d2d358392a3271efa + unpublished B3 patch 21c57bb9ec8720239ee6a878c72042a4c0fd3456ba279df75a4a37bf237409c6'}.get(sha(kernel.read_bytes()),'other supplied kernel'), program_sha256=sha((out/names[0]).read_bytes()), measurement=measurement, frames={}, keys=[])
with (out/'stderr.txt').open('wb') as err:
    vm = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, cwd=out, stderr=err)
    try:
        monitor = opt['Monitor'](vm)
        monitor.call('qmp_capabilities')
        def key(*keys):
            monitor.key(*keys)
            meta['keys'].append(list(keys))
            time.sleep(0.42)
        def capture(label):
            path = out / (label+'.ppm')
            monitor.call('screendump', filename=str(path))
            frame=path.read_bytes()
            rows=ns['read_screen'](frame,glyphs)
            meta['frames'][label]=sha(frame)
            (out/(label+'.txt')).write_text('\n'.join(rows))
            return rows
        opt['wait_for'](lambda: serial.exists() and 'desktop: ' in serial.read_text(), 'waiting for compact Home', 60)
        time.sleep(.5)
        initial=capture('home')
        meta['requested']=geometry
        meta['actual_desktop']=next(l for l in serial.read_text().splitlines() if l.startswith('desktop: '))
        meta['home_ppm_dimensions']=(out/'home.ppm').read_bytes().split(b'\n',2)[1].decode()
        key('spc')
        for i,name in enumerate(names):
            if i: key('down')
            key('ctrl','p')
        key('esc');key('down')
        full=capture('selected')
        meta['selected_rows']=full
        meta['pins_attempted']=len(names)
        key('ret')
        opt['wait_for'](lambda: 'PARROTS READY' in serial.read_text(), 'Queue Desk open', 20)
        key('esc')
        opt['wait_for'](lambda:'queue.elf ended DONE: exit 0' in serial.read_text(), 'Queue Desk exit',20)
        time.sleep(.4)
        capture('returned')
        key('f10');capture('power');key('ret')
        while not any(x.get('event')=='SHUTDOWN' for x in monitor.events):
            monitor.events.append(monitor.read())
        meta['shutdown']=next(x['data'] for x in monitor.events if x.get('event')=='SHUTDOWN')
        meta['exit']=vm.wait(timeout=20)
        meta['passes']=sum(x.startswith('  pass ') for x in serial.read_text().splitlines())
        meta['complete_digest_visible']=any(meta['program_sha256'][:16] in r for r in full)
        meta['all_self_tests_pass']='ALL SELF-TESTS PASS.' in serial.read_text()
        print(meta['actual_desktop'],meta['home_ppm_dimensions'],meta['selected_rows'],flush=True)
        print(meta['shutdown'],meta['exit'],meta['passes'],meta['complete_digest_visible'])
    finally:
        if vm.poll() is None:
            vm.kill(); vm.wait()
        (out/'result.json').write_text(json.dumps(meta,indent=2)+'\n')

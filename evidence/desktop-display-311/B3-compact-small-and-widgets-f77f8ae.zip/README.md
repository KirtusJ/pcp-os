# B3 compact Home readback

These are six independent QEMU guests. The earlier kernel is from the single-app tester CD at 04a2954c5296cce90106d32d2d358392a3271efa (hosted run 44899146236, artifact 14705781097). The later kernel was compiled from the clean checkout at f77f8aef17b2da9f69e2d6538af7868946b1d553, tree 6679d1f00936c39011b5bdc6b3ba73416c71fd13, with Rust 1.100.0. Both exact kernel files and the Queue Desk executable are included. Their hashes are in SHA256SUMS and the per-guest results. The executable is the same for every alias. The first kernel ELF starts 541c0ece; the second starts ef76e0d8; the Queue Desk executable starts 46f4bbd5.

## Custom display sizes

At 320x200, Bochs and the raw P6 header confirm the requested mode. With the one admitted pin chosen, queue.elf is visible but its size and digest are absent. The footer shows only 'Up/Down choose   Enter open'. All four paired original/new frames (initial, selected, returned, and power) are byte-for-byte identical. Both guests actually launch Queue Desk and return it DONE/0. The kernel's Bochs mode validation accepts requests starting at 320x200 with widths divisible by eight. The standard test reader skips frames below 640x480, so tiny.py broadens only its geometry check; the cell reader and kernel font stay the same.

At 640x400, nine short pins were attempted on both kernels. The old kernel displays all nine and overwrites the selected program's facts with the footer. The new kernel admits seven and shows the full selected identity, including 53 KiB and the SHA-256 prefix, plus a separate full footer. Both guests launched the selected Queue Desk and returned DONE/0.

## Populated widgets at 640x480

The guests used the same key sequence, the same 64-character registered name (two display lines), and nine short aliases. Queue Desk ran three times under the second alias, then Recent activity, This machine and Session were enabled. Timestamps naturally differ between runs.

| Capture | Earlier kernel | New kernel |
|---|---|---|
| widgets-long (ten pins, wrapped pin selected) | One Recent line below the footer. | Identity and footer; no widget rows. |
| widgets-ten-programs (ten pins, Programs selected) | Three Recent lines, memory on row 21 and session on row 23. | Three Recent lines; no memory or session, with row 21 blank. |
| widgets-seven (seven pins, wrapped pin selected) | Three Recent lines on rows 19–21 and memory on row 23. | Two Recent lines on rows 19–20 and no memory; row 21 blank. |
| widgets-seven-programs (seven pins, Programs selected) | Three Recent lines, memory and session. | Three Recent lines, memory and session. |

Rows are zero-based. The footer occupies row 22. The new kernel limits widget drawing to row 20 (rows minus four), independently of its pin-capacity change.

All six serial logs record 72 passing checks and the final ALL SELF-TESTS PASS verdict. Every VM issued a guest-requested shutdown and exited 0. These are virtual-machine observations.

## Replay

Use Python 3.10+ and x86-64 system QEMU with PC, TCG, SeaBIOS, standard VGA and the corresponding BIOS/option-ROM files. These runs used QEMU 10.0.13. From this extracted archive's directory, set OLD_TREE and NEW_TREE to local source checkouts at the two commits above. Give each command a new output directory. Using the equivalent kernel reader at the other revision does not change its font or framebuffer decoding.

```sh
TINY_MODE=320x200 python3 -B tiny.py "$OLD_TREE" inputs/old-kernel.elf32 inputs/queue.elf replay-old-320
TINY_MODE=320x200 python3 -B tiny.py "$NEW_TREE" inputs/new-kernel.elf32 inputs/queue.elf replay-new-320
TINY_MODE=640x400 python3 -B tiny.py "$OLD_TREE" inputs/old-kernel.elf32 inputs/queue.elf replay-old-640
TINY_MODE=640x400 python3 -B tiny.py "$NEW_TREE" inputs/new-kernel.elf32 inputs/queue.elf replay-new-640
python3 -B widgets.py "$OLD_TREE" inputs/old-kernel.elf32 inputs/queue.elf replay-old-widgets
python3 -B widgets.py "$NEW_TREE" inputs/new-kernel.elf32 inputs/queue.elf replay-new-widgets
sha256sum -c SHA256SUMS
```

Both harnesses accept --qemu with the emulator path. They record the original P6s, decoded text, keys, serial and QMP shutdown. The kernel source label in each result was assigned by matching the exact input ELF hash. Source reads, screen pixels, hashes and guest logs are independent of that label.

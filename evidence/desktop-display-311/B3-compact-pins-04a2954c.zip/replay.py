"""Check the selected pin's identity at compact-display capacity."""
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import subprocess
import time

import argparse
parser = argparse.ArgumentParser()
parser.add_argument("source", type=Path, help="PCP OS checkout at the recorded revision")
parser.add_argument("kernel", type=Path, help="measured kernel.elf32 extracted from its hosted tester CD")
parser.add_argument("program", type=Path, help="surf.elf with the SHA-256 recorded in result.json")
parser.add_argument("output", type=Path, help="fresh output directory")
parser.add_argument("--qemu", default="qemu-system-x86_64")
args = parser.parse_args()
src = args.source.resolve()
opt = runpy.run_path(str(src / 'examples/optical-disk-check/check.py'))
screen = opt['SCREEN']
glyphs = screen['kernel_glyphs']()
kernel = args.kernel.resolve()
measurement = runpy.run_path(str(src / 'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](kernel.read_bytes())
out = args.output.resolve()
out.mkdir()
geometry = '640x480'
names = [f'program-{i:02}.elf' for i in range(1, 14)]
for name in names:
    shutil.copyfile(args.program.resolve(), out / name)
serial = out / 'serial.txt'
cmd = [args.qemu, '-machine', 'pc', '-accel', 'tcg', '-cpu', 'qemu64', '-m', '256M', '-vga', 'std', '-nic', 'none', '-display', 'none', '-monitor', 'none', '-qmp', 'stdio', '-serial', 'file:'+str(serial), '-kernel', str(kernel), '-append', f'desktop={geometry} image={measurement}', '-initrd', ','.join(names)]
sha = lambda b: hashlib.sha256(b).hexdigest()
meta = dict(kernel_sha256=sha(kernel.read_bytes()), source='04a2954c5296cce90106d32d2d358392a3271efa', program_sha256=sha((out/names[0]).read_bytes()), measurement=measurement, frames={}, keys=[])
with (out/'stderr.txt').open('wb') as err:
    vm = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, cwd=out, stderr=err)
    try:
        monitor = opt['Monitor'](vm)
        monitor.call('qmp_capabilities')
        def key(*keys):
            monitor.key(*keys)
            meta['keys'].append(list(keys))
            time.sleep(0.35)
        def capture(label):
            path = out / (label+'.ppm')
            monitor.call('screendump', filename=str(path))
            frame=path.read_bytes()
            rows=screen['read_screen'](frame,glyphs)
            meta['frames'][label]=sha(frame)
            (out/(label+'.txt')).write_text('\n'.join(rows))
            return rows
        opt['wait_for'](lambda: serial.exists() and 'desktop: 640x480' in serial.read_text(), 'waiting for compact Home', 60)
        time.sleep(.5)
        initial=capture('home')
        assert 'PCP OS | DESKTOP' in initial[1],initial
        key('spc')
        for i,name in enumerate(names):
            if i:
                key('down')
            key('ctrl','p')
            if i==0:
                key('esc'); key('down')
                one=capture('one-selected')
                assert any(meta['program_sha256'][:16] in r for r in one),one
                key('spc')
        key('esc')
        full=capture('full-selected')
        print('\n'.join(full),flush=True)
        assert sum('PINNED program-' in row for row in full)==13,full
        key('f10')
        q=capture('power')
        assert 'Switch PCP OS off?' in q[3],q
        key('ret')
        while not any(x.get('event')=='SHUTDOWN' for x in monitor.events):
            monitor.events.append(monitor.read())
        meta['shutdown']=next(x['data'] for x in monitor.events if x.get('event')=='SHUTDOWN')
        meta['exit']=vm.wait(timeout=20)
        meta['passes']=sum(x.startswith('  pass ') for x in serial.read_text().splitlines())
        meta['complete_digest_visible']=any(meta['program_sha256'][:16] in r for r in full)
        print(meta['shutdown'],meta['exit'],meta['passes'],meta['complete_digest_visible'])
    finally:
        if vm.poll() is None:
            vm.kill(); vm.wait()
        (out/'result.json').write_text(json.dumps(meta,indent=2)+'\n')

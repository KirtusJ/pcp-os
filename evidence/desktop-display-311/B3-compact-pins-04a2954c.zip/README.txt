B3 compact Home at 640x480

The QEMU 10.0.13 guest used the measured kernel extracted with xorriso from unpublished-tester-cd in run 44899146236, artifact 14705781097. Its original ZIP SHA-256 was 3bcf4e2f3df1be09f7b168d9bf7bdc1dce8cbc20447dc72d4728c1849601c80c. The program came from the two-app CD in the shared media bundle, run 44899266193, artifact 14705910212. The guest uses thirteen ordinary copies of this program with distinct short filenames. It runs entirely without attached disks. Both candidate inputs are identified in result.json.

Run python3 replay.py OS_CHECKOUT KERNEL_ELF32 SURF_ELF FRESH_OUTPUT. With one selected pin the name, size and digest are readable. With 13 pinned, the launcher's first program is still selected on Home and named under Enter starts, but the footer overwrites its size and digest. Each original PPM is accompanied by its decoded rows. The QMP key sequence and full frame digests are in result.json. The guest confirmed power-off and ended normally.

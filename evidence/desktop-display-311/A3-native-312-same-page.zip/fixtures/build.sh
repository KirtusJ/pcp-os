#!/bin/sh
# Rebuild the six temporary guest programs into a fresh directory.
set -eu
source_dir=$(realpath "$1")
mkdir "$2"
out=$(realpath "$2")
here=$(dirname "$(realpath "$0")")
build() {
    name=$1
    input=$2
    shift 2
    gcc -Os -ffreestanding -fno-stack-protector -fno-asynchronous-unwind-tables -fpie "$@" -c "$here/$input" -o "$out/$name.o"
    ld -T "$source_dir/store/games/flux-rink/guest.ld" --build-id=none -s -o "$out/$name.elf" "$out/$name.o"
}
build files files.c
build write23 fixture.c -DFILE_COUNT=23
build write31 fixture.c -DFILE_COUNT=31
build sharedprefixA fixture.c '-DMARK="alpha"'
build sharedprefixB fixture.c '-DMARK="bravo"'
build shoredprefixC fixture.c '-DMARK="charlie"'

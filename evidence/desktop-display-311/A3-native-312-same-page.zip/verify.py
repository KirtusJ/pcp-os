"""Replay the stored raw observations. Supply the exact #312 source checkout for the font and ELF reader."""
import hashlib
import json
import re
import runpy
import sys
from pathlib import Path

from PIL import Image

root = Path(__file__).resolve().parent
src = Path(sys.argv[1]).resolve()
reader = runpy.run_path(str(src / 'examples/tester-cd/check.py'))
measure = runpy.run_path(str(src / 'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure']
glyphs = reader['kernel_glyphs']()
sha = lambda data: hashlib.sha256(data).hexdigest()
jsonfile = lambda path: json.loads(path.read_bytes())
baseline = jsonfile(root / 'receipts/baseline-305.json')
draft = jsonfile(root / 'receipts/draft-312.json')
for receipt, folder in [(baseline, 'baseline'), (draft, 'pin312/inputs')]:
    raw = (root / folder / 'kernel.elf32').read_bytes()
    assert {'sha256': sha(raw), 'bytes': len(raw)} == receipt['on_disc']['kernel.elf32']
    assert measure(raw) == receipt['kernel_measurement']
    ids = jsonfile(root / folder / 'identities.json')
    assert (ids['commit'], ids['tree'], ids['iso']) == (receipt['source_commit'], receipt['source_tree'], receipt['iso_sha256'])
row_cache = {}
screens = 0
def extract_rows(frame_path, expected_size, saved_text):
    global screens
    raw = frame_path.read_bytes()
    magic, dims, depth, pixels = raw.split(b'\n', 3)
    w, h = expected_size
    assert magic == b'P6' and dims.decode() == f'{w} {h}' and depth == b'255' and len(pixels) == w*h*3
    key = sha(raw)
    if key not in row_cache:
        row_cache[key] = reader['read_screen'](raw, glyphs)
    rows = row_cache[key]
    assert '\n'.join(rows)+'\n' == saved_text.read_text(), saved_text
    screens += 1
    return rows
def read_runtime(d, r, receipt):
    log = (d / 'serial.txt').read_text()
    assert receipt['kernel_measurement']+' (measured; equal to the value the loader named)' in log
    assert r['kernel_sha256']==receipt['on_disc']['kernel.elf32']['sha256'] and r['measurement']==receipt['kernel_measurement']
    assert r['exit_code']==0 and sum(l.startswith('  pass ') for l in log.splitlines())==72
    assert 'ALL SELF-TESTS PASS.' in log and not re.search(r'^  FAIL',log,re.M)
    assert sum(e.get('event')=='SHUTDOWN' and e.get('data')=={'guest':True,'reason':'guest-shutdown'} for e in r['events'])==1
    assert '-kernel' in r['argv'] and '-initrd' in r['argv'] and '-cdrom' not in r['argv']
    return log
paths = sorted([*root.glob('capture-*'),*root.glob('draft-*')])
assert len(paths)==10
for d in paths:
    r = jsonfile(d/'result.json')
    fixed = d.name.startswith('draft-')
    log = read_runtime(d,r,draft if fixed else baseline)
    app = r['argv'][r['argv'].index('-initrd')+1]
    exe = root/('fixtures' if app=='files.elf' else 'pin312/inputs')/app
    assert sha(exe.read_bytes()) == r['fixture_sha256']
    assert f'starting {app} ({exe.stat().st_size} bytes, SHA-256 {r["fixture_sha256"]})' in log
    assert log.count(app+' ended DONE: exit 0') == 1 and r['checks']==72
    dims = tuple(map(int,r['geometry'].split('x')))
    rows = {f.stem:extract_rows(f,dims,f.with_suffix('.txt')) for f in sorted(d.glob('*.ppm'))}
    assert rows['power'][1].strip()=='POWER OFF' and 'Enter switch off' in rows['power'][-2]
    assert (d/'home.ppm').read_bytes()==(d/'returned.ppm').read_bytes()
    assert r['home_restored'] and any('Programs' in s for s in rows['home']) and any(app in s for s in rows['launcher'])
    n = r['files']
    if app=='files.elf':
        assert n==['audit-'+'A'*180+'X','audit-'+'A'*180+'Y','budit-'+'A'*180+'X']
        for i,name in enumerate(n,1):
            assert f'{name}={i}' in log.splitlines()
        w,h=dims
        clip=w//10-20
        assert r['clip']==clip
        if fixed:
            assert 'FILES: showing 1 to 3 of 3,' in rows['files'][1]
            pieces=[([name[j:j+clip],'1','KiB'] if j==0 else [name[j:j+clip]]) for name in n for j in range(0,len(name),clip)]
            assert [s.strip().split() for s in rows['files'][4:4+len(pieces)]]==pieces
            assert r['screen_or_row_hashes']==[sha((d/'files.ppm').read_bytes())]
        else:
            assert 'FILES: 3 file(s)' in rows['files'][1]
            assert [s.strip().split() for s in rows['files'][4:7]]==[[name[:clip],'1','KiB'] for name in n]
            pix=(d/'files.ppm').read_bytes().split(b'\n',3)[3]; stride=w*20*3
            hashes=[sha(pix[k*stride:(k+1)*stride]) for k in (4,5,6)]
            assert hashes==r['full_width_row_hashes'] and hashes[0]==hashes[1]!=hashes[2]
    else:
        count=int(re.search(r'\d+',app)[0])
        assert n==[f'f{i:03}' for i in range(1,count+1)]
        assert re.findall(r'^created/read (f\d{3})$',log,re.M)==n
        for name,top in [('first',0),('after-down',1),('after-up',0),('after-pgdn',1),('after-pgup',0)]:
            lines=rows[name]
            assert f'FILES: showing {top+1} to {count-1+top} of {count},' in lines[1]
            assert 'Page Up/Page Down' in lines[-2]
            assert [line.strip().split() for line in lines[4:4+count-1]]==[[x,'1','KiB'] for x in n[top:top+count-1]]
        hashes=[sha((d/(s+'.ppm')).read_bytes()) for s in ('first','after-down','after-up','after-pgdn','after-pgup')]
        assert hashes[0]==hashes[2]==hashes[4] and hashes[0]!=hashes[1]==hashes[3] and hashes[1:]==r['screen_or_row_hashes']
d=root/'pin312/observed-pins'
r=jsonfile(d/'result.json'); log=read_runtime(d,r,draft)
assert r['source']==draft['source_commit'] and r['final_passes']==72
assert r['files']=={f.name:sha(f.read_bytes()) for f in sorted(d.glob('*')) if f.suffix in ('.ppm','.txt')}
rows={f.stem:extract_rows(f,(1920,1080),f.with_suffix('.rows.txt')) for f in sorted(d.glob('*.ppm'))}
assert rows['question'][1].strip()=='POWER OFF' and 'Enter switch off' in rows['question'][-2]
names=['sharedprefixA.elf','sharedprefixB.elf','shoredprefixC.elf']; marks=['alpha','bravo','charlie']
for i,(n,m) in enumerate(zip(names,marks)):
    raw=(root/'pin312/inputs'/n).read_bytes()
    assert r['programs'][n]==sha(raw)
    assert log.count(f'starting {n} ({len(raw)} bytes, SHA-256 {sha(raw)})')==2
    for entry in ('entered '+m,'Esc '+m): assert log.splitlines().count(entry)==2
    assert log.count(n+' ended DONE: exit 0')==2
    assert any('> '+n[:16] in s and sha(raw)[:16] in s for s in rows[f'launcher-{i}'])
    assert sum('pinned to the desktop' in s for s in rows[f'pinned-{i}'])==i+1
for form in ('bar','dock'):
    hashes=[]
    for i,n in enumerate(names):
        for state in ('selected','returned'):
            frame=rows[f'{form}-{state}-{i}']
            assert any('Enter starts' in s for s in frame) and any(n in s for s in frame)
            assert any('SHA-256 '+r['programs'][n][:16]+'...' in s and 'KiB' in s for s in frame)
            assert not any(other in s for other in names if other!=n for s in frame)
            assert any('sharedpref..' in s and 'shoredpref..' in s for s in frame)
        key=f'{form}-selected-{i}'
        x,y=(10+(i+1)*190+50,1040) if form=='bar' else ((1920-(4*140+20))//20*10+10+(i+1)*140+10,1020)
        with Image.open(d/(key+'.ppm')) as image:
            h=sha(image.crop((x,y,x+120,y+20)).tobytes())
        assert h==r['results'][key]['label_rgb_sha256']
        hashes.append(h)
    assert hashes[0]==hashes[1]!=hashes[2]
pre=root/'preliminary-rejected'
raw=(pre/'serial.txt').read_text()
assert 'a5ae1d6dd08b87266b232b3e2a6e80b730f6d9b4529a4019f85a8f0b7d2098da' in raw
assert 'files.elf could not be started: a segment lies outside the memory a program may have' in raw and 'files.elf ended DONE' not in raw
extract_rows(pre/'launcher.ppm',(800,600),pre/'launcher.txt')
print(f'11 completed direct-kernel sessions; {screens-1} P6 frames matched saved text. One preliminary rejection verified separately.')

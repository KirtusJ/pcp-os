# PCP OS native file and shortcut identity observations

Eleven QEMU sessions reached guest shutdown. Four exposed a file-name collision on the frozen #305 kernel. Seven exercised the #312 draft. The captures cover the F3 file inventory and graphical desktop shortcuts. Every session directly loaded a measured kernel with QEMU’s `-kernel` and supplied temporary user programs through `-initrd`. The kernel bytes came from the tester CDs. The recorded boot path uses a virtual PC, TCG, 128 MiB of RAM, standard VGA and no network or persistent disk. Firmware optical boot and physical hardware require separate observations.

| Directory | Sessions | Observation |
|---|---:|---|
| `capture-*` | 4 | At 640×480, 800×600, 1024×768 and 1920×1080, the first two 187-byte names differed only at the final character. Their entire F3 rows were pixel-identical at each geometry. Changing the first character of the control name changed its row. The fixture wrote and reopened distinct bytes 1, 2 and 3. |
| `draft-files-*` | 4 | At the same four sizes F3 wrapped each complete name across rows. The distinguishing X and Y suffixes and the control’s initial character were visible. Each name matched its guest readback. |
| `draft-23-800x600`, `draft-31-1024x768` | 2 | Guests wrote and reopened 23 and 31 files. The first pages showed 1–22 and 1–30. Down and Page Down exposed the final file, while Up and Page Up each restored the original frame byte for byte. |
| `pin312/observed-pins` | 1 | At 1920×1080, three pinned programs launched from both bar and dock. Two shortened labels had identical 120×20 pixel crops. The selected panel disclosed the full filename, size and matching digest prefix before launch and after return. The third label provided a distinct visual control. All six launches produced the expected entry marker, Esc marker and successful return. |

Each completed session recorded 71 startup self-tests, a passing final register test, a guest-initiated QMP shutdown and QEMU exit 0. The reference set contains 77 original P6 screenshots from the completed sessions, their decoded rows, serial transcripts, stderr and per-run JSON. The preliminary 800×600 attempt is separate. An earlier 8,480-byte fixture (SHA-256 `a5ae1d6dd08b87266b232b3e2a6e80b730f6d9b4529a4019f85a8f0b7d2098da`) failed kernel admission because a segment lay outside the permitted program memory. Its one launcher capture and serial transcript document only that rejection. The successful long-name fixture is 8,552 bytes, SHA-256 `eba12336d81f555f61212eac89c8e998d2060acc1e3975a6c8deb1d5ed50c272`.

## Kernel provenance

| | Frozen #305 baseline | #312 draft |
|---|---|---|
| Source commit | `bc70ad5a2505a0f85e99bc22a575f4e5aabd1608` | `86546ce14423eafb3dafc43b231d1e074b3e99e0` |
| Build | [Run 44887282478](https://github.com/KirtusJ/pcp-os/actions/runs/44887282478), two-app CD | [Run 44896105320](https://github.com/KirtusJ/pcp-os/actions/runs/44896105320), one-app CD |
| CD artifact | [14700715832](https://github.com/KirtusJ/pcp-os/actions/runs/44887282478/artifacts/14700715832) | [14704451437](https://github.com/KirtusJ/pcp-os/actions/runs/44896105320/artifacts/14704451437) |
| Evidence artifact with original build receipt | [14700790573](https://github.com/KirtusJ/pcp-os/actions/runs/44887282478/artifacts/14700790573) | [14704126520](https://github.com/KirtusJ/pcp-os/actions/runs/44896105320/artifacts/14704126520) |
| CD artifact ZIP SHA-256 | `1f7aebc82e0e2e6a19e9167f25893ed33c186c46ece1808a349c0cfd250de293` | `9bd5cf931754f7f5e5849c3329b19ae241965f02a4a81895702167b40e8c3771` |
| Extracted kernel ELF SHA-256 | `1a9be4264861d01cd4f233fcb411e90217302f5768195ec7ddff71f7520269f1` | `4bf7a5cc8b7c6451f84ba90a55fec6e1b8ad040671caf59a1391c47d911de00a` |
| Running kernel measurement | `8ec0fbba1caae0a8405ef650468a41b41f09ee245aef2bac38d86825fa0ea2c9` | `08a4907d50457511400f9048c90bbd1cbb7c22a3fd4faea92f6adbf6be2a0fac` |

Both kernel ELFs and both original build receipts are included. Before packaging, the CD ZIP digests were compared with GitHub’s artifact records. Each ISO was extracted and checked against its receipt, then its kernel was read back and byte-compared with the archived ELF. The receipt files are byte-identical to the originals in the two evidence ZIPs. The artifact metadata and ISO hashes are in `receipts/`.

The baseline capture reports identify `a5a76b6071922812ca293b07ec8b48b42a543414` as their **checker checkout**. The booted baseline kernel has the #305 digest above. The decoder functions and kernel glyph font were identical across the #305, checker and #312 checkouts. The original absolute paths in recorded QEMU commands identify the capture workspace.

## Verification and replay

Use a Linux host with Python 3, Pillow, Git, QEMU x86 with TCG, BIOS and standard VGA firmware. The capture host used Debian QEMU 10.0.13. GCC 14.2 and GNU ld 2.44 reproduced all six supplied fixture ELFs byte for byte. Run from the extracted archive directory with Python assertions enabled.

```sh
sha256sum --check SHA256SUMS
git clone https://github.com/KirtusJ/pcp-os.git pcp-src
git -C pcp-src fetch origin 86546ce14423eafb3dafc43b231d1e074b3e99e0 a5a76b6071922812ca293b07ec8b48b42a543414
git -C pcp-src checkout --detach 86546ce14423eafb3dafc43b231d1e074b3e99e0
git -C pcp-src worktree add --detach ../baseline-checker a5a76b6071922812ca293b07ec8b48b42a543414
python3 verify.py pcp-src
```

The verifier decodes the original P6 frames with the kernel font, checks the saved rows and serial evidence, recomputes kernel measurements and checks the recorded QMP outcomes. To rebuild the fixture programs, use `sh fixtures/build.sh pcp-src rebuilt` in a directory without an existing `rebuilt` folder. The single `files.c` fixture generates the long names. The marked and file-count variants come from `fixture.c`.

The following commands produce new observations in separate directories. Use each of the four sizes above for the long-name cases.

```sh
qemu=$(command -v qemu-system-x86_64)
python3 replay.py baseline-checker baseline/kernel.elf32 fixtures/files.elf "$qemu" replay-baseline-800 800x600
python3 replay.py pcp-src pin312/inputs/kernel.elf32 fixtures/files.elf "$qemu" replay-draft-800 800x600 --fixed
python3 replay.py pcp-src pin312/inputs/kernel.elf32 pin312/inputs/write23.elf "$qemu" replay-23 800x600 --count 23
python3 replay.py pcp-src pin312/inputs/kernel.elf32 pin312/inputs/write31.elf "$qemu" replay-31 1024x768 --count 31
mkdir replay-pins
cp pin312/guest_checks.py replay-pins/
cp -r pin312/inputs replay-pins/
ln -s ../pcp-src replay-pins/src
python3 replay-pins/guest_checks.py pins "$qemu"
```

The bundled file-list replay driver covers all three modes. The baseline capture originally used an earlier version of the same driver. Its original JSON uses `full_width_row_hashes` for the three row hashes. A new baseline run uses `screen_or_row_hashes` for the same three measurements. The stored JSON and framebuffer bytes are the original observations.

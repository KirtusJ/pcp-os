"""Pack the results, preserving each failed trial and its original captures."""
import hashlib
import json
from pathlib import Path
import runpy
import sys
import tarfile
import zipfile

root=Path(__file__).resolve().parent
source='f9743bfbb61e771806c165779d15b854cc29232e'
tree='992986aac40fc4e25ed54f23d6ae299eb7d8b821'
def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):
    return json.loads((root/path).read_text())
def write(path,value):
    (root/path).write_text(json.dumps(value,indent=2)+'\n')
def files_in(folder,extensions):
    return [p for p in (root/folder).rglob('*') if p.is_file() and p.suffix in extensions]
def tar(name,files):
    with tarfile.open(root/name,'w:xz',preset=3) as archive:
        for path in sorted(set(files)):
            archive.add(path,arcname=path.relative_to(root),recursive=False)
    with tarfile.open(root/name) as arc:
        for member in arc:
            original=root/member.name
            assert hashlib.file_digest(arc.extractfile(member),'sha256').hexdigest()==digest(original)
def zip_files(name,files):
    with zipfile.ZipFile(root/name,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for p in sorted(set(files)):z.write(p,p.relative_to(root))
    with zipfile.ZipFile(root/name) as z:assert z.testzip() is None
if sys.argv[1]=='guests':
    modes=['320x200','640x480','bar','dock']
    results={}
    for mode in modes:
        path=f'final-{mode}'
        d=read(path+'/observations.json')
        for label,expected in d['frames'].items():
            assert digest(root/path/(label+'.ppm'))==expected
        assert all(type(ok) is bool for _,ok in d['checks'])
        assert [key for key,ok in d['checks'] if not ok]==d['failures']
        results[mode]=dict(failures=d['failures'],checks=sum(ok for _,ok in d['checks']),total_checks=len(d['checks']),guest_exit=d['qemu_exit'],self_test_pass_lines=d['self_test_pass_lines'],launches=d['launches'])
    main=[root/p for p in ['guest_names.py','read_disc.py','read_plain.py','queue-receipt.json','plain-cd/receipt.json','hosted-compact-pins.json']]
    for mode in modes:main+=files_in('final-'+mode,{'.ppm','.json','.log','.txt'})
    control=read('artifact-name-control.json')
    extra=[root/p for p in ['first-capture.py','artifact_name_control.py','artifact-name-control.json']]
    for mode in modes:extra+=files_in('guest-'+mode,{'.ppm','.json','.log','.txt'})
    for length in (64,65,113):extra+=files_in('control-'+str(length),{'.log','.txt'})
    # The initial graphic samples captured some frames during repaint. The stable, repeated observations are separate.
    write('display-readback.json',dict(source=source,tree=tree,fixture='Queue Desk from the hosted two-program tester CD',kernel_sha256=digest(root/'disc-kernel.elf32'),program_sha256=digest(root/'disc-rdesk.elf'),modes=results,extended_first_attempts={m:read('guest-'+m+'/observations.json')['failures'] for m in modes},control_results=control))
    main.append(root/'display-readback.json')
    tar('desktop-guests.tar.xz',main)
    tar('extra-and-initial-trials.tar.xz',extra)
elif sys.argv[1]=='suite':
    d=read('full/results.json')
    failures=[]
    passed=total=groups=0
    for row in d['results']:
        checks=row['checks']
        assert all(type(c['ok']) is bool for c in checks)
        assert row['ok']==all(c['ok'] for c in checks)
        passed+=sum(c['ok'] for c in checks)
        total+=len(checks)
        groups+=row['ok']
        failures.extend(dict(group=row['test'],assertion=c['check'],detail=c['detail']) for c in checks if not c['ok'])
    assert len(d['results'])==d['tests'] and groups==d['passed'] and total==d['checks']
    assert any('240 seconds' in g['test'] for g in d['results'])
    status=int((root/'suite.exit').read_text())
    assert status==(1 if failures else 0)
    assert digest(root/'kernel.elf32')==d['kernel_sha256'] and digest(root/'programs/doom.elf')==d['doom_sha256']
    assert all(digest(root/'data'/n)==v for n,v in d['game_data'].items())
    measure=runpy.run_path(str(root/'src/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure']((root/'kernel.elf32').read_bytes())
    value=dict(source=source,tree=tree,command='env -u PCPOS_TESTS_ONLY PCPOS_ADAPTER_CHECKOUT="$PWD/src" python3 -u run_stdio.py "$PWD/kernel.elf32" "$PWD/programs" "$PWD/data" "$PWD/full"',build='sh src/PCP_OS_Rust/crates/pcpos-kernel/run.sh build',kernel_sha256=d['kernel_sha256'],kernel_measurement=measure,emulator=d['emulator'],start=(root/'start').read_text().strip(),end=(root/'stop').read_text().strip(),exit=status,groups_passed=groups,groups_total=d['tests'],assertions_passed=passed,assertions_total=total,failed_assertions=failures,raw_results_sha256=digest(root/'full/results.json'))
    write('suite-readback.json',value)
    orig=[root/p for p in ['pack_review.py','suite-readback.json','full.log','inputs.sha256','compiler.txt','build.log','qmp-transport.diff','run_stdio.py','start','stop','suite.exit','src/PCP_OS_Rust/crates/pcpos-kernel/tests/run_tests.py']]
    orig+=files_in('full',{'.log','.stderr','.png','.json'})
    write('audio-hashes.json',{str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=digest(p)) for p in files_in('full',{'.wav'})})
    zip_files('kernel-suite.zip',orig+[root/'audio-hashes.json'])
    print((groups,d['tests'],passed,total,failures))
elif sys.argv[1]=='replay':
    summary=read('replay-pins/summary.json')
    assert summary['passed'] and not summary['problems']
    assert summary['kernel_measurement']==read('hosted-compact-pins.json')['kernel_measurement']
    files=files_in('replay-pins',{'.ppm','.txt','.json'})+files_in('replay-socket-attempt',{'.log','.txt'})+[root/n for n in ['replay.log','replay_stdio.py','replay-transport.diff','src/examples/tester-cd/check_compact_pins.py']]
    tar('compact-regression-replay.tar.xz',files)
elif sys.argv[1]=='widgets':
    r=read('widget-comparison/result.json')
    assert r['qemu_exit']==0 and r['shutdown'].startswith('ALL SELF-TESTS PASS.')
    assert r['identical_pages']==[True]*3 and r['distinct_short_status']
    for v in r['states'].values():
        assert all('widget' not in x['status'] for x in v['paged'])
    tar('widget-count.tar.xz',files_in('widget-comparison',{'.ppm','.txt','.log','.json'})+[root/'widget_count.py'])

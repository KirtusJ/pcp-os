"""Compare the same pin's complete guest framebuffer with one and two hidden widget lines."""
from pathlib import Path
import hashlib
import json
import runpy
import shutil
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
out=root/'widget-comparison'
out.mkdir()
kernel=root/'disc-kernel.elf32'
prog=root/'disc-rdesk.elf'
opt=runpy.run_path(str(root/'src/examples/optical-disk-check/check.py'))
glyphs=opt['SCREEN']['kernel_glyphs']()
decode=runpy.run_path(str(root/'src/examples/tester-cd/check_compact_pins.py'))['read']
names=['a'*30+'A'+'z'*29+'.elf','short.elf']
for name in names:
    shutil.copyfile(prog,out/name)
measured=json.loads((root/'queue-receipt.json').read_text())['kernel_measurement']
serial=out/'serial.log'
log=lambda:serial.read_text(errors='replace') if serial.exists() else ''
qemu=str(Path(sys.argv[1]).resolve())
cmd=[qemu,'-machine','pc','-accel','tcg','-cpu','qemu64','-m','256M','-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel',str(kernel),'-append','desktop=320x200 image='+measured,'-initrd',','.join(names)]
states={}
with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
    try:
        mon=opt['Monitor'](guest)
        mon.call('qmp_capabilities')
        def key(*codes):
            mon.key(*codes)
            time.sleep(.36)
        def capture(label):
            path=out/(label+'.ppm')
            for _ in range(15):
                mon.call('screendump',filename=str(path))
                previous=path.read_bytes()
                time.sleep(.3)
                mon.call('screendump',filename=str(path))
                frame=path.read_bytes()
                if frame==previous:break
            else:raise AssertionError('unstable '+label)
            rows=decode(frame,glyphs)
            (out/(label+'.txt')).write_text('\n'.join(rows)+'\n')
            return {'status':rows[4].strip(),'frame_sha256':hashlib.sha256(frame).hexdigest()}
        opt['wait_for'](lambda: 'desktop: 320x200' in log() and measured+' (measured; equal' in log(),'verified desktop',45)
        time.sleep(.6)
        key('spc')
        key('ctrl','p')
        key('down')
        key('ctrl','p')
        key('esc')
        key('down')
        for count,steps in [(1,3),(2,4)]:
            key('f2')
            for _ in range(steps):key('down')
            key('ret')
            key('esc')
            readings=[]
            for i in range(3):
                if i:key('right')
                readings.append(capture(f'widgets-{count}-long-page{i+1}'))
            key('down')
            short=capture(f'widgets-{count}-short')
            key('up')
            states[count]={'paged':readings,'short':short}
        key('f10')
        key('ret')
        code=guest.wait(timeout=20)
    finally:
        if guest.poll() is None:
            guest.kill()
            guest.wait()
result=dict(kernel=hashlib.sha256(kernel.read_bytes()).hexdigest(),source='f9743bfbb61e771806c165779d15b854cc29232e',states=states,command=cmd,
            identical_pages=[x==y for x,y in zip(states[1]['paged'],states[2]['paged'])],
            distinct_short_status=states[1]['short']['status']!=states[2]['short']['status'],qemu_exit=code,shutdown=log().splitlines()[-1])
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(result['identical_pages'],[states[i]['short']['status'] for i in states],code)

from hashlib import sha256
from pathlib import Path
import json, runpy, zipfile
sha=lambda v:sha256(v).hexdigest()
checks={}
for name,expected in [('unpublished-tester-cd-queue-desk','de03f3a0a6f431be98fd9699512772d3e1ddbd7a39758800049a4c6ed8650dea'),('tester-cd-evidence-queue-desk','d5f59b7f0f0d728a92341e6663fc5b54ef22ed71955584adc109aee35b1c3a24')]:
 checks[name]=sha(Path(name+'.zip').read_bytes());assert checks[name]==expected
with zipfile.ZipFile('tester-cd-evidence-queue-desk.zip') as z:
 receipt=json.loads(z.read('first/receipt.json'))
 Path('queue-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
with zipfile.ZipFile('unpublished-tester-cd-queue-desk.zip') as z:
 image=z.read('pcp-os-tester.iso')
assert receipt['source_commit']=='f9743bfbb61e771806c165779d15b854cc29232e'
assert receipt['source_tree']=='992986aac40fc4e25ed54f23d6ae299eb7d8b821' and receipt['uncommitted_changes'] is False
assert sha(image)==receipt['iso_sha256']
files=runpy.run_path('src/examples/tester-cd/build.py')['read_back'](image)
for name in ['kernel.elf32','rdesk.elf']:
 assert sha(files[name])==receipt['inputs'][name]['sha256']
 Path('disc-'+name).write_bytes(files[name])
print(checks,receipt['kernel_measurement'])

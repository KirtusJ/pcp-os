from pathlib import Path
import hashlib, json, runpy, zipfile
sha=lambda data:hashlib.sha256(data).hexdigest()
out=Path('plain-cd');out.mkdir(exist_ok=True)
assert sha(Path('tester-cd-evidence.zip').read_bytes())=='07e0969c35e641fd65599250dcec7fde474f877ff5807b7b21e93542ae3056a6'
assert sha(Path('unpublished-tester-cd.zip').read_bytes())=='9d4317da07fe38523ac8202777b7063a8ffb65df82bfdd704358852924883ede'
with zipfile.ZipFile('tester-cd-evidence.zip') as z:
 receipt=json.loads(z.read('first/receipt.json'))
 assert receipt['source_commit']=='f9743bfbb61e771806c165779d15b854cc29232e' and receipt['source_tree']=='992986aac40fc4e25ed54f23d6ae299eb7d8b821' and receipt['uncommitted_changes'] is False
 (out/'receipt.json').write_bytes(z.read('first/receipt.json'))
 summary=json.loads(z.read('evidence/compact-pins/summary.json'))
 Path('hosted-compact-pins.json').write_text(json.dumps(summary,indent=2)+'\n')
 assert summary['passed'] and not summary['problems'] and summary['kernel_measurement']==receipt['kernel_measurement']
 assert all(v['exit_code']==0 for v in summary['results'].values())
 hosted_kernel=z.read('evidence/compact-pins/boot/kernel.elf32')
with zipfile.ZipFile('unpublished-tester-cd.zip') as z:
 image=z.read('pcp-os-tester.iso')
 assert sha(image)==receipt['iso_sha256']
 (out/'pcp-os-tester.iso').write_bytes(image)
 files=runpy.run_path('src/examples/tester-cd/build.py')['read_back'](image)
 assert files['kernel.elf32']==hosted_kernel==Path('disc-kernel.elf32').read_bytes()
print(sha(hosted_kernel),summary['programs'])

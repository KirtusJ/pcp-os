"""Boot each input alone, power down from Home and read the register and shutdown verdict."""
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
qemu=Path(sys.argv[1]).resolve()
opt=runpy.run_path(str(root/'src/examples/optical-disk-check/check.py'))
measure=json.loads((root/'queue-receipt.json').read_text())['kernel_measurement']
checks=[]
for length in (64,65,113):
    out=root/f'control-{length}'
    out.mkdir()
    name=('matching-prefix-'*9)[:length-5]+'7.elf'
    assert len(name.encode())==length
    shutil.copyfile(root/'disc-rdesk.elf',out/name)
    logpath=out/'serial.log'
    log=lambda:logpath.read_text(errors='replace') if logpath.exists() else ''
    cmd=[str(qemu),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','256M','-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(logpath),'-kernel',str(root/'disc-kernel.elf32'),'-append','desktop=320x200 image='+measure,'-initrd',name]
    with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
        try:
            monitor=opt['Monitor'](guest)
            monitor.call('qmp_capabilities')
            opt['wait_for'](lambda: 'desktop: 320x200' in log() and measure+' (measured; equal' in log(),'verified desktop',45)
            time.sleep(.7)
            monitor.key('f10')
            time.sleep(.55)
            monitor.key('ret')
            code=guest.wait(timeout=35)
        finally:
            if guest.poll() is None:
                guest.kill()
                guest.wait()
    lines=log().splitlines()
    row=dict(length=length,exit=code,verdict=lines[-1],register_messages=[l for l in lines if 'register refused ARTIFACT_ADDED' in l],program_launched=any(l.startswith('starting '+name) for l in lines),command=cmd)
    checks.append(row)
(root/'artifact-name-control.json').write_text(json.dumps(checks,indent=2)+'\n')
print([(r['length'],r['exit'],r['verdict'][:22],len(r['register_messages'])) for r in checks])

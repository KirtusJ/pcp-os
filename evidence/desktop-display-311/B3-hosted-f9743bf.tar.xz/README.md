# B3 desktop read-back on f9743bf

I booted the kernel and Queue Desk extracted from the Queue Desk tester CD in Actions run 44908609151. The receipt identifies source f9743bfbb61e771806c165779d15b854cc29232e, tree 992986aac40fc4e25ed54f23d6ae299eb7d8b821, and a clean build. I verified both downloaded ZIP digests, the ISO digest, the two binaries and the executable measurement seen by each guest. The guests were diskless QEMU 10.0.13 TCG machines with virtual standard VGA.

At 320×200 the same selected 64-byte name renders identically on each of its three pages with one hidden widget line and five. The short neighboring pin displays the different counts. The selected name itself reads correctly on all pages, including byte 31. The selected pin's size and digest prefix are visible and Enter produces a visible refusal that persists while paging. At 640×480 the guest shows full names and all five widget lines. In both modes seven pins were reachable and three Queue Desk sessions ended successfully.

The Files runs used a guest program that wrote zero to 31 named files of 1 KiB. The driver compared the visible ranges, totals, names, units and paging controls on every page and required an exact pixel match to the selected Home after Esc. It covered 0, 1, 3 and 31 files at 320×200, 23 at 800×600, 31 at 1024×768 and 1280×720, and 31 at 1280×960 with native 2× type. Ten completed guests each recorded 72 passing checks and a guest-requested shutdown. Three preliminary attempts are retained. One expected the compact heading on graphical Home. One requested 2560×1440 and got 1920×1080. One tried to read the native double-size face with the regular font. These attempts do not count as completed guest runs.

Run python3 -IB verify.py in the extracted directory to check the captures against the records. The replay arguments, input measurement, key events or file fixture source and framebuffer hashes are in the hosted subdirectories. For a fresh run, check out the named source commit and supply the kernel and Queue Desk extracted from the published ISO. The 2× reader uses NumPy and Pillow.

Hosted ZIP SHA-256 values:
- unpublished-tester-cd-queue-desk (artifact 14709345525): de03f3a0a6f431be98fd9699512772d3e1ddbd7a39758800049a4c6ed8650dea
- tester-cd-evidence-queue-desk (artifact 14708719027): d5f59b7f0f0d728a92341e6663fc5b54ef22ed71955584adc109aee35b1c3a24

The included receipt carries the ISO, binary and measurement digests. Original screenshots use native P6 format. The worker register records dispatch and release. The local preliminary runs used a separately compiled kernel and are excluded from the ten hosted-kernel guest counts.

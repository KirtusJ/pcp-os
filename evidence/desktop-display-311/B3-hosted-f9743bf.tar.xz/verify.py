"""Check the hosted receipt, original QEMU frames, serial records and Files coverage."""
import hashlib
import json
import sys
from pathlib import Path

root = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
get = lambda p: json.loads(p.read_bytes())
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
rev = 'f9743bfbb61e771806c165779d15b854cc29232e'
receipt = get(root/'hosted/receipt.json')
assert receipt['source_commit']==rev and receipt['uncommitted_changes'] is False
assert receipt['source_tree']=='992986aac40fc4e25ed54f23d6ae299eb7d8b821'
kernel=receipt['on_disc']['kernel.elf32']['sha256']
program=receipt['on_disc']['rdesk.elf']['sha256']
for name,expected in [('pcp-os-tester.iso',receipt['iso_sha256']),('kernel.elf32',kernel),('rdesk.elf',program)]:
    p=root/'hosted'/name
    if p.is_file(): assert digest(p)==expected
for width in (320,640):
    d=root/'hosted'/f'widgets{width}'
    record=get(d/'result.json')
    assert record['source']==rev and record['kernel_sha256']==kernel and record['program_sha256']==program
    assert record['measurement']==receipt['kernel_measurement']
    assert record['shutdown']=={'guest':True,'reason':'guest-shutdown'} and record['exit']==0 and record['passes']==72
    assert all(digest(d/(name+'.ppm'))==h for name,h in record['frames'].items())
    assert (d/'serial.txt').read_text().count('program-02.elf ended DONE: exit 0')==3
    rows=lambda n:(d/(n+'.txt')).read_text().splitlines()
    if width==320:
        for i,src in enumerate(('one-widget-long','one-widget-long-p2','one-widget-long-p3'),start=1):
            assert (d/(src+'.ppm')).read_bytes()==(d/f'a-part-{i}.ppm').read_bytes()
            assert f'name {i}/3' in rows(src)[4] and 'widget' not in rows(src)[4]
        assert '1 widget' in rows('one-widget-short')[4] and '5 widget' in rows('five-widget-short')[4]
        assert (d/'one-widget-short.ppm').read_bytes()!=(d/'five-widget-short.ppm').read_bytes()
        for label,ch in [('a','A'),('b','B')]:
            assert ''.join(rows(f'{label}-part-{i}')[6].strip() for i in (1,2,3))=='a'*30+ch+'z'*29+'.elf'
        for name in ('refused-a','refused-a-part-1','refused-a-part-2'):
            assert 'Not started: not admitted' in rows(name)[2]
        assert 'Not started' not in rows('short-after-refused-a')[2]
    else:
        for label,ch in [('a','A'),('b','B')]:
            view=rows(f'{label}-part-1')
            begin=view.index('  Enter starts')+1
            assert ''.join(x.strip() for x in view[begin:begin+2])=='a'*30+ch+'z'*29+'.elf'
            assert any(program[:16] in x for x in view)
            assert sum(' DONE program-02.elf' in x for x in view)==3
            assert any('memory ' in x for x in view) and any('Session files' in x for x in view)
    for i in range(1,8):
        rowset=rows(f'chosen-{i}')
        assert any('Enter open' in r for r in rowset)
        if width==320: assert f'Place {i+1}/8' in rowset[4]
    print(f'{width}: validated seven pins, three completed sessions, name and widget comparisons')
for d in sorted((root/'hosted').iterdir()):
    if not d.is_dir() or not (d/'report.json').exists():continue
    j=get(d/'report.json')
    if not j.get('shutdown'):
        print(d.name,'incomplete first attempt'); continue
    assert j['measurement']==receipt['kernel_measurement'] and j['kernel_sha256']==kernel
    assert j['unique_names_reached']==j['count'] and j['passes']==72 and j['exit']==0 and j['shutdown']['guest']
    assert all(digest(d/(key+'.ppm'))==f['sha256'] for key,f in j['frames'].items())
    assert j['frames']['home']['sha256']==j['frames']['restored']['sha256']
    print(d.name,j['unique_names_reached'],'names; returned to identical Home')

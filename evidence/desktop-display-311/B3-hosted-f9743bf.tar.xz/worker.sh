set -eu
where=$(cd "$(dirname "$0")" && pwd)
pcpb=/workspace/scratch/37d126f1c36d
export PCPOS_BIN="$pcpb/build-worker/release/pcpos"
label=$1
shift
exec "$pcpb/run/register-dispatch" --register "$where/review.jsonl" B3 "$label" -- "$@"

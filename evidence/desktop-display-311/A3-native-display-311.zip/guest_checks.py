from pathlib import Path
from hashlib import sha256
import json,os,sys,time,subprocess,runpy,re
from PIL import Image,ImageChops
root=Path(__file__).resolve().parent
mode=sys.argv[1];qemu=Path(sys.argv[2]).resolve();out=root/('observed-'+mode);out.mkdir(exist_ok=True)
ident=json.loads((root/'inputs/identities.json').read_bytes())
checker=runpy.run_path(str(root/'src/examples/tester-cd/check.py'));glyphs=checker['kernel_glyphs']()
names=['sharedprefixA.elf','sharedprefixB.elf','shoredprefixC.elf'] if mode=='pins' else ['write'+mode+'.elf']
size={'pins':'1920x1080','23':'800x600','31':'1024x768'}[mode]
ser=out/'serial.txt'
cmd=[str(qemu),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','128M','-kernel','kernel.elf32','-initrd',','.join(names),'-append','image='+ident['measurement']+' desktop='+size,'-vga','std','-nic','none','-audiodev','none,id=snd0','-device','AC97,audiodev=snd0','-display','none','-serial','file:'+str(ser),'-monitor','none','-qmp','stdio','-no-reboot']
proc=subprocess.Popen(cmd,cwd=root/'inputs',stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(out/'stderr.txt').open('w'),text=True)
qevents=[]
def recv():
 while True:
  line=proc.stdout.readline()
  if not line:raise RuntimeError('QEMU closed: '+str(proc.poll()))
  m=json.loads(line)
  if 'event' in m:qevents.append(m)
  else:return m
def rpc(name,**args):
 proc.stdin.write(json.dumps({'execute':name,'arguments':args})+'\n');proc.stdin.flush();res=recv();assert 'error' not in res,res;return res
def key(*names):
 rpc('send-key',keys=[{'type':'qcode','data':v} for v in names],**{'hold-time':80});time.sleep(.32)
def waitserial(text,count=1):
 end=time.monotonic()+25
 while time.monotonic()<end:
  if ser.exists() and ser.read_text(errors='replace').count(text)>=count:return
  if proc.poll()!=None:break
  time.sleep(.12)
 raise RuntimeError('waiting '+text+' '+(ser.read_text(errors='replace')[-700:] if ser.exists() else ''))
def read(name):
 raw=(out/(name+'.ppm')).read_bytes()
 return checker['read_screen'](raw,glyphs)
def capture(name,check=None):
 p=out/(name+'.ppm');end=time.monotonic()+14
 while True:
  rpc('screendump',filename=str(p))
  rows=read(name)
  if rows and (check is None or check(rows)):break
  if time.monotonic()>end:raise RuntimeError(name+' wrong screen: '+str(rows)[-1200:])
  time.sleep(.22)
 (out/(name+'.rows.txt')).write_text('\n'.join(rows)+'\n')
 return rows
def shot(name):
 return (out/(name+'.ppm')).read_bytes()
def count_name(n):return len([l for l in ser.read_text(errors='replace').splitlines() if l.startswith(n+' ended DONE: exit 0')])
def pin_check():
 marks=['alpha','bravo','charlie']
 key('spc')
 for i,n in enumerate(names):
  if i:key('down')
  capture('launcher-'+str(i),lambda x:any('> '+n[:16] in r and ident['programs'][n][:16] in r for r in x))
  key('ctrl','p')
  capture('pinned-'+str(i),lambda x:sum('pinned to the desktop' in r for r in x)==i+1)
 key('esc')
 frames={}
 for form in ['bar','dock']:
  if form=='dock':
   for _ in range(3):key('left')
   key('f2');key('down');key('ret');key('esc')
  for i,n in enumerate(names):
   key('right')
   label='{}-selected-{}'.format(form,i)
   capture(label,lambda rows:sum(row.count('sharedprefix') for row in rows)==2 and any('shoredprefix' in row for row in rows))
   key('ret');waitserial('entered '+marks[i],1 if form=='bar' else 2)
   key('esc');waitserial('Esc '+marks[i],1 if form=='bar' else 2)
   waitserial(n+' ended DONE: exit 0',1 if form=='bar' else 2)
   capture(form+'-returned-'+str(i),lambda rows:sum(row.count('sharedprefix') for row in rows)==2 and any('shoredprefix' in row for row in rows))
   full=[row for row in read(label) if n in row or ident['programs'][n][:16] in row]
   frames[label]={'full_name_or_digest_rows':full}
  regions=[]
  w,h=map(int,size.split('x'));y=h//20*20
  for i in range(3):
   im=Image.open(out/(form+'-selected-'+str(i)+'.ppm'))
   if form=='bar':
    x=10+(i+1)*190+50; yy=y-40
   else:
    x=(w-(4*140+20))//20*10+10+(i+1)*140+(140-120)//20*10; yy=y-60
   crop=im.crop((x,yy,x+120,yy+20)); regions.append(crop)
   frames[form+'-selected-'+str(i)]['label_rgb_sha256']=sha256(crop.tobytes()).hexdigest()
  # Full P6 is retained. Transparent text has a plate gradient that is independent of slot.
  assert ImageChops.difference(regions[0],regions[1]).getbbox() is None,(form,'alias crops differ')
  assert ImageChops.difference(regions[0],regions[2]).getbbox() is not None,(form,'control same')
 return frames
def files_check():
 count=int(mode); key('ret');key('ret'); waitserial(names[0]+' ended DONE: exit 0');key('esc')
 capture('home-before-f3',lambda rows:any('PCP OS | DESKTOP' in l for l in rows));key('f3')
 limit=count-1
 pred=lambda rows:any('FILES: '+str(count)+' file(s)' in l for l in rows) and any('f%03d'%limit in l for l in rows)
 before=capture('initial',pred)
 def listfiles(rows):return [l.strip().split()[0] for l in rows if re.match(r'^\s*f\d{3}\s',l)]
 expected=['f%03d'%i for i in range(1,count+1)]
 assert listfiles(before)==expected[:-1],listfiles(before)
 for n in ['down','pgdn','end','up','pgup']:
  key(n);capture('after-'+n,pred);assert shot('after-'+n)==shot('initial'),n
 key('esc');capture('home-after-f3',lambda rows:any('PCP OS | DESKTOP' in l for l in rows))
 assert shot('home-after-f3')==shot('home-before-f3')
 assert all('created/read '+n in ser.read_text(errors='replace') for n in expected)
 return dict(count=count,visible=listfiles(before),created_and_read=expected,home_restored=True,no_motion=['down','pgdn','end','up','pgup'])
try:
 recv();rpc('qmp_capabilities');waitserial('desktop: '+size);time.sleep(.8)
 result=pin_check() if mode=='pins' else files_check()
 key('f10');capture('question',lambda s:any('POWER OFF' in l for l in s));key('ret')
 proc.wait(timeout=8);rem=proc.stdout.read().splitlines()
 qevents += [json.loads(l) for l in rem if 'event' in json.loads(l)]
 serial=ser.read_text(errors='replace')
 assert ident['measurement']+' (measured; equal' in serial and 'ALL SELF-TESTS PASS.' in serial
 assert proc.returncode==0 and any(q.get('event')=='SHUTDOWN' and q['data']['guest'] for q in qevents)
 res=dict(fixture=mode,source=ident['commit'],kernel_sha256=ident['kernel'],measurement=ident['measurement'],programs={n:ident['programs'][n] for n in names},qemu=subprocess.check_output([qemu,'--version'],text=True).splitlines()[0],argv=cmd,final_passes=sum(s.startswith('  pass ') for s in serial.splitlines()),exit_code=proc.returncode,events=qevents,results=result,files={p.name:sha256(p.read_bytes()).hexdigest() for p in sorted(out.glob('*')) if p.suffix in ['.ppm','.txt']})
 (out/'result.json').write_text(json.dumps(res,indent=2));print(mode,proc.returncode,res['final_passes'])
finally:
 if proc.poll() is None:proc.terminate();proc.wait(timeout=8)

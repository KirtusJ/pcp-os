from pathlib import Path
import hashlib, json,runpy,subprocess,zipfile
root=Path(__file__).resolve().parent
tools=root/'src/PCP_OS_Rust/crates/pcpos-kernel/tools'
out=root/'inputs';out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(root/'frozen.zip') as z: image=z.read('pcp-os-tester.iso')
items=runpy.run_path(str(root/'src/examples/tester-cd/build.py'))['read_back'](image)
elf=items['kernel.elf32']; (out/'kernel.elf32').write_bytes(elf)
m=runpy.run_path(str(tools/'measure.py'))['measure'](elf)
assert m in items['limine.conf'].decode()
config=dict(commit=subprocess.check_output(['git','-C',root/'src','rev-parse','HEAD'],text=True).strip(),tree=subprocess.check_output(['git','-C',root/'src','rev-parse','HEAD^{tree}'],text=True).strip(),iso=sha(image),kernel=sha(elf),measurement=m,build_url='https://github.com/KirtusJ/pcp-os/actions/runs/44887282478/artifacts/14700715832',programs={})
for name,flag in [('sharedprefixA.elf','-DMARK="alpha"'),('sharedprefixB.elf','-DMARK="bravo"'),('shoredprefixC.elf','-DMARK="charlie"'),('write23.elf','-DFILE_COUNT=23'),('write31.elf','-DFILE_COUNT=31')]:
    obj=out/(name+'.o')
    subprocess.run(['gcc','-Os','-ffreestanding','-fno-stack-protector','-fno-asynchronous-unwind-tables','-fpie',flag,'-c',root/'fixture.c','-o',obj],check=True)
    subprocess.run(['ld','-T',root/'src/store/games/flux-rink/guest.ld','--build-id=none','-s','-o',out/name,obj],check=True)
    config['programs'][name]=sha((out/name).read_bytes())
(out/'identities.json').write_text(json.dumps(config,indent=2))

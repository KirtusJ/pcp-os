"""Exercise F3 with ordinary files written inside a measured, diskless guest."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import struct
import subprocess
import time

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_program(out, count):
    assembly = ['.intel_syntax noprefix', '.text']
    for n in range(1, count + 1):
        assembly.extend([f'lea rdi, [rip + name{n}]', 'call save'])
    assembly.extend(['mov eax,60', 'xor edi,edi', 'syscall', 'save:',
                     'mov eax,2', 'mov esi,577', 'mov edx,420', 'syscall', 'test rax,rax', 'js failed',
                     'mov rdi,rax','mov eax,1','lea rsi,[rip + data]','mov edx,1024',
                     'syscall','cmp rax,1024','jne failed','mov eax,3','syscall','test rax,rax','jne failed',
                     'ret','failed:','mov eax,60','mov edi,1','syscall','data: .zero 1024'])
    for n in range(1,count+1):
        assembly.append(f'name{n}: .asciz "file{n:02d}.txt"')
    src = out / 'fixture.S'
    src.write_text('\n'.join(assembly)+'\n')
    subprocess.run(['as','--64',src,'-o',out/'fixture.o'],check=True)
    subprocess.run(['objcopy','-O','binary','-j','.text',out/'fixture.o',out/'fixture.bin'],check=True)
    raw = (out/'fixture.bin').read_bytes()
    size = 120 + len(raw)
    header = struct.pack('<16sHHIQQQIHHHHHH', b'\x7fELF\x02\x01\x01',3,62,1,120,64,0,0,64,56,1,0,0,0)
    (out/'files.elf').write_bytes(header + struct.pack('<IIQQQQQQ',1,5,0,0,0,size,size,4096) + raw)

def read_double(frame, source):
    import numpy as np
    from PIL import Image
    from io import BytesIO
    atlas=(source/'PCP_OS_Rust/crates/pcpos-kernel/src/font-2x.bin').read_bytes()
    glyphs={bytes(np.packbits(np.frombuffer(atlas[n:n+800],dtype=np.uint8)>0)):chr(32+n//800) for n in range(0,len(atlas),800)}
    im=np.asarray(Image.open(BytesIO(frame)))
    rows=[]
    for y in range(0,im.shape[0]-39,40):
        line=[]
        for x in range(0,im.shape[1]-19,20):
            cell=im[y:y+40,x:x+20]
            # The monospaced font leaves the upper-left pixel in its background.
            mask=np.any(cell!=cell[0,0],axis=2)
            line.append(glyphs.get(bytes(np.packbits(mask)),'?'))
        rows.append(''.join(line).rstrip())
    return rows

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for a in ('source','kernel','qemu','output'):
        p.add_argument(a, type=Path)
    p.add_argument('geometry')
    p.add_argument('count',type=int)
    p.add_argument('--scale', type=int, choices=(1,2), default=1)
    args=p.parse_args()
    w,h=map(int,args.geometry.split('x'))
    home_mark='F1 keys' if w>=1280 and h>=720 and args.scale==1 else 'PCP OS | DESKTOP'
    source,kernel,out=args.source.resolve(),args.kernel.resolve(),args.output.resolve()
    out.mkdir(parents=True)
    write_program(out,args.count)
    optical=runpy.run_path(str(source/'examples/optical-disk-check/check.py'))
    read=runpy.run_path(str(source/'examples/tester-cd/check_compact_pins.py'))['read']
    glyphs=optical['SCREEN']['kernel_glyphs']()
    measurement=runpy.run_path(str(source/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](kernel.read_bytes())
    serial=out/'serial.txt'
    cmd=[str(args.qemu.resolve()),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','128M','-nic','none','-vga','std','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel',str(kernel),'-append','desktop='+args.geometry+' ui_scale='+str(args.scale)+' image='+measurement,'-initrd','files.elf']
    assert subprocess.check_output(['git','hash-object',source/'PCP_OS_Rust/crates/pcpos-kernel/src/session.rs'],text=True).strip()=='c2e2dda267ee9b471b4649ac7d5bfb723559f528'
    case={'commit':'07702222e84990b5c716676ac67dcd8b47d2cbd2','measurement':measurement,'kernel_sha256':sha(kernel.read_bytes()),'count':args.count,'geometry':args.geometry,'argv':cmd,'frames':{}}
    with (out/'stderr.txt').open('wb') as err:
        guest=subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
        try:
            monitor=optical['Monitor'](guest)
            monitor.call('qmp_capabilities')
            def key(code):
                monitor.key(code)
                time.sleep(.27)
            def wait_log(s):
                optical['wait_for'](lambda:serial.exists() and s in serial.read_text(),s,25)
            def capture(name,expect):
                ppm=out/(name+'.ppm')
                previous=None
                end=time.monotonic()+8
                while time.monotonic()<end:
                    monitor.call('screendump',filename=str(ppm))
                    raw=ppm.read_bytes()
                    if raw==previous:
                        if 'at 2x UI scale' in serial.read_text():
                            rows=read_double(raw,source)
                        else:
                            rows=read(raw,glyphs)
                        if any(expect in row for row in rows):
                            case['frames'][name]={'rows':rows,'sha256':sha(raw)}
                            return rows
                    previous=raw
                    time.sleep(.12)
                raise RuntimeError(f'{name}: {expect} absent; {read(raw,glyphs)}')
            wait_log(f'desktop: {args.geometry} at {args.scale}x UI scale')
            wait_log(measurement+' (measured; equal')
            capture('startup',home_mark)
            key('spc')
            monitor.key('ctrl','p');time.sleep(.3)
            key('ret')
            wait_log('files.elf ended DONE: exit 0')
            key('esc')
            key('down')
            capture('home',home_mark)
            key('f3')
            first=capture('first','FILES:')
            raw_height=int(args.geometry.split('x')[1])
            scale=2 if 'at 2x UI scale' in serial.read_text() else 1
            page=max(raw_height//(20*scale)-8,1)
            n=args.count
            def verify_page(label, top):
                rows=case['frames'][label]['rows']
                end=min(n,top+page)
                expected=[f'file{i:02d}.txt' for i in range(top+1,end+1)]
                actual=[row.split()[0] for row in rows if row.strip().startswith('file')]
                assert actual==expected,(label,actual,expected,rows)
                for name in expected:
                    assert any(row.strip().split()==[name,'1','KiB'] for row in rows),(label,name,rows)
                long=f'FILES: showing {top+1} to {end} of {n}, {n} KiB'
                short=f'FILES: {top+1}-{end}/{n} | {n} KiB'
                allowed=(long,short) if n else ('FILES: 0 file(s), 0 KiB',)
                assert rows[1].strip() in allowed,(label,rows[1],allowed)
                assert 'Esc back' in rows[-2],(label,rows[-2])
                case['frames'][label]['expected_range']=[top+1 if n else 0,end,n]
                return actual
            seen=set(verify_page('first',0))
            top=0
            for step in range(1,1+max(1,(n+page-1)//page)):
                key('pgdn')
                label=f'down-{step}'
                capture(label,'FILES:')
                top=min(top+page,max(n-page,0))
                seen.update(verify_page(label,top))
                if top==max(n-page,0):break
            assert seen=={f'file{i:02d}.txt' for i in range(1,n+1)}
            key('up');capture('up','FILES:')
            top=max(0,top-1);verify_page('up',top)
            step=0
            while top>0 or step==0:
                key('pgup');step+=1
                label=f'back-{step}';capture(label,'FILES:')
                top=max(0,top-page);verify_page(label,top)
            key('esc');capture('restored',home_mark)
            assert case['frames']['home']['sha256']==case['frames']['restored']['sha256']
            assert case['frames']['first']['sha256']==case['frames'][label]['sha256']
            case['unique_names_reached']=len(seen)
            case['ui_scale']=scale
            key('f10')
            capture('power','Switch PCP OS off?')
            key('ret')
            while not any(e['event']=='SHUTDOWN' for e in monitor.events):
                monitor.events.append(monitor.read())
            case['shutdown']=next(e['data'] for e in monitor.events if e['event']=='SHUTDOWN')
            case['exit']=guest.wait(timeout=15)
            log=serial.read_text()
            case['passes']=sum(l.startswith('  pass ') for l in log.splitlines())
            assert case['shutdown']=={'guest':True,'reason':'guest-shutdown'} and case['exit']==0 and case['passes']==72 and 'ALL SELF-TESTS PASS.' in log
            print(args.geometry,n,case['frames']['first']['rows'][1],case['frames']['first']['rows'][-2],flush=True)
        finally:
            if guest.poll() is None:
                guest.kill()
                guest.wait()
            (out/'report.json').write_text(json.dumps(case,indent=2)+'\n')
if __name__=='__main__':
    main()

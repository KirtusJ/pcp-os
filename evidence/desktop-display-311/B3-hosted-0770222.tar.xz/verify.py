"""Replay independent screen and receipt checks for B3's 0770222 candidate decision."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
def run(*args):
    subprocess.run([sys.executable,'-IB',*map(str,args)],check=True)
run(root/'verify_origin.py')
receipt=json.loads((root/'hosted/receipt.json').read_text())
for variant in ('hosted','local'):
    for path in (root/variant).glob('*-*-*/result.json'):
        r=json.loads(path.read_text())
        assert r['source_session_blob']=='c2e2dda267ee9b471b4649ac7d5bfb723559f528'
        assert r['program_sha256']==receipt['on_disc']['rdesk.elf']['sha256']
        if variant=='hosted':
            assert r['kernel_sha256']==receipt['on_disc']['kernel.elf32']['sha256']
            assert r['measurement']==receipt['kernel_measurement']
    run(root/'verify_widths.py',root/variant,root/'source',variant)
run(root/'verify_controls.py',root)
for mode in ('440-64-2','320-255-14'):
    d=root/'local'/mode
    r=json.loads((d/'result.json').read_text())
    for label in r['frames']:
        if label.startswith(('one-','off-')):
            a=(d/(label+'.txt')).read_text().splitlines()
            b=(root/'hosted'/mode/(label+'.txt')).read_text().splitlines()
            assert a[4:]==b[4:]
    print('Independent local and hosted displays agree for',mode)

"""Decode each captured PPM and compare its navigation hint and complete name to the expected text."""
import hashlib
import json
import runpy
import sys
from pathlib import Path

root = Path(sys.argv[1])
source = Path(sys.argv[2]).resolve()
read = runpy.run_path(str(source/'examples/tester-cd/check_compact_pins.py'))['read']
glyphs = runpy.run_path(str(source/'examples/tester-cd/check.py'))['kernel_glyphs']()
expected = set('432-64-2 440-64-2 480-64-2 528-64-2 536-64-2 640-64-2 440-255-16 552-255-16 560-255-16 320-255-16'.split())
kind = sys.argv[3]
expected.update(('320-255-14','320-255-15','848-255-16','856-255-16'))
if kind=='local':
    expected={'440-64-2','320-255-14'}
cases = {p.parent.name:p for p in root.glob('*-*-*/result.json')}
assert set(cases) == expected
for case, file in sorted(cases.items()):
    d = file.parent
    r = json.loads(file.read_text())
    assert r['exit']==0 and r['pass_lines']==72 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    w, length, pins = map(int,case.split('-'))
    assert r['clean'] == (length==64)
    serial = (d/'serial.txt').read_text()
    if not r['clean']:
        assert '1 SELF-TEST(S) FAILED' in serial and 'the register refused ARTIFACT_ADDED:' in serial
    else:
        assert 'ALL SELF-TESTS PASS.' in serial and 'SELF-TEST(S) FAILED' not in serial
    assert r['program_sha256']=='46f4bbd5e4d754a78d9b018d15d9249f8dbce04fb536e6bc49f638104850d8b1'
    assert (w,length,pins)==(r['width'],r['length'],r['pins'])
    goalname = ''.join(chr(97+(i//10)%26) for i in range(length-4))+'.elf'
    for label, digest in r['frames'].items():
        frame = (d/(label+'.ppm')).read_bytes()
        assert hashlib.sha256(frame).hexdigest() == digest
        rows = read(frame,glyphs)
        assert rows == (d/(label+'.txt')).read_text().split('\n')
        if label.startswith(('one-','off-')):
            page = int(label.split('-')[1])
            total = r['pages']
            count = f'{pins+1}/{pins+1}'
            row = rows[4].strip()
            room=w//10-4
            wordings=(f'Places {pins+1} to {pins+1} of {pins+1} | name part {page} of {total}: Left/Right',
                      f'Place {count} | name {page}/{total} <- ->',
                      f'{count} | name {page}/{total} <- ->',
                      f'{count} | {page}/{total} <- ->')
            expected_hint=next(hint for hint in wordings if len(hint)<=room)
            hidden='1 widget line(s) not shown'
            bottom=rows[-1].strip()
            if label.startswith('one-') and len(expected_hint)+3+len(hidden)<=room:
                assert row==expected_hint+' | '+hidden and not bottom,(case,label,row,bottom)
            else:
                assert row==expected_hint,(case,label,row,expected_hint)
                assert bottom==(hidden if label.startswith('one-') else ''),(case,label,bottom)
            assert '53 KiB' in rows[7] and r['program_sha256'][:14] in rows[7] and 'Enter open' in rows[8]
        if label == 'refusal':
            assert 'Not started' in rows[2]
    for state in ('one','off'):
        parts=[(d/f'{state}-{n:02d}.txt').read_text().splitlines()[6].strip() for n in range(1,r['pages']+1)]
        assert ''.join(parts)==goalname
    print(kind,case,r['pages'],'pages','complete hint and widget count')

# F3 wrapped-range correction

The same 640×480 QEMU guest case was run directly against the kernels recovered from the one-app tester CDs of two successive #312 revisions. The fixture writes, reopens and checks distinct bytes in 31 files. File 16 starts on the last row of the initial viewport and spans three rows. The two run directories retain the original QMP framebuffer dumps, decoded rows, serial output, kernel, fixture, argument list and build receipt. These sessions used direct kernel loading, TCG, 128 MiB RAM and a volatile store.

| Key / position | Visible file ordinals | Earlier heading | Fixed heading |
|---|---|---|---|
| Initial | 1–16 | 1–16 | 1–16 |
| Page Down | 16–30 | 17–30 | 16–30 |
| Down at the end | 16–31 | 17–31 | 16–31 |
| Up to the complete 101-character name | 16–29 | 16–29 | 16–29 |

The runs used the same input keys, verified fixture bytes and QEMU machine settings. Each original F3 body matched every one of the 16 expected rows. The fixture binaries were byte-identical. The observer waited for each expected body; it independently decoded the heading and retained the original frame. Each guest returned to the original first page and Home, passed its final register test (72 pass records in all), issued guest shutdown and exited QEMU with status 0. The source fix tests for a nonempty intersection between each file’s row interval and the viewport.

The earlier source was `7a3265234ad4e66637aeccbc672ba424d9fdda62`. Its one-app [tester CD](https://github.com/KirtusJ/pcp-os/actions/runs/44898465593/artifacts/14705565120) yielded ELF SHA-256 `4bf7a5cc8b7c6451f84ba90a55fec6e1b8ad040671caf59a1391c47d911de00a` and measured image `08a4907d50457511400f9048c90bbd1cbb7c22a3fd4faea92f6adbf6be2a0fac`. The seven F3 frames matched byte-for-byte the earlier 3b085321 observations.

The fixed source was `04a2954c5296cce90106d32d2d358392a3271efa`. Its one-app [tester CD](https://github.com/KirtusJ/pcp-os/actions/runs/44899146236/artifacts/14705781097) yielded ELF SHA-256 `541c0ecea03db58b6987312e6e99800f1935803792ffb034ddd03f6db61a3090` and measured image `1cb547a13b97cf1a9400244815fe6bd307cf39376cdab4d5e4d7cdd57b5b6fc6`. Each run’s origin file records the original GitHub artifact digests and underlying ISO SHA-256. The full P6 comparison for all seven F3 captures is in `before-after.json`. In four split-page frames exactly 86 pixels changed, all inside the heading digit at x 181–188 and y 23–34. The other three F3 frames were byte-identical.

A second fixed-head run directly booted the kernel extracted from the [two-app tester CD](https://github.com/KirtusJ/pcp-os/actions/runs/44899146236/artifacts/14705646575). The kernels from the two separately mastered CDs were byte-identical, and both produced identical captures for all seven F3 page positions. The `two-app-repeat/` directory preserves the second run’s original evidence and the second CD’s own build receipt. The archive contains 33 P6 captures in all, 11 per native session.

To verify the archive, extract it and run `sha256sum --check SHA256SUMS`. For independent pixel comparison use Python 3 and Pillow and run `python3 compare_range.py before/observed after/observed repeated-comparison.json`. To repeat either native guest, check out the source commit for that side in a separate checkout, then run `python3 after/observe.py "$(command -v qemu-system-x86_64)" replay-fixed --source /path/to/fixed/checkout` or the corresponding `before/observe.py` invocation. The recorded Linux QEMU was 10.0.13 with standard VGA and BIOS. The specifications in each observer are specific to its recorded revision.

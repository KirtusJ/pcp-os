"""Compare before/after original P6s, including every file-list pixel outside the heading."""
from pathlib import Path
from PIL import Image,ImageChops
from hashlib import sha256
import json,sys
before,after,output=map(Path,sys.argv[1:4])
data=[json.loads((p/'result.json').read_bytes()) for p in (before,after)]
assert data[0]['fixture_sha256']==data[1]['fixture_sha256']
rows=[]
for old,new in zip(*(d['observations'] for d in data),strict=True):
    tag=old['frame']
    assert tag==new['frame'] and old['visible']==new['visible']==new['stated']
    p=before/(tag+'.ppm');q=after/(tag+'.ppm')
    with Image.open(p) as x,Image.open(q) as y:
        diff=ImageChops.difference(x,y)
        bbox=diff.getbbox()
        count=sum(1 for rgb in diff.getdata() if rgb!=(0,0,0))
    assert sha256(p.read_bytes()).hexdigest()==old['sha256'] and sha256(q.read_bytes()).hexdigest()==new['sha256']
    if old['stated']==new['stated']:
        assert not bbox and p.read_bytes()==q.read_bytes()
    else:
        assert old['stated'][0]==new['stated'][0]+1 and old['stated'][1]==new['stated'][1] and bbox is not None
        assert 20<=bbox[1]<bbox[3]<=40, bbox
    rows.append(dict(frame=tag,before_heading=old['heading'],after_heading=new['heading'],visible=new['visible'],
                     changed_pixels=count,changed_pixel_bbox=bbox,before_sha256=old['sha256'],after_sha256=new['sha256']))
report=dict(before_source=data[0]['source'],after_source=data[1]['source'],fixture_sha256=data[0]['fixture_sha256'],pages=rows)
output.write_text(json.dumps(report,indent=2)+'\n')
print([(r['frame'],r['changed_pixels'],r['changed_pixel_bbox']) for r in rows])

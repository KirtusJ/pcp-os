"""Read desktop text and change two ordinary widget settings in a disposable guest."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import time
import zipfile

root = Path(__file__).resolve().parent
src = root / 'source'
head = '20ff668b27a885cbc60be01c02484873f4d067ba'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('mode', choices=['prepare','320x200','640x480','800x600'])
parser.add_argument('--qemu', default='qemu-system-x86_64')
args = parser.parse_args()
suite = runpy.run_path(str(src/'examples/tester-cd/check_compact_pins.py'))
opt = runpy.run_path(str(src/'examples/optical-disk-check/check.py'))
glyphs = suite['CHECK']['kernel_glyphs']()
def digest(data):
    return hashlib.sha256(data).hexdigest()
if args.mode == 'prepare':
    with zipfile.ZipFile(root/'cd.zip') as cd, zipfile.ZipFile(root/'ci.zip') as ci:
        receipt = json.loads(ci.read('first/receipt.json'))
        image = cd.read('pcp-os-tester.iso')
        assert receipt['source_commit'] == head and receipt['iso_sha256'] == digest(image)
        assert not receipt['uncommitted_changes']
        content = suite['BUILD']['read_back'](image)
        assert content['kernel.elf32'] == ci.read('evidence/compact-pins/boot/kernel.elf32')
        measure = runpy.run_path(str(src/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure']
        assert receipt['kernel_measurement'] == measure(content['kernel.elf32'])
        for file in ('kernel.elf32','surf.elf'):
            (root/file).write_bytes(content[file])
        (root/'receipt.json').write_bytes(ci.read('first/receipt.json'))
    raise SystemExit
receipt = json.loads((root/'receipt.json').read_bytes())
out = root/args.mode
out.mkdir()
serial = out/'serial.txt'
cmd = [args.qemu,'-machine','pc','-accel','tcg','-cpu','qemu64','-m','256M','-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel','kernel.elf32','-append','desktop='+args.mode+' image='+receipt['kernel_measurement'],'-initrd','surf.elf']
report = dict(source=head, kernel_sha256=digest((root/'kernel.elf32').read_bytes()), command=cmd, frames={}, keys=[])
with (out/'stderr.txt').open('wb') as stderr, subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr, cwd=root) as guest:
    try:
        monitor = opt['Monitor'](guest)
        monitor.call('qmp_capabilities')
        opt['wait_for'](lambda: serial.exists() and 'desktop: '+args.mode in serial.read_text(errors='replace'), 'requested display', 45)
        time.sleep(.45)
        def key(code):
            monitor.key(code)
            report['keys'].append(code)
            time.sleep(.20)
        def capture(name, title=None):
            path = out/(name+'.ppm')
            monitor.call('screendump',filename=str(path))
            frame = path.read_bytes()
            assert frame.split(b'\n',3)[1].decode().replace(' ','x')==args.mode
            lines = suite['read'](frame,glyphs)
            if title: assert any(title in line for line in lines), (name,title,lines)
            (out/(name+'.txt')).write_text('\n'.join(lines)+'\n')
            report['frames'][name]=digest(frame)
            return lines
        capture('home','PCP OS')
        for name,code,title in [('keys','f1','KEYS ON THE DESKTOP'),('register','f4','REGISTER'),('verification','f5','VERIFICATION')]:
            key(code)
            capture(name,title)
            key('esc')
            capture(name+'-return','PCP OS')
            assert report['frames'][name+'-return']==report['frames']['home']
        key('f2')
        capture('settings-0','SETTINGS')
        for i in range(1,5):
            key('down')
            capture('selection-'+str(i),'SETTINGS')
            if i in (3,4):
                key('ret')
                capture('toggled-'+str(i),'SETTINGS')
        key('esc')
        capture('home-widgets','PCP OS')
        key('f2')
        capture('reopen-settings','SETTINGS')
        for i in range(1,5):
            key('down')
            if i in (3,4):key('ret')
        key('esc')
        capture('home-reset','PCP OS')
        assert report['frames']['home-widgets']!=report['frames']['home']
        assert report['frames']['home-reset']==report['frames']['home']
        key('f10')
        capture('power','POWER OFF')
        key('esc')
        capture('power-return','PCP OS')
        assert report['frames']['power-return']==report['frames']['home']
        key('f10')
        key('ret')
        report['exit']=guest.wait(timeout=14)
        while not any(e['event']=='SHUTDOWN' for e in monitor.events): monitor.events.append(monitor.read())
        report['shutdown']=next(e['data'] for e in monitor.events if e['event']=='SHUTDOWN')
        log=serial.read_text(errors='replace')
        report['checks']=sum(x.startswith('  pass ') for x in log.splitlines())
        assert receipt['kernel_measurement']+' (measured; equal' in log and report['checks']==72 and report['exit']==0
        assert report['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    finally:
        if guest.poll() is None: guest.kill();guest.wait()
        (out/'result.json').write_text(json.dumps(report,indent=2)+'\n')

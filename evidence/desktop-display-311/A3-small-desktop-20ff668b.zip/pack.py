from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED
import json

root=Path('.')
def digest(p):
    return sha256(p.read_bytes()).hexdigest()
r=json.loads(Path('receipt.json').read_bytes())
summary={'tested_commit':r['source_commit'],'tested_tree':r['source_tree'],'iso_sha256':r['iso_sha256'],'kernel_measurement':r['kernel_measurement'],
         'kernel_sha256':digest(Path('kernel.elf32')),'artifact_sources':{},'observations':{}}
for name,artifact,expected in [('cd.zip',14707959504,'8a960bcafbd047faa03c4e1e56b21622f1c25c4251e192ec6070cc1af20d82af'),('ci.zip',14707944651,'1915b7b8dc629bedff31b9035a9938ea13894e93eadddb4c6786c8b9b214325c')]:
    assert digest(Path(name))==expected
    summary['artifact_sources'][name]={'sha256':expected,'url':f'https://github.com/KirtusJ/pcp-os/actions/runs/44906589959/artifacts/{artifact}'}
files=[Path(f) for f in ('read_views.py','pack.py','receipt.json')]
for mode in ('320x200','640x480','800x600'):
    d=Path(mode)
    q=json.loads((d/'result.json').read_bytes())
    images=q['frames']
    assert all(digest(d/(k+'.ppm'))==v for k,v in images.items())
    def rows(label):
        return [s.strip() for s in (d/(label+'.txt')).read_text().splitlines() if s.strip()]
    small=mode=='320x200'
    assert (images['selection-3']==images['toggled-3']==images['selection-4']==images['toggled-4'])==small
    assert (images['home']!=images['home-widgets']) and images['home']==images['home-reset']
    assert (('2 widget line(s) not shown' in rows('home-widgets')) if small else ('[on]  This machine' in rows('reopen-settings') and '[on]  Session' in rows('reopen-settings')))
    assert q['checks']==72 and q['exit']==0 and q['shutdown']['guest']
    view=dict(exit=q['exit'],checks=q['checks'],shutdown=q['shutdown'],home_restored=images['home']==images['home-reset'],
              settings_images={k:images[k] for k in ('selection-2','selection-3','toggled-3','selection-4','toggled-4')},
              home_with_widgets=rows('home-widgets'),settings_rows=rows('reopen-settings'),power_text=rows('power'),keys=rows('keys'),verification=rows('verification'),register_heading=rows('register')[:2])
    if mode in ('320x200','640x480'):
        with ZipFile('ci.zip') as z:
            hosted=z.read('evidence/compact-pins/'+mode+'/power-question.ppm')
        assert hosted==(d/'power.ppm').read_bytes()
        view['power_matches_hosted_frame']=True
    summary['observations'][mode]=view
    files.extend(f for f in sorted(d.iterdir()) if f.is_file())
doc=Path('A3-small-desktop-20ff668b.json')
doc.write_text(json.dumps(summary,indent=2)+'\n')
files.append(doc)
out=Path('A3-small-desktop-20ff668b.zip')
with ZipFile(out,'w',ZIP_DEFLATED,compresslevel=7) as z:
    for file in files:z.write(file)
    z.writestr('SHA256SUMS',''.join(digest(f)+'  '+f.as_posix()+'\n' for f in files))
    z.writestr('README.md','Use a fresh directory, with repository commit '+r['source_commit']+' checked out as source/. Download cd.zip and ci.zip using the two URLs and digests in A3-small-desktop-20ff668b.json. Run python3 read_views.py prepare and then python3 read_views.py MODE for each of 320x200, 640x480 and 800x600. The optional --qemu argument selects the emulator. The result.json in each guest folder lists the exact command, framebuffer digests and key sequence. Screens are QEMU P6 frames.\n')
with ZipFile(out) as z:assert z.testzip() is None
print(len(files),out.stat().st_size,digest(out))

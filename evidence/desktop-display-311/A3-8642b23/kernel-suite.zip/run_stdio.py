"""Run the tracked test suite with QMP over stdio when AF_UNIX is unavailable."""
import difflib
import os
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
source = Path(os.environ.get('PCPOS_ADAPTER_CHECKOUT', root / 'source')) / 'PCP_OS_Rust/crates/pcpos-kernel/tests/run_tests.py'
original = source.read_text()
start = original.index('        self.started = time.time(); self.p = subprocess.Popen')
end = original.index('\n    def _read(self):', start)
replacement = '''        self.started = time.time()
        self.p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  stderr=(self.dir / 'qemu.stderr').open('wb'), cwd=self.dir)
        self._read(); self.qmp("qmp_capabilities")'''
changed = (original[:start] + replacement + original[end:]).replace('"unix:qmp,server=on,wait=off"', '"stdio"').replace('self.f.readline()', 'self.p.stdout.readline()').replace('self.f.write(', 'self.p.stdin.write(').replace('self.f.flush()', 'self.p.stdin.flush()')
(root / 'qmp-transport.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True), changed.splitlines(True), fromfile='original/run_tests.py', tofile='transport/run_tests.py')))
sys.argv[0] = str(source)
exec(compile(changed, str(source), 'exec'), {'__name__': '__main__', '__file__': str(source)})

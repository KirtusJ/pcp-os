#!/bin/bash
set -eu
cd "$(dirname "$0")"
toolbase=/workspace/scratch/edecb50126f6/boot-audit/uefi-bios-regression
export CARGO_HOME="$toolbase/cargo" CARGO_NET_OFFLINE=true
export PATH="/workspace/scratch/7c7df1723510/work/a3-suite312/bin:$toolbase/toolchain/bin:$toolbase/toolchain/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$toolbase/bin:$PATH"
export PCPOS_KERNEL_STAGE="$PWD/build"
mkdir -p src/PCP_OS_Rust/crates/pcpos-kernel/target
rustc -Vv > compiler.txt
sh src/PCP_OS_Rust/crates/pcpos-kernel/run.sh build > build.log 2>&1
cp src/PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32 kernel.elf32
sha256sum kernel.elf32 programs/*.elf data/*.wad src/PCP_OS_Rust/crates/pcpos-kernel/tests/run_tests.py > inputs.sha256
date -u +%FT%TZ > start
set +e
env -u PCPOS_TESTS_ONLY PCPOS_ADAPTER_CHECKOUT="$PWD/src" python3 -u run_stdio.py "$PWD/kernel.elf32" "$PWD/programs" "$PWD/data" "$PWD/full" > full.log 2>&1
status=$?
echo "$status" > suite.exit
date -u +%FT%TZ > stop
exit "$status"

"""Pack the results, preserving each failed trial and its original captures."""
import hashlib
import json
from pathlib import Path
import runpy
import sys
import tarfile
import zipfile

root=Path(__file__).resolve().parent
source='8642b2357531c4590fa2c23b32e424e34135515d'
tree='a292064a9d9f91b5a8e89f2eaa85067ed7db50d5'
def digest(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()
def read(path):
    return json.loads((root/path).read_text())
def write(path,value):
    (root/path).write_text(json.dumps(value,indent=2)+'\n')
def files_in(folder,extensions):
    return [p for p in (root/folder).rglob('*') if p.is_file() and p.suffix in extensions]
def tar(name,files):
    with tarfile.open(root/name,'w:xz',preset=3) as archive:
        for path in sorted(set(files)):
            archive.add(path,arcname=path.relative_to(root),recursive=False)
    with tarfile.open(root/name) as arc:
        for member in arc:
            original=root/member.name
            assert hashlib.file_digest(arc.extractfile(member),'sha256').hexdigest()==digest(original)
def zip_files(name,files):
    with zipfile.ZipFile(root/name,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for p in sorted(set(files)):z.write(p,p.relative_to(root))
    with zipfile.ZipFile(root/name) as z:assert z.testzip() is None
if __name__=='__main__' and sys.argv[1]=='suite':
    d=read('full/results.json')
    failures=[]
    passed=total=groups=0
    for row in d['results']:
        checks=row['checks']
        assert all(type(c['ok']) is bool for c in checks)
        assert row['ok']==all(c['ok'] for c in checks)
        passed+=sum(c['ok'] for c in checks)
        total+=len(checks)
        groups+=row['ok']
        failures.extend(dict(group=row['test'],assertion=c['check'],detail=c['detail']) for c in checks if not c['ok'])
    assert len(d['results'])==d['tests'] and groups==d['passed'] and total==d['checks']
    assert any('240 seconds' in g['test'] for g in d['results'])
    status=int((root/'suite.exit').read_text())
    assert status==(1 if failures else 0)
    assert digest(root/'kernel.elf32')==d['kernel_sha256'] and digest(root/'programs/doom.elf')==d['doom_sha256']
    assert all(digest(root/'data'/n)==v for n,v in d['game_data'].items())
    measure=runpy.run_path(str(root/'src/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure']((root/'kernel.elf32').read_bytes())
    value=dict(source=source,tree=tree,command='env -u PCPOS_TESTS_ONLY PCPOS_ADAPTER_CHECKOUT="$PWD/src" python3 -u run_stdio.py "$PWD/kernel.elf32" "$PWD/programs" "$PWD/data" "$PWD/full"',build='sh src/PCP_OS_Rust/crates/pcpos-kernel/run.sh build',kernel_sha256=d['kernel_sha256'],kernel_measurement=measure,emulator=d['emulator'],start=(root/'start').read_text().strip(),end=(root/'stop').read_text().strip(),exit=status,groups_passed=groups,groups_total=d['tests'],assertions_passed=passed,assertions_total=total,failed_assertions=failures,raw_results_sha256=digest(root/'full/results.json'))
    write('suite-readback.json',value)
    orig=[root/p for p in ['review_lib.py','run_suite.sh','suite-readback.json','full.log','inputs.sha256','compiler.txt','build.log','qmp-transport.diff','run_stdio.py','start','stop','suite.exit','src/PCP_OS_Rust/crates/pcpos-kernel/tests/run_tests.py']]
    orig+=files_in('full',{'.log','.stderr','.png','.json'})
    write('audio-hashes.json',{str(p.relative_to(root)):dict(bytes=p.stat().st_size,sha256=digest(p)) for p in files_in('full',{'.wav'})})
    zip_files('kernel-suite.zip',orig+[root/'audio-hashes.json'])
    print((groups,d['tests'],passed,total,failures))

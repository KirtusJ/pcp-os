"""Re-read captured guest pixels, inputs, serial verdicts, and worker results on the nominated source."""
from pathlib import Path
import json
import re
import runpy
import subprocess
from review_lib import root, source, tree, read, write, digest, files_in, tar

def git(ref):
    return subprocess.check_output(['git','-C',str(root/'src'),'rev-parse',ref],text=True).strip()

assert git('HEAD') == source and git('HEAD^{tree}') == tree
opt = runpy.run_path(str(root/'src/examples/optical-disk-check/check.py'))
glyphs = opt['SCREEN']['kernel_glyphs']()
decode = runpy.run_path(str(root/'src/examples/tester-cd/check_compact_pins.py'))['read']
modes = {}
widths = []
files = [root/name for name in ('pack_checks.py','review_lib.py','dispatch.py','guest_names.py','test_status.py','local_fixture.py','local/receipt.json','queue/receipt.json','plain/receipt.json','read_discs.py','artifacts.json','hosted-pins.json','replay_stdio.py','replay-transport.diff','replay.log','src/examples/tester-cd/check_compact_pins.py')]
assert digest(root/'plain/kernel.elf32') == digest(root/'queue/kernel.elf32')
assert digest(root/'local/rdesk.elf') == digest(root/'queue/rdesk.elf')
for group in ('local','hosted'):
    fixture = 'local' if group == 'local' else 'queue'
    expected = digest(root/fixture/'kernel.elf32')
    entries = read(group+'-workers.json')
    assert len(entries) == (2 if group=='local' else 12)
    assert all(item['exit']==0 for item in entries),entries
    files += [root/(group+'-workers.json'),root/(group+'-workers.log')]
    for item in entries:
        case=item['label']
        files += files_in(case,{'.log','.txt','.json','.ppm'})+[root/(case+'.worker.log')]
        if case.startswith('launch-'):
            d=read(case+'/observations.json')
            assert expected==d['kernel_sha256'] and d['qemu_exit']==0 and d['self_test_pass_lines']==72
            assert not d['failures'] and all(ok for _,ok in d['checks'])
            assert all(digest(root/case/(k+'.ppm'))==v for k,v in d['frames'].items())
            assert [len(l['name']) for l in d['launches']]==[32,33,63,64,64]
            modes[d['mode']]=dict(checks=len(d['checks']),outcomes=[i['outcome'] for i in d['launches']],self_tests=72,exit=d['qemu_exit'])
            continue
        d=read(case+'/result.json')
        n,pins,total = d['length'],d['pins'],d['pages']
        assert d['source']==source and d['kernel_sha256']==expected and d['exit']==0
        name='a'*30+'B'+('abcdefghijklmnopqrstuvwxyz'*9)[:n-35]+'.elf'
        serial=(root/case/'serial.log').read_text()
        assert d['guest_verdict']==serial.splitlines()[-1]
        failed='register refused ARTIFACT_ADDED' in serial
        assert failed==(n>64) and (d['guest_verdict']=='1 SELF-TEST(S) FAILED' if failed else d['guest_verdict'].startswith('ALL SELF-TESTS PASS.'))
        assert name+' could not be started:' in serial
        refs=[]
        for k,pages in d['cases'].items():
            assert len(pages)==total
            joined=''
            for i,p in enumerate(pages,1):
                path=root/case/f'widgets{k}-p{i}.ppm'
                assert digest(path)==p['frame']
                lines=decode(path.read_bytes(),glyphs)
                status,part,footer=lines[4].strip(),lines[6].strip(),lines[-1].strip()
                assert status==p['status'] and part==p['name'] and footer==p['footer']
                assert footer==(f'{k} widget line(s) not shown' if int(k) else '')
                place=pins+1
                assert f'{place}/{place}' in status or f'Places {place} to {place} of {place}' in status
                assert f'{i}/{total}' in status or f'part {i} of {total}' in status
                assert lines[7].strip()==p['facts']
                kib=((root/fixture/'rdesk.elf').stat().st_size+1023)//1024
                assert f'{kib} KiB' in p['facts'] and digest(root/fixture/'rdesk.elf')[:14] in p['facts']
                refs.append(('Left/Right' in status) or ('<-' in status and '->' in status))
                joined+=part
            assert joined==name
        assert all(refs)==d['complete_hint_each_page'] and len(set(refs))==1
        assert d['refusal']['refusal']
        widths.append(dict(build=group,kernel_sha256=expected,geometry=d['geometry'],place=f'{place}/{place}',name_bytes=n,pages=total,first_status=d['cases']['0'][0]['status'],last_status=d['cases']['0'][-1]['status'],all_directions_visible=all(refs),hidden_widget_counts=[0,1,2],full_name_verified=True,enter_refusal=d['refusal']['refusal'],serial_pass_lines=sum(line.startswith('  pass ') for line in serial.splitlines()),serial_failed_assertions=int(failed),qemu_exit=d['exit']))
host = read('hosted-pins.json')
replay = read('replay-pins/summary.json')
assert replay['passed'] and not replay['problems'] and host['passed'] and not host['problems']
assert replay['kernel_measurement']==host['kernel_measurement']
for record in (replay,host):
    assert len(record['results']['640x480']['controls_refused'])==3
    assert record['results']['ten-parts-320x200']['joined_equals_name']
assert '1 SELF-TEST(S) FAILED' in (root/'replay-pins/ten-320/serial.txt').read_text()
ledger = root.parent/'a3-1591757/delegate-build/release/parrots-all-the-way-down'
for group,count in [('local',2),('hosted',13)]:
    state=json.loads(subprocess.check_output([str(ledger),'status',str(root/(group+'.redb'))],text=True))
    assert len(state['nodes'])==count
    if any(n['state']!='Finished' for n in state['nodes']):
        import time
        for _ in range(20):
            time.sleep(.2)
            state=json.loads(subprocess.check_output([str(ledger),'status',str(root/(group+'.redb'))],text=True))
            if all(n['state']=='Finished' for n in state['nodes']):
                break
    assert all(n['state']=='Finished' for n in state['nodes'])
    write(group+'-status.json',state)
    files.append(root/(group+'-status.json'))
files += files_in('replay-pins',{'.log','.txt','.json','.ppm'})
report=dict(source=source,tree=tree,local_kernel=digest(root/'kernel.elf32'),hosted_kernel=digest(root/'queue/kernel.elf32'),queue_program_sha256=digest(root/'queue/rdesk.elf'),widths=widths,launches=modes,tracked_replay=replay,hosted_compact_report=host,workflow_run=44913636810,scope='QEMU runs with the listed names and geometries. Local kernel and hosted tester-CD kernel are recorded separately. Files is B3’s review.')
write('desktop-readback.json',report)
files.append(root/'desktop-readback.json')
tar('desktop-guests.tar.xz',files)
print('widths',len(widths),'complete hints',sum(x['all_directions_visible'] for x in widths),'launch modes',len(modes))

"""Verify the two hosted ISO receipts, extract their inputs and read the hosted compact checks."""
from pathlib import Path
from zipfile import ZipFile
import hashlib, json, runpy, subprocess, sys
root=Path(__file__).resolve().parent
sha=lambda d:hashlib.sha256(d).hexdigest()
commit=subprocess.check_output(['git','-C',str(root/'src'),'rev-parse','HEAD'],text=True).strip()
tree=subprocess.check_output(['git','-C',str(root/'src'),'rev-parse','HEAD^{tree}'],text=True).strip()
read_back=runpy.run_path(str(root/'src/examples/tester-cd/build.py'))['read_back']
def load_zip(name,fn):
    artifact=next(a for a in json.loads((root/'artifacts.json').read_text()) if a['name']==name)
    file=root/(name+'.zip')
    assert artifact['workflow_run']['head_sha']==commit and artifact['digest']=='sha256:'+sha(file.read_bytes())
    with ZipFile(file) as z:return z.read(fn)
def verify(flavor):
    suffix='-queue-desk' if flavor=='queue' else ''
    disk='unpublished-tester-cd'+suffix
    evidence='tester-cd-evidence'+suffix
    receipt=json.loads(load_zip(evidence,'first/receipt.json'))
    assert receipt['source_commit']==commit and receipt['source_tree']==tree and receipt['uncommitted_changes'] is False
    image=load_zip(disk,'pcp-os-tester.iso')
    assert sha(image)==receipt['iso_sha256']
    out=root/flavor
    out.mkdir(exist_ok=True)
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    (out/'pcp-os-tester.iso').write_bytes(image)
    files=read_back(image)
    for n in ['kernel.elf32','surf.elf']+(['rdesk.elf'] if flavor=='queue' else []):
        assert sha(files[n])==receipt['inputs'][n]['sha256']
        (out/n).write_bytes(files[n])
    if flavor=='plain':
        assert files['kernel.elf32']==load_zip(evidence,'evidence/compact-pins/boot/kernel.elf32')
        raw=load_zip(evidence,'evidence/compact-pins/summary.json')
        (root/'hosted-pins.json').write_bytes(raw)
        result=json.loads(raw)
        assert result['passed'] and not result['problems'] and result['kernel_measurement']==receipt['kernel_measurement']
    print(flavor,receipt['source_commit'],sha(files['kernel.elf32']),receipt['kernel_measurement'])
verify(sys.argv[1])

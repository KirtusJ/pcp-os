"""Read complete selected names and key hints from a real compact Home without assuming a label format."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import time

p=argparse.ArgumentParser()
for name in ('source','fixture','qemu','out'): p.add_argument(name,type=Path)
p.add_argument('width',type=int)
p.add_argument('pins',type=int)
p.add_argument('length',type=int)
a=p.parse_args()
src,fixture,qemu,out=(getattr(a,n).resolve() for n in ('source','fixture','qemu','out'))
out.mkdir()
meta=json.loads((fixture/'receipt.json').read_text())
kernel=fixture/'kernel.elf32'
app=(fixture/'rdesk.elf').read_bytes()
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(kernel.read_bytes())==meta['inputs']['kernel.elf32']['sha256'] and sha(app)==meta['inputs']['rdesk.elf']['sha256']
opt=runpy.run_path(str(src/'examples/optical-disk-check/check.py'))
glyphs=opt['SCREEN']['kernel_glyphs']()
decode=runpy.run_path(str(src/'examples/tester-cd/check_compact_pins.py'))['read']
name='a'*30+'B'+('abcdefghijklmnopqrstuvwxyz'*9)[:a.length-35]+'.elf'
assert len(name)==a.length
names=[f'desk-{i:02}.elf' for i in range(1,a.pins)]+[name]
for n in names: (out/n).write_bytes(app)
mode=f'{a.width}x200'
across=a.width//10-4
total=(len(name)+across-1)//across
cmd=[str(qemu),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','256M','-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(out/'serial.log'),'-kernel',str(kernel),'-append','desktop='+mode+' image='+meta['kernel_measurement'],'-initrd',','.join(names)]
def serial(): return (out/'serial.log').read_text(errors='replace') if (out/'serial.log').exists() else ''
cases={}
with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
    try:
        mon=opt['Monitor'](guest)
        mon.call('qmp_capabilities')
        def key(*v):
            mon.key(*v)
            time.sleep(.3)
        def frame(tag):
            path=out/(tag+'.ppm')
            last=None
            for _ in range(30):
                mon.call('screendump',filename=str(path))
                raw=path.read_bytes()
                if last==raw:break
                last=raw;time.sleep(.18)
            else: raise RuntimeError('screen did not settle '+tag)
            assert tuple(map(int,raw.split(b'\n',2)[1].split()))==(a.width,200)
            rr=decode(raw,glyphs)
            assert len(rr)==10
            (out/(tag+'.txt')).write_text('\n'.join(rr)+'\n')
            return dict(frame=sha(raw),status=rr[4].strip(),name=rr[6].strip(),facts=rr[7].strip(),footer=rr[-1].strip(),keys=rr[-2].strip(),refusal=[r.strip() for r in rr if 'Not started:' in r])
        opt['wait_for'](lambda:'desktop: '+mode in serial() and meta['kernel_measurement']+' (measured; equal' in serial(),'measured desktop',45)
        time.sleep(.5)
        key('spc')
        for i in range(a.pins):
            if i:key('down')
            key('ctrl','p')
        key('esc')
        for _ in names:key('down')
        for count in (0,1,2):
            if count:
                key('f2')
                for _ in range(count+2):key('down')
                key('ret');key('esc')
            pages=[]
            for i in range(total):
                if i:key('right')
                pages.append(frame(f'widgets{count}-p{i+1}'))
            assert ''.join(page['name'] for page in pages)==name and all(sha(app)[:14] in page['facts'] for page in pages)
            assert all(page['footer']==(f'{count} widget line(s) not shown' if count else '') for page in pages)
            if count==2:
                key('ret')
                opt['wait_for'](lambda:name+' could not be started:' in serial(),'reported refusal',15)
                refused=frame('refused-last')
                assert refused['refusal'] and refused['name']==pages[-1]['name']
                for j in reversed(range(total-1)):
                    key('left')
                    earlier=frame(f'after-left-p{j+1}')
                    assert earlier['name']==pages[j]['name'] and earlier['status']==pages[j]['status'] and earlier['refusal']
            key('up')
            short=frame(f'widgets{count}-short')
            assert short['name']==names[-2]
            key('down')
            cases[str(count)]=pages
        key('f10');key('ret')
        exit_code=guest.wait(timeout=30)
        assert exit_code==0
    finally:
        if guest.poll() is None:guest.kill();guest.wait()
verdict=serial().splitlines()[-1]
assert (verdict.startswith('ALL SELF-TESTS PASS.') if a.length<=64 else verdict=='1 SELF-TEST(S) FAILED' and 'register refused ARTIFACT_ADDED' in serial())
def hints(text):
    return ('<-' in text and '->' in text) or 'Left/Right' in text
result=dict(source=meta['source_commit'],kernel_sha256=meta['inputs']['kernel.elf32']['sha256'],geometry=mode,pins=a.pins,length=a.length,pages=total,cases=cases,refusal=refused,complete_hint_each_page=all(hints(row['status']) for group in cases.values() for row in group),guest_verdict=verdict,exit=exit_code,command=cmd)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(mode,a.pins,a.length,total,result['complete_hint_each_page'],cases['0'][0]['status'],cases['0'][-1]['status'],flush=True)

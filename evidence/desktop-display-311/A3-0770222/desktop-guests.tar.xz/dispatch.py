"""Dispatch independent compact and graphical proofs; all byte inputs are verified by the checks."""
from pathlib import Path
import concurrent.futures
import json
import subprocess
import sys

root = Path(__file__).resolve().parent
source = root / 'src'
tool = root.parent / 'a3-1591757/delegate-build/release/pcp-delegate'
qemu = Path('/workspace/scratch/7c7df1723510/work/emulator/qemu-system-x86_64')
kind = sys.argv[1]
fixture = root / ('local' if kind == 'local' else 'queue')
widths = [(440, 2, 64), (320, 16, 255)]
if kind == 'hosted':
    widths.extend([(432,2,64),(528,2,64),(536,2,64),(552,16,64),(560,16,64),(320,16,64),(640,2,64),(480,16,64),(320,14,255)])
tasks = []
for width, pins, length in widths:
    label = f'{kind}-{width}-{pins}-{length}'
    tasks.append((label,[root/'test_status.py',source,fixture,qemu,root/label,width,pins,length]))
if kind == 'hosted':
    for mode in ('320x200','640x480','bar','dock'):
        label = 'launch-'+mode
        tasks.append((label,[root/'guest_names.py',source,fixture/'kernel.elf32',fixture/'rdesk.elf',qemu,root/label,mode]))

def run(task):
    label, args = task
    cmd = [str(tool),str(root/(kind+'.redb')),label,label,'--',sys.executable,*map(str,args)]
    with (root/(label+'.worker.log')).open('wb') as log:
        status = subprocess.run(cmd,cwd=root,stdout=log,stderr=log).returncode
    print(label,status,flush=True)
    return dict(label=label,exit=status,command=cmd)

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(run,tasks))
(root/(kind+'-workers.json')).write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(value['exit'] for value in results))

"""Read program names on a real guest and connect each visible choice to its Enter result."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import runpy
import shutil
import subprocess
import time

p = argparse.ArgumentParser(description=__doc__)
for key in ('source', 'kernel', 'program', 'qemu', 'output'):
    p.add_argument(key, type=Path)
p.add_argument('mode', choices=('320x200', '640x480', 'bar', 'dock'))
p.add_argument('--extended', action='store_true', help='Also attach a 113-byte name, outside the 64-byte artifact-name limit.')
a = p.parse_args()
source, kernel, program, qemu, out = (getattr(a, key).resolve() for key in ('source', 'kernel', 'program', 'qemu', 'output'))
out.mkdir()
graphic = a.mode in ('bar','dock')
tiny = a.mode == '320x200'
size = '1920x1080' if graphic else a.mode
opt = runpy.run_path(str(source/'examples/optical-disk-check/check.py'))
glyphs = opt['SCREEN']['kernel_glyphs']()
decode = opt['SCREEN']['read_screen'] if graphic else runpy.run_path(str(source/'examples/tester-cd/check_compact_pins.py'))['read']
measure = runpy.run_path(str(source/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](kernel.read_bytes())
sha = lambda d: hashlib.sha256(d).hexdigest()
data = program.read_bytes()
digest = sha(data)
bytes_kib = f'{(len(data)+1023) >> 10} KiB'
alias = lambda n: ('matching-prefix-'*9)[:n-5]+str(n % 10)+'.elf'
names = [alias(n) for n in (32,33,63)] + ['a'*30+letter+'z'*29+'.elf' for letter in 'AB']
if a.extended:
    names.append(alias(113))
for name in names:
    (out / name).write_bytes(data)
serial = out/'serial.log'
cmd = [str(qemu),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','256M','-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel',str(kernel),'-append',f'desktop={size} image={measure} bar={a.mode}','-initrd',','.join(names)]
record = dict(mode=a.mode,size=size,kernel_sha256=sha(kernel.read_bytes()),measurement=measure,program_sha256=digest,program_bytes=len(data),command=cmd,frames={},launches=[],checks=[],failures=[])
def check(label, ok):
    record['checks'].append([label,bool(ok)])
    if not ok:
        record['failures'].append(label)
def log():
    return serial.read_text(errors='replace') if serial.exists() else ''
with (out/'stderr.txt').open('wb') as err, subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
    try:
        mon=opt['Monitor'](guest)
        mon.call('qmp_capabilities')
        def key(*codes):
            mon.key(*codes)
            time.sleep(.36)
        def capture(label):
            path=out/(label+'.ppm')
            previous = None
            stable_since = time.monotonic()
            deadline = stable_since + 18
            while time.monotonic() < deadline:
                mon.call('screendump',filename=str(path))
                frame = path.read_bytes()
                if frame != previous:
                    previous = frame
                    stable_since = time.monotonic()
                elif time.monotonic() - stable_since > (.9 if graphic else .24):
                    break
                time.sleep(.17)
            else:
                raise RuntimeError('Display did not settle for '+label)
            rows=decode(frame,glyphs)
            if rows is None:
                raise ValueError('invalid frame '+label)
            (out/(label+'.txt')).write_text('\n'.join(rows)+'\n')
            record['frames'][label]=sha(frame)
            return rows
        def wait(predicate,label):
            opt['wait_for'](predicate,label,45)
        wait(lambda: 'desktop: '+size in log() and measure+' (measured; equal' in log(),'verified boot')
        time.sleep(.65)
        key('spc')
        for i in range(len(names)):
            if i: key('down')
            key('ctrl','p')
        key('esc')
        for i,name in enumerate(names):
            key('right' if graphic else 'down')
            label=f'pin{i+1}-{len(name)}'
            cut=len(log())
            pages=math.ceil(len(name)/28) if tiny else 1
            chunks=[]
            facts=bytes_kib+(' sha '+digest[:min(16,28-len(bytes_kib)-7)]+'..' if tiny else '   SHA-256 '+digest[:16]+'...')
            def read_page(rows,page,tag):
                check(tag+' digest and size',any(facts in row for row in rows))
                if tiny:
                    check(tag+' page and place',rows[4].strip()==f'Place {i+2}/{len(names)+1} | name {page}/{pages} <- ->')
                    return rows[6].strip()
                if graphic:
                    return name if any(name in row for row in rows) else ''
                last_pin=max((j for j,r in enumerate(rows) if r.strip().startswith(('PINNED ','Programs'))),default=-1)
                factrow=next((j for j,r in enumerate(rows) if facts in r),0)
                return ''.join(r.strip() for r in rows[last_pin+1:factrow] if r.strip() and r.strip()!='Enter starts' and not r.strip().startswith('Not started:'))
            for page in range(1,pages+1):
                if page>1: key('right')
                tag=label+'-page'+str(page)
                rows=capture(tag)
                chunks.append(read_page(rows,page,tag))
            check(label+' whole name',''.join(chunks)==name)
            if tiny:
                key('right')
                stop=capture(label+'-right-stop')
                check(label+' upper bound',read_page(stop,pages,label+' upper')==chunks[-1])
                for _ in range(pages):key('left')
                first=capture(label+'-left-stop')
                check(label+' lower bound',read_page(first,1,label+' lower')==chunks[0])
                for _ in range(1,pages):key('right')
            check(label+' no launch while navigating','starting '+name+' (' not in log()[cut:])
            cut=len(log())
            key('ret')
            wait(lambda: 'could not be started:' in log()[cut:] or 'PARROTS READY' in log()[cut:],'launch '+name)
            launched='PARROTS READY' in log()[cut:]
            check(label+' selected bytes',f'starting {name} ({len(data)} bytes, SHA-256 {digest})' in log()[cut:])
            check(label+' admission boundary',launched==(len(name)==32))
            if launched:
                key('esc')
                wait(lambda: name+' ended DONE: exit 0' in log()[cut:],'normal exit')
            after=capture(label+'-after-enter')
            part=read_page(after,pages,label+' after Enter')
            check(label+' identity retained',part==chunks[-1] and bool(part))
            if not launched:
                caption='Not started: '+('not admitted' if tiny else 'the program could not be admitted as a task')
                check(label+' visible refusal',any(caption in row for row in after))
                check(label+' recorded refusal', name+' could not be started: the program could not be admitted as a task' in log()[cut:])
            record['launches'].append(dict(name=name,pages=chunks,outcome='ran and exited 0' if launched else 'refused',visible_digest=facts,refusal_rows=[r.strip() for r in after if 'Not started:' in r]))
        if tiny:
            pair=[entry['pages'] for entry in record['launches'] if len(entry['name'])==64]
            check('aliases differ only on second page',[j for j,(l,r) in enumerate(zip(*pair),1) if l!=r]==[2])
        key('f10')
        capture('power')
        key('ret')
        record['qemu_exit']=guest.wait(timeout=35)
        check('normal shutdown',record['qemu_exit']==0 and 'ALL SELF-TESTS PASS.' in log())
        record['self_test_pass_lines']=sum(l.startswith('  pass ') for l in log().splitlines())
    except Exception as error:
        record['failures'].append(repr(error))
    finally:
        if guest.poll() is None:
            guest.kill()
            guest.wait()
        (out/'observations.json').write_text(json.dumps(record,indent=2)+'\n')
print(a.mode, len(record['launches']),record['failures'])
raise SystemExit(bool(record['failures']))

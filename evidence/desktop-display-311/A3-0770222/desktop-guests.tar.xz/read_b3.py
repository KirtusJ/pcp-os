"""Read B3's original Files frames and three-session serial records for the frozen head."""
from pathlib import Path
import collections
import hashlib
import json
import re
import runpy
import tarfile
root=Path(__file__).resolve().parent
meta=json.loads((root/'queue/receipt.json').read_text())
check=runpy.run_path(str(root/'src/examples/tester-cd/check_compact_pins.py'))
glyphs=check['CHECK']['kernel_glyphs']()
sha=lambda data:hashlib.sha256(data).hexdigest()
archive=root/'b3-hosted.tar.xz'
observation=dict(source=meta['source_commit'],evidence_commit='d626ef740f41d7c91a34cf8aca9df2d958deb83b',archive_path='evidence/desktop-display-311/B3-hosted-0770222.tar.xz',archive_sha256=sha(archive.read_bytes()),files=[],queue_sessions=[])
with tarfile.open(archive) as t:
    reports=[s for s in t.getnames() if s.startswith('hosted/files-') and s.endswith('/report.json')]
    assert len(reports)==8
    for name in reports:
        folder=name.rsplit('/',1)[0]
        record=json.load(t.extractfile(name))
        assert record['commit']==meta['source_commit'] and record['kernel_sha256']==meta['inputs']['kernel.elf32']['sha256']
        assert record['exit']==0 and record['unique_names_reached']==record['count']
        home=t.extractfile(folder+'/home.ppm').read()
        restored=t.extractfile(folder+'/restored.ppm').read()
        assert home==restored
        observation['files'].append(dict(case=folder,geometry=record['geometry'],scale=record['ui_scale'],files_reached=record['count'],home_and_restored_sha256=sha(home)))
    for label in ('seven320','seven640','fourteen320'):
        folder='hosted/'+label+'/'
        record=json.load(t.extractfile(folder+'result.json'))
        assert record['source']==meta['source_commit'] and record['all_pass'] and record['exit']==0
        serial=t.extractfile(folder+'serial.txt').read().decode()
        counts=collections.Counter(re.findall(r'^([^ \r\n]+\.elf) ended DONE: exit 0',serial,re.M))
        assert counts['program-02.elf']==3
        frame=t.extractfile(folder+'five-widget-short.ppm').read()
        rows=[v.strip() for v in check['read'](frame,glyphs)]
        assert ('5 widget line(s) not shown' in rows if label.endswith('320') else any(v.startswith('memory ') for v in rows))
        observation['queue_sessions'].append(dict(case=label,exit_zero_short_programs=counts['program-02.elf'],frame_sha256=sha(frame),frame_rows=rows))
(root/'b3-crosscheck.json').write_text(json.dumps(observation,indent=2)+'\n')

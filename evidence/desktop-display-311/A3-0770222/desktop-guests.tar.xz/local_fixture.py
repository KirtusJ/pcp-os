from pathlib import Path
import hashlib,json,shutil,runpy,subprocess
root=Path(__file__).resolve().parent
fixture=root/'local'
fixture.mkdir()
shutil.copyfile(root/'kernel.elf32',fixture/'kernel.elf32')
previous=root.parent/'a3-1591757/queue'
shutil.copyfile(previous/'rdesk.elf',fixture/'rdesk.elf')
def git(ref):return subprocess.check_output(['git','-C',str(root/'src'),'rev-parse',ref],text=True).strip()
inputs={n:dict(sha256=hashlib.sha256((fixture/n).read_bytes()).hexdigest()) for n in ('kernel.elf32','rdesk.elf')}
assert inputs['rdesk.elf']['sha256']==json.loads((previous/'receipt.json').read_text())['inputs']['rdesk.elf']['sha256']
measure=runpy.run_path(str(root/'src/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure']
(fixture/'receipt.json').write_text(json.dumps(dict(source_commit=git('HEAD'),source_tree=git('HEAD^{tree}'),inputs=inputs,kernel_measurement=measure((fixture/'kernel.elf32').read_bytes()),origin='locally built exact-source kernel with previous hosted Queue Desk control'),indent=2)+'\n')

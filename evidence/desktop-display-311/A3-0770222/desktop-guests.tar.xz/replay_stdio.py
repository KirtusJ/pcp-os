"""Execute the exact-source compact pin checker, replacing only the QMP socket channel."""
from pathlib import Path
import difflib
path=Path('src/examples/tester-cd/check_compact_pins.py').resolve()
original=path.read_text()
s=original.replace('"unix:%s,server=on,wait=off" % sock','"stdio"').replace('stdout=subprocess.DEVNULL','stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True')
start=s.index('        end = time.monotonic() + 20')
end=s.index('        def rpc(',start)
s=s[:start]+'        stream = guest.stdin\n\n'+s[end:]
s=s.replace('stream.readline()', 'guest.stdout.readline()')
Path('replay-transport.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='original/check_compact_pins.py',tofile='transport/check_compact_pins.py')))
exec(compile(s,str(path),'exec'),{'__name__':'__main__','__file__':str(path)})

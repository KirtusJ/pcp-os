"""Capture selected Home with one 64-byte alias at the same position in each guest."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import subprocess
import time

parser = argparse.ArgumentParser(description=__doc__)
for name in ("source", "kernel", "program", "qemu", "out"):
    parser.add_argument("--" + name, type=Path, required=True)
parser.add_argument("case", choices=("middle-a", "middle-b", "suffix", "prefix"))
args = parser.parse_args()
source = args.source.resolve()
kernel = args.kernel.resolve()
program = args.program.resolve()
out = args.out.resolve() / args.case
out.mkdir(parents=True)
initial = ("c" if args.case == "prefix" else "a") + "a" * 29
middle = "B" if args.case == "middle-b" else "A"
tail = "z" * 28 + ("y" if args.case == "suffix" else "z") + ".elf"
alias = initial + middle + tail
assert len(alias.encode()) == 64
shutil.copyfile(program, out / alias)
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
measurement = runpy.run_path(str(source / "PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py"))["measure"](kernel.read_bytes())
optic = runpy.run_path(str(source / "examples/optical-disk-check/check.py"))
read = runpy.run_path(str(source / "examples/tester-cd/check_compact_pins.py"))["read"]
font = optic["SCREEN"]["kernel_glyphs"]()
serial = out / "serial.txt"
screen = out / "home.ppm"
command = [str(args.qemu.resolve()), "-machine", "pc", "-accel", "tcg", "-m", "256M", "-cpu", "qemu64",
           "-nic", "none", "-vga", "std", "-display", "none", "-monitor", "none", "-qmp", "stdio",
           "-serial", "file:" + str(serial), "-kernel", str(kernel), "-append", "desktop=320x200 image=" + measurement, "-initrd", alias]
result = dict(alias=alias, kernel_sha256=digest(kernel), measurement=measurement, app_sha256=digest(program), argv=command)
with (out / "stderr.txt").open("wb") as err:
    guest = subprocess.Popen(command, cwd=out, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err)
    try:
        q = optic["Monitor"](guest)
        q.call("qmp_capabilities")
        def log():
            return serial.read_text(errors="replace") if serial.exists() else ""
        optic["wait_for"](lambda: "desktop: 320x200" in log() and measurement+" (measured; equal" in log(),"desktop measurement",45)
        assert f"file from the loader: {alias} (" in log()
        time.sleep(.3)
        def key(*codes):
            q.key(*codes)
            time.sleep(.3)
        for keys in (("spc",), ("ctrl","p"), ("esc",), ("down",)):
            key(*keys)
        rows = []
        previous = None
        for unused in range(30):
            q.call("screendump", filename=str(screen))
            frame = screen.read_bytes()
            rows = read(frame,font)
            if frame == previous and any("PINNED " in line for line in rows):
                break
            previous = frame
            time.sleep(.12)
        else:
            raise ValueError(f"Selected Home did not settle: {rows}")
        assert b"P6\n320 200\n255\n" == frame[:15]
        assert any("Places 2 to 2 of 2" in row for row in rows), rows
        result.update(frame_sha256=digest(screen), rows=rows)
        key("f10")
        key("ret")
        result["exit"] = guest.wait(timeout=25)
        while not any(event["event"] == "SHUTDOWN" for event in q.events):
            q.events.append(q.read())
        result["shutdown"] = next(event["data"] for event in q.events if event["event"] == "SHUTDOWN")
        result["pass_lines"] = sum(line.startswith("  pass ") for line in log().splitlines())
        assert result["exit"] == 0 and result["shutdown"].get("guest") is True and result["pass_lines"] == 72
    finally:
        if guest.poll() is None:
            guest.kill()
            guest.wait()
        (out/"result.json").write_text(json.dumps(result, indent=2)+"\n")

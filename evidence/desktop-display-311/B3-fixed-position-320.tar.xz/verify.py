"""Read original QEMU frames, loader entries and shutdown receipts after each guest exited."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent / "guests"
images = {}
names = {}
kernels = set()
programs = set()
for case in ("middle-a", "middle-b", "prefix", "suffix"):
    directory = root / case
    result = json.loads((directory / "result.json").read_text())
    pixels = (directory / "home.ppm").read_bytes()
    serial = (directory / "serial.txt").read_text()
    names[case] = result["alias"]
    assert len(names[case].encode("ascii")) == 64
    assert f"file from the loader: {names[case]} (" in serial
    assert result["measurement"] + " (measured; equal" in serial
    assert sum(line.startswith("  pass ") for line in serial.splitlines()) == 72
    assert result["exit"] == 0 and result["shutdown"] == {"guest": True, "reason": "guest-shutdown"}
    assert pixels.startswith(b"P6\n320 200\n255\n") and len(pixels) == 15 + 320 * 200 * 3
    assert hashlib.sha256(pixels).hexdigest() == result["frame_sha256"]
    assert "Places 2 to 2 of 2" in " ".join(result["rows"])
    images[case] = pixels
    kernels.add(result["kernel_sha256"])
    programs.add(result["app_sha256"])
assert len(kernels) == len(programs) == 1
for case, position in (("middle-b",31),("prefix",1),("suffix",60)):
    altered = [i for i,(x,y) in enumerate(zip(names["middle-a"],names[case]), 1) if x != y]
    assert altered == [position]
    equal = images["middle-a"] == images[case]
    assert equal == (case == "middle-b")
    print(f"Byte {position}: selected Home identical = {equal}")

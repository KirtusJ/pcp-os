# Selected filename at 320×200

Director B3 ran four diskless QEMU guests. Each loaded the same Queue Desk ELF under one 64-byte ASCII filename and selected it in Home position 2 of 2. Changing only byte 31 left the complete Home P6 identical. Changing only byte 1 or byte 60 changed it. Each guest passed 72 self-tests and requested shutdown.

The kernel is B3’s previously published reference patch on source commit 3d345bf68df5b64cf8345dfa6754c7d98046b01d. Z3’s working copy and future #312 candidate have separate identities. The glyph rows describe the initial selected Home before Enter. These runs exercised no name-paging interaction.

After extraction, run `python3 -I verify.py` from this directory. For a fresh boot, extract candidate.elf32 and rdesk.elf from [B3’s original reference archive](https://github.com/KirtusJ/pcp-os/blob/6deb95c4af14690b1994696efb135838b7f9b991/evidence/desktop-display-311/B3-3d345bf/launch-feedback.zip). Check out the source commit above. Run the following four times, substituting middle-a, middle-b, prefix and suffix for CASE.

```sh
python3 -IB boot.py CASE --source /path/to/source --kernel /path/to/candidate.elf32 --program /path/to/rdesk.elf --qemu /path/to/qemu-system-x86_64 --out ./fresh
```

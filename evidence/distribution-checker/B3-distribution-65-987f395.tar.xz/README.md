# Independent B3 review of distribution PR 65

B3 compared the F10 reader at distribution 987f395b3836843205e13d18500e03dba8f0da34 with its parent, 11dbf5aeb51c4695c3a0a911d0d9fa21170f94fc. The OS font/decoder checkout for the published regression is 89792700243ad5dd4efde3091993984845087e2c. The original P6 pixels came from B3's own guest runs. Each archived reader matches its Git blob.

Four unit tests and all 16 published pixel verdicts passed. Of 42 independent paired inputs, 20 were native complete dialogs from 0dd8ec98, three were 1× originals at native 1280×720, 1920×1080 and 2560×1440 on 528fbf97, and two were the explicit 2× scope controls. The other 17 were 15 independent pixel alterations and two historical boundary frames. A complete 320×200 dialog and the historical complete 760×460 dialog changed from rejected to accepted. Replacing the final question mark with one white pixel at 800×600 changed from accepted to rejected. The historical 752×480 missing-letter frame was rejected by both. Blanking either action, “not” or “lost.” failed at all three mutated sizes. Both 2× controls were rejected by the nominated 1× reader.

After unpacking, run the following commands. The repository in OS must be checked out at the pinned OS commit. Python 3 and NumPy are needed for the independent pixel alterations.

    sha256sum --quiet -c SHA256SUMS
    python3 -B candidate/test_desktop_screens.py -v
    python3 -B candidate/check_power_frames.py "$OS"
    python3 -B replay.py --source "$OS" --captures captures --output fresh.json
    cmp replay.json fresh.json

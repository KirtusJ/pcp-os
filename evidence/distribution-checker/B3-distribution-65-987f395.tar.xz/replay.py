"""Compare the nominated F10 reader with the distribution parent on B3's raw QEMU frames."""
from pathlib import Path
from importlib.util import module_from_spec, spec_from_file_location
import argparse, hashlib, json, sys
import numpy as np
root=Path(__file__).resolve().parent
sessions=root.parent
args=argparse.ArgumentParser()
args.add_argument('--source',type=Path,default=sessions/'power-check-bc578cc/os')
args.add_argument('--captures',type=Path)
args.add_argument('--output',type=Path,default=root/'replay.json')
opts=args.parse_args()
source=opts.source.resolve()
def load(name):
    spec=spec_from_file_location(name,root/name/'desktop_screens.py')
    module=module_from_spec(spec);spec.loader.exec_module(module)
    return module.DesktopScreens(source,{})
old=load('base'); new=load('candidate')
report={}
def test(label, raw, expected, base_expected=None):
    a=old.matches(raw,'power');b=new.matches(raw,'power')
    report[label]={'sha256':hashlib.sha256(raw).hexdigest(),'base':a,'candidate':b,'size':raw.split(b'\n',2)[1].decode()}
    assert b is expected and (base_expected is None or a is base_expected),(label,a,b)
def alter(raw, target, partial=False):
    magic,geom,depth,body=raw.split(b'\n',3);w,h=map(int,geom.split())
    im=np.frombuffer(body,dtype='u1').reshape(h,w,3).copy()
    found=[]
    for r in range(h//20):
        line=[]
        for c in range(w//10):
            cell=im[r*20:(r+1)*20,c*10:(c+1)*10]
            key=tuple(np.any(cell!=im[0,0],axis=2).ravel())
            char=new.glyphs.get(key)
            assert char is not None
            line.append(char)
        s=''.join(line)
        if target in s: found.append((r,s.index(target)))
    assert len(found)==1,found
    r,c=found[0]
    im[r*20:(r+1)*20,c*10:(c+len(target))*10]=im[0,0]
    if partial: im[r*20+10,c*10+4]=[255,255,255]
    return b'\n'.join((magic,geom,depth,im.tobytes()))
def read(g):return (g/'power.ppm').read_bytes()
small=opts.captures/'os-0dd8ec9' if opts.captures else sessions/'power-layout-review/guests'
for g in sorted(small.iterdir()):
    raw=read(g);test('os-0dd8ec9/'+g.name,raw,True)
large=opts.captures/'os-528fbf9' if opts.captures else sessions/'high-density-321/guests'
for mode in ('1280x720','1920x1080','2560x1440'):
    raw=read(large/(mode+'-64m-default'))
    test('os-528fbf9/'+mode,raw,True)
for mode in ('1920x1080','2560x1440'):
    raw=read(large/(mode+'-64m-2x'))
    test('explicit-2x-outside-scope/'+mode,raw,False)
for mode in ('320x200','352x200','800x600'):
    raw=read(small/mode)
    for token in ('?','not','lost.','Enter switch off','Esc go back'):
        test('altered-'+mode+'/'+token,alter(raw,token,partial=(token=='?')),False,True if (mode,token)==('800x600','?') else None)
historic=opts.captures/'historical' if opts.captures else sessions/'power-check-bc578cc/guests'
test('historical-one-letter-clip/752x480',read(historic/'752x480'),False,False)
test('historical-complete/760x460',read(historic/'760x460'),True,False)
assert report['os-0dd8ec9/320x200']['base'] is False
opts.output.write_text(json.dumps(report,indent=2)+'\n')
print(len(report),'paired verdicts passed.')

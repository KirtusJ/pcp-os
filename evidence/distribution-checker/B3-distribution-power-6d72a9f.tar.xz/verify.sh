set -eu
d=$(cd "$(dirname "$0")" && pwd)
cd "$d"
sha256sum --quiet -c SHA256SUMS
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
git init -q "$tmp/os"
git -C "$tmp/os" index-pack --stdin < reader-source.pack > /dev/null
git -C "$tmp/os" update-ref --no-deref HEAD 89792700243ad5dd4efde3091993984845087e2c
for f in examples/tester-cd/check.py examples/optical-disk-check/check.py PCP_OS_Rust/crates/pcpos-kernel/src/font.rs PCP_OS_Rust/crates/pcpos-kernel/src/session.rs; do
  mkdir -p "$tmp/os/$(dirname "$f")"
  git -C "$tmp/os" show "HEAD:$f" > "$tmp/os/$f"
done
python3 -B candidate/test_desktop_screens.py
python3 -B candidate/check_power_frames.py "$tmp/os" > "$tmp/ci.log"
cmp ci-readback.log "$tmp/ci.log"
python3 -B replay.py --os "$tmp/os" --report "$tmp/readback.json"
cmp readback.json "$tmp/readback.json"

"""Verify the distribution power-screen checker on native P6 captures and measured pixel controls."""
import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re

import numpy as np

ROOT = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--os', type=Path, default=ROOT / 'os')
p.add_argument('--report', type=Path, default=ROOT / 'readback.json')
args = p.parse_args()
font = args.os / 'PCP_OS_Rust/crates/pcpos-kernel/src/font.rs'
table = ast.literal_eval('[' + font.read_text().split(' = [', 1)[1].split('];', 1)[0] + ']')
glyphs = {np.packbits(np.asarray(c) > 0).tobytes(): chr(32+i) for i, c in enumerate(table)}
body = ['The register is closed and verified first. Files of this session that were',
        'not saved by a program are lost.']
footer = 'Enter switch off    Esc go back'


def reader(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / name / 'desktop_screens.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.DesktopScreens(args.os, {})


old = reader('parent')
new = reader('candidate')


def unpack(data):
    magic, size, depth, pixels = data.split(b'\n', 3)
    w, h = map(int, size.split())
    assert magic == b'P6' and depth == b'255' and len(pixels) == w*h*3
    return np.frombuffer(pixels, dtype=np.uint8).reshape(h, w, 3)


def encode(frame):
    h, w, _ = frame.shape
    return f'P6\n{w} {h}\n255\n'.encode() + frame.tobytes()


def row(frame, n):
    band = frame[20*n:20*(n+1)]
    chars = []
    for x in range(0, (band.shape[1]//10)*10, 10):
        cell = band[:, x:x+10]
        # Text and blank cells in this dialog have flat ground in the top-left pixel.
        mask = np.any(cell != cell[0, 0], axis=2)
        chars.append(glyphs.get(np.packbits(mask).tobytes(), '?'))
    return ''.join(chars).rstrip()


def assess(data):
    frame = unpack(data)
    h, w, _ = frame.shape
    rows = [row(frame, n).strip() for n in range(h//20)]
    lines = [v for v in rows[5:-2] if v]
    complete = (rows[1] == 'POWER OFF' and rows[3] == 'Switch PCP OS off?'
                and ' '.join(lines) == ' '.join(body) and rows[-2] == footer)
    return {'sha256': hashlib.sha256(data).hexdigest(), 'size': [w,h], 'warning_lines': lines,
            'footer': rows[-2], 'complete': complete, 'parent': old.matches(data, 'power'),
            'candidate': new.matches(data, 'power')}


results = {}
for group in ['originals', 'guests']:
    group_results = results[group] = {}
    for path in sorted((ROOT / group).glob('*/power.ppm')):
        mode = path.parent.name
        data = path.read_bytes()
        entry = group_results[mode] = assess(data)
        w, h = entry['size']
        assert mode == f'{w}x{h}'
        assert entry['candidate'] == (w >= 640 and h >= 480 and entry['complete'])
        if group == 'guests':
            recorded = json.loads((path.parent / 'result.json').read_text())
            for stem, digest in recorded['frames'].items():
                assert hashlib.sha256((path.parent / (stem+'.ppm')).read_bytes()).hexdigest() == digest
            assert recorded['frames']['power'] == recorded['frames']['confirmed-prompt'] == entry['sha256']
            assert recorded['frames']['home'] == recorded['frames']['cancelled']
            assert recorded['key_log'] == ['f10','esc','f10','ret'] and recorded['exit'] == 0
            assert recorded['final_checks'] == 72 and recorded['shutdown'] == {'guest':True,'reason':'guest-shutdown'}
assert len(results['originals']) == 12
assert {m for m,e in results['originals'].items() if e['parent']} == {'640x480', '800x600'}
assert {m for m,e in results['originals'].items() if e['candidate']} == {'800x600'}
boundary = {m: (e['complete'],e['parent'],e['candidate']) for m,e in results['guests'].items()}
assert boundary == {'752x480':(False,True,False), '760x480':(True,True,True), '760x460':(True,False,False)}, boundary

# Place exact word rectangles from a native complete dialog onto the body of the original 640px dialog.
src = unpack((ROOT/'guests/760x480/power.ppm').read_bytes())
base = unpack((ROOT/'originals/640x480/power.ppm').read_bytes())
words = []
for n, text in enumerate(body,5):
    expected = '  '+text
    assert row(src,n) == expected
    for m in re.finditer(r'\S+',expected):
        words.append((m[0],src[20*n:20*(n+1),10*m.start():10*m.end()]))
blank = base[100,0].copy()
assert np.all(base[140:160] == blank)
def reflow(groups):
    dst = base.copy()
    dst[100:180] = blank
    for n,group in enumerate(groups,5):
        col = 2
        for i in group:
            word, tile = words[i]
            dst[20*n:20*(n+1),10*col:10*(col+len(word))] = tile
            col += len(word)+1
    return dst

layout = [list(range(a,b)) for a,b in [(0,7),(7,14),(14,len(words))]]
trial = reflow(layout)
controls = results['pixel_controls'] = {}
def control(name, image, expected):
    outcome = controls[name] = assess(encode(image))
    assert outcome['candidate'] is expected and outcome['complete'] is expected, name

control('complete-three-line-reflow',trial,True)
for term in ('closed','not','lost.'):
    omit = [[i for i in line if words[i][0] != term] for line in layout]
    control('omit-'+term.rstrip('.'),reflow(omit),False)
control('swap-body-rows',reflow([layout[1],layout[0],layout[2]]),False)
for name,n,phrase in [('title',1,'POWER OFF'),('question',3,'Switch PCP OS off?'),
                       ('confirm-action',22,'Enter switch off'),('cancel-action',22,'Esc go back')]:
    altered = trial.copy()
    col = row(altered,n).index(phrase)
    altered[20*n:20*(n+1),10*col:10*(col+len(phrase))] = blank
    control('erase-'+name,altered,False)
args.report.write_text(json.dumps(results,indent=2)+'\n')
print('Originals:',len(results['originals']), 'Fresh:',boundary,'Pixel controls:',len(controls))

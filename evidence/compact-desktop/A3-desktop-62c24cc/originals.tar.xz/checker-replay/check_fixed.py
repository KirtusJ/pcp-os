"""Replay the corrected scroll predicate on native pages, then challenge it with conflicting digests."""
from pathlib import Path
import ast,json,re
import verify_f5 as orig

root=Path(__file__).resolve().parent
src=root/'checker-012ca21.py'
tree=ast.parse(src.read_text())
parts=[n for n in tree.body if (isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LABEL' for t in n.targets)) or (isinstance(n,ast.FunctionDef) and n.name=='whole_heads')]
trial=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='text_trial')
start=next(i for i,n in enumerate(trial.body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='heads')
end=next(i for i,n in enumerate(trial.body[start:],start) if isinstance(n,ast.If))
code=compile(ast.Module(body=parts+trial.body[start:end+1],type_ignores=[]),str(src),'exec')
def verdict(pages):
    space=dict(re=re,found=[],verification_rows=pages,verification=[' '.join(' '.join(rows).split()) for rows in pages])
    exec(code,space)
    return not space['found']
def other(c):return '1' if c=='0' else '0'
scores={}
for p in sorted(root.glob('*x*/result.json')):
    rec=json.loads(p.read_text())
    scores[p.parent.name]={}
    for stage in ['before','after']:
        expected=rec[stage]['verification']['full']
        original=[]; erased=[]
        for txt in sorted(p.parent.glob(stage+'-f5-page-*.txt')):
            raw=txt.with_suffix('.ppm').read_bytes()
            rows=orig.decode(raw)
            original.append(rows)
            bad,_=orig.erase(raw,rows,expected)
            erased.append(orig.decode(bad))
        assert verdict(original) and not verdict(erased)
        score={'original_accepted':True,'erased_digit_rejected':True}
        if p.parent.name=='320x200':
            # A text-level edit to a valid hexadecimal character on the partial scroll page only.
            fork=[list(page) for page in original]
            at=next(i for i,r in enumerate(fork[2]) if r.strip()==expected[:28])
            row=fork[2][at];idx=row.index(expected[0])
            fork[2][at]=row[:idx]+other(row[idx])+row[idx+1:]
            assert not verdict(fork)
            # Introduce a second complete head which agrees on its first sixteen digits.
            other_page=original[3].copy()
            at=next(i for i,r in enumerate(other_page) if r.strip()==expected[-8:])
            row=other_page[at];other_page[at]=row[:-1]+other(row[-1])
            assert not verdict(original+[other_page])
            score.update(conflicting_partial_rejected=True,conflicting_full_rejected=True)
        scores[p.parent.name][stage]=score
(root/'corrected-verdicts.json').write_text(json.dumps(scores,indent=2)+'\n')
print('Corrected predicate passed original and adverse cases at',len(scores),'sizes, two register states each.')

"""Reread F5, F10 and the failed-start Programs notice from raw captures of both kernels."""
import argparse
import json
from pathlib import Path
import re
import runpy


def investigate(source, evidence):
    tester = runpy.run_path(str(source / 'examples/tester-cd/check_small_screens.py'))
    read = tester['PINS']['read']
    glyphs = tester['CHECK']['kernel_glyphs']()
    results = {}
    for role in ('parent', 'candidate'):
        for mode in ('320x200', '640x480', '800x600', '1280x720', '1920x1080', '2560x1440'):
            folder = evidence / role / mode
            def read_frame(path):
                frame = path.read_bytes()
                assert frame.split(b'\n', 2)[1].decode() == mode.replace('x', ' ')
                rows = read(frame, glyphs)
                assert rows is not None and '\n'.join(rows)+'\n' == path.with_suffix('.txt').read_text(), path
                return rows

            pages = [read_frame(p) for p in sorted(folder.glob('verification-again-[0-9]*.ppm'))]
            assert pages
            heads = tester['whole_heads'](pages)
            full = {h for h in heads if len(h) == 64}
            assert len(full) == (role == 'candidate'), (role, mode, heads)
            prefixes = set()
            for page in pages:
                prefixes.update(re.findall(r'head ([0-9a-f]{16})\.\.\.', tester['joined'](page)))
            if role == 'candidate':
                digest = next(iter(full))
                assert prefixes == {digest[:16]} and all(digest.startswith(part) for part in heads)
            verdict = {
                'whole_f5_digest': bool(full),
                'whole_f10_warning': not tester['power_problems'](read_frame(folder/'power-1.ppm'))
            }
            if mode in ('320x200', '640x480'):
                rows = read_frame(folder/'failed-programs.ppm')
                verdict['whole_disabled_notice'] = any('Programs are disabled.' in row for row in rows)
                assert verdict['whole_disabled_notice'] == (role == 'candidate')
            results.setdefault(mode, {})[role] = verdict
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path, help='checkout of the checker at 62c24cc')
    parser.add_argument('evidence', type=Path, help='extracted archive with parent and candidate directories')
    args = parser.parse_args()
    print(json.dumps(investigate(args.source.resolve(), args.evidence.resolve()), indent=2))

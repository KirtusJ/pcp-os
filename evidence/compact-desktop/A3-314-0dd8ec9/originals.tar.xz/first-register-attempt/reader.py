"""Compare the F4 and F5 register readings on a measured PCP OS kernel and preserve the original frames."""
import hashlib
import json
import runpy
import subprocess
import sys
import time
from pathlib import Path

from power_layout import complete_power_warning

here = Path(__file__).resolve().parent
source = here.parent / "f10-source"
kernel = here / "kernel.elf32"
mode = sys.argv[1]
out = here / ("register-" + mode)
out.mkdir()
width, height = map(int, mode.split("x"))
kernel_tools = source / "PCP_OS_Rust/crates/pcpos-kernel/tools"
measurement = runpy.run_path(str(kernel_tools / "measure.py"))["measure"](kernel.read_bytes())
guest_tools = runpy.run_path(str(source / "examples/optical-disk-check/check.py"))
reader = runpy.run_path(str(source / "examples/tester-cd/check_compact_pins.py"))
glyphs = reader["CHECK"]["kernel_glyphs"]()
serial = out / "serial.txt"
def serial_text():
    return serial.read_text(errors="replace") if serial.exists() else ""
cmd = [str(here.parent/"bin/qemu-system-x86_64"), "-machine", "pc", "-accel", "tcg", "-cpu", "qemu64", "-m", "128M",
       "-vga", "std", "-nic", "none", "-display", "none", "-monitor", "none", "-qmp", "stdio", "-serial", "file:"+str(serial),
       "-kernel", str(kernel), "-append", f"desktop={mode} image={measurement}", "-initrd", str(here.parent/"replay/rdesk.elf")]
with (out/"stderr.txt").open("wb") as err, subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        monitor = guest_tools["Monitor"](vm)
        monitor.call("qmp_capabilities")
        guest_tools["wait_for"](lambda: "desktop: "+mode in serial_text() and measurement+" (measured; equal" in serial_text(), "measured desktop", 45)
        time.sleep(.35)
        def press(key):
            monitor.key(key)
            time.sleep(.24)
        def capture(name):
            p = out/(name+".ppm")
            previous = None
            for _ in range(16):
                monitor.call("screendump", filename=str(p))
                image = p.read_bytes()
                if image == previous:
                    assert image.startswith(f"P6\n{width} {height}\n255\n".encode())
                    return image
                previous = image
                time.sleep(.12)
            raise RuntimeError("unstable display "+name)
        import re
        def rows(frame):
            return reader["read"](frame, glyphs)
        def text(frame):
            return "".join("".join(rows(frame)).split())
        def find_page(name, move, predicate, stride, limit):
            for n in range(limit):
                frame=capture(f"{name}-{n:02}")
                found=predicate(text(frame))
                if found:
                    return frame,found
                if n+1 < limit:
                    for _ in range(stride):
                        monitor.key(move)
                        time.sleep(.095)
                    time.sleep(.09)
            raise RuntimeError(name+" target missing")
        home=capture("home")
        press("f5")
        vframe,v=find_page("verification","down",lambda t: re.search(r"Register:(\d+)events,head([0-9a-f]{16})\.\.\.",t),1,8)
        press("esc")
        assert capture("home-after-f5")==home
        press("f4")
        titleframe=capture("register-title")
        title=[s.strip() for s in rows(titleframe) if "REGISTER:" in s][0]
        count=re.search(r"REGISTER: (\d+) events, (?:chain )?intact",title).group(1)
        assert count==v.group(1)
        rframe,h=find_page("register","up",lambda t: re.search(r"head([0-9a-f]{64})(?![0-9a-f])",t),6,30)
        assert h.group(1)[:16]==v.group(2)
        press("esc")
        assert capture("home-after-f4")==home
        press("f10")
        power=capture("power")
        assert complete_power_warning(rows(power))
        press("ret")
        code=vm.wait(timeout=25)
        while not any(e["event"]=="SHUTDOWN" for e in monitor.events):
            monitor.events.append(monitor.read())
        shutdown=next(e["data"] for e in monitor.events if e["event"]=="SHUTDOWN")
        checks=sum(line.startswith("  pass ") for line in serial_text().splitlines())
        assert code==0 and checks==72 and shutdown=={"guest":True,"reason":"guest-shutdown"}
        record=dict(mode=mode,source=subprocess.check_output(["git","-C",str(source),"rev-parse","HEAD"],text=True).strip(),kernel_measurement=measurement,title=title,
                    f5_prefix=v.group(2),f4_full=h.group(1),count=int(count),checks=checks,exit=code,shutdown=shutdown,home_restored_twice=True)
        (out/"result.json").write_text(json.dumps(record,indent=2)+"\n")
        print(mode,title,count,h.group(1),v.group(2))
    finally:
        if vm.poll() is None:
            vm.kill()
            vm.wait()

"""Run the tracked QEMU check over stdio in environments without Unix sockets."""
import difflib
import os
from pathlib import Path
import sys
root=Path(__file__).resolve().parent
name=sys.argv.pop(1)
src=root/'source/examples/tester-cd'/name
text=src.read_text()
s=text.replace('"unix:%s,server=on,wait=off" % sock','"stdio"')
if name=='check.py':
    s=s.replace('guest = subprocess.Popen(cmd, stderr=err)','guest = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, stderr=err)')
    ending='        stream = channel.makefile("rw")'
else:
    s=s.replace('stdout=subprocess.DEVNULL','stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True')
    ending='        stream = link.makefile("rw")'
    mode=os.environ['A3_SCREEN_SIZE']
    marker='        roomy = mode == "640x480"'
    assert marker in s
    s=s.replace(marker,'        if mode != '+repr(mode)+':\n            continue\n'+marker)
a=s.index('        end = time.monotonic() + 20\n        while not sock.exists():')
b=s.index(ending,a)+len(ending)
s=(s[:a]+s[b:]).replace('stream.readline()', 'guest.stdout.readline()').replace('stream.write(', 'guest.stdin.write(').replace('stream.flush()', 'guest.stdin.flush()')
assert 'stream.' not in s
diff_name='transport-'+os.environ.get('A3_SCREEN_SIZE','optical')+'.diff'
(root/diff_name).write_text(''.join(difflib.unified_diff(text.splitlines(True),s.splitlines(True),fromfile='source/'+name,tofile='host/'+name)))
sys.argv[0]=str(src)
exec(compile(s,str(src),'exec'),{'__file__':str(src),'__name__':'__main__'})

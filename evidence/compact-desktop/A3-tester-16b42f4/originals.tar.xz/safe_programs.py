"""Observe the failed-start desktop and register using a wrong expected measurement."""
import argparse,hashlib,json,re,runpy,subprocess,time
from pathlib import Path
base=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('build',type=Path)
parser.add_argument('mode')
parser.add_argument('out',type=Path)
args=parser.parse_args()
out=args.out.resolve()
out.mkdir(parents=True)
receipt=json.loads((args.build/'receipt.json').read_text())
iso=(args.build/'pcp-os-tester.iso').read_bytes()
assert hashlib.sha256(iso).hexdigest()==receipt['iso_sha256']
repo=base/'source'
items=runpy.run_path(str(repo/'examples/tester-cd/build.py'))['read_back'](iso)
for k in ['kernel.elf32','surf.elf']:
    assert hashlib.sha256(items[k]).hexdigest()==receipt['on_disc'][k]['sha256']
    (out/k).write_bytes(items[k])
name=receipt['kernel_measurement']
wrong=('1' if name[0]=='0' else '0')+name[1:]
cmd=[str(base.parent/'bin/qemu-system-x86_64'),'-machine','pc','-cpu','qemu64','-m','256M','-device','VGA,vgamem_mb=64','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(out/'serial.txt'),'-kernel','kernel.elf32','-append',f'desktop={args.mode} image={wrong}','-initrd','surf.elf']
qtools=runpy.run_path(str(repo/'examples/optical-disk-check/check.py'))
reader=runpy.run_path(str(repo/'examples/tester-cd/check_compact_pins.py'))
glyphs=reader['CHECK']['kernel_glyphs']()
record={'revision':receipt['source_commit'],'true_measurement':name,'supplied_measurement':wrong,'mode':args.mode,'passed':False}
def log():
    serial=out/'serial.txt'
    return serial.read_text(errors='replace') if serial.exists() else ''
with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
    try:
        monitor=qtools['Monitor'](guest)
        monitor.call('qmp_capabilities')
        qtools['wait_for'](lambda:'desktop: '+args.mode in log() and 'it is in SAFE and starts no program' in log(),'failed-start desktop',45)
        def key(value):
            monitor.key(value)
            time.sleep(.22)
        def capture(label):
            p=out/(label+'.ppm')
            last=None
            for _ in range(20):
                monitor.call('screendump',filename=str(p))
                raw=p.read_bytes()
                if raw==last:break
                last=raw
                time.sleep(.12)
            else:raise ValueError('screen did not settle')
            assert raw.split(b'\n',2)[1].decode().replace(' ','x')==args.mode
            rows=reader['read'](raw,glyphs)
            (out/(label+'.txt')).write_text('\n'.join(rows)+'\n')
            return raw,rows
        def register(label):
            key('f4')
            _,rows=capture(label)
            count=next(re.search(r'REGISTER: (\d+) events, (?:chain )?intact',r)[1] for r in rows if re.search(r'REGISTER: (\d+) events, (?:chain )?intact',r))
            key('esc')
            return int(count)
        time.sleep(.35)
        capture('home')
        record['before']=register('before-register')
        key('spc')
        raw,lines=capture('programs')
        record['rows']=[r.strip() for r in lines if r.strip()]
        record['disabled_notice']='Programs are disabled.' in ' '.join(' '.join(lines).split())
        assert any('surf.elf' in s for s in lines)
        key('ret')
        after,_=capture('programs-after-enter')
        record['same_screen_after_enter']=after==raw
        key('esc')
        record['after']=register('after-register')
        assert record['before']==record['after']
        key('f10')
        capture('power')
        key('ret')
        record['exit']=guest.wait(timeout=30)
        while not any(e['event']=='SHUTDOWN' for e in monitor.events):
            monitor.events.append(monitor.read())
        record['shutdown']=next(e['data'] for e in monitor.events if e['event']=='SHUTDOWN')
        text=log()
        record['task_launches']=len(re.findall(r'^starting surf\.elf ',text,re.M))
        record['closed']=int(re.search(r'kernel register: (\d+) events',text)[1])
        assert record['closed']==record['after']+2 and record['task_launches']==0
        assert 'did not verify itself' in text and 'ALL SELF-TESTS PASS' not in text
        assert record['shutdown']=={'guest':True,'reason':'guest-shutdown'}
        record['passed']=True
    finally:
        if guest.poll() is None:guest.kill();guest.wait()
        (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(args.mode,'notice:',record['disabled_notice'],'events:',record['before'],record['after'],'launches:',record['task_launches'])

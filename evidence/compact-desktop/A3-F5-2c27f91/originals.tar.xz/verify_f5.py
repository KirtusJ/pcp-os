"""Replay the exact Git checker clauses over native guest pixels and one-digit pixel erasures."""
from pathlib import Path
import ast,hashlib,json,re
import numpy as np
from ledger_check import event_hash
root=Path(__file__).resolve().parent
f=ast.literal_eval('['+(root/'font.rs').read_text().split(' = [',1)[1].split('];',1)[0]+']')
glyph={np.packbits(np.array(g)>0).tobytes():chr(32+i) for i,g in enumerate(f)}
def decode(raw):
    m,size,d,body=raw.split(b'\n',3)
    w,h=map(int,size.split())
    assert m==b'P6' and d==b'255' and len(body)==w*h*3
    pix=np.frombuffer(body,dtype='u1').reshape(h,w,3)
    masks=(pix[:h//20*20,:w//10*10]!=pix[0,0]).any(2).reshape(h//20,20,w//10,10).transpose(0,2,1,3)
    packed=np.packbits(masks.reshape(h//20,w//10,200),axis=-1)
    return [''.join(glyph.get(c.tobytes(),'�') for c in row).rstrip() for row in packed]
def exact(path):
    tree=ast.parse(path.read_text())
    title=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='LABEL' for x in n.targets)]
    helper=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='whole_heads']
    trial=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='text_trial')
    pos=next(i for i,n in enumerate(trial.body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='heads')
    code=compile(ast.Module(body=title+helper+trial.body[pos:pos+3],type_ignores=[]),str(path),'exec')
    def read(pages):
        space=dict(re=re,verification_rows=pages,verification=[' '.join(' '.join(v).split()) for v in pages],found=[])
        exec(code,space)
        return dict(accepts=not space['found'],candidate_lengths=sorted(len(s) for s in space['heads']))
    return read
def erase(raw,rows,expected):
    parts=raw.split(b'\n',3)
    width=int(parts[1].split()[0])
    pixels=bytearray(parts[3])
    changed=False
    for iy,row in enumerate(rows):
        word=row.strip()
        if not re.fullmatch('[0-9a-f]+',word) or not expected.endswith(word):continue
        col=len(row.rstrip())-1
        for y in range(20):
            offset=((iy*20+y)*width+col*10)*3
            pixels[offset:offset+30]=parts[3][:3]*10
        changed=True
    return b'\n'.join(parts[:3]+[bytes(pixels)]),changed
checks={tag:exact(root/('checker-'+tag+'.py')) for tag in ('ea3bbb4','2c27f91')}
results={}
for p in sorted(root.glob('*x*/result.json')):
    item=json.loads(p.read_text())
    assert item['passed']
    mode=p.parent.name
    results[mode]={}
    for stage in ['before','after']:
        expected=item[stage]['verification']['full']
        originals=[]; altered=[]; n=0
        for txt in sorted(p.parent.glob(stage+'-f5-page-*.txt')):
            raw=txt.with_suffix('.ppm').read_bytes()
            rows=decode(raw)
            assert rows==txt.read_text().splitlines()
            originals.append(rows)
            bad,changed=erase(raw,rows,expected)
            altered.append(decode(bad));n+=int(changed)
        assert n
        results[mode][stage]={tag:{'original':tester(originals),'last_digit_erased':tester(altered)} for tag,tester in checks.items()}
        assert all(not v['last_digit_erased']['accepts'] for v in results[mode][stage].values())
    task=json.loads((p.parent/'task-records.json').read_text())
    current=item['before']['verification']['full']
    for i,record in enumerate(task+item['closing_records']):
        assert record['prev']==current
        current=event_hash(record)
        if i==2:assert current==item['after']['verification']['full']
    assert current==item['closed']['head']
    print(mode,results[mode]['after'])
(root/'checker-results.json').write_text(json.dumps(results,indent=2)+'\n')

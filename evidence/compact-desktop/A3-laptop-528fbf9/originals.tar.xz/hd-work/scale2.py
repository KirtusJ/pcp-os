"""Exercise the F10 dialog on a measured PCP OS kernel and preserve the original frames."""
import hashlib
import json
import runpy
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
from power_layout import complete_power_warning

here = Path(__file__).resolve().parent
source = here.parent / "hd-source"
kernel = here / "kernel.elf32"
mode = sys.argv[1]
out = here / ("scale2-"+mode)
out.mkdir()
width, height = map(int, mode.split("x"))
kernel_tools = source / "PCP_OS_Rust/crates/pcpos-kernel/tools"
measurement = runpy.run_path(str(kernel_tools / "measure.py"))["measure"](kernel.read_bytes())
guest_tools = runpy.run_path(str(source / "examples/optical-disk-check/check.py"))
reader = runpy.run_path(str(source / "examples/tester-cd/check_compact_pins.py"))
glyphs = reader["CHECK"]["kernel_glyphs"]()
serial = out / "serial.txt"
def serial_text():
    return serial.read_text(errors="replace") if serial.exists() else ""
cmd = [str(here.parent/"bin/qemu-system-x86_64"), "-machine", "pc", "-accel", "tcg", "-cpu", "qemu64", "-m", "256M",
       "-device", "VGA,vgamem_mb=64", "-nic", "none", "-display", "none", "-monitor", "none", "-qmp", "stdio", "-serial", "file:"+str(serial),
       "-kernel", str(kernel), "-append", f"desktop={mode} ui_scale=2 image={measurement}", "-initrd", str(here.parent/"replay/rdesk.elf")]
with (out/"stderr.txt").open("wb") as err, subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        monitor = guest_tools["Monitor"](vm)
        monitor.call("qmp_capabilities")
        guest_tools["wait_for"](lambda: "desktop: "+mode in serial_text() and measurement+" (measured; equal" in serial_text(), "measured desktop", 45)
        time.sleep(.35)
        def press(key):
            monitor.key(key)
            time.sleep(.24)
        def capture(name):
            p = out/(name+".ppm")
            previous = None
            for _ in range(16):
                monitor.call("screendump", filename=str(p))
                image = p.read_bytes()
                if image == previous:
                    assert image.startswith(f"P6\n{width} {height}\n255\n".encode())
                    return image
                previous = image
                time.sleep(.12)
            raise RuntimeError("unstable display "+name)
        home = capture("home")
        assert "desktop: "+mode+" at 2x UI scale" in serial_text()
        font=(source/"PCP_OS_Rust/crates/pcpos-kernel/src/font-2x.bin").read_bytes()
        masks=np.frombuffer(font,dtype=np.uint8).reshape(95,40,20)
        alphabet={np.packbits(g>0).tobytes():chr(32+i) for i,g in enumerate(masks)}
        def doubled_rows(frame):
            pixels=np.frombuffer(frame.split(b"\n",3)[3],dtype=np.uint8).reshape(height,width,3)
            ink=np.any(pixels!=pixels[0,0],axis=2)
            return ["".join(alphabet.get(np.packbits(ink[y:y+40,x:x+20]).tobytes(),"~")
                            for x in range(0,width,20)).rstrip() for y in range(0,height,40)]
        home_text=doubled_rows(home)
        assert any("PCP OS | DESKTOP" in l for l in home_text)
        assert any("Up/Down choose   Enter open   F1 keys   F10 off" in l for l in home_text)
        press("f10")
        power=capture("power")
        rows=doubled_rows(power)
        assert complete_power_warning(rows),rows
        controls={}
        press("esc")
        assert capture("home-restored") == home
        press("f10")
        assert capture("power-reopened") == power
        press("ret")
        code = vm.wait(timeout=35)
        while not any(e["event"]=="SHUTDOWN" for e in monitor.events):
            monitor.events.append(monitor.read())
        shutdown = next(e["data"] for e in monitor.events if e["event"]=="SHUTDOWN")
        log = serial_text()
        checks = sum(line.startswith("  pass ") for line in log.splitlines())
        assert code==0 and checks==72 and shutdown=={"guest":True,"reason":"guest-shutdown"} and "ALL SELF-TESTS PASS." in log
        record = dict(mode=mode,scale=2,logical_size=[width//2,height//2],font_2x_sha256=hashlib.sha256(font).hexdigest(),boot_surface="plain program list", source=subprocess.check_output(["git","-C",str(source),"rev-parse","HEAD"],text=True).strip(),
                      measurement=measurement, kernel_sha256=hashlib.sha256(kernel.read_bytes()).hexdigest(),
                      rows=[[i,line.strip()] for i,line in enumerate(rows) if line.strip()], omitted_glyph_accepted=controls,
                      power_sha256=hashlib.sha256(power).hexdigest(), home_restored=True, power_reopened=True,
                      exit=code,checks=checks,shutdown=shutdown)
        (out/"result.json").write_text(json.dumps(record,indent=2)+"\n")
        print(mode,record["scale"],record["logical_size"],checks,code)
    finally:
        if vm.poll() is None:
            vm.kill()
            vm.wait()


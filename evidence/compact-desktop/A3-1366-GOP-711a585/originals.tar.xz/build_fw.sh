#!/bin/bash
set -eo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
prefix="$root/../root/usr"
export PATH="$prefix/bin:$PATH"
export CPATH="$prefix/include"
export LIBRARY_PATH="$prefix/lib/x86_64-linux-gnu"
cd "$root/edk2-2025.02"
if [ ! -e BaseTools/Source/C/BrotliCompress/brotli/c ]; then
  ln -s "$PWD/MdeModulePkg/Library/BrotliCustomDecompressLib/brotli/c" BaseTools/Source/C/BrotliCompress/brotli/c
fi
if [ ! -f "$root/fixed-mode.patch" ]; then
python3 - "$root" <<'PY'
from pathlib import Path
import difflib,sys
p=Path('OvmfPkg/QemuRamfbDxe/QemuRamfb.c')
raw=p.read_bytes()
s=raw.decode().replace('\r\n','\n')
a=s.index('  {\n',s.index('mQemuRamfbModeInfo[]'))
b=s.index('\n};',a)
new=s[:a]+'  {\n    0,\n    1366,\n    768,\n  }'+s[b:]
old='// 800 x 600\n  //\n  QemuRamfbGraphicsOutputSetMode (&mQemuRamfbGraphicsOutput, 1);'
assert old in new
new=new.replace(old,'// Fixed-size laptop display fixture\n  //\n  QemuRamfbGraphicsOutputSetMode (&mQemuRamfbGraphicsOutput, 0);')
Path(sys.argv[1],'fixed-mode.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),new.splitlines(True),'a/'+str(p),'b/'+str(p))))
p.write_bytes(new.replace('\n','\r\n').encode() if b'\r\n' in raw else new.encode())
PY
fi
source edksetup.sh >/dev/null
make -s -j8 -C BaseTools/Source/C
build -a X64 -b RELEASE -t GCC5 -p OvmfPkg/OvmfPkgX64.dsc -n 8 -D FD_SIZE_4MB

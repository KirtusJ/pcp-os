"""Compare firmware framebuffer bytes, measured guest output and QEMU's visible PC screen."""
import hashlib
import json
import re
import runpy
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
from PIL import Image

here = Path(__file__).resolve().parent
runtime = here.parent
source = runtime / "gop-os"
firmware_example = source / "examples/firmware-owned-uefi"
sys.path.insert(0, str(firmware_example))
from usb_trial import OPTICAL, loader_picture, usb_command
from image import digest

label, ram, code_path, vars_path, target = sys.argv[1:6]
out = here / label
out.mkdir()
image = json.loads((here / "image.json").read_text())
code, variables = Path(code_path).resolve(), Path(vars_path).resolve()
volume = here / 'stock/usb.img'
command = usb_command(str(runtime / 'bin/qemu-system-x86_64'), code, variables, volume, out, int(ram), 'ramfb')
serial, trace = out / 'serial.txt', out / 'firmware.txt'
font_reader = runpy.run_path(str(source / 'examples/tester-cd/check_compact_pins.py'))
glyphs = font_reader['CHECK']['kernel_glyphs']()
checker = runpy.run_path(str(runtime / 'dist-65-merged/audit/public-live-cd/desktop_screens.py'))
record = dict(requested=target, ram_mib=int(ram), qemu=subprocess.check_output([command[0],'--version'],text=True).splitlines()[0],
              kernel_source=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip(),
              source_patch='examples/firmware-owned-uefi/load-base.patch', measured_kernel=image['measurement'],
              usb_sha256=image['usb_sha256'], firmware_code_sha256=digest(code), vars_template_sha256=digest(variables),
              usb_read_only=False, passed=False)
def log(path):
    return path.read_text(errors='replace') if path.exists() else ''
def screenshot(name):
    path=out/(name+'.ppm')
    native_png=out/(name+'.png')
    native_ppm=out/(name+'.qemu.ppm')
    previous=None
    for _ in range(24):
        qmp('screendump',filename=str(native_png),format='png')
        with Image.open(native_png) as picture:
            width,height=picture.size
            pixels=picture.convert('RGB').tobytes()
        if pixels==previous:
            qmp('screendump',filename=str(native_ppm),format='ppm')
            magic,size,depth,body=native_ppm.read_bytes().split(b'\n',3)
            assert magic==b'P6' and depth==b'255' and size==f'{width} {height}'.encode()
            row_bytes,remainder=divmod(len(body),height)
            assert remainder==0 and row_bytes>=3*width
            packed=b''.join(body[y*row_bytes:y*row_bytes+3*width] for y in range(height))
            assert packed==pixels
            data=f'P6\n{width} {height}\n255\n'.encode()+pixels
            path.write_bytes(data)
            record['qemu_ppm_bytes_per_row']=row_bytes
            record['packed_rgb_bytes_per_row']=3*width
            return data
        previous=pixels
        time.sleep(.12)
    raise ValueError('display kept changing at '+name)
def press(key):
    monitor.key(key)
    time.sleep(.3)
try:
    with (out/'stderr.txt').open('wb') as err, subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err) as guest:
        try:
            monitor=OPTICAL['Monitor'](guest)
            qmp=monitor.call
            qmp('qmp_capabilities')
            media=next(b for b in qmp('query-block') if b.get('device')=='stick')
            assert media['inserted']['ro'] and media['removable'] and Path(media['inserted']['file'])==volume
            record['usb_read_only']=True
            qmp('cont')
            OPTICAL['wait_for'](lambda:'owned-handoff' in log(trace),'firmware handing off',75)
            OPTICAL['wait_for'](lambda: 'desktop: ' in log(serial) and
                                image['measurement']+' (measured; equal' in log(serial),'measured desktop',60)
            time.sleep(.65)
            home=screenshot('home')
            firmware=log(trace).splitlines()
            expected=['removable-vm','allocation=0000000000000000','owned-before-write','content-verified','exit_status=0000000000000000','owned-handoff']
            assert [x for x in firmware if x in expected]==expected
            details,address=loader_picture(log(serial),firmware,out/'home.ppm')
            record['loader_display']=details
            width,height=map(int,home.split(b'\n',2)[1].split())
            size=f'{width}x{height}'
            record['captured']=size
            record['kernel_reported']=re.search(r'Loader, (\d+x\d+),',details)[1]
            pitch=int(next(x.split('=')[1] for x in firmware if x.startswith('console_pitch=')),16)
            record['firmware_pitch_bytes']=pitch
            record['framebuffer_address']=hex(address)
            assert target=='firmware-default' or target==size
            assert f'desktop: {size}' in log(serial)
            qmp('stop')
            current=screenshot('home-stopped')
            assert current==home
            raw=out/'home.bgrx'
            response=qmp('human-monitor-command',**{'command-line':f'pmemsave {address:#x} {pitch*height} "{raw}"'})
            assert raw.is_file(),response
            mem=np.fromfile(raw,dtype=np.uint8).reshape(height,pitch)[:,:width*4].reshape(height,width,4)
            assert mem[:,:,2::-1].tobytes()==home.split(b'\n',3)[3]
            record['matched_framebuffer_pixels']=width*height
            qmp('cont')
            if target!='firmware-default':
                press('spc')
                frame=screenshot('programs')
                m,sz,d,pixels=frame.split(b'\n',3)
                stripe=b'\n'.join([m,f'{width} 20'.encode(),d,pixels[120*3*width:140*3*width]])
                line=font_reader['read'](stripe,glyphs)[0]
                caption=next(x for x in ('Choose one. Each runs with only what it is granted.','Choose one to start. Each runs with only what it is granted.') if x in line)
                x0=line.index(caption)*10
                x1=x0+len(caption)*10
                band=np.frombuffer(pixels,dtype=np.uint8).reshape(height,width,3)[118]
                left=right=x0+5
                while left>0 and np.array_equal(band[left-1],band[x0+5]):
                    left-=1
                while right<width and np.array_equal(band[right],band[x0+5]):
                    right+=1
                assert left<=x0<x1<=right
                record['programs']={'caption':caption,'panel_interior':[left,right],'caption_cells':[x0,x1],'right_clearance':right-x1}
                press('esc')
                assert screenshot('home-after-programs')==home
            press('f10')
            power=screenshot('power')
            rows=checker['power_warning_rows'](power,glyphs)
            assert checker['complete_power_warning'](rows),rows
            record['warning_and_actions']=[s for s in rows if s]
            press('esc')
            assert screenshot('home-after-power')==home
            press('f10')
            assert screenshot('power-reopened')==power
            press('ret')
            OPTICAL['wait_for'](lambda:qmp('query-status')['status']=='shutdown','guest shutdown',40)
            record['shutdown']=next(e['data'] for e in monitor.events if e['event']=='SHUTDOWN')
            qmp('quit')
            record['qemu_exit']=guest.wait(timeout=8)
            logtext=log(serial)
            record['checks']=sum(x.startswith('  pass ') for x in logtext.splitlines())
            assert 'ALL SELF-TESTS PASS.' in logtext and record['checks']==72
            assert record['qemu_exit']==0 and record['shutdown']=={'guest':True,'reason':'guest-shutdown'}
            assert digest(volume)==image['usb_sha256']
            record['home_restored']=record['identical_power_after_reopen']=record['passed']=True
        finally:
            if guest.poll() is None:
                guest.kill()
                guest.wait()
finally:
    (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record))

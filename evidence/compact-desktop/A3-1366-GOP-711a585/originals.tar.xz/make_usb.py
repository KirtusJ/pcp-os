import json, os, runpy
from pathlib import Path
here=Path(__file__).resolve().parent
runtime=here.parent
prefix=runtime/'root/usr'
source=runtime/'gop-os/examples/firmware-owned-uefi'
work=here/'stock'
work.mkdir(exist_ok=True)
recipe=(source/'image.py').read_text().replace('/usr/include/efi',str(prefix/'include/efi')).replace('/usr/lib',str(prefix/'lib'))
script=here/'image_host.py'
script.write_text(recipe)
os.environ['PATH']=f"{prefix}/bin:{prefix}/sbin:"+os.environ['PATH']
os.environ['LD_LIBRARY_PATH']=str(runtime/'lib')
fn=runpy.run_path(str(script))['make']
image=fn(runtime/'live.iso',here/'kernel.elf32',runtime/'gop-os/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py',work,source,usb_vm=True)
(here/'image.json').write_text(json.dumps(image,indent=2)+'\n')
print(image['measurement'],image['usb_sha256'])

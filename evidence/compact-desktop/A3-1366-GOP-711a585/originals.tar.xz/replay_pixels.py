"""Run with Python 3 and Pillow from the extracted evidence directory."""
from pathlib import Path
import hashlib
import json
from PIL import Image

root=Path(__file__).resolve().parent
for line in (root/'SHA256SUMS').read_text().splitlines():
    expected,name=line.split('  ',1)
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
for label in ['stock-default','exact-128','exact-256','png-128','png-256']:
    folder=root/label
    record=json.loads((folder/'result.json').read_text())
    width,height=map(int,record['captured'].split('x'))
    png=folder/'home.png'
    ppm=folder/('home.qemu.ppm' if png.exists() else 'home.ppm')
    magic, size, depth, body=ppm.read_bytes().split(b'\n',3)
    assert magic==b'P6' and size==f'{width} {height}'.encode() and depth==b'255'
    stride,leftover=divmod(len(body),height)
    assert leftover==0 and stride>=3*width
    rgb=b''.join(body[start:start+3*width] for start in range(0,len(body),stride))
    bgrx=(folder/'home.bgrx').read_bytes()
    assert len(bgrx)==record['firmware_pitch_bytes']*height
    fw=Image.frombytes('RGB',(width,height),bgrx,'raw','BGRX',record['firmware_pitch_bytes'],1)
    assert rgb==fw.tobytes()
    if png.exists():
        for name in ['home','power']:
            with Image.open(folder/(name+'.png')) as image:
                assert image.size==(width,height)
                pixels=image.convert('RGB').tobytes()
            raw=(folder/(name+'.qemu.ppm')).read_bytes().split(b'\n',3)[3]
            assert b''.join(raw[y*stride:y*stride+width*3] for y in range(height))==pixels
        assert (folder/'home.png').read_bytes()==(folder/'home-after-power.png').read_bytes()
        assert (folder/'power.png').read_bytes()==(folder/'power-reopened.png').read_bytes()
        assert record['programs']['right_clearance']==19
    assert record['passed']==(not label.startswith('exact-'))
    if record['passed']:
        assert record['checks']==72 and record['qemu_exit']==0
    print(label,width,height,width*height,'matching pixels',stride-3*width,'extra native PPM bytes per row')

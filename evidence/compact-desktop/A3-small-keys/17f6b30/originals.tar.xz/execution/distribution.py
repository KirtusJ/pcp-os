import hashlib,json,runpy,sys
from pathlib import Path
dist,src,cases=map(lambda s:Path(s).resolve(),sys.argv[1:])
api=runpy.run_path(str(dist/'audit/public-live-cd/desktop_screens.py'))
font=runpy.run_path(str(src/'examples/tester-cd/check.py'))['kernel_glyphs']()
reader=api['DesktopScreens'](src,{})
assert reader.confirm_power and reader.verification_key=='f5'
out={}
for f in sorted(cases.glob('*x*/result.json')):
    r=json.loads(f.read_text())
    if r['policy']!='uniform':continue
    d=r['frames']['power']
    data=(f.parent/(d+'.ppm')).read_bytes()
    assert hashlib.sha256(data).hexdigest()==d
    w,h=map(int,r['size'].split('x'))
    rows=api['power_warning_rows'](data,font)
    assert api['complete_power_warning'](rows) and reader.matches(data, 'power')
    text='Switch PCP OS off?'
    magic,size,depth,buf=data.split(b'\n',3)
    actual=runpy.run_path(str(src/'examples/tester-cd/check_compact_pins.py'))['read'](data,font)
    yy,xx=next((i,line.index(text)+len(text)-1) for i,line in enumerate(actual) if text in line)
    px=bytearray(buf)
    for y in range(yy*20,(yy+1)*20):
        start=w*3*y;px[start+xx*30:start+(xx+1)*30]=buf[start:start+3]*10
    damaged=b'\n'.join([magic,size,depth,px])
    assert not api['complete_power_warning'](api['power_warning_rows'](damaged,font))
    out[r['size']]={'complete':True,'missing_question_mark':False}
assert len(out)==8
print(json.dumps(out,indent=2))

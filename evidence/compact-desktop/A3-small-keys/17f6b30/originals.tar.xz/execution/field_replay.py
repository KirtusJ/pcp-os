"""Call the exact list_trial on intact scanouts and four separate one-glyph erasures."""
from pathlib import Path
import hashlib,json,re,runpy,sys
src,guest,report=(Path(p).resolve() for p in sys.argv[1:])
c=runpy.run_path(str(src/'examples/tester-cd/check_small_screens.py'))
glyphs=c['CHECK']['kernel_glyphs']()
r=json.loads((guest/'result.json').read_text())
f=r['frames']; w,h=map(int,r['size'].split('x')); assert (w,h)==(320,200)
def fetch(digest):
    data=(guest/(digest+'.ppm')).read_bytes()
    assert hashlib.sha256(data).hexdigest()==digest
    return data
pics={'programs-alpha.elf':fetch(f['programs-first']),'programs-bravo.elf':fetch(f['programs-second']),'details-left':fetch(f['details-returned-to-choice'])}
for k in c['LETTERS']:pics['programs-letter-'+k]=fetch(f['programs-'+k])
ids=[]
for i,digest in enumerate(r['details_pages']+[r['details_pages'][-1]]):
    label='details-'+str(i+1)
    ids.append(label)
    pics[label]=fetch(digest)
def decode(frame):return c['PINS']['read'](frame,glyphs)
body=[];offsets={}
for label in ids:
    part=decode(pics[label])[1:-1]
    overlap=max((n for n in range(1,min(len(body),len(part))+1) if body[-n:]==part[:n]),default=0)
    assert not body or overlap
    offsets[label]=len(body)-overlap
    body.extend(part[overlap:])
assert body==r['details_text']
facts={name:(f'{((guest/name).stat().st_size+1023)//1024} KiB',r['facts'][name]) for name in ['alpha.elf','bravo.elf']} if (guest/'alpha.elf').is_file() else {name:(f'{((guest.parent.parent/"fixtures"/name).stat().st_size+1023)//1024} KiB',r['facts'][name]) for name in ['alpha.elf','bravo.elf']}
cases={'original':None}
for name,(_,digest) in facts.items():
    loc=[n for n,row in enumerate(body) if row.strip()==name]
    assert len(loc)==2
    for section,i in zip(['PROGRAMS','FILES FROM THE LOADER'],loc):
        first=i+3
        assert body[first-1].strip()=='SHA-256'
        text=''
        while len(text)<64:
            last=first
            text+=body[first].strip()
            first+=1
        assert text==digest
        cases[section+' / '+name]=last
result={}
for case,position in cases.items():
    mask={}
    edits=[]
    for label in ids:
        if position is None or not offsets[label]<=position<offsets[label]+8:continue
        pic=pics[label]
        row=position-offsets[label]+1
        old=decode(pic)
        end=len(old[row])*10
        mag,size,depth,buf=pic.split(b'\n',3)
        raster=bytearray(buf)
        for y in range(row*20,(row+1)*20):
            start=3*w*y
            raster[start+3*(end-10):start+3*end]=buf[start:start+3]*10
        changed=b'\n'.join([mag,size,depth,bytes(raster)])
        expected=list(old);expected[row]=old[row][:-1]
        assert decode(changed)==expected
        mask[label]=changed;edits.append([label,row,end//10-1])
    def screen(label,gate):
        pic=mask.get(label,pics[label]); lines=decode(pic)
        assert gate(lines,pic)
        return lines,pic
    problems=[];details={}
    c['list_trial'](lambda *keys:None,screen,False,71,problems,details,'320x200',facts)
    if position is None:assert not problems,problems
    else:
        heading,name=case.split(' / ')
        assert edits and problems and all('K2:' in p and name in p and heading in p for p in problems),problems
    result[case]={'checker_accepted':not problems,'erased_digit_locations':edits,'problems':problems}
report.write_text(json.dumps(result,indent=2)+'\n')
print([(k,v['checker_accepted']) for k,v in result.items()])

"""Use native PCP workers to run each original geometry in its own output directory."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import os,subprocess,sys
here=Path(__file__).resolve().parent
work=here/'suite-stdio'
work.mkdir(exist_ok=True)
modes='320x200 320x220 320x240 320x260'.split()
def run(mode):
    env={**os.environ,'A3_SCREEN_SIZE':mode,'OMP_THREAD_LIMIT':'1'}
    cmd=[here.parent/'desk-build/release/pcp-delegate',here/'tasks.redb','screen-'+mode,'Exercise the tracked desktop checks at '+mode,'--',sys.executable,'-IB',here/'stdio.py','check_small_screens.py',here.parent/'third-next-work/tester',work/mode,'--qemu',here.parent/'bin/qemu-system-x86_64']
    with (work/(mode+'.log')).open('w') as log:
        process=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
    print(mode,process.returncode,flush=True)
    return process.returncode
with ThreadPoolExecutor(max_workers=3) as pool:
    failures=sum(x!=0 for x in pool.map(run,modes))
sys.exit(bool(failures))

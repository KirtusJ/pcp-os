"""Request scale two on the frozen #324 guest and examine actual, stable display frames."""
from pathlib import Path
import hashlib
import json
import runpy
import subprocess
import sys
import time
import numpy as np
from PIL import Image
from read import font, rows

here=Path(__file__).resolve().parent
runtime=here.parent
source=runtime/"third-check2"
size=sys.argv[1]
w,h=map(int,size.split("x"))
scale=2 if w>=1280 and h>=960 else 1
folder=here/size
folder.mkdir()
hash_bytes=lambda b:hashlib.sha256(b).hexdigest()
src_hash=subprocess.check_output(["git","-C",source,"rev-parse","HEAD"],text=True).strip()
build=runtime/"a3-release314/queue"
receipt=json.loads((build/"receipt.json").read_text())
assert receipt["source_commit"]==src_hash and not receipt["uncommitted_changes"]
cd=(build/"pcp-os-tester.iso").read_bytes()
assert hash_bytes(cd)==receipt["iso_sha256"]
files=runpy.run_path(str(source/"examples/tester-cd/build.py"))["read_back"](cd)
names=("kernel.elf32","rdesk.elf","surf.elf")
for name in names:
    (folder/name).write_bytes(files[name])
opt=runpy.run_path(str(source/"examples/optical-disk-check/check.py"))
checker=runpy.run_path(str(source/"examples/tester-cd/check_small_screens.py"))
font_table=font(source,scale)
serial=folder/"serial.txt"
def log():
    return serial.read_text(errors="replace") if serial.exists() else ""
cmd=[runtime/"bin/qemu-system-x86_64","-machine","pc","-accel","tcg","-m","128M","-cpu","qemu64","-nic","none","-vga","none","-device","VGA,vgamem_mb=64","-display","none","-qmp","stdio","-monitor","none","-serial","file:"+str(serial),"-no-reboot","-kernel",names[0],"-initrd",",".join(names[1:]),"-append",f"image={receipt['kernel_measurement']} desktop={size} ui_scale=2"]
r={"source":src_hash,"size":size,"scale_requested":2,"scale_expected":scale,"columns":w//(10*scale),"frames":{},"completed":False}
with (folder/"stderr.txt").open("wb") as err, subprocess.Popen(cmd,cwd=folder,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        mon=opt["Monitor"](vm)
        mon.call("qmp_capabilities")
        def press(*keys):
            mon.key(*keys)
            time.sleep(.32)
        def snap(label):
            path=folder/"latest.ppm"
            last=None
            for attempt in range(35):
                mon.call("screendump",filename=str(path))
                raw=path.read_bytes()
                if raw==last:
                    break
                last=raw
                time.sleep(.12)
            else:
                raise ValueError("unstable "+label)
            magic,shape,depth,body=raw.split(b"\n",3)
            assert (magic,shape,depth)==(b"P6",size.replace("x"," ").encode(),b"255") and len(body)==w*h*3
            digest=hash_bytes(body)
            pixels=np.frombuffer(body,dtype="u1").reshape(h,w,3)
            if not (folder/(digest+".png")).exists():
                Image.fromarray(pixels).save(folder/(digest+".png"),compress_level=2)
            r["frames"][label]=digest
            decoded=rows(pixels,font_table,scale)
            (folder/(label+".txt")).write_text("\n".join(decoded)+"\n")
            return digest,decoded
        opt["wait_for"](lambda:f"desktop: {size} at {scale}x UI scale" in log(),"selected mode",60)
        assert receipt["kernel_measurement"]+" (measured; equal" in log()
        time.sleep(.4)
        home,_=snap("home")
        for key in "drpvkf":
            press(key); assert snap("home-"+key)[0]==home
        press("spc");snap("programs");press("down")
        selected,listing=snap("selected")
        if scale==2: assert any("surf.elf" in row for row in listing),listing
        for key in "drpvkf":
            press(key); assert snap("programs-"+key)[0]==selected
        press("ctrl","d")
        _,view=snap("details-0")
        if r["columns"]<96:
            parts=[];previous=None
            for page in range(25):
                dig,page_rows=snap("details-"+str(page))
                if dig==previous: break
                assert "DETAILS" in [line.strip() for line in page_rows],page_rows
                assert any(line.strip().endswith("Esc back") for line in page_rows),page_rows
                piece=[s.strip() for s in page_rows[3:3+h//(20*scale)-6]]
                overlap=max((n for n in range(1,min(len(parts),len(piece))+1) if parts[-n:]==piece[:n]),default=0)
                if parts: assert overlap
                parts+=piece[overlap:]
                previous=dig
                if not any("Up/Down scroll" in line for line in page_rows): break
                press("down")
            facts={name:(f"{(len(files[name])+1023)//1024} KiB",hash_bytes(files[name])) for name in names[1:]}
            problems=checker["details_problems"](parts,facts)
            assert not problems,problems
            r["route"]="scrolling Details";r["verified_sections"]=list(checker["details_sections"](parts))
            (folder/"sections.txt").write_text("\n".join(parts)+"\n")
            press("esc")
        else:
            assert any("Register:" in row for row in view),view
            assert any("FILES FROM THE LOADER" in row for row in view),view
            press("r");assert any("REGISTER" in row for row in snap("plain-register")[1])
            press("esc");snap("plain-back");press("d")
            r["route"]="plain Details"
        assert snap("returned")[0]==selected
        press("f10"); _,question=snap("power");assert not checker["power_problems"](question),question
        press("esc");assert snap("cancelled")[0]==selected
        press("f10");time.sleep(.25);press("ret");r["exit"]=vm.wait(timeout=45)
        r["final_checks"]=sum(line.startswith("  pass ") for line in log().splitlines())
        assert r["exit"]==0 and r["final_checks"]==72 and "ALL SELF-TESTS PASS." in log()
        r["completed"]=True
    finally:
        if vm.poll() is None: vm.kill();vm.wait()
        (folder/"result.json").write_text(json.dumps(r,indent=2)+"\n")
print(size,scale,r["columns"],r["route"],r["final_checks"])

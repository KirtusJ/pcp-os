"""Run the frozen K1 and K2 predicates against recorded QEMU scanouts on each side of #324."""
import hashlib,json,runpy,sys
from pathlib import Path
root=Path(__file__).resolve().parent
source,base,current=(Path(p).resolve() for p in sys.argv[1:4])
tools=runpy.run_path(str(source/'examples/tester-cd/check_small_screens.py'))
glyphs=tools['CHECK']['kernel_glyphs']()
frames=json.loads((base/'result.json').read_text())['frames']
class SeriesEnd(Exception):
    pass
class FrameRejected(Exception):
    pass

def old_file(label):
    alias={'programs-alpha.elf':'programs-first','programs-bravo.elf':'programs-second','details-1':'details'}
    word=alias.get(label,label.replace('-letter-','-'))
    path=base/(frames[word]+'.ppm')
    assert hashlib.sha256(path.read_bytes()).hexdigest()==frames[word]
    return path

out={}
for name,pick in [('parent',old_file),('frozen',lambda label:current/(label+'.ppm'))]:
    problems=[]; invoked=[]
    def screen(label,predicate):
        if label=='settings-0':
            raise SeriesEnd
        ppm=pick(label).read_bytes()
        decoded=tools['PINS']['read'](ppm,glyphs)
        ok=bool(predicate(decoded,ppm))
        invoked.append((label,ok,hashlib.sha256(ppm).hexdigest()))
        if not ok:raise FrameRejected(label)
        return decoded,ppm
    try:
        tools['settings_trial'](lambda *args:None,screen,False,problems,{},'320x200')
    except SeriesEnd:pass
    assert len(invoked)==7
    details={}
    facts={}
    for program in tools['PROGRAMS']:
        file=(base/program) if name=='parent' else (current.parent/'boot'/program)
        data=file.read_bytes()
        facts[program]=(str((len(data)+1023)//1024)+' KiB',hashlib.sha256(data).hexdigest())
    rejected=None
    try:
        tools['list_trial'](lambda *args:None,screen,False,71,problems,details,'320x200',facts)
    except FrameRejected as exc:rejected=str(exc)
    k1=[p for p in problems if ' K1:' in p]
    assert [l for l,_,_ in invoked if l.startswith('programs-letter-')]==['programs-letter-'+k for k in tools['LETTERS']]
    if name=='parent':
        assert len(k1)==10 and rejected=='details-1', (problems,rejected)
        assert set(p.split('letter ')[1][0] for p in k1 if p.endswith('desktop'))==set('rpkvf')
        assert set(p.split('letter ')[1][0] for p in k1 if p.endswith('programs'))==set('drpkv')
    else:
        assert not problems and not rejected and details['details_pages']>1
    out[name]={'stock_K1_failures':k1,'other_stock_findings':list(p for p in problems if p not in k1),
               'K2_rejected_at':rejected,'K2_pages_accepted':details.get('details_pages'), 'invoked_frames':invoked}
print(json.dumps(out,indent=2))

"""Independently check the retained Queue Desk and desktop frames against their serial records."""
from pathlib import Path
import hashlib
import json
import re
import runpy
import sys

def check_case(folder, source):
    def sha(blob):
        return hashlib.sha256(blob).hexdigest()
    stock=runpy.run_path(str(source/'examples/tester-cd/check_small_screens.py'))
    controls=stock['CHECK']
    font=controls['kernel_glyphs']()
    r=json.loads((folder/'result.json').read_text())
    size=r['size']
    w,h=map(int,size.split('x'))
    photos=r['frames']
    rows={}
    for name,digest in photos.items():
        data=(folder/(digest+'.ppm')).read_bytes()
        assert sha(data)==digest
        magic,shape,depth,pix=data.split(b'\n',3)
        assert magic==b'P6' and depth==b'255'
        if name in ('app-saved','app-restored'):
            assert shape==b'800 480' and len(pix)==800*480*3
            controls['check_desk_label'](data,'opal')
        else:
            assert shape==f'{w} {h}'.encode() and len(pix)==w*h*3
            lines=stock['PINS']['read'](data,font)
            assert lines==(folder/(name+'.txt')).read_text().splitlines()
            rows[name]=lines
    assert photos['selected-pin']==photos['prelaunch-cancel']
    assert any('rdesk.elf' in line for line in rows['selected-pin'])
    if w>=1280:
        assert any('> rdesk.elf' in line for line in rows['programs-after-removal'])
    else:
        raw=(folder/(photos['programs-after-removal']+'.ppm')).read_bytes()
        chosen=stock['chosen_rows'](raw)
        assert len(chosen)==1 and rows['programs-after-removal'][chosen[0]][3:]=='rdesk.elf'
    reader=lambda key:' '.join(' '.join(rows[key]).split())
    assert 'No program has written a file.' in reader('files-empty')
    assert re.search(r'\bparrots\.queue +3 KiB\b',reader('files-saved'))
    assert 'parrots.queue' not in reader('files-empty')
    assert 'No program has written a file.' not in reader('files-saved')
    assert all('Switch PCP OS off?' in reader(k) for k in ('prelaunch-power','final-power'))
    assert rows['pin-after-save']!=rows['selected-pin']
    actual_counts=[int(re.search(r'Register: (\d+) events, head',reader(name))[1]) for name in ('register-initial','register-after-save','register-after-finish')]
    assert actual_counts==r['register_counts']==[43,46,49]
    activities=[line for line in rows['pin-removed'] if re.search(r'\b\d{2}:\d{2}:\d{2}\s+DONE\s+rdesk\.elf\b',line)]
    if (w,h)==(320,200):assert '2 widget line(s) not shown' in reader('pin-removed') and not activities
    else:assert len(activities)==2
    log=(folder/'serial.txt').read_text()
    assert f'desktop: {size} at 1x UI scale' in log and r['measurement']+' (measured; equal to the value the loader named)' in log
    markers=['state=NONE store=New queue','state=ACTIVE store=Session save','rdesk.elf ended DONE: exit 0','state=ACTIVE store=Queue restored','state=FINISHED store=Session save','rdesk.elf ended DONE: exit 0']
    at=0
    for expected in markers:
        at=log.index(expected,at)+len(expected)
    assert log.count('rdesk.elf ended DONE: exit 0')==2
    assert 'the store holds 1 file(s), 2064 bytes' in log
    assert re.search(r'kernel register: 51 events, head [0-9a-f]{64}',log)
    assert r['passed'] and r['exit_code']==0 and r['checks']==72 and sum(s.startswith('  pass ') for s in log.splitlines())==72 and 'ALL SELF-TESTS PASS.' in log
    return {'register':actual_counts+[51],'queue_file_bytes':2064,'activity_rows_visible':len(activities),'widget_rows_reported_hidden':2 if not activities else 0,'native_checks':72,'pixel_verified_label':'opal'}

if __name__=='__main__':
    source,base=map(lambda x:Path(x).resolve(),sys.argv[1:])
    cases={f.parent.name:check_case(f.parent,source) for f in sorted(base.glob('*x*/result.json'))}
    assert len(cases)==6
    print(json.dumps(cases,indent=2))

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,sys
here=Path(__file__).resolve().parent
def run(size):
    cmd=[here.parent/'desk-build/release/pcp-delegate',here/'tasks.redb','pin-'+size,'Launch and return from a real Queue Desk pin at '+size,'--',sys.executable,'-IB',here/'probe.py',size]
    with (here/(size+'.log')).open('w') as log:
        code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
    print(size,code,flush=True)
    return code
with ThreadPoolExecutor(max_workers=2) as pool:
    results=list(pool.map(run,sys.argv[1:]))
sys.exit(any(results))

"""Exercise the compact and graphical Home with a real pin, saved file and application return."""
import hashlib
import json
from pathlib import Path
import re
import runpy
import subprocess
import sys
import time

here=Path(__file__).resolve().parent
rt=here.parent
size=sys.argv[1]
w,h=map(int,size.split('x'))
out=here/size
out.mkdir()
src=rt/'third-check2'
kit=rt/'a3-release314/queue'
receipt=json.loads((kit/'receipt.json').read_text())
sha=lambda blob:hashlib.sha256(blob).hexdigest()
image=(kit/'pcp-os-tester.iso').read_bytes()
assert sha(image)==receipt['iso_sha256'] and not receipt['uncommitted_changes']
assert receipt['source_commit']==subprocess.check_output(['git','-C',src,'rev-parse','HEAD'],text=True).strip()
check=runpy.run_path(str(src/'examples/tester-cd/check.py'))
stock=runpy.run_path(str(src/'examples/tester-cd/check_small_screens.py'))
opt=runpy.run_path(str(src/'examples/optical-disk-check/check.py'))
font=check['kernel_glyphs']()
files=runpy.run_path(str(src/'examples/tester-cd/build.py'))['read_back'](image)
for name in ['kernel.elf32','surf.elf','rdesk.elf']:
    (out/name).write_bytes(files[name])
serial=out/'serial.txt'
def log():
    return serial.read_text(errors='replace') if serial.exists() else ''
def await_log(needle,n=1):
    opt['wait_for'](lambda:log().count(needle)>=n,needle,50)
measure=receipt['kernel_measurement']
cmd=[rt/'bin/qemu-system-x86_64','-machine','pc','-accel','tcg','-cpu','qemu64','-m','128M','-vga','none','-device','VGA,vgamem_mb=64','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-no-reboot','-kernel','kernel.elf32','-initrd','surf.elf,rdesk.elf','-append',f'image={measure} desktop={size}']
r=dict(size=size,source=receipt['source_commit'],measurement=measure,iso_sha256=sha(image),frames={},keys=[],passed=False)
with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        mon=opt['Monitor'](vm)
        mon.call('qmp_capabilities')
        def key(*keys):
            mon.key(*keys)
            r['keys'].append(list(keys))
            time.sleep(.34)
        def capture(name,app=False):
            path=out/'current.ppm'
            last=None
            for _ in range(40):
                mon.call('screendump',filename=str(path))
                data=path.read_bytes()
                if data==last:break
                last=data;time.sleep(.18)
            else:raise ValueError('unsettled '+name)
            sw,sh=(800,480) if app else (w,h)
            magic,sz,depth,pixels=data.split(b'\n',3)
            assert (magic,sz,depth,len(pixels))==(b'P6',f'{sw} {sh}'.encode(),b'255',3*sw*sh),(name,sz)
            digest=sha(data); dst=out/(digest+'.ppm')
            if dst.exists():path.unlink()
            else:path.rename(dst)
            r['frames'][name]=digest
            if app:check['check_desk_label'](data,'opal');return []
            lines=stock['PINS']['read'](data,font)
            (out/(name+'.txt')).write_text('\n'.join(lines)+'\n')
            return lines
        def contains(lines,text):
            return any(text in row for row in lines)
        def events(label):
            key('f5')
            lines=capture(label)
            m=re.search(r'Register: (\d+) events, head',' '.join(' '.join(lines).split()))
            assert m,label
            key('esc')
            return int(m[1])
        await_log('desktop: '+size+' at 1x UI scale')
        assert measure+' (measured; equal' in log()
        before=events('register-initial')
        key('f2')
        key('down');key('down');key('ret');key('esc')
        key('f3');empty=capture('files-empty')
        assert contains(empty,'No program has written a file.'),empty
        key('esc');key('spc');key('down')
        choice=capture('programs-second')
        assert contains(choice,'rdesk.elf')
        key('ctrl','p');key('esc')
        key('right' if w>=1280 and h>=720 else 'down')
        pin=capture('selected-pin')
        assert contains(pin,'rdesk.elf'),pin
        key('f10');assert contains(capture('prelaunch-power'),'POWER OFF')
        key('esc');capture('prelaunch-cancel')
        assert r['frames']['prelaunch-cancel']==r['frames']['selected-pin']
        key('ret');await_log('state=NONE store=New queue')
        for k in ['n','o','p','a','l','ret']:key(k)
        await_log('state=ACTIVE store=Session save');capture('app-saved',True)
        key('esc');await_log('rdesk.elf ended DONE: exit 0')
        post=capture('pin-after-save')
        key('f3');written=capture('files-saved');assert contains(written,'parrots.queue'),written
        key('esc')
        middle=events('register-after-save')
        key('ret');await_log('state=ACTIVE store=Queue restored');capture('app-restored',True)
        key('f');await_log('state=FINISHED store=Session save')
        key('esc');await_log('rdesk.elf ended DONE: exit 0',2)
        post=capture('pin-after-finish')
        after=events('register-after-finish')
        assert before<middle<after
        r['register_counts']=[before,middle,after]
        key('delete')
        removed=capture('pin-removed')
        if w>=1280 or h>=480:
            assert sum(bool(re.search(r'\bDONE\s+rdesk\.elf',line)) for line in removed)==2,removed
        else:
            assert contains(removed,'widget line(s) not shown'),removed
        key('ret')
        actual=capture('programs-after-removal')
        if w>=1280:
            assert contains(actual,'> rdesk.elf')
        else:
            raw=(out/(r['frames']['programs-after-removal']+'.ppm')).read_bytes()
            chosen=stock['chosen_rows'](raw)
            assert len(chosen)==1 and actual[chosen[0]][3:]=='rdesk.elf'
        assert log().count('rdesk.elf ended DONE: exit 0')==2
        key('esc');key('f10');capture('final-power');key('ret')
        r['exit_code']=vm.wait(timeout=30)
        assert r['exit_code']==0 and 'ALL SELF-TESTS PASS.' in log()
        r['checks']=sum(l.startswith('  pass ') for l in log().splitlines())
        assert r['checks']==72
        r['passed']=True
    finally:
        if vm.poll() is None:vm.kill();vm.wait()
        (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(size,r['register_counts'],r['checks'])

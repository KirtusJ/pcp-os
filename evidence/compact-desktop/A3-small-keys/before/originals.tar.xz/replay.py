"""Verify each archived scanout and reconstruct observed routes from matching full frames."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import runpy


def replay(src, data):
    checks=runpy.run_path(str(src/'examples/tester-cd/check_small_screens.py'))
    fonts=checks['CHECK']['kernel_glyphs']()
    results={}
    for folder in sorted(p for p in data.iterdir() if p.is_dir() and (p/'result.json').exists()):
        r=json.loads((folder/'result.json').read_text())
        size=r['size']
        w,h=map(int,size.split('x'))
        assert folder.name==size and r['passed'] and r['exit_code']==0
        graphic=w>=1280 and h>=720
        compact_legacy=not graphic and r['policy']=='legacy'
        frames=r['frames']
        for digest in set(frames.values()):
            frame=(folder/(digest+'.ppm')).read_bytes()
            magic,dimensions,maximum,pixels=frame.split(b'\n',3)
            assert magic==b'P6' and dimensions==f'{w} {h}'.encode() and maximum==b'255'
            assert len(pixels)==w*h*3 and hashlib.sha256(frame).hexdigest()==digest
        def lines(name):
            return checks['PINS']['read']((folder/(frames[name]+'.ppm')).read_bytes(),fonts)
        for view,title in [('home-help','KEYS ON THE DESKTOP'),('programs-help','KEYS IN THE PROGRAMS'),('files','FILES'),('register','REGISTER'),('verification','VERIFICATION'),('power','POWER OFF'),('details','PCP OS')]:
            assert any(title in row for row in lines(view)),(size,view)
        for phase,char_index in [('programs-first',0),('programs-second',1)]:
            rows=lines(phase)
            name=('alpha.elf','bravo.elf')[char_index]
            if graphic:
                assert any('> '+name in row for row in rows),(size,phase)
            else:
                frame=(folder/(frames[phase]+'.ppm')).read_bytes()
                chosen=checks['chosen_rows'](frame)
                assert len(chosen)==1 and rows[chosen[0]][3:]==name
        assert frames['programs-first']!=frames['programs-second']
        results[size]={}
        for surface,stay,help_view in [('home','home','home-help'),('programs','programs-second','programs-help')]:
            refs=dict(k=help_view,f='files' if surface=='home' else stay,r='register',v='verification',p='power',d='details' if surface=='programs' else stay)
            actual={}
            alternatives={frames[name]:name for name in set(refs.values())|{stay}}
            assert len(alternatives)==len(set(refs.values())|{stay})
            for key,name in refs.items():
                target=alternatives[frames[surface+'-'+key]]
                assert target==(name if compact_legacy else stay),(size,surface,key,target)
                actual[key]=target if target!=stay else 'unchanged'
                if target!=stay: assert frames[surface+'-'+key+'-back']==frames[stay]
            results[size][surface]=actual
        assert frames['details-r']==frames['register'] and frames['details-p']==frames['power']
        assert frames['details-r-back']==frames['details-p-back']==frames['details']
        assert frames['details-returned-to-choice']==frames['programs-cancelled-power']==frames['programs-second']
        serial=(folder/'serial.txt').read_text()
        assert f'desktop: {size} at 1x UI scale' in serial and r['measurement']+' (measured; equal' in serial
        assert sum(s.startswith('  pass ') for s in serial.splitlines())==72 and 'ALL SELF-TESTS PASS.' in serial
        assert not re.search(r'starting (alpha|bravo)\.elf',serial)
        results[size]['selection_after_details_and_cancel']='bravo.elf'
    assert len(results)==6
    return results

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path)
    parser.add_argument('data',type=Path)
    args=parser.parse_args()
    print(json.dumps(replay(args.source.resolve(),args.data.resolve()),indent=2))

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import sys
here=Path(__file__).resolve().parent
rt=here.parent
def check(size):
    args=[rt/'desk-build/release/pcp-delegate',here/'tasks.redb','letters-'+size,'Test letter routes and selected program at '+size,'--',sys.executable,'-IB',here/'probe.py',rt/'second-target',rt/'register-live/tester-target',rt/'bin/qemu-system-x86_64',here/size,size,'legacy']
    with (here/(size+'.log')).open('w') as log:
        code=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT).returncode
    print(size,code,flush=True)
    return code
with ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(check,sys.argv[1:]))
sys.exit(any(results))

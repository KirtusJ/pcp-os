"""Check every retained native capture and reconstruct which screen each tested letter reached."""
import hashlib,json,re,runpy,sys
from pathlib import Path

def inspect_run(root, source):
    check=runpy.run_path(str(source/'examples/tester-cd/check_small_screens.py'))
    font=check['CHECK']['kernel_glyphs']()
    summary={}
    for d in sorted(root.iterdir()):
        if not (d/'result.json').exists():continue
        record=json.loads((d/'result.json').read_text())
        m=record['size']
        w,h=map(int,m.split('x'))
        policy=record['policy']
        assert record['passed'] and record['exit_code']==0 and record['passed_checks']==72
        log=(d/'serial.txt').read_text()
        assert f'desktop: {m} at 1x UI scale' in log and record['measurement']+' (measured; equal' in log
        assert sum(l.startswith('  pass ') for l in log.splitlines())==72 and 'ALL SELF-TESTS PASS.' in log
        assert not re.search(r'starting (alpha|bravo)\.elf',log)
        f=record['frames']
        for digest in set(f.values()):
            pic=(d/(digest+'.ppm')).read_bytes()
            magic,size,depth,body=pic.split(b'\n',3)
            assert magic==b'P6' and size==f'{w} {h}'.encode() and depth==b'255' and len(body)==w*h*3 and hashlib.sha256(pic).hexdigest()==digest
        def rows(digest):
            return check['PINS']['read']((d/(digest+'.ppm')).read_bytes(),font)
        if policy=='widget':
            expected='Files last until power-off' if w==320 else 'Session files | cleared at power-off'
            assert sum(r.strip()==expected for r in rows(f['home-with-session-widget']))==1
            assert not any(expected in r for r in rows(f['home-before-widget']))
            summary[d.name]={'widget':expected}
            continue
        if policy=='plain':
            for field,label in [('plain-entry','PCP OS'),('plain-register','REGISTER'),('plain-power','POWER OFF'),('plain-to-launcher','alpha.elf')]:
                assert any(label in r for r in rows(f[field]))
            assert f['plain-entry']==f['back-from-register']==f['back-from-power']
            summary[d.name]={'boot':'first=details','routes':['R register','P confirmation','D programs']}
            continue
        for surface,before in [('home','home'),('programs','programs-second')]:
            assert all(f[surface+'-'+letter]==f[before] for letter in 'kfrvpd')
        for view,title in [('home-help','KEYS ON THE DESKTOP'),('programs-help','KEYS IN THE PROGRAMS'),('files','FILES'),('register','REGISTER'),('verification','VERIFICATION'),('power','POWER OFF')]:
            assert any(title in row for row in rows(f[view]))
        bravo=rows(f['programs-second'])
        if w>=1280 and h>=720:assert any('> bravo.elf' in r for r in bravo)
        else:
            selected=check['chosen_rows']((d/(f['programs-second']+'.ppm')).read_bytes())
            assert len(selected)==1 and bravo[selected[0]][3:]=='bravo.elf'
            foot=' '.join(' '.join(' '.join(bravo[-3:]).split()).split())
            assert 'Esc back F1 keys F10 off' in foot
        assert f['programs-first']!=f['programs-second']==f['programs-cancelled-power']==f['details-returned-to-choice']
        details='plain'
        if w//10 < 96:
            details='text'
            assert f['details']==f['compact-details-r']==f['compact-details-p']==f['compact-details-d']
            body=[]
            for digest in record['details_pages']:
                page=rows(digest)
                assert any(r.strip()=='DETAILS' for r in page)
                assert any(r.strip().endswith('Esc back') for r in page)
                top,capacity=(3,h//20-6) if h//20>=14 else (1,h//20-2)
                visible=page[top:top+capacity]
                overlap=max((n for n in range(1,min(len(body),len(visible))+1) if body[-n:]==visible[:n]),default=0)
                assert not body or overlap
                body+=visible[overlap:]
            assert body==record['details_text']
            joined=''.join(l.strip() for l in body)
            predicates=joined.split('PROGRAMS')[1].split('FILES FROM THE LOADER')
            assert len(predicates)==2
            programs,remaining=predicates
            files,machine=remaining.split('MACHINE')
            assert 'keyboard: PS/2' in machine
            facts=record['facts']
            long=next(k for k in facts if k.endswith('.txt'))
            assert len(set(facts.values()))==3
            for name,digest in facts.items():
                assert hashlib.sha256((root.parent/'fixtures'/name).read_bytes()).hexdigest()==digest
            def check_section(section,names):
                at=0
                for name in names:
                    count=((root.parent/'fixtures'/name).stat().st_size+1023)//1024
                    pattern=name+f'{count} KiBSHA-256'+facts[name]
                    found=section.find(pattern,at)
                    if found<0:return False
                    at=found+len(pattern)
                return True
            assert check_section(programs,['alpha.elf','bravo.elf']) and check_section(files,['alpha.elf','bravo.elf',long])
            # Distinguish a correct field from the same valid digest belonging to the other row.
            assert not check_section(programs.replace(facts['bravo.elf'],facts['alpha.elf']),['alpha.elf','bravo.elf'])
            assert not check_section(files.replace(facts[long],facts[long][:-1]),['alpha.elf','bravo.elf',long])
        else:
            assert f['details-r']==f['register'] and f['details-p']==f['power']
            assert f['details-r-back']==f['details-p-back']==f['details']
        summary[d.name]={'bare_keys_each_surface':'K F R V P D','after_details_and_power_cancel':'bravo.elf','details':details,'detail_pages':len(record.get('details_pages',[]))}
    return summary
if __name__=='__main__':
    source,path=(Path(p).resolve() for p in sys.argv[1:])
    print(json.dumps(inspect_run(path,source),indent=2))

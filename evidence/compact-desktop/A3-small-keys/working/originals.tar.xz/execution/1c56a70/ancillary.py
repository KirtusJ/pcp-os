"""Characterize Home, Programs and Details keyboard routes and the selected item on return."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import time


def sha(data):
    return hashlib.sha256(data).hexdigest()


def execute(args):
    src, build, out = (p.resolve() for p in (args.source, args.build, args.out))
    out.mkdir(parents=True)
    receipt = json.loads((build/'receipt.json').read_text())
    commit = subprocess.check_output(['git','-C',src,'rev-parse','HEAD'],text=True).strip()
    assert not receipt['uncommitted_changes'] and receipt['source_commit'] == commit
    image = (build/'pcp-os-tester.iso').read_bytes()
    assert sha(image) == receipt['iso_sha256']
    files = runpy.run_path(str(src/'examples/tester-cd/build.py'))['read_back'](image)
    for local, member in [('kernel.elf32','kernel.elf32'), ('alpha.elf','surf.elf'), ('bravo.elf','surf.elf')]:
        (out/local).write_bytes(files[member])
    opt = runpy.run_path(str(src/'examples/optical-disk-check/check.py'))
    stock = runpy.run_path(str(src/'examples/tester-cd/check_small_screens.py'))
    glyphs = stock['CHECK']['kernel_glyphs']()
    w,h = map(int,args.size.split('x'))
    graphic = w >= 1280 and h >= 720
    legacy = not graphic and args.policy == 'legacy'
    long_file = 'loader-note-that-wraps-onto-a-second-display-line.txt'
    (out/long_file).write_bytes(b'PCP desktop file identity control.\n')
    (out/'bravo.elf').write_bytes(args.second.read_bytes())
    facts = {name:sha((out/name).read_bytes()) for name in ['alpha.elf','bravo.elf',long_file]}
    assert len(set(facts.values()))==3
    measurement = receipt['kernel_measurement']
    serial = out/'serial.txt'
    cmd = [str(args.qemu.resolve()),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','128M','-vga','none','-device','VGA,vgamem_mb=64','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel','kernel.elf32','-initrd','alpha.elf,bravo.elf,'+long_file,'-append',f'image={measurement} desktop={args.size}'+(' first=details' if args.policy=='plain' else ''),'-no-reboot']
    result = dict(facts=facts,size=args.size,policy=args.policy,source=commit,measurement=measurement,iso_sha256=sha(image),frames={},actions={},passed=False)
    frames = result['frames']
    with (out/'stderr.txt').open('wb') as err, subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
        try:
            mon = opt['Monitor'](vm)
            mon.call('qmp_capabilities')
            def press(*keys):
                mon.key(*keys)
                time.sleep(.65)
            def take(label):
                tmp = out/'screen.ppm'
                old = None
                for i in range(24):
                    mon.call('screendump',filename=str(tmp))
                    data = tmp.read_bytes()
                    assert data.startswith(f'P6\n{w} {h}\n255\n'.encode())
                    if data==old: break
                    old=data
                    time.sleep(.15)
                else: raise RuntimeError(label+' did not settle')
                digest=sha(data)
                path=out/(digest+'.ppm')
                if not path.exists(): tmp.rename(path)
                else: tmp.unlink()
                frames[label]=digest
                return digest
            def read(digest):
                return stock['PINS']['read']((out/(digest+'.ppm')).read_bytes(),glyphs)
            def exercise(surface, reference, bindings):
                for key, expectation in bindings.items():
                    press(key)
                    got = take(surface+'-'+key)
                    result['actions'].setdefault(surface,{})[key] = expectation
                    assert got==frames[expectation], (surface,key,expectation,got,frames[expectation])
                    if got!=reference:
                        press('d' if expectation=='details' else 'esc')
                        assert take(surface+'-'+key+'-back')==reference,(surface,key,'return')
            opt['wait_for'](lambda:serial.exists() and f'desktop: {args.size}' in serial.read_text(errors='replace'),'native desktop',60)
            assert measurement+' (measured; equal' in serial.read_text()
            time.sleep(.6)
            if args.policy=='plain':
                details=take('plain-entry')
                assert any('PCP OS' in line for line in read(details))
                press('r'); reg=take('plain-register')
                assert any('REGISTER' in line for line in read(reg))
                press('esc'); assert take('back-from-register')==details
                press('p'); power=take('plain-power')
                assert any('POWER OFF' in line for line in read(power))
                press('esc'); assert take('back-from-power')==details
                press('d'); launcher=take('plain-to-launcher')
                assert launcher!=details and any('alpha.elf' in row for row in read(launcher))
            else:
                original=take('home-before-widget')
                press('f2')
                for _ in range(4):press('down')
                press('ret'); press('esc')
                short='Files last until power-off'
                long='Session files | cleared at power-off'
                expected=short if w//10-4<len(long) else long
                active=take('home-with-session-widget')
                actual=read(active)
                assert len([line for line in actual if line.strip()==expected])==1,(args.size,actual)
                result['widget_text']=expected
                assert active!=original and expected not in '\n'.join(read(original))
            press('f10')
            press('ret')
            result['exit_code']=vm.wait(timeout=30)
            log=serial.read_text(errors='replace')
            result['passed_checks']=sum(s.startswith('  pass ') for s in log.splitlines())
            assert 'ALL SELF-TESTS PASS.' in log and result['passed_checks']==72 and result['exit_code']==0
            assert not any('starting '+name in log for name in ('alpha.elf','bravo.elf'))
            result['passed']=True
        finally:
            if vm.poll() is None: vm.kill(); vm.wait()
            (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('source','build','qemu','out'): parser.add_argument(name,type=Path)
    parser.add_argument('size')
    parser.add_argument('policy',choices=('widget','plain'))
    parser.add_argument('second',type=Path)
    execute(parser.parse_args())

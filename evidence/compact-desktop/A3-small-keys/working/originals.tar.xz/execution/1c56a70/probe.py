"""Characterize Home, Programs and Details keyboard routes and the selected item on return."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import time


def sha(data):
    return hashlib.sha256(data).hexdigest()


def execute(args):
    src, build, out = (p.resolve() for p in (args.source, args.build, args.out))
    out.mkdir(parents=True)
    receipt = json.loads((build/'receipt.json').read_text())
    commit = subprocess.check_output(['git','-C',src,'rev-parse','HEAD'],text=True).strip()
    assert not receipt['uncommitted_changes'] and receipt['source_commit'] == commit
    image = (build/'pcp-os-tester.iso').read_bytes()
    assert sha(image) == receipt['iso_sha256']
    files = runpy.run_path(str(src/'examples/tester-cd/build.py'))['read_back'](image)
    for local, member in [('kernel.elf32','kernel.elf32'), ('alpha.elf','surf.elf'), ('bravo.elf','surf.elf')]:
        (out/local).write_bytes(files[member])
    opt = runpy.run_path(str(src/'examples/optical-disk-check/check.py'))
    stock = runpy.run_path(str(src/'examples/tester-cd/check_small_screens.py'))
    glyphs = stock['CHECK']['kernel_glyphs']()
    w,h = map(int,args.size.split('x'))
    graphic = w >= 1280 and h >= 720
    legacy = not graphic and args.policy == 'legacy'
    long_file = 'loader-note-that-wraps-onto-a-second-display-line.txt'
    (out/long_file).write_bytes(b'PCP desktop file identity control.\n')
    (out/'bravo.elf').write_bytes(args.second.read_bytes())
    facts = {name:sha((out/name).read_bytes()) for name in ['alpha.elf','bravo.elf',long_file]}
    assert len(set(facts.values()))==3
    measurement = receipt['kernel_measurement']
    serial = out/'serial.txt'
    cmd = [str(args.qemu.resolve()),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','128M','-vga','none','-device','VGA,vgamem_mb=64','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel','kernel.elf32','-initrd','alpha.elf,bravo.elf,'+long_file,'-append',f'image={measurement} desktop={args.size}','-no-reboot']
    result = dict(facts=facts,size=args.size,policy=args.policy,source=commit,measurement=measurement,iso_sha256=sha(image),frames={},actions={},passed=False)
    frames = result['frames']
    with (out/'stderr.txt').open('wb') as err, subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
        try:
            mon = opt['Monitor'](vm)
            mon.call('qmp_capabilities')
            def press(*keys):
                mon.key(*keys)
                time.sleep(.65)
            def take(label):
                tmp = out/'screen.ppm'
                old = None
                for i in range(24):
                    mon.call('screendump',filename=str(tmp))
                    data = tmp.read_bytes()
                    assert data.startswith(f'P6\n{w} {h}\n255\n'.encode())
                    if data==old: break
                    old=data
                    time.sleep(.15)
                else: raise RuntimeError(label+' did not settle')
                digest=sha(data)
                path=out/(digest+'.ppm')
                if not path.exists(): tmp.rename(path)
                else: tmp.unlink()
                frames[label]=digest
                return digest
            def read(digest):
                return stock['PINS']['read']((out/(digest+'.ppm')).read_bytes(),glyphs)
            def exercise(surface, reference, bindings):
                for key, expectation in bindings.items():
                    press(key)
                    got = take(surface+'-'+key)
                    result['actions'].setdefault(surface,{})[key] = expectation
                    assert got==frames[expectation], (surface,key,expectation,got,frames[expectation])
                    if got!=reference:
                        press('d' if expectation=='details' else 'esc')
                        assert take(surface+'-'+key+'-back')==reference,(surface,key,'return')
            opt['wait_for'](lambda:serial.exists() and f'desktop: {args.size}' in serial.read_text(errors='replace'),'native desktop',60)
            assert measurement+' (measured; equal' in serial.read_text()
            time.sleep(.6)
            home=take('home')
            assert any('Programs' in r for r in read(home))
            for key,name,marker in [('f1','home-help','KEYS ON THE DESKTOP'),('f3','files','FILES'),('f4','register','REGISTER'),('f5','verification','VERIFICATION'),('f10','power','POWER OFF')]:
                press(key)
                view=take(name)
                assert view!=home and any(marker in r for r in read(view)), (key,marker)
                press('esc')
                assert take(name+'-back')==home
            home_routes = {'k':'home-help','f':'files','r':'register','v':'verification','p':'power','d':'home'}
            exercise('home',home,{k:(route if legacy else 'home') for k,route in home_routes.items()})
            press('spc')
            first=take('programs-first')
            press('down')
            selected=take('programs-second')
            assert selected!=first
            rows=read(selected)
            if graphic: assert any('> bravo.elf' in r for r in rows),rows
            else:
                original=(out/(selected+'.ppm')).read_bytes()
                lit=stock['chosen_rows'](original)
                assert len(lit)==1 and rows[lit[0]][3:]=='bravo.elf',rows
            press('f1')
            help_page=take('programs-help')
            assert any('KEYS IN THE PROGRAMS' in r for r in read(help_page))
            press('esc')
            assert take('programs-help-back')==selected
            press('ctrl','d')
            details=take('details')
            if w//10 < 96:
                assert details!=selected and any(row.strip()=='DETAILS' for row in read(details))
                pages=[details]
                for key in ('r','p','d'):
                    press(key)
                    assert take('compact-details-'+key)==details
                for n in range(100):
                    press('down')
                    got=take('read-details-'+str(n))
                    if got==pages[-1]:break
                    pages.append(got)
                else: raise ValueError('Details did not reach its last page')
                result['details_pages']=pages
                body=[]
                for page in pages:
                    lines=read(page)
                    assert any(row.strip().endswith('Esc back') for row in lines)
                    first_row,body_rows=(3,h//20-6) if h//20>=14 else (1,h//20-2)
                    part=lines[first_row:first_row+body_rows]
                    overlap=0
                    if body:
                        overlap=max((i for i in range(1,min(len(body),len(part))+1) if body[-i:]==part[:i]),default=0)
                        assert overlap,(args.size,'no overlap')
                    body+=part[overlap:]
                result['details_text']=body
                combined=''.join(line.strip() for line in body)
                progs,remaining=combined.split('FILES FROM THE LOADER',1)
                loader,machine=remaining.split('MACHINE',1)
                progs=progs.split('PROGRAMS',1)[1]
                assert progs.index('alpha.elf')<progs.index('bravo.elf') and 'keyboard: PS/2' in machine
                assert loader.index('alpha.elf')<loader.index('bravo.elf')<loader.index(long_file)
                for section,names in ((progs,['alpha.elf','bravo.elf']),(loader,['alpha.elf','bravo.elf',long_file])):
                    for name in names:
                        chunks=section.split(name)
                        expected_kib=((out/name).stat().st_size+1023)//1024
                        assert len(chunks)==2 and chunks[1].startswith(f'{expected_kib} KiBSHA-256'+facts[name]),(args.size,name,section)
                press('esc')
            else:
                assert details!=selected and any('PCP OS' in r for r in read(details))
                for key,dest in [('r','register'),('p','power')]:
                    press(key)
                    assert take('details-'+key)==frames[dest]
                    press('esc')
                    assert take('details-'+key+'-back')==details
                press('d')
            assert take('details-returned-to-choice')==selected
            prog_routes = {'k':'programs-help','f':'programs-second','r':'register','v':'verification','p':'power','d':'details'}
            exercise('programs',selected,{k:(route if legacy else 'programs-second') for k,route in prog_routes.items()})
            press('f10')
            assert take('programs-f10')==frames['power']
            press('esc')
            assert take('programs-cancelled-power')==selected
            press('f10')
            press('ret')
            result['exit_code']=vm.wait(timeout=30)
            log=serial.read_text(errors='replace')
            result['passed_checks']=sum(s.startswith('  pass ') for s in log.splitlines())
            assert 'ALL SELF-TESTS PASS.' in log and result['passed_checks']==72 and result['exit_code']==0
            assert not any('starting '+name in log for name in ('alpha.elf','bravo.elf'))
            result['passed']=True
        finally:
            if vm.poll() is None: vm.kill(); vm.wait()
            (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('source','build','qemu','out'): parser.add_argument(name,type=Path)
    parser.add_argument('size')
    parser.add_argument('policy',choices=('uniform',))
    parser.add_argument('second',type=Path)
    execute(parser.parse_args())

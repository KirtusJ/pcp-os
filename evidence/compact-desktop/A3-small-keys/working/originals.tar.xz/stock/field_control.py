"""Run the unchanged stock list_trial on original pixels and on per-program digest erasures."""
from pathlib import Path
import hashlib
import json
import re
import runpy
import sys

src, raw, report = (Path(p).resolve() for p in sys.argv[1:4])
stock=runpy.run_path(str(src/'examples/tester-cd/check_small_screens.py'))
font=stock['CHECK']['kernel_glyphs']()
read=stock['PINS']['read']
mode='320x200'
w,h=320,200
digest=hashlib.sha256((raw.parent/'boot/alpha.elf').read_bytes()).hexdigest()
assert digest==hashlib.sha256((raw.parent/'boot/bravo.elf').read_bytes()).hexdigest()
def rows(data):
    return read(data,font)
originals={p.stem:p.read_bytes() for p in raw.glob('*.ppm') if p.name.startswith(('details','programs-'))}
pages=sorted((n for n in originals if re.fullmatch(r'details-[0-9]+',n)),key=lambda n:int(n.split('-')[-1]))
assert len(pages)>3
merged=[]
offsets={}
for label in pages:
    part=rows(originals[label])[1:9]
    overlap=max((n for n in range(1,min(len(merged),len(part))+1) if merged[-n:]==part[:n]),default=0)
    if merged:assert overlap
    offsets[label]=len(merged)-overlap
    merged+=part[overlap:]
targets={}
for app in ('alpha.elf','bravo.elf'):
    indices=[n for n,r in enumerate(merged) if r.strip()==app]
    assert len(indices)==2
    both=[]
    for index in indices:
        field=next(n for n in range(index+1,len(merged)) if merged[n].strip()=='SHA-256')+1
        positions=[]
        while field<len(merged) and re.fullmatch('[a-f0-9]+',merged[field].strip()):
            positions.append(field)
            field+=1
        assert ''.join(merged[n].strip() for n in positions)==digest
        both.extend(positions)
    targets[app]=both

def judge(field_names):
    altered={}
    positions=set().union(*(set(targets[app]) for app in field_names))
    changes=[]
    for name in pages:
        source=originals[name]
        mag,dims,depth,raster=source.split(b'\n',3)
        assert (mag,dims,depth,len(raster))==(b'P6',b'320 200',b'255',w*h*3)
        pixels=bytearray(raster)
        before=rows(source)
        expected=list(before)
        for i in range(8):
            if offsets[name]+i not in positions:continue
            y=i+1
            assert re.fullmatch('[a-f0-9]+',before[y].strip())
            limit=len(before[y])*10
            x0=(len(before[y])-len(before[y].lstrip()))*10
            for scanline in range(y*20,(y+1)*20):
                start=3*(scanline*w)
                ground=raster[start:start+3]
                pixels[start+3*x0:start+3*limit]=ground*(limit-x0)
            changes.append([name,y,before[y].strip()])
            expected[y]=''
        edited=b'\n'.join([mag,dims,depth,bytes(pixels)])
        assert rows(edited)==expected
        altered[name]=edited
    def screen(name,accept):
        data=altered.get(name,originals[name])
        actual=rows(data)
        assert accept(actual,data),name
        return actual,data
    results={}
    problems=[]
    stock['list_trial'](lambda *keys:None,screen,False,71,problems,results,mode,digest)
    return {'checker_accepted':not problems,'problems':problems,'erased_rows':changes,'pages_seen':results['details_pages']}

cases={'original':judge([]),'alpha_only_erased':judge(['alpha.elf']),'bravo_only_erased':judge(['bravo.elf']),'both_erased':judge(['alpha.elf','bravo.elf'])}
assert cases['original']['checker_accepted'] and cases['alpha_only_erased']['checker_accepted'] and cases['bravo_only_erased']['checker_accepted'] and not cases['both_erased']['checker_accepted']
assert cases['both_erased']['problems'] and all('K2:' in p for p in cases['both_erased']['problems'])
report.write_text(json.dumps({'digest':digest,'pages':pages,'cases':cases},indent=2)+'\n')
print({k:(r['checker_accepted'],len(r['erased_rows'])) for k,r in cases.items()})

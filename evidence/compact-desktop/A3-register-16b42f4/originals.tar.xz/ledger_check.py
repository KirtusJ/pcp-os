"""Verify the two ordered shutdown records against the final serial SHA-256."""
from datetime import datetime, timedelta
import hashlib
import json

def event_hash(event):
    return hashlib.sha256(json.dumps(event,sort_keys=True,separators=(',',':')).encode('ascii')).hexdigest()

def record(seq,prev,ts,event,reason,source,target):
    return dict(actor='host',auth='HOST',body=dict(event=event,reason=reason,**{'from':source,'to':target}),
                kind='SYSTEM_STATE',prev=prev,seq=seq,ts=ts)

def closing_records(count,head,serial_hash,seconds):
    base=datetime(2026,11,21,12)
    choices=[(base+timedelta(seconds=s)).strftime('%Y-%m-%dT%H:%M:%SZ') for s in range(seconds+1)]
    for i,t1 in enumerate(choices):
        first=record(count,head,t1,'SHUTDOWN','end of the session','OPERATIONAL','STOPPING')
        mid=event_hash(first)
        for t2 in choices[i:]:
            last=record(count+1,mid,t2,'STOPPED_OK','stopped in order','STOPPING','STOPPED')
            if event_hash(last)==serial_hash:
                return [first,last]
    raise ValueError('displayed F4 head does not regenerate the final serial digest')

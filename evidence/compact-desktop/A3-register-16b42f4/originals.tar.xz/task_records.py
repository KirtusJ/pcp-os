"""Reconstruct one observed task from its program output, printed exit note and register head."""
from datetime import datetime,timedelta
import hashlib,json,re,sys
from pathlib import Path
from ledger_check import event_hash

def recover(folder):
    data=json.loads((folder/'result.json').read_text())
    pre,after=[data[k]['register'] for k in ('before','after')]
    if pre['clipped'] or after['clipped']:
        return None
    log=(folder/'serial.txt').read_text()
    task=re.search(r'^starting rdesk\.elf \(\d+ bytes, SHA-256 ([0-9a-f]{64})\)\n(.*?)^rdesk\.elf ended DONE: ([^\n]+)',log,re.M|re.S)
    program,output,note=task.groups()
    assert program==data['program_sha256']
    output=output.encode()
    digest=hashlib.sha256(output).hexdigest()
    base=datetime(2026,11,21,12)
    closure=datetime.strptime(data['closing_records'][0]['ts'],'%Y-%m-%dT%H:%M:%SZ')
    times=[(base+timedelta(seconds=n)).strftime('%Y-%m-%dT%H:%M:%SZ') for n in range(int((closure-base).total_seconds())+1)]
    visible=(folder/'after-f4.txt').read_text()
    defs=[('TASK_STARTED','kernel',dict(label='rdesk.elf',worker='PROGRAM',review=None,quiet_limit=0,budget=0,attempt='program rdesk.elf of SHA-256 '+program,observed='PROCESS_CREATED',id='T15')),
          ('ARTIFACT_ADDED','kernel',dict(sha256=digest,size=len(output),origin='PRODUCED',stored=False,task='T15')),
          ('TASK_ENDED','host',dict(id='T15',outcome='DONE',result=digest,read_back=digest,note=note,observed='PROCESS_END'))]
    def candidates(index,earliest,max_seconds):
        kind,actor,body=defs[index]
        seen=re.search(r'^\s*'+str(pre['count']+index)+r'\s+(\S+Z)\s+'+actor+r'\s+'+kind,visible,re.M)
        if seen:return [seen[1]]
        pos=times.index(earliest)
        return times[pos:pos+max_seconds]
    def event(index,prev,ts):
        kind,actor,body=defs[index]
        return dict(actor=actor,auth='HOST',body=body.copy(),kind=kind,prev=prev,seq=pre['count']+index,ts=ts)
    for t0 in candidates(0,times[0],len(times)):
        first=event(0,pre['head'],t0)
        h1=event_hash(first)
        for t1 in candidates(1,t0,4):
            second=event(1,h1,t1)
            h2=event_hash(second)
            for t2 in candidates(2,t1,3):
                last=event(2,h2,t2)
                for spent in range(65):
                    last['body']['spent']=spent
                    if event_hash(last)==after['head']:
                        return [first,second,last]
    raise ValueError('three records did not reproduce the screen digest: '+folder.name)

if __name__=='__main__':
    for arg in sys.argv[1:]:
        folder=Path(arg)
        records=recover(folder)
        if records:
            (folder/'task-records.json').write_text(json.dumps(records,indent=2)+'\n')
            print(folder.name,[r['ts'] for r in records],records[-1]['body']['spent'])

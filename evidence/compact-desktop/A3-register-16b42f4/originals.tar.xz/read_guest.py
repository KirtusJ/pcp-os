"""Read register and verification pixels before and after running a measured Queue Desk guest."""
import hashlib,json,os,re,runpy,subprocess,sys,time
from pathlib import Path
import numpy as np
from ledger_check import closing_records

here=Path(__file__).resolve().parent
source=here/'source'
kernel=here/'kernel.elf32'
mode=sys.argv[1]
out=here/mode
out.mkdir()
w,h=map(int,mode.split('x'))
serial=out/'serial.txt'
app=here/'rdesk.elf'
ktop=source/'PCP_OS_Rust/crates/pcpos-kernel'
measure=runpy.run_path(str(ktop/'tools/measure.py'))['measure'](kernel.read_bytes())
opt=runpy.run_path(str(source/'examples/optical-disk-check/check.py'))
font=runpy.run_path(str(source/'examples/tester-cd/check.py'))['kernel_glyphs']()
glyphs={np.packbits(np.array(mask,dtype='u1')).tobytes():c for mask,c in font.items()}
def rows(data):
    magic,sz,depth,pix=data.split(b'\n',3)
    assert magic==b'P6' and sz==f'{w} {h}'.encode() and depth==b'255' and len(pix)==w*h*3
    array=np.frombuffer(pix,dtype=np.uint8).reshape(h,w,3)
    masks=(array[:h//20*20,:w//10*10]!=array[0,0]).any(2).reshape(h//20,20,w//10,10).transpose(0,2,1,3)
    keys=np.packbits(masks.reshape(h//20,w//10,200),axis=-1)
    return [''.join(glyphs.get(k.tobytes(),'�') for k in row).rstrip() for row in keys]
def log():
    return serial.read_text(errors='replace') if serial.exists() else ''
def sha(data):
    return hashlib.sha256(data).hexdigest()
def register_field(lines):
    count=next((re.search(r'REGISTER: (\d+) events, (?:chain )?intact',line) for line in lines if 'REGISTER: ' in line),None)
    if not count:return None
    for i,line in enumerate(lines):
        m=re.search(r'\bhead(?: ([0-9a-f]+)(\.\.)?)?$',line.strip())
        if not m:continue
        value=m[1] or ''
        if m[2]:return dict(count=int(count[1]),head=value,clipped=True)
        for following in lines[i+1:]:
            if not re.fullmatch(r'[0-9a-f]+',following.strip()):break
            value+=following.strip()
        if len(value)==64:return dict(count=int(count[1]),head=value,clipped=False)
    return None
def verification_field(lines):
    text=' '.join(' '.join(lines).split())
    match=re.search(r'Register: (\d+) events, head ([0-9a-f]{16})\.\.\.',text)
    return dict(count=int(match[1]),head=match[2]) if match else None
def agree(r,v):
    n=min(len(r['head']),len(v['head']))
    return r['count']==v['count'] and n>0 and r['head'][:n]==v['head'][:n]
def sample(label,key,direction,reader):
    press(key)
    attempts=0
    while attempts<=25:
        data=capture(label)
        field=reader(rows(data))
        if field:
            (out/(label+'.txt')).write_text('\n'.join(rows(data))+'\n')
            press('esc')
            return field
        for _ in range(6 if key=='f4' else 1):press(direction,.091)
        attempts+=1
    raise ValueError('no field: '+label)
def take_pair(stage):
    v=sample(stage+'-f5','f5','down',verification_field)
    r=sample(stage+'-f4','f4','up',register_field)
    assert agree(r,v),(r,v)
    if r['clipped']:
        available=w//10-4-len(f"THE KERNEL'S REGISTER: {r['count']} events, chain intact, head ")-2
        assert len(r['head'])==available
    return {'register':r,'verification':v}
qemu=here.parent/'bin/qemu-system-x86_64'
cmd=[str(qemu),'-machine','pc','-accel','tcg','-cpu','qemu64','-m','256M','-device','VGA,vgamem_mb=64','-nic','none','-display','none','-rtc','base=2026-11-21T12:00:00,clock=vm','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel',str(kernel),'-append',f'desktop={mode} image={measure}','-initrd',app.name]
rec=dict(mode=mode,source=subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip(),measurement=measure,kernel_sha256=sha(kernel.read_bytes()),program_sha256=sha(app.read_bytes()),passed=False)
started=time.monotonic()
with (out/'stderr.txt').open('wb') as err, subprocess.Popen(cmd,cwd=here,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        mon=opt['Monitor'](vm)
        mon.call('qmp_capabilities')
        def press(key,delay=.19):
            mon.key(key)
            time.sleep(delay)
        def capture(label):
            path=out/(label+'.ppm')
            old=None
            for _ in range(18):
                mon.call('screendump',filename=str(path))
                data=path.read_bytes()
                if data==old:return data
                old=data
                time.sleep(.11)
            raise ValueError('unstable '+label)
        opt['wait_for'](lambda:'desktop: '+mode in log() and measure+' (measured; equal' in log(),'measured desktop',60)
        time.sleep(.4)
        rec['before']=take_pair('before')
        press('spc')
        press('ret')
        opt['wait_for'](lambda:'PARROTS READY' in log(),'Queue Desk ready',30)
        press('esc')
        opt['wait_for'](lambda:'rdesk.elf ended DONE: exit 0' in log(),'Queue Desk completion',30)
        press('esc')
        rec['after']=take_pair('after')
        b,a=rec['before'],rec['after']
        assert a['register']['count']>b['register']['count']
        assert a['verification']['head']!=b['verification']['head']
        # Pair genuine screenshots from different moments as a stale-display control.
        rec['stale_pair_accepted']=agree(b['register'],a['verification']) or agree(a['register'],b['verification'])
        assert not rec['stale_pair_accepted']
        press('f10')
        power=capture('power')
        dist=runpy.run_path(str(here.parent/'dist-65-merged/audit/public-live-cd/desktop_screens.py'))
        assert dist['complete_power_warning'](dist['power_warning_rows'](power,font))
        press('ret')
        rec['exit_code']=vm.wait(timeout=30)
        while not any(e['event']=='SHUTDOWN' for e in mon.events):
            mon.events.append(mon.read())
        rec['shutdown']=next(e['data'] for e in mon.events if e['event']=='SHUTDOWN')
        s=re.search(r'kernel register: (\d+) events, head ([0-9a-f]{64})',log())
        rec['closed']={'count':int(s[1]),'head':s[2]}
        last=a['register']
        assert int(s[1])==last['count']+2
        if not last['clipped']:
            rec['closing_records']=closing_records(last['count'],last['head'],s[2],int(time.monotonic()-started)+12)
        rec['checks']=sum(l.startswith('  pass ') for l in log().splitlines())
        assert rec['checks']==72 and 'ALL SELF-TESTS PASS.' in log()
        assert rec['exit_code']==0 and rec['shutdown']==dict(guest=True,reason='guest-shutdown')
        rec['passed']=True
    finally:
        if vm.poll() is None:vm.kill();vm.wait()
        (out/'result.json').write_text(json.dumps(rec,indent=2)+'\n')
print(mode,rec['before']['register']['count'],rec['after']['register']['count'],rec['closed']['count'])

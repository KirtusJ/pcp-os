"""Check the saved register frames and SHA-256 links without booting a guest. Uses NumPy."""
import ast,hashlib,json,re
from pathlib import Path
import numpy as np
from ledger_check import event_hash

base=Path(__file__).resolve().parent
font=ast.literal_eval('['+(base/'font.rs').read_text().split(' = [',1)[1].split('];',1)[0]+']')
glyph={np.packbits(np.array(g)>0).tobytes():chr(32+i) for i,g in enumerate(font)}
def read(raw):
    m,sz,d,p=raw.split(b'\n',3)
    w,h=map(int,sz.split())
    assert m==b'P6' and d==b'255' and len(p)==w*h*3
    pix=np.frombuffer(p,dtype='u1').reshape(h,w,3)
    bits=(pix[:h//20*20,:w//10*10]!=pix[0,0]).any(2).reshape(h//20,20,w//10,10).transpose(0,2,1,3)
    packed=np.packbits(bits.reshape(h//20,w//10,200),axis=-1)
    return [''.join(glyph.get(c.tobytes(),'�') for c in row).rstrip() for row in packed]
def full_head(rows):
    for i,row in enumerate(rows):
        m=re.search(r'\bhead(?: ([0-9a-f]+))?$',row.strip())
        if m:
            value=m[1] or ''
            for extra in rows[i+1:]:
                if not re.fullmatch(r'[0-9a-f]+',extra.strip()):break
                value+=extra.strip()
            if len(value)==64:return value
    return None
def change_visible_last_digit(raw,rows,value):
    parts=raw.split(b'\n',3)
    width=int(parts[1].split()[0])
    endpoint=None
    for i,line in enumerate(rows):
        match=re.search(r'\bhead(?: ([0-9a-f]+))?$',line.strip())
        if match is None:continue
        assembled=match[1] or ''
        endpoint=i
        for j in range(i+1,len(rows)):
            if not re.fullmatch(r'[0-9a-f]+',rows[j].strip()):break
            assembled+=rows[j].strip()
            endpoint=j
        if assembled==value:break
        endpoint=None
    if endpoint is not None:
        row=endpoint
        line=rows[row]
        col=len(line)-1
        repl='0' if value[-1]!='0' else '1'
        start=row*20*3*width+col*30
        blank=parts[3][:3]
        orig=[]
        for y in range(20):
            offset=start+y*3*width
            orig.extend(parts[3][i:i+3] for i in range(offset,offset+30,3))
        # Reuse a genuine original glyph from the same text color if available.
        region=None
        for n,other in enumerate(rows):
            for k,char in enumerate(other):
                if char==repl:
                    pos=n*20*3*width+k*30
                    region=[parts[3][pos+y*3*width:pos+y*3*width+30] for y in range(20)]
                    break
            if region:break
        if not region:
            rgb=max((c for c in orig if c!=blank),default=b'\xff\xff\xff')
            mask=font[ord(repl)-32]
            region=[b''.join(rgb if v else blank for v in mask[y*10:(y+1)*10]) for y in range(20)]
        mod=bytearray(parts[3])
        for y,stripe in enumerate(region):
            pos=start+y*width*3
            mod[pos:pos+30]=stripe
        return b'\n'.join(parts[:3]+[bytes(mod)])
    raise ValueError('final hex digit unavailable')
for line in (base/'SHA256SUMS').read_text().splitlines():
    expected,name=line.split('  ',1)
    assert hashlib.sha256((base/name).read_bytes()).hexdigest()==expected,name
for folder in sorted(base.glob('*x*/result.json')):
    path=folder.parent
    rec=json.loads(folder.read_text())
    assert rec['passed'] and rec['checks']==72
    for stage in ['before','after']:
        f4raw=(path/(stage+'-f4.ppm')).read_bytes()
        f4=read(f4raw)
        f5=read((path/(stage+'-f5.ppm')).read_bytes())
        assert '\n'.join(f4)+'\n'==(path/(stage+'-f4.txt')).read_text()
        assert '\n'.join(f5)+'\n'==(path/(stage+'-f5.txt')).read_text()
        field=rec[stage]['register']
        count=str(field['count'])
        assert re.search(r'REGISTER: '+count+r' events, (?:chain )?intact',' '.join(f4))
        assert 'Register: '+count+' events, head '+rec[stage]['verification']['head']+'...' in ' '.join(' '.join(f5).split())
        if field['clipped']:
            assert any('head '+field['head']+'..' in line for line in f4)
        else:
            assert full_head(f4)==field['head']
    if (path/'task-records.json').exists():
        records=json.loads((path/'task-records.json').read_text())+rec['closing_records']
        expected=rec['before']['register']['head']
        for idx,event in enumerate(records):
            assert event['prev']==expected and event['seq']==rec['before']['register']['count']+idx
            expected=event_hash(event)
            if idx==2:assert expected==rec['after']['register']['head']
        assert expected==rec['closed']['head']
        original=rec['after']['register']['head']
        changed=full_head(read(change_visible_last_digit(f4raw,f4,original)))
        assert len(changed)==64 and changed[:-1]==original[:-1] and changed[-1]!=original[-1]
        first,last=rec['closing_records']
        other_last={**last,'prev':event_hash({**first,'prev':changed})}
        assert event_hash(other_last)!=rec['closed']['head']
    print(path.name,rec['before']['register']['count'],rec['after']['register']['count'],rec['closed']['count'],len(rec['after']['register']['head']),'visible digits')

"""Read Z3's two proposed F10 layouts after the captured cells have been decoded."""
TITLE = "POWER OFF"
QUESTION = "Switch PCP OS off?"
WARNING = ("The register is closed and verified first. "
           "Files of this session that were not saved by a program are lost.")
CONFIRM = "Enter switch off"
CANCEL = "Esc go back"
ACTIONS = CONFIRM + "    " + CANCEL


def complete_power_warning(rows):
    if not rows or len(rows) < 5:
        return False
    lines = [line.strip() for line in rows]
    if lines[0] == TITLE and lines[1] == QUESTION:
        if lines[-1] == ACTIONS:
            body = lines[2:-1]
        elif lines[-2:] == [CONFIRM, CANCEL]:
            body = lines[2:-2]
        else:
            return False
    elif lines[:5] == ["", TITLE, "", QUESTION, ""] and lines[-2:] == [ACTIONS, ""]:
        body = lines[5:-2]
    else:
        return False
    return " ".join(line for line in body if line) == WARNING

"""Replay B3's three original boundary-mode guests and match the power image digests."""
import hashlib
import json
from pathlib import Path
import runpy
import tarfile
from power_layout import complete_power_warning
root = Path(__file__).resolve().parent
source = root.parent / "a3-settings314/src"
decoder = runpy.run_path(str(source / "examples/tester-cd/check_compact_pins.py"))
glyphs = decoder["CHECK"]["kernel_glyphs"]()
result = {}
with tarfile.open(root / "b3.tar.xz") as pack:
    for mode,want in [("752x480",False),("760x480",True),("760x460",True)]:
        data = pack.extractfile("guests/"+mode+"/power.ppm").read()
        again = pack.extractfile("guests/"+mode+"/confirmed-prompt.ppm").read()
        assert data == again
        rows = decoder["read"](data,glyphs)
        verdict = complete_power_warning(rows)
        assert verdict == want,(mode,verdict,rows)
        result[mode] = dict(accepted=verdict,sha256=hashlib.sha256(data).hexdigest(),
                            visible_rows=[s.strip() for s in rows if s.strip()])
(root/"peer-results.json").write_text(json.dumps(result,indent=2)+"\n")
print([(k,v["accepted"]) for k,v in result.items()])

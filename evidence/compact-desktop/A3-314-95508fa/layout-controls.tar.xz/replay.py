"""Construct proposed layouts with guest glyphs and challenge their order, omissions and actions."""
import hashlib
import json
from pathlib import Path
import runpy
from textwrap import wrap

import numpy as np
from power_layout import complete_power_warning

root = Path(__file__).resolve().parent
originals = root.parent / "a3-settings314"
decoder = runpy.run_path(str(originals / "src/examples/tester-cd/check_compact_pins.py"))
glyphs = decoder["CHECK"]["kernel_glyphs"]()
read = decoder["read"]
source = (originals / "800x600/power.ppm").read_bytes()
decoded = read(source,glyphs)
pixels = np.frombuffer(source.split(b"\n",3)[3],dtype=np.uint8).reshape(600,800,3)
background = pixels[0,0]
templates = {}
for style,indices in {"title":(1,), "prompt":(3,), "body":(5,6), "keys":(28,)}.items():
    glyph = {}
    for row in indices:
        for col, char in enumerate(decoded[row]):
            cell = pixels[20*row:20*(row+1),10*col:10*(col+1)]
            if char in glyph:
                assert np.array_equal(cell,glyph[char])
            glyph[char] = cell
    templates[style] = glyph
warning = " ".join(decoded[i].strip() for i in (5,6))
title,question,actions = (decoded[i].strip() for i in (1,3,28))
confirm,cancel = actions.split("    ")


def draw(width,height,lines):
    pic = np.empty((height,width,3),dtype=np.uint8)
    pic[:] = background
    for row,style,text in lines:
        assert 0 <= row < height//20
        assert len(text)+2 <= width//10
        for col,char in enumerate(text,2):
            pic[row*20:(row+1)*20,col*10:(col+1)*10] = templates[style][char]
    return f"P6\n{width} {height}\n255\n".encode() + pic.tobytes()


def form(width,height):
    cols,rows = width//10,height//20
    body = ([decoded[5].strip(), decoded[6].strip()] if cols >= 79
            else wrap(warning,width=cols-4))
    roomy = cols >= 35 and rows >= 12 and 5+len(body) <= rows-2
    if roomy:
        first = 5
        front = [(1,"title",title),(3,"prompt",question)]
        keys = [(rows-2,"keys",actions)]
    else:
        first = 2
        front = [(0,"title",title),(1,"prompt",question)]
        keys = ([(rows-1,"keys",actions)] if len(actions) <= cols-4
                else [(rows-2,"keys",confirm),(rows-1,"keys",cancel)])
    return front + [(first+i,"body",line) for i,line in enumerate(body)] + keys


def inspect(mode,lines):
    width,height = map(int,mode.split("x"))
    frame = draw(width,height,lines)
    return (complete_power_warning(read(frame,glyphs)),hashlib.sha256(frame).hexdigest())


result = {}
for mode in ("320x200","320x220","320x480","340x240","350x240","640x200","640x220","640x480","760x460","800x600"):
    size = list(map(int,mode.split("x")))
    lines = form(*size)
    ok,h = inspect(mode,lines)
    assert ok,mode
    tests = {}
    words = warning.split()
    for i,word in enumerate(words):
        other = list(lines)
        start = 0
        for j,(row,style,text) in enumerate(other):
            if style != "body":
                continue
            chunk = text.split()
            if start <= i < start+len(chunk):
                del chunk[i-start]
                other[j] = (row,style," ".join(chunk))
                break
            start += len(chunk)
        accepted,sha = inspect(mode,other)
        assert not accepted,(mode,i,word)
        tests[f"omit word {i+1} ({word})"] = sha
    for label,part in (("title",title),("question",question),("confirm",confirm),("cancel",cancel)):
        bad = [(row,style,t.replace(part,"")) for row,style,t in lines]
        accepted,sha = inspect(mode,bad)
        assert not accepted,(mode,label)
        tests["omit "+label] = sha
    result[mode] = {"accepted":h,"expected_refusals":tests}
for mode in ("320x200","320x220","320x240","320x260","320x280","640x480","800x600"):
    frame = (originals / mode / "power.ppm").read_bytes()
    accepted = complete_power_warning(read(frame,glyphs))
    assert accepted == (mode == "800x600")
    result.setdefault(mode,{})["old_guest"] = dict(accepted=accepted,sha256=hashlib.sha256(frame).hexdigest())
(root / "readback.json").write_text(json.dumps(result,indent=2)+"\n")
print("10 proposed layouts accepted; 240 omission controls rejected; 7 original guest screens read.")

"""Read the frames independently of the keystrokes, including the words and highlight on each selected row."""
import hashlib,json,runpy,subprocess
from pathlib import Path
import numpy as np
from PIL import Image

root=Path(__file__).resolve().parent
source=root/'src'
reader=runpy.run_path(str(source/'examples/tester-cd/check_compact_pins.py'))
glyphs=reader['CHECK']['kernel_glyphs']()
names={'bar':'A bar across the screen','dock':'A dock in the middle','recent':'Recent activity','machine':'This machine','session':'Session'}
panel=(24,54,79)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pixels(path):
    with Image.open(path) as picture:return np.array(picture)
def compare(a,b):
    mask=np.any(pixels(a)!=pixels(b),axis=2)
    y,x=np.nonzero(mask)
    return dict(changed_pixels=int(mask.sum()),bounds=[int(x.min()),int(y.min()),int(x.max()),int(y.max())] if x.size else None)
def inspect(folder):
    data=json.loads((folder/'result.json').read_text())
    assert data['startup']==71 and data['checks']==72 and data['exit']==0
    cache={}
    def rows(name):
        p=folder/(name+'.ppm')
        raw=p.read_bytes()
        h=sha(raw)
        assert h==data['frames'][name]
        if h not in cache:cache[h]=reader['read'](raw,glyphs)
        return cache[h]
    def visible(name,label):
        text=rows(name)
        p=pixels(folder/(name+'.ppm'))
        selected=[]
        for i,line in enumerate(text):
            if label not in line:continue
            x=line.index(label)*10
            if np.any(np.all(p[i*20:(i+1)*20,x:x+len(label)*10]==panel,axis=-1)):
                selected.append(line.strip())
        return selected
    def path(name):return folder/(name+'.ppm')
    for n in data['frames']:rows(n)
    decoded={n:rows(n) for n in data['frames']}
    (folder/'decoded.json').write_text(json.dumps(decoded,indent=2)+'\n')
    out={}
    initial=data['frames']['home-initial']
    assert initial==data['frames']['home-forms-restored']
    for n,label in names.items():
        before=n+'-before'
        after=n+('-after' if n in ('bar','dock') else '-on')
        assert 'SETTINGS' in '\n'.join(rows(before))
        result=compare(path(before),path(after))
        result.update(label=label,selected_before=visible(before,label),selected_after=visible(after,label),escape_hint=any('Esc back' in row for row in rows(after)))
        if n in ('bar','dock'):
            result['state_shown']=any('( )' in r for r in result['selected_before']) and any('(o)' in r for r in result['selected_after'])
        else:
            result['state_shown']=any('[  ]' in r for r in result['selected_before']) and any('[on]' in r for r in result['selected_after'])
            assert data['frames'][after]==data['frames'][n+'-reopened']
            assert data['frames'][before]==data['frames'][n+'-off']
            assert initial==data['frames'][n+'-home-restored']
            result['home_pixels']=compare(path('home-initial'),path(n+'-home'))['changed_pixels']
            base=rows('home-initial')
            result['new_home_rows']=[t.strip() for t in rows(n+'-home') if t.strip() and t not in base]
        out[n]=result
    return dict(choices=out,checks=data['checks'],exit=data['exit'],shutdown=data['shutdown'])
modes='320x200 320x220 320x240 320x260 320x280 320x480 640x220 640x240 640x260 640x280 640x480 800x600'.split()
summary={size:inspect(root/size) for size in modes}
report=dict(source=subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip(),
            tree=subprocess.check_output(['git','-C',source,'rev-parse','HEAD^{tree}'],text=True).strip(),
            kernel_sha256=sha((root/'kernel.elf32').read_bytes()),profiles=summary)
(root/'settings-readback.json').write_text(json.dumps(report,indent=2)+'\n')
for mode,r in summary.items():
    print(mode,[(k,a['changed_pixels'],a['state_shown'],a.get('home_pixels'),a.get('new_home_rows')) for k,a in r['choices'].items()])

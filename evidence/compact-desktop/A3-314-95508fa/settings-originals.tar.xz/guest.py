"""Exercise all five Settings choices through the desktop keyboard in a fresh QEMU guest."""
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
source = root/'src'
kernel = root/'kernel.elf32'
program = root/'rdesk.elf'
mode = sys.argv[1]
out = root/mode
out.mkdir()
def sha(data):
    return hashlib.sha256(data).hexdigest()

origin = json.loads((root/'guest-source.json').read_text())
assert sha(program.read_bytes()) == origin['inputs']['rdesk.elf']['sha256']
assert all(sha((root/name).read_bytes()) == sha(program.read_bytes()) for name in ('alpha.elf', 'bravo.elf'))
head = subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip()
kpath = source/'PCP_OS_Rust/crates/pcpos-kernel'
measure = runpy.run_path(str(kpath/'tools/measure.py'))['measure'](kernel.read_bytes())
qemu = '/workspace/scratch/7c7df1723510/work/emulator/qemu-system-x86_64'
opt = runpy.run_path(str(source/'examples/optical-disk-check/check.py'))
serial = out/'serial.txt'
def log():
    return serial.read_text(errors='replace') if serial.exists() else ''
cmd=[qemu,'-machine','pc','-accel','tcg','-cpu','qemu64','-m','256M','-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(serial),'-kernel',str(kernel),'-append','desktop='+mode+' image='+measure,'-initrd','alpha.elf,bravo.elf']
record=dict(mode=mode,head=head,kernel=sha(kernel.read_bytes()),measurement=measure,app=sha(program.read_bytes()),command=cmd,keys=[],frames={})

with (out/'stderr.txt').open('wb') as err, subprocess.Popen(cmd,cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
    try:
        m=opt['Monitor'](guest)
        m.call('qmp_capabilities')
        def key(name):
            m.key(name)
            record['keys'].append(name)
            time.sleep(.20)
        def frame(name):
            path=out/(name+'.ppm')
            last=None
            for _ in range(15):
                m.call('screendump',filename=str(path))
                raw=path.read_bytes()
                if raw==last:break
                last=raw
                time.sleep(.15)
            else:raise ValueError('unstable capture '+name)
            shape=raw.split(b'\n',3)
            assert shape[0]==b'P6' and shape[1].decode().replace(' ','x')==mode
            assert shape[2]==b'255' and len(shape[3])==3*int(mode.split('x')[0])*int(mode.split('x')[1])
            record['frames'][name]=sha(raw)
        def choose(index):
            key('f2')
            for _ in range(index):key('down')
        opt['wait_for'](lambda:'desktop: '+mode in log() and measure+' (measured; equal' in log(),'measured desktop',40)
        time.sleep(.45)
        record['startup']=sum(s.startswith('  pass ') for s in log().splitlines())
        assert record['startup']==71
        # Seed a finished task so Recent activity always has one real event to show on Home.
        key('spc');frame('program-first');key('down');frame('program-second');key('ret')
        opt['wait_for'](lambda:'PARROTS READY' in log(),'Queue Desk',30)
        key('esc')
        opt['wait_for'](lambda:'bravo.elf ended DONE: exit 0' in log(),'finished task',30)
        key('esc');frame('home-initial')
        choose(1);frame('dock-before');key('ret');frame('dock-after');key('esc')
        choose(0);frame('bar-before');key('ret');frame('bar-after');key('esc')
        frame('home-forms-restored')
        for i,name in enumerate(['recent','machine','session'],2):
            choose(i);frame(name+'-before')
            key('ret');frame(name+'-on');key('esc');frame(name+'-home')
            choose(i);frame(name+'-reopened')
            key('ret');frame(name+'-off');key('esc');frame(name+'-home-restored')
        key('f10');frame('power');key('ret')
        record['exit']=guest.wait(timeout=20)
        while not any(e['event']=='SHUTDOWN' for e in m.events):m.events.append(m.read())
        record['shutdown']=next(e['data'] for e in m.events if e['event']=='SHUTDOWN')
        record['checks']=sum(s.startswith('  pass ') for s in log().splitlines())
        assert record['checks']==72 and record['exit']==0 and record['shutdown']==dict(guest=True,reason='guest-shutdown')
        assert 'ALL SELF-TESTS PASS.' in log()
    finally:
        if guest.poll() is None:guest.kill();guest.wait()
        (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(mode,record['checks'],record['exit'])

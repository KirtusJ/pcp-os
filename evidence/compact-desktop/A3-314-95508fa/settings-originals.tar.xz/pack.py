from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,tempfile
root=Path(__file__).resolve().parent
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
v=json.loads((root/'settings-readback.json').read_text())
software=['guest.py','read_frames.py','pack.py','build-kernel.sh','compiler.txt','build.log','kernel.elf32','rdesk.elf','guest-source.json','settings-readback.json','worker-status.json','confirm.py','guest-worker.sh','alpha.elf','bravo.elf']
files=[root/f for f in software]
for mode,record in v['profiles'].items():
    folder=root/mode
    meta=json.loads((folder/'result.json').read_text())
    assert int((root/(mode+'.exit')).read_text())==0 and meta['head']==v['source']
    assert meta['kernel']==sha(root/'kernel.elf32') and meta['app']==sha(root/'rdesk.elf')
    assert all(sha(folder/(name+'.ppm'))==h for name,h in meta['frames'].items())
    assert all(c['home_pixels']>0 for c in record['choices'].values() if 'home_pixels' in c)
    files.extend(sorted(folder.iterdir()))
    files.extend([root/(mode+'.exit'),root/(mode+'.log')])
entries={str(p.relative_to(root)):sha(p) for p in files}
manifest=root/'SHA256SUMS'
manifest.write_text(''.join(h+'  '+n+'\n' for n,h in entries.items()))
files.append(manifest)
with tarfile.open(root/'settings-originals.tar.xz','w:xz',preset=1) as t:
    seen={}
    for path in files:
        name=str(path.relative_to(root));h=sha(path)
        if h in seen:
            member=t.gettarinfo(str(path),name)
            member.type=tarfile.LNKTYPE;member.size=0;member.linkname=seen[h]
            t.addfile(member)
        else:t.add(path,arcname=name,recursive=False);seen[h]=name
with tempfile.TemporaryDirectory() as dest,tarfile.open(root/'settings-originals.tar.xz') as t:
    t.extractall(dest,filter='data')
    for name,h in entries.items():assert sha(Path(dest)/name)==h
print(len(entries),'files checked',sha(root/'settings-originals.tar.xz'))

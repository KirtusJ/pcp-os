#!/bin/bash
set -u
size=$1
a3-1591757/delegate-build/release/pcp-delegate a3-small314/tasks.redb "boot-$size" "Read five Settings choices and choose the second program at $size" -- python3 -B a3-small314/guest.py "$size" > "a3-small314/$size.log" 2>&1
result=$?
echo "$result" > "a3-small314/$size.exit"
exit "$result"

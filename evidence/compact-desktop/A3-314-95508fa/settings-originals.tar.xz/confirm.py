"""Verify selected settings, restored Home, the chosen program and its complete ordinary grants."""
import json
from pathlib import Path
root=Path(__file__).resolve().parent
report=json.loads((root/'settings-readback.json').read_bytes())
total=widgets=0
for mode,record in report['profiles'].items():
    folder = root/mode
    choices=record['choices']
    assert len(choices)==5
    assert all(v['state_shown'] and v['escape_hint'] and v['changed_pixels']>0 for v in choices.values()),mode
    for name in ('recent','machine','session'):
        assert choices[name]['home_pixels']>0
        widgets+=1
    total+=len(choices)
    rows=json.loads((folder/'decoded.json').read_bytes())
    for key,app in [('program-first','alpha.elf'),('program-second','bravo.elf')]:
        lines=[line.strip() for line in rows[key]]
        assert lines.count('?'+app)==1 and sum(s.startswith('?') and s.endswith('.elf') for s in lines)==1
        verdict=[s for s in lines if s.startswith('Verified')]
        assert len(verdict)==1 and 'all 71 self-tests' in verdict[0]
        start=next(i for i,s in enumerate(lines) if s.startswith('Access:'))
        text=' '.join(' '.join(lines[start:]).split())
        assert text == 'Access: console, display, keyboard, files and store Up/Down choose Enter open D details R register P off',(mode,text)
    serial=(folder/'serial.txt').read_text()
    assert 'starting bravo.elf (' in serial and 'bravo.elf ended DONE: exit 0' in serial
    record['programs']=dict(first='alpha.elf',second='bravo.elf',launched='bravo.elf',verdict=verdict[0],grants='console, display, keyboard, files and store')
assert (total,widgets)==(60,36)
(root/'settings-readback.json').write_text(json.dumps(report,indent=2)+'\n')
print(total,"selected controls with state, footer, and changed pixels;",widgets,"widget/Home cycles; 12 second-choice launches")

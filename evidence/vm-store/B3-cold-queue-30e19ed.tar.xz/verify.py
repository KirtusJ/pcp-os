"""Verify the embedded workflow artifact and repeat the screen and journal checks."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'source/examples/vm-store'))
import check_queue
import check_queue_files

def sha(data):
    return hashlib.sha256(data).hexdigest()

def verify_pair(directory):
    summary = json.loads((directory / 'results.json').read_text())
    assert summary['label'] == 'cold morning'
    assert summary['kernel_measurement'] == 'c99b256e5df82600ff063be98d4a119328da26e4fe26fbb1612518d6d2e7761b'
    assert [row['status'] for row in summary['boots']] == ['Disk save', 'Queue restored']
    before = (directory / 'save.raw').read_bytes()
    assert before == (directory / 'restore.raw').read_bytes()
    check_queue.check_journal(before)
    for record in summary['boots']:
        boot = record['boot']
        assert record['disk_sha256'] == sha(before)
        assert record['screenshot_sha256'] == sha((directory / (boot + '.ppm')).read_bytes())
        serial = (directory / (boot + '.serial')).read_text()
        assert 'ALL SELF-TESTS PASS.' in serial and 'queue.elf ended DONE: exit 0' in serial
        assert summary['kernel_measurement'] + ' (measured; equal' in serial
    check_queue_files.check_capture(directory / 'restore-files.ppm')

z = root / 'queue.zip'
assert sha(z.read_bytes()) == '41b2d00d94e8929390b740768dac8e882112eabb6487bd55ef160076824e50d6'
with tempfile.TemporaryDirectory() as temp, zipfile.ZipFile(z) as artifact:
    hosted = Path(temp)
    artifact.extractall(hosted)
    verify_pair(hosted)
    for file, expected in [('kernel.elf', '116ccd7d6f1fe54a827ac5be0d458d5ffc9e81e5c42321fc43f2e29752a28d65'), ('queue.elf', 'b7467790402a4d6b4cc14052f50f89268a835a8104afc899618c7dab23a7c694')]:
        assert sha((hosted / file).read_bytes()) == expected
verify_pair(root / 'guest')
report = subprocess.check_output([sys.executable, '-B', str(root/'read_files.py'), str(root/'source'), str(root/'names')], text=True)
assert report == (root/'names.jsonl').read_text()
cases = [json.loads(line) for line in report.splitlines()]
assert [(x['col'],x['native_screen'],x['exact_journal']) for x in cases] == [(2,True,True),(3,False,False),(2,True,False)]
assert cases[0]['ppm_sha256'] == cases[2]['ppm_sha256'] != cases[1]['ppm_sha256']
wide = root / 'width/exact'
pixels = (wide / 'files.ppm').read_bytes()
assert pixels.split(b'\n', 2)[1] == b'1360 768'
font = check_queue.optical['SCREEN']['kernel_glyphs']()
rows = check_queue.optical['SCREEN']['read_screen'](pixels,font)
assert rows[4].index('3 KiB') == 122 and check_queue.saved_queue_visible(rows,pixels)
assert json.loads((wide / 'result.json').read_text())['exit'] == 33
assert 'ALL SELF-TESTS PASS.' in (wide / 'serial.txt').read_text()
print('Verified hosted and local cold-restore pairs, 11 controls on each, three native filenames, and 1360x768.')

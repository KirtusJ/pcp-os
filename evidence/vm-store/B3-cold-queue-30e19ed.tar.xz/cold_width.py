"""Boot one genuine or space-bearing filename from a temporary single-file volume."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys
import time

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('name',choices=['exact','leading','trailing'])
for arg in ('source','replay','output','qemu'): p.add_argument(arg,type=Path)
a=p.parse_args()
sys.path.insert(0,str(a.source.resolve()/'examples/vm-store'))
import check_queue as check
def digest(buf):
    return hashlib.sha256(buf).digest()
def sha(path):
    return digest(path.read_bytes()).hex()
def variant(old,name):
    # Build a separate input to the read-only cold boot. Both guest-generated save files stay intact.
    check.check_journal(old)
    offset=130*512
    block=old[offset:offset+512]
    gen,size=struct.unpack_from('<QI',block,8)
    payload=old[offset+512:offset+512+size]
    namesize,recordsize=struct.unpack_from('<HI',payload)
    data=payload[6+namesize:]
    assert gen==2 and len(data)==recordsize==2064 and payload[6:6+namesize]==b'parrots.queue'
    body=struct.pack('<HI',len(name),len(data))+name+data
    hdr=b'PCPSLOT1'+struct.pack('<QI',gen,len(body))+digest(body)
    result=bytearray(old)
    result[offset:offset+84]=hdr+digest(hdr)
    result[offset+512:offset+512+len(body)]=body
    return bytes(result)
out=a.output.resolve()/a.name;out.mkdir(parents=True,exist_ok=False)
replay=a.replay.resolve()
name={'exact':b'parrots.queue','leading':b' parrots.queue','trailing':b'parrots.queue '}[a.name]
disk=out/'input.raw'
original=(replay/'save.raw').read_bytes()
data=variant(original,name);disk.write_bytes(data)
if a.name=='exact':assert data==original
kernel=replay/'kernel.elf';queue=replay/'queue.elf'
measure=json.loads((replay/'results.json').read_text())['kernel_measurement']
volume=(replay/'volume/volume-id.txt').read_text().strip()
cmd=[str(a.qemu.resolve()),'-machine','pc','-accel','tcg','-cpu','max','-m','256M','-smp','1','-nic','none','-display','none','-vga','std','-qmp','stdio','-monitor','none','-no-reboot','-kernel',str(kernel),'-initrd',str(queue),'-append',f'desktop=1360x768 store=ide0 store_id={volume} image={measure}','-serial','file:'+str(out/'serial.txt'),'-drive',f'if=none,id=store,format=raw,file={disk}','-device','ide-hd,drive=store,bus=ide.0,unit=0,serial=PCP-VM-STORE','-device','isa-debug-exit,iobase=0xf4,iosize=4']
r={'name':name.decode(),'argv':cmd,'kernel':sha(kernel),'queue':sha(queue),'disk_before':sha(disk)}
with (out/'stderr.txt').open('wb') as err:
    vm=subprocess.Popen(cmd,cwd=out,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
    try:
        mon=check.Monitor(vm);mon.call('qmp_capabilities')
        desktop=check.optical['DesktopScreens'](mon,out,35,sound=False)
        desktop.home('home')
        mon.key('f3')
        rows=desktop.wait('files',lambda rows:rows[1].strip().startswith('FILES:') and '3 KiB' in rows[4])
        r['rows']=rows
        (out/'files.txt').write_text('\n'.join(rows)+'\n')
        r['matcher']=check.saved_queue_visible(rows,(out/'files.ppm').read_bytes())
        r['frame']=sha(out/'files.ppm')
        mon.key('esc');desktop.home('restored');assert sha(out/'home.ppm')==sha(out/'restored.ppm')
        mon.key('f10');desktop.wait('power',lambda v:v[1]=='  POWER OFF' and 'Switch PCP OS off?' in v[3]);mon.key('ret')
        r['exit']=vm.wait(timeout=35)
        serial=(out/'serial.txt').read_text()
        assert r['exit']==33 and 'ALL SELF-TESTS PASS.' in serial and 'VM checkpoint store mounted: 1 file(s)' in serial
        assert r['disk_before']==sha(disk) and measure+' (measured; equal' in serial
        assert data==disk.read_bytes()
    finally:
        if vm.poll() is None:vm.kill();vm.wait()
        (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(a.name,r['matcher'],rows[4].index('parrots.queue'),rows[4].index('3 KiB'),r['frame'])

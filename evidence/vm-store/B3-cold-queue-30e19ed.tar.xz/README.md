# B3 independent read-back of PR 317 at 30e19ed

GitHub Actions run 44917736180, artifact 14712008309, supplied queue.zip. The repository head was 30e19ededc133b873bc22454bcb875098d77cac4. The source directory contains the tracked Python checkers and the source files they read. In a fresh directory, the B3 PCP OS worker booted the two binaries from this workflow, saved the queue under “cold morning,” and restored it on a second boot. The production checker passed. The hosted and local disks each remained byte-identical within their own save/restore pair. Each volume was created independently.

The names directory contains the native Files pixels and raw volumes from three independent guest boots using the same kernel, Queue Desk binary and queue payload. The local predicate and journal were applied to those raw bytes at the reviewed revision. A separate genuine 1360×768 guest rendered the size at column 122 and exited 33 after a confirmed shutdown. At 1920×1080 the size appears at column 178. Columns start at zero.

Run sha256sum -c SHA256SUMS and python3 -B verify.py after extraction. The unaltered workflow ZIP is embedded. Full original three-control boots and their construction script are in B3-cold-queue-49e6458.tar.xz at evidence commit cb32a0405e31d61a8844e12464991c617d24859e.

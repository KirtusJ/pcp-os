"""Compare captured Files pixels and the exact stored filenames from three cold-boot controls."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import sys
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('source',type=Path);p.add_argument('controls',type=Path)
a=p.parse_args()
sys.path.insert(0,str(a.source.resolve()/'examples/vm-store'))
import check_queue as q
font=q.optical['SCREEN']['kernel_glyphs']()
read=q.optical['SCREEN']['read_screen']
for mode in ('exact','leading','trailing'):
    d=a.controls/mode
    im=(d/'files.ppm').read_bytes(); rows=read(im,font)
    disk=(d/'input.raw').read_bytes(); offset=130*512
    gen,length=struct.unpack_from('<QI',disk,offset+8); assert gen==2
    body=disk[offset+512:offset+512+length]
    assert hashlib.sha256(body).digest()==disk[offset+20:offset+52]
    n,size=struct.unpack_from('<HI',body); name=body[6:6+n].decode('ascii')
    assert size==len(body)-6-n==2064
    try:
        q.check_journal(disk); journal=True
    except (ValueError,RuntimeError,AssertionError,SystemExit):
        journal=False
    print(json.dumps(dict(case=mode,name=name,col=rows[4].index('parrots.queue'),size_col=rows[4].index('3 KiB'),native_screen=q.saved_queue_visible(rows),exact_journal=journal,ppm_sha256=hashlib.sha256(im).hexdigest())))

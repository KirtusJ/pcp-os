"""Recompute the cold-boot evidence without using network access."""
from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def log(p):return p.read_text(errors='replace')
for rel in ('replay','hosted'):
    d=root/rel; js=json.loads((d/'results.json').read_text());assert js['label']=='cold morning'
    assert [x['status'] for x in js['boots']]==['Disk save','Queue restored']
    assert sha(d/'save.raw')==sha(d/'restore.raw')==js['boots'][0]['disk_sha256']==js['boots'][1]['disk_sha256']
    for x in js['boots']:
        assert sha(d/(x['boot']+'.ppm'))==x['screenshot_sha256']
        serial=log(d/(x['boot']+'.serial'))
        assert 'ALL SELF-TESTS PASS.' in serial and 'queue.elf ended DONE: exit 0' in serial
for mode in ('exact','leading','trailing'):
    d=root/'names'/mode
    r=json.loads((d/'result.json').read_text())
    assert r['exit']==33 and r['frame']==sha(d/'files.ppm') and r['disk_before']==sha(d/'input.raw')
    assert 'VM checkpoint store mounted: 1 file(s)' in log(d/'serial.txt')
    assert sha(d/'home.ppm')==sha(d/'restored.ppm')
for label,src in [('28f466b',root/'source'),('49e6458',root/'revisions/49e6458/source')]:
    output=subprocess.check_output([sys.executable,'-B',str(root/'read_files.py'),str(src),str(root/'names')],text=True)
    rows=[json.loads(s) for s in output.splitlines()]
    assert [r['col'] for r in rows]==[2,3,2]
    assert [r['exact_journal'] for r in rows]==[True,False,False]
    assert [r['native_screen'] for r in rows]==[True,True,True]
    assert rows[0]['ppm_sha256']==rows[2]['ppm_sha256']!=rows[1]['ppm_sha256']
    print(label,'3 filename controls verified')

"""Read back the revision's serial driver with a status sequence, a scratch register and a write log."""
import json,os,subprocess,sys,tempfile
from pathlib import Path
src=Path(sys.argv[1]).read_text()
driver=src[src.index('const COM1: u16'):src.index('/// Whether the processor says it is run by an emulator')]
model=r"""
use std::{cell::RefCell,sync::atomic::Ordering};
struct Port {mode:String,init:bool,scratch:u8,status_reads:u32,scratch_reads:u32,writes:Vec<(u16,u8)>}
thread_local! {static PORT:RefCell<Port>=RefCell::new(Port{mode:String::new(),init:true,scratch:0,status_reads:0,scratch_reads:0,writes:vec![]});}
fn inb(addr:u16)->u8 {PORT.with(|p|{let mut p=p.borrow_mut();match addr-COM1 {
5=>{p.status_reads+=1;if p.init {if p.mode=="absent"{255}else{0}} else {match p.mode.as_str(){
"never"=>0,"edge" if p.status_reads<1_000_000=>0,"late" if p.status_reads<=1_000_000=>0,
"gone" if p.status_reads>=2=>255,"edge-gone" if p.status_reads<1_000_000=>0,"edge-gone"=>255,_=>32}}},
7=>{p.scratch_reads+=1;match p.mode.as_str() {"fixed-zero"=>0,"fixed-a5"=>165,"only-first"=>90,_=>p.scratch}},
_=>panic!("unexpected register read")}})}
fn outb(addr:u16,value:u8){PORT.with(|p|{let mut p=p.borrow_mut();p.writes.push((addr-COM1,value));if addr==COM1+7{p.scratch=value}})}
fn main(){
let mode=std::env::args().nth(1).unwrap();PORT.with(|p|p.borrow_mut().mode=mode);
serial_init();
let init=SERIAL.load(Ordering::SeqCst);
PORT.with(|p|{let mut p=p.borrow_mut();println!("{} {} {} {:?}",init,p.status_reads,p.scratch_reads,p.writes);p.init=false;p.status_reads=0;p.writes.clear()});
for value in [b'A',b'B',b'C'] {serial_put(value);PORT.with(|p|{let p=p.borrow();println!("{} {} {:?}",SERIAL.load(Ordering::SeqCst),p.status_reads,p.writes);});}
}
"""
with tempfile.TemporaryDirectory() as td:
    d=Path(td);(d/'model.rs').write_text(driver+model)
    subprocess.run([os.environ['RUSTC'],'--edition=2021',str(d/'model.rs'),'-o',str(d/'model')],check=True)
    out={name:subprocess.check_output([d/'model',name],text=True).splitlines() for name in
         ['absent','fixed-zero','fixed-a5','only-first','healthy','never','edge','late','gone','edge-gone']}
    print(json.dumps(out,indent=2))

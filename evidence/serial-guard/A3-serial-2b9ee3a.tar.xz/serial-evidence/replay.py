from pathlib import Path
from PIL import Image
import hashlib,json
root=Path(__file__).resolve().parent
meta=json.loads((root/'media.json').read_text())
base=json.loads((root/'reference-result.json').read_text())
assert '0 problem(s)' in (root/'port-writes.txt').read_text()
assert meta['kernel_revision']=='2b9ee3aa852045758f31598a6293d9d1734dc26a'
assert len(json.loads((root/'serial-model.json').read_text()))==10
for machine in ('pc','q35'):
    case=root/machine
    r=json.loads((case/'result.json').read_text())
    args=json.loads((case/'argv.json').read_text())
    assert args[args.index('-serial')+1]=='none'
    tree=(case/'qtree.txt').read_text()
    assert 'isa-serial' not in tree and 'pci-serial' not in tree and 'dev:' in tree
    assert all('serial' not in c['label'] for c in r['chardev'])
    assert r['machine']==machine and r['kernel']==meta['kernel'] and r['elf']==meta['disc_files']['tailorbird.elf']
    assert r['iso']==meta['iso']
    for stage,reference in r['frames'].items():
        with Image.open(case/(stage+'.png')) as im:
            assert im.size==(800,600)
            digest=hashlib.sha256(b'P6\n800 600\n255\n'+im.tobytes()).hexdigest()
        assert digest==reference
        if stage in ('app','typed','submit'):
            assert digest==base[stage]['sha256']
    assert 'all 71 self-tests passed' in (case/'home.txt').read_text()
    assert 'POWER OFF' in (case/'confirm.txt').read_text()
    assert any(e.get('event')=='SHUTDOWN' and e['data']=={'guest':True,'reason':'guest-shutdown'} for e in r['events'])
    print(machine,'silent optical frames and guest shutdown verified')

import json
import os
import runpy
import shutil
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
runtime = root.parent
revision = sys.argv[1]
source = root / revision
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
kernel_dir = source / 'PCP_OS_Rust/crates/pcpos-kernel'
kernel = (kernel_dir / 'target/pcpos-kernel.elf32').read_bytes()
measure = runpy.run_path(str(kernel_dir / 'tools/measure.py'))['measure'](kernel)
helper = runpy.run_path(str(source / 'examples/tester-cd/build.py'))
digest = helper['sha']
origin = runtime / 'a3-337-media/800x600'
meta = json.loads((origin / 'media.json').read_text())
original = (origin / 'first.iso').read_bytes()
assert digest(original) == meta['iso']
original_files = helper['read_back'](original)
assert digest(original_files['tailorbird.elf']) == meta['app']
output = root / (revision + '-media')
output.mkdir(exist_ok=True)
stage = output / 'tree'
shutil.copytree(origin / 'tree', stage, dirs_exist_ok=True)
(stage / 'kernel.elf32').write_bytes(kernel)
config = original_files['limine.conf'].decode()
assert config.count(meta['measurement']) == 1
(stage / 'limine.conf').write_text(config.replace(meta['measurement'], measure))
readme = original_files['readme.txt'].decode()
assert readme.count('53a551a297ec35f50917c12efada45f3150ece35') == 1
(stage / 'readme.txt').write_text(readme.replace('53a551a297ec35f50917c12efada45f3150ece35', commit))
env = dict(os.environ, PATH=str(runtime / 'root/usr/bin') + ':' + os.environ['PATH'], LD_LIBRARY_PATH=str(runtime / 'lib'), SOURCE_DATE_EPOCH=str(helper['EPOCH']), LC_ALL='C', TZ='UTC')
for name in ['first.iso', 'second.iso']:
    helper['assemble'](stage, output / name, env)
iso = (output / 'first.iso').read_bytes()
assert iso == (output / 'second.iso').read_bytes()
files = helper['read_back'](iso)
assert files.keys() == original_files.keys()
for name, data in files.items():
    if name in ('kernel.elf32','limine.conf','readme.txt'):
        assert data == (stage / name).read_bytes()
    elif name not in ('boot.cat', 'limine-bios-cd.bin'):
        assert data == original_files[name]
assert files['limine-bios-cd.bin'][:8] + files['limine-bios-cd.bin'][64:] == original_files['limine-bios-cd.bin'][:8] + original_files['limine-bios-cd.bin'][64:]
result = dict(kernel_revision=commit,kernel=digest(kernel),measurement=measure,app=meta['app'],app_source=meta['revision'],iso=digest(iso),prior_iso=digest(original),disc_files={k:digest(v) for k,v in sorted(files.items())})
(output / 'media.json').write_text(json.dumps(result,indent=2)+'\n')
print(commit,result['kernel'],result['iso'])

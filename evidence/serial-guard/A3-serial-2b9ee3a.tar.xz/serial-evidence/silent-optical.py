import json
import hashlib
import runpy
import subprocess
import sys
import time
from pathlib import Path

root=Path(__file__).resolve().parent
rt=root.parent
machine=sys.argv[1]
media=root/'serial-src-media'
out=media/('silent-'+machine)
out.mkdir(exist_ok=True)
meta=json.loads((media/'media.json').read_text())
prior=root/'parent-media/boot-pc'
reference=json.loads((prior/'result.json').read_text())
reader=runpy.run_path(str(root/'parent/examples/tester-cd/check_compact_pins.py'))['read']
glyphs=runpy.run_path(str(root/'parent/examples/tester-cd/check.py'))['kernel_glyphs']()
Qemu=runpy.run_path(str(rt/'a3-tailor-media/app2/guest/tests/qemu_smoke.py'))['Qemu']
args=[str(rt/'bin/qemu-system-x86_64'),'-machine',machine,'-accel','tcg','-cpu','qemu64','-m','64M','-boot','order=d','-cdrom',str(media/'first.iso'),'-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','none']
(out/'argv.json').write_text(json.dumps(args,indent=2))
guest=Qemu.__new__(Qemu)
guest.folder=out
guest.proc=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(out/'stderr.txt').open('wb'),bufsize=0)
report=dict(machine=machine,kernel=meta['kernel'],iso=meta['iso'],elf=meta['app'],frames={})
def capture(name,*,words=(),match=None,timeout=45):
    until=time.monotonic()+timeout
    while time.monotonic()<until:
        time.sleep(.2)
        dim,_,digest=guest.screenshot(name)
        if dim!=(800,600):continue
        if match and digest!=reference[match]['sha256']:continue
        if words:
            lines=reader((out/(name+'.ppm')).read_bytes(),glyphs)
            if not all(word in ' '.join(lines) for word in words):continue
            (out/(name+'.txt')).write_text('\n'.join(lines)+'\n')
        report['frames'][name]=digest
        return
    raise ValueError(name+' screen never matched')
try:
    guest._response()
    guest.qmp('qmp_capabilities')
    tree=guest.qmp('human-monitor-command',**{'command-line':'info qtree'})['return']
    (out/'qtree.txt').write_text(tree)
    assert 'isa-serial' not in tree and 'pci-serial' not in tree
    devs=guest.qmp('query-chardev')['return']
    assert not any('serial' in d['label'] for d in devs)
    report['chardev']=devs
    drives=[b['inserted'] for b in guest.qmp('query-block')['return'] if 'inserted' in b]
    assert len(drives)==1 and drives[0]['ro'] and Path(drives[0]['file']).resolve()==(media/'first.iso').resolve()
    capture('home',words=('Programs','all 71 self-tests passed'))
    guest.key('ret'); capture('list',words=('surf.elf',))
    guest.key('down');capture('selected',words=('tailorbird.elf',))
    guest.key('ret');capture('app',match='app')
    for key in ('h','e','l','l','o'): guest.key(key)
    capture('typed',match='typed')
    guest.key('ret');capture('submit',match='submit')
    guest.key('esc');capture('returned',words=('tailorbird.elf',))
    guest.key('esc');capture('desktop',words=('Programs',))
    guest.key('f10');capture('confirm',words=('POWER OFF',))
    guest.key('ret')
    assert guest.proc.wait(timeout=20)==0
    events=[json.loads(line) for line in guest.proc.stdout.read().splitlines() if line.strip()]
    assert any(e.get('event')=='SHUTDOWN' and e['data'].get('guest') and e['data'].get('reason')=='guest-shutdown' for e in events)
    report['events']=events
    (out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
    print(machine,'verified 71 startup checks on screen, three matching app frames, confirmed shutdown without serial')
finally:
    guest.stop()

"""Launch the USB's unmodified Surfbird from Programs and record its normal outcome on each virtual adapter."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,time
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'src/examples/firmware-owned-uefi'))
import usb_trial as u
adapter=sys.argv[1]
assert adapter in ('ramfb','virtio-vga','std')
usb=root/'peer-usb.img'
info=json.loads((root/'peer-image.json').read_text())
assert u.digest(usb)==info['usb_sha256'] and subprocess.check_output(['git','-C',root/'src','rev-parse','HEAD'],text=True).strip() in info['build']
out=root/('app-'+adapter)
out.mkdir()
qemu='/workspace/scratch/7c7df1723510/work/emulator/qemu-system-x86_64'
fw=root.parent/'a3-313-review/dependencies/usr/share/OVMF'
args=u.usb_command(qemu,fw/'OVMF_CODE_4M.fd',fw/'OVMF_VARS_4M.fd',usb,out,128,'std' if adapter=='std' else 'virtio-vga')
if adapter=='ramfb':
    args[args.index('virtio-vga')]='ramfb'
serial=out/'serial.txt'
def read():return serial.read_text(errors='replace') if serial.exists() else ''
def finished():return re.search(r'^surf\.elf ended .*',read(),re.M)
r=dict(adapter=adapter,usb_sha256=info['usb_sha256'],measurement=info['measurement'],argv=args)
with (out/'stderr.txt').open('wb') as err, subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
    try:
        m=u.OPTICAL['Monitor'](guest)
        rpc=m.call
        rpc('qmp_capabilities')
        r['blocks']=rpc('query-block')
        removable=next(b for b in r['blocks'] if b.get('device')=='stick')
        assert removable['inserted']['ro'] and removable['removable']
        rpc('cont')
        screens=u.OPTICAL['DesktopScreens'](m,out,30,app_digests={'surf.elf':u.make.__globals__['MEMBERS'][0][2]},command_line='image='+info['measurement'])
        screens.home('home')
        r['startup']=sum(l.startswith('  pass ') for l in read().splitlines())
        r['display']=next(l for l in read().splitlines() if l.startswith('display:'))
        assert r['startup']==71 and info['measurement']+' (measured; equal' in read()
        m.key('spc')
        screens.launcher('selected','surf.elf')
        m.key('ret')
        u.OPTICAL['wait_for'](lambda:'SURFBIRD media ready' in read() or finished(),'application startup or terminal result',30)
        r['media_ready']='SURFBIRD media ready' in read()
        rpc('screendump',filename=str(out/'after-launch.ppm'))
        if r['media_ready'] and not finished():
            m.key('spc')
        u.OPTICAL['wait_for'](finished,'application completion',30)
        r['application_end']=finished()[0].strip()
        screens.launcher('returned','surf.elf')
        m.key('f10')
        screens.wait('power',lambda rows:any('Switch PCP OS off?' in x for x in rows))
        m.key('ret')
        u.OPTICAL['wait_for'](lambda:rpc('query-status')['status']=='shutdown','guest shutdown',25)
        r['shutdown']=next(e['data'] for e in m.events if e['event']=='SHUTDOWN')
        rpc('quit')
        r['exit']=guest.wait(timeout=10)
        r['final']=sum(l.startswith('  pass ') for l in read().splitlines())
        assert r['shutdown']=={'guest':True,'reason':'guest-shutdown'} and r['exit']==0 and r['final']==72 and 'ALL SELF-TESTS PASS.' in read()
    finally:
        if guest.poll() is None:guest.kill();guest.wait()
        (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(r['display'],r['media_ready'],r['application_end'],r['final'])

"""Check the application's own terminal status, separately from the guest's shutdown."""
import hashlib
import json
from pathlib import Path
import subprocess
import review_lib
root = Path(__file__).resolve().parent
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
head = subprocess.check_output(['git','-C',root/'src','rev-parse','HEAD'],text=True).strip()
media = json.loads((root/'peer-image.json').read_text())
assert head in media['build'] and media['usb_sha256']==sha(root/'peer-usb.img')
rows={}
files=[root/f for f in ['usb_app.py','read_usb_apps.py','peer-image.json','parse_peer.py','usb-parser-readback.json']]
for adapter,ready in [('ramfb',False),('virtio-vga',False),('std',True)]:
    name='app-'+adapter
    folder=root/name
    record=json.loads((folder/'result.json').read_text())
    serial=(folder/'serial.txt').read_text()
    assert record['startup']==71 and record['final']==72 and record['exit']==0
    assert 'ALL SELF-TESTS PASS.' in serial
    assert record['media_ready']==ready and record['application_end'] in serial
    assert 'starting surf.elf (65304 bytes, SHA-256 b87f1185f86961ff8afdb21315c811f0c071c474d09737613146be46cbb98b34)' in serial
    assert int((root/(name+'.exit')).read_text())==0
    if ready:
        assert 'surf.elf ended DONE: exit 0' in serial and 'SURFBIRD media ready' in serial
    else:
        assert 'display setup failed' in serial and 'surf.elf ended FAILED: exit 2' in serial
        assert '0 frames shown' in record['application_end'] and "0 of them the display's" in record['application_end']
    captures={p.name:sha(p) for p in folder.glob('*.ppm')}
    assert {'home.ppm','selected.ppm','after-launch.ppm','returned.ppm','power.ppm'}==set(captures)
    rows[adapter]={'display':record['display'],'media_ready':ready,'program_outcome':record['application_end'],'guest_shutdown':record['shutdown'],'serial_sha256':sha(folder/'serial.txt'),'captures':captures}
    files.extend(p for p in folder.iterdir() if p.suffix in {'.json','.txt','.ppm'})
    files.extend([root/(name+'.exit'),root/(name+'.log')])
src=root/'src/PCP_OS_Rust/crates/pcpos-kernel/src/dev.rs'
current=src.read_text()
prev=subprocess.check_output(['git','-C',root/'src','show','3cf7752:PCP_OS_Rust/crates/pcpos-kernel/src/dev.rs'],text=True)
def mode(s):
    return s[s.index('pub fn display_set('):].split('\n}',1)[0]+'\n}'
assert mode(current)==mode(prev)
out=root/'usb-application-readback.json'
out.write_text(json.dumps(dict(commit=head,media_sha256=media['usb_sha256'],b3_archive_sha256=sha(root/'b3-usb.tar.xz'),app='surf.elf',requested_mode='640x360',mode_set_function_unchanged_from='3cf7752',outcomes=rows),indent=2)+'\n')
review_lib.tar('usb-application-guests.tar.xz',files+[out])
print([(k,v['program_outcome'].split(' after ')[0]) for k,v in rows.items()])

"""Read both optical boots and two VM processes, checking every recorded frame against its digest."""
import hashlib
import json
import re
import runpy
import subprocess
import tarfile
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent
def rev(repo, what):
    return subprocess.check_output(['git','-C',str(root/repo),'rev-parse',what],text=True).strip()
def load(path):
    return json.loads(path.read_bytes())
def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()

head = rev('src','HEAD')
tree = rev('src','HEAD^{tree}')
checker = rev('distribution','HEAD')
assert checker == '2abeead177d616582db7029561df2e10c95381eb'
parse = runpy.run_path(str(root/'src/examples/tester-cd/check.py'))['launcher_boot_profile']
evidence = { 'source':head, 'tree':tree, 'distribution_checker':checker, 'kernel_suite_build':sha(root/'kernel.elf32'), 'boots':{} }
for name in ['optical-plain','optical-queue','opt-vm/first','opt-vm/cold']:
    folder = root/name
    record = load(folder/'result.json')
    text = (folder/'serial.txt').read_text()
    lines = text.splitlines()
    home = next(i for i,s in enumerate(lines) if 'leaves no memory behind' in s)
    start = sum(s.startswith('  pass ') for s in lines[:home+1])
    end = sum(s.startswith('  pass ') for s in lines)
    assert (start,end,record['exit_code']) == (71,72,0)
    assert 'ALL SELF-TESTS PASS.' in text and not any(s.startswith('  FAIL ') for s in lines)
    command, width, sound = parse(text)
    display = next(s for s in lines if s.startswith('display: '))
    frames = record.get('screen_sha256')
    if frames is not None:
        assert record['source_commit']==head and record['source_tree']==tree and record['startup_pass_lines']==start
        assert record['shutdown']==dict(guest=True,reason='guest-shutdown')
        for n, digest in frames.items():
            assert sha(folder/(n+'.ppm'))==digest
    else:
        frames = record['screen_checks']
        assert any(e.get('event')=='SHUTDOWN' and e.get('data')==dict(guest=True,reason='guest-shutdown') for e in record['events'])
        for n, item in frames.items():
            assert sha(folder/n)==item['sha256']
    file = folder/('home.ppm' if name.startswith('optical') else 'home-at-start.ppm')
    with file.open('rb') as image:
        assert image.readline()==b'P6\n'
        native_width, height = map(int,image.readline().split())
    assert width==native_width
    evidence['boots'][name] = dict(startup=start,final=end,exit=0,display=display,parser_width=width,frame_size=[width,height],parsed_sound=sound,checked_frames=len(frames),serial_sha256=sha(folder/'serial.txt'))
for flavor in ['plain','queue']:
    rec=load(root/flavor/'receipt.json')
    assert rec['source_commit']==head and rec['source_tree']==tree and rec['uncommitted_changes'] is False
    evidence[flavor]=dict(iso=rec['iso_sha256'],kernel=rec['inputs']['kernel.elf32']['sha256'],measurement=rec['kernel_measurement'])
for task in ['optical-plain','optical-queue','opt-vm']:
    assert int((root/(task+'.exit')).read_text())==0
workspace=load(root/'opt-vm/result.json')
assert workspace['zip_sha256']==sha(root/'workspace.zip') and workspace['saved_disk_sha256']==sha(root/'opt-vm/fixture.raw')
with zipfile.ZipFile(root/'workspace.zip') as z:
    build=json.loads(z.read('build.json'))
    assert build['source_commit']==head and build['source_tree']==tree
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in build['files'].items())
    evidence['vm_build']=build
    (root/'workspace-build.json').write_text(json.dumps(build,indent=2)+'\n')
evidence['vm_store']=workspace
(root/'distribution-readback.json').write_text(json.dumps(evidence,indent=2)+'\n')
files=[p for n in ['optical-plain','optical-queue','opt-vm'] for p in (root/n).rglob('*') if p.is_file()]
files += [root/n for n in ['distribution-readback.json','artifacts.json','hosted-pins.json','plain/receipt.json','queue/receipt.json','workspace-build.json','check-distribution.sh','read_discs.py','read_distribution.py','rust-framebuffer.log','optical-plain.log','optical-queue.log','opt-vm.log','opt-vm.exit','optical-plain.exit','optical-queue.exit']]
seen={}
with tarfile.open(root/'distribution-guests.tar.xz','w:xz',preset=1) as archive:
    for f in sorted(files):
        n=str(f.relative_to(root))
        h=sha(f)
        if h in seen:
            item=archive.gettarinfo(str(f),n)
            item.type=tarfile.LNKTYPE
            item.linkname=seen[h]
            item.size=0
            archive.addfile(item)
        else:
            archive.add(f,arcname=n,recursive=False)
            seen[h]=n
with tarfile.open(root/'distribution-guests.tar.xz') as archive:
    for entry in archive:
        if entry.islnk():
            assert sha(root/entry.name)==sha(root/entry.linkname)
        else:
            assert hashlib.file_digest(archive.extractfile(entry),'sha256').hexdigest()==sha(root/entry.name)
print(json.dumps(evidence['boots'],indent=2))

#!/bin/bash
set -eu
cd "$(dirname "$0")"
export PATH="$(realpath ../distribution-f77/bin):$PATH"
qemu=/workspace/scratch/7c7df1723510/work/emulator/qemu-system-x86_64
checker=distribution/audit
case "$1" in
  plain|queue)
    python3 read_discs.py "$1"
    python3 "$checker/public-live-cd/check_host_boot.py" "$1/pcp-os-tester.iso" "optical-$1" --desktop-build "$PWD/src" "$PWD/$1/receipt.json" --qemu "$qemu"
    ;;
  vm)
    python3 - <<'PY'
import json,hashlib,pathlib,zipfile,subprocess
root=pathlib.Path.cwd()
record=next(a for a in json.loads((root/'artifacts.json').read_text()) if a['name']=='vm-store-queue')
z=root/'vm-store-queue.zip'
assert record['workflow_run']['head_sha']==subprocess.check_output(['git','-C','src','rev-parse','HEAD'],text=True).strip()
assert 'sha256:'+hashlib.sha256(z.read_bytes()).hexdigest()==record['digest']
with zipfile.ZipFile(z) as archive:
    target=root/'src/PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32'
    assert (root/'kernel.elf32').is_file()
    target.write_bytes(archive.read('kernel.elf'))
PY
    python3 "$checker/vm-workspace/build.py" "$PWD/src" "$PWD/queue" "$checker/vm-workspace/pcp-vm-workspace.zip" workspace.zip
    python3 "$checker/vm-workspace/check.py" workspace.zip "$PWD/src" opt-vm --desktop-first --qemu "$qemu"
    ;;
esac

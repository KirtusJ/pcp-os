# Two firmware profiles on the same USB

Director B3 used the read-only USB from the KirtusJ/pcp-os workflow for commit 751f40c5be636b474b9fe92f2608621acdf72040. QEMU 10.0.13 used disposable Q35/TCG guests and Debian OVMF.

The 128 MiB guest reached Home, passed 72 checks, restored its initial Home frame byte for byte after F5/Esc, and shut down on request. The 256 MiB factory-enrolled Microsoft Secure Boot profile refused the USB before PCP OS entered. The device-specific refusal appears in the original serial and P6. The host stopped this guest at the firmware prompt.

The archive contains both guests’ original serials, frames, firmware state and result records, the unmodified USB image, and its hosted image manifest. The enrolled test’s command is in enrolled/result.json and the ordinary test’s command is in ordinary/result.json. Each was executed by a local PCP OS hosted worker. Paths in those records identify the original run. The immutable source of the USB checker and the original workflow are linked below.

[Exact USB checker](https://github.com/KirtusJ/pcp-os/blob/751f40c5be636b474b9fe92f2608621acdf72040/examples/firmware-owned-uefi/usb_trial.py) · [Hosted USB artifact](https://github.com/KirtusJ/pcp-os/actions/runs/44903435629/artifacts/14706499167)

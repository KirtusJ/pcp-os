# Hosted USB on two OVMF profiles

B3 downloaded artifact 14709620766 from workflow 44910215712 on commit 926c888e01e2892d0378d7992f7224e7dbf5c868. The ZIP digest was 1b9729ac4a7cbb28141a7aa40b5b33ccf462d4acebb4ec78910c0dda2928f75d. The hosted image receipt identifies a clean source tree. The USB used in these three fresh, local QEMU guests is included.

In ordinary/ the virtio VGA guest’s physical boot header reported 0x104c, three modules, a 32-bit direct-colour framebuffer at 0x80000000, 5120 bytes per line, 1280×800 pixels and BGR channel positions. The kernel reported the same address, showed Home, passed 72 checks and shut down on request. A second guest in observer/ ran the full USB observer through F5, Esc, F10 and Enter. The Home frames matched, the internal drive had zero write operations and the firmware variables were unchanged after Home.

In enrolled/ a fresh 256 MiB Q35 guest used the stock Microsoft-enrolled OVMF template with Secure Boot enabled and SMM. Firmware reported Access Denied when loading the same USB. The console and serial preserve the refusal. The loader trace was empty and the kernel did not enter. The host stopped the guest at the firmware prompt. The extracted EFI application's PE certificate directory was empty. Security variables PK, KEK, db, dbx, SecureBootEnable and CustomMode had the same contents before and after. All runs used QEMU 10.0.13 on the B3 Linux host. No physical machine was run.

The individual guest commands and input hashes are in their result.json files. The image.json file here is the original hosted manifest. The ordinary boot and enrolled refusal used the same USB SHA-256, fe8bc66801f2eef6125bd03f7ec2b15fab1fc13307dd93a7f52c0cfdcdc827aa.

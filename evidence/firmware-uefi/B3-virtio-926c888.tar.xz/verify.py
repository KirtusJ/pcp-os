"""Read the observed Multiboot information and recheck guest evidence after extraction."""
from pathlib import Path
import hashlib
import json
import struct
import sys

root=Path(__file__).resolve().parent if len(sys.argv)<2 else Path(sys.argv[1])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
manifest=read(root/'image.json') if (root/'image.json').exists() else read(root/'build/image.json')
usb=root/'usb.img' if (root/'usb.img').exists() else root/'build/usb.img'
assert sha(usb)==manifest['usb_sha256']
expected={'std':(0x80000000,5120,1280,800,72),'virtio-vga':(0x80000000,5120,1280,800,72),'ramfb':(0x6a3f000,3200,800,600,71)}
for dev,values in expected.items():
    d=root/'guests'/dev
    j=read(d/'result.json')
    b=(d/'boot-info.bin').read_bytes()
    assert int.from_bytes(b[0:4],'little')==0x104c and int.from_bytes(b[20:24],'little')==3
    address,pitch,width,height=struct.unpack_from('<QIII',b,88)
    assert (address,pitch,width,height)==values[:4]
    assert list(b[108:116])==[32,1,16,8,8,8,0,8]
    assert j['usb_sha256']==j['usb_after']==manifest['usb_sha256'] and j['disk_before']==j['disk_after']
    assert j['exit']==0 and j['shutdown']=={'guest':True,'reason':'guest-shutdown'} and j['all_pass'] and j['pass_lines']==values[4]
    assert manifest['measurement']+' (measured; equal' in (d/'serial.txt').read_text()
    if dev=='ramfb':assert j['desktop'] is None
    if dev=='virtio-vga':assert j['display'].startswith('display: Loader, 1280x800') and j['desktop'].startswith('desktop: 1280x800')
    print(dev,hex(address),width,height,j['display'])
for name in ('std-128','std-256','virtio-vga-128'):
    d=root/'full'/name
    j=read(d/'result.json')
    assert j['passed'] and j['self_tests']==72 and j['exit']==0
    assert j['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    assert sha(d/'home.ppm')==sha(d/'home-after-verification.ppm') and sha(d/'home-verification.ppm')!=sha(d/'home.ppm')
    assert all(s['nvme_sha256']==j['nvme_sha256_after_quit'] and sha(d/s['vars_snapshot'])==s['vars_sha256'] for s in j['snapshots'])
    assert all(i['nvme_bytes_preserved'] and i['counter_deltas']['sentinel']['wr_operations']==0 for i in j['intervals'])
    assert j['intervals'][-1]['vars_bytes_changed']==j['intervals'][-1]['counter_deltas']['varstore']['wr_operations']==0
    assert j['usb_sha256_after']==manifest['usb_sha256']
    print(name,'Home / Verification / identical Home; zero internal disk writes; guest shutdown')

import hashlib,json,sys
from pathlib import Path
base=Path(sys.argv[1])
for name in ('128','256','negative'):
    path=base/name
    r=json.loads((path/'result.json').read_text())
    note=json.loads((path/'home-check.json').read_text())
    def digest(n):return hashlib.sha256((path/n).read_bytes()).hexdigest()
    assert digest('home.ppm')==note['home_sha256'] and digest('home-after-verification.ppm')==note['after_esc_sha256']
    if name=='negative':
        assert not r['passed'] and not note['same'] and len(note['substitutions'])==1 and note['rejection']=='Esc from Verification did not restore the original Home frame'
        assert digest('home.ppm')!=digest('home-after-verification.ppm') and not (path/'power.ppm').exists()
    else:
        assert r['passed'] and note['same'] and r['exit']==0 and r['self_tests']==72 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
        assert r['nvme_sha256_after_quit']==digest('internal.raw') and r['vars_sha256_after_quit']==digest('vars.fd')
        assert all(i['nvme_bytes_preserved'] and i['counter_deltas']['sentinel']['wr_operations']==0 for i in r['intervals'])
        assert sum(line.startswith('  pass ') for line in (path/'serial.txt').read_text().splitlines())==72
    print(name,note['same'],note['rejection'] or 'guest shutdown')

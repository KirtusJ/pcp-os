"""Run the corrected USB trial with its original hosted media; optional negative input substitutes one captured P6."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sys

here=Path(__file__).resolve().parent
root=here.parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('case',choices=['128','256','negative'])
parser.add_argument('--repo',type=Path,default=root/'validation/313-home-guard')
parser.add_argument('--inputs',type=Path,default=root/'usb-cross-host/inputs.json')
parser.add_argument('--media',type=Path,default=root/'usb-cross-host/hosted-usb.img')
parser.add_argument('--firmware',type=Path,default=root/'validation/pkg/root/usr/share/OVMF')
parser.add_argument('--qemu',type=Path,default=root/'validation/bin/qemu-system-x86_64')
parser.add_argument('--changed-home',type=Path,default=root/'display-check/positive/home-both.ppm')
parser.add_argument('--out',type=Path,default=here)
args=parser.parse_args()
source=args.repo.resolve()/'examples/firmware-owned-uefi'
sys.path.insert(0,str(source))
import usb_trial

inputs=json.loads(args.inputs.read_text())
image=inputs['input']
media=args.media.resolve()
firmware=args.firmware.resolve()
qemu=args.qemu.resolve()
case=args.out.resolve()/args.case
def sha(data):return hashlib.sha256(data).hexdigest()
assert sha(media.read_bytes())==image['usb_sha256']
assert sha((firmware/'OVMF_CODE_4M.fd').read_bytes())==inputs['firmware_sha256']
assert sha((firmware/'OVMF_VARS_4M.fd').read_bytes())==inputs['initial_vars_sha256']
changed=args.changed_home.resolve()
substitutions=[]
diagnostic='Esc from Verification did not restore the original Home frame'
if args.case=='negative':
    original_monitor=usb_trial.OPTICAL['Monitor']
    class SubstituteCapture(original_monitor):
        def call(self, name, **fields):
            result=super().call(name,**fields)
            target=Path(fields['filename']) if name=='screendump' else None
            if target and target.name=='home-after-verification.ppm':
                actual=target.read_bytes()
                orig=(case/'home.ppm').read_bytes()
                if actual==orig:
                    assert changed.read_bytes()!=orig
                    shutil.copyfile(changed,target)
                    substitutions.append({'observed_guest_home':sha(actual),'supplied_native_home':sha(target.read_bytes())})
            return result
    usb_trial.OPTICAL['Monitor']=SubstituteCapture
try:
    usb_trial.trial(str(qemu),firmware/'OVMF_CODE_4M.fd',firmware/'OVMF_VARS_4M.fd',media,image,case,256 if args.case=='negative' else int(args.case))
except ValueError as exc:
    if args.case!='negative' or str(exc)!=diagnostic:raise
    rejection=str(exc)
else:
    if args.case=='negative': raise AssertionError('changed Home was accepted')
    rejection=None
receipt=json.loads((case/'result.json').read_text())
original=sha((case/'home.ppm').read_bytes()); restored=sha((case/'home-after-verification.ppm').read_bytes())
summary={'case':args.case,'home_sha256':original,'after_esc_sha256':restored,'same':original==restored,
         'usb_sha256':sha(media.read_bytes()),'efi_sha256':image['efi_sha256'],'measurement':image['measurement'],
         'nvme':receipt.get('nvme_sha256_after_quit'),'serial_pass_lines':sum(x.startswith('  pass ') for x in (case/'serial.txt').read_text().splitlines()),
         'complete_guest':receipt['passed'],'guest_shutdown':receipt.get('shutdown'),'exit':receipt.get('exit'),
         'rejection':rejection,'substitutions':substitutions}
if rejection:
    assert len(substitutions)==1 and not receipt['passed'] and original!=restored and not (case/'power.ppm').exists()
else:
    assert receipt['passed'] and original==restored and receipt['self_tests']==72 and receipt['exit']==0
    assert receipt['shutdown']=={'guest':True,'reason':'guest-shutdown'}
(case/'home-check.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))

from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
root=Path(__file__).resolve().parent
source=root/'src'
sys.path.insert(0,str(source/'examples/firmware-owned-uefi'))
import usb_trial
profiles={'128':(128,'std'),'256':(256,'std'),'virtio-vga':(128,'virtio-vga'),'ramfb-128':(128,'ramfb'),'ramfb-256':(256,'ramfb')}
def rev(ref):
    return subprocess.check_output(['git','-C',source,'rev-parse',ref],text=True).strip()
if __name__=='__main__':
    case=sys.argv[1]
    media=root/'hosted-usb.img'
    with zipfile.ZipFile(root/'full-heap-usb-observations.zip') as z:
        info=json.loads(z.read('usb-observations/image.json'))
        assert info['experiment_commit']==rev('HEAD') and info['experiment_tree']==rev('HEAD^{tree}')
        if case=='prepare':
            media.write_bytes(z.read('usb-observations/usb.img'))
            (root/'image.json').write_text(json.dumps(info,indent=2)+'\n')
            assert usb_trial.digest(media)==info['usb_sha256']
            sys.exit(0)
    assert usb_trial.digest(media)==info['usb_sha256']
    ram,video=profiles[case]
    fw=root.parent/'a3-313-review/dependencies/usr/share/OVMF'
    qemu='/workspace/scratch/7c7df1723510/work/emulator/qemu-system-x86_64'
    result=usb_trial.trial(qemu,fw/'OVMF_CODE_4M.fd',fw/'OVMF_VARS_4M.fd',media,info,root/case,ram,video)
    assert result['passed'] and result['self_tests']==72 and result['exit']==0
    print(case,result.get('loader_display'),result['self_tests'],result['shutdown'])

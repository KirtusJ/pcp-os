from pathlib import Path
import hashlib,json,re,subprocess,tarfile,zipfile
from run_usb import root,rev,profiles,usb_trial as u
sha=lambda raw:hashlib.sha256(raw).hexdigest()
hardware={}
zfile=root/'full-heap-usb-observations.zip'
assert sha(zfile.read_bytes())=='106ef6eea5788ed0c238fd52ed332253eb6977130bfca1dddbb26f200d8df22a'
with zipfile.ZipFile(zfile) as archive:
    for case in profiles:
        pair={}
        for tag in ['local','hosted']:
            def blob(name):
                return (root/case/name).read_bytes() if tag=='local' else archive.read('usb-observations/'+case+'/'+name)
            r=json.loads(blob('result.json'))
            serial=blob('serial.txt').decode(errors='replace').splitlines()
            before=next(i for i,row in enumerate(serial) if 'leaves no memory behind' in row)
            assert sum(s.startswith('  pass ') for s in serial[:before+1])==71
            assert sum(s.startswith('  pass ') for s in serial)==72 and r['self_tests']==72 and r['passed']
            assert r['exit']==0 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
            assert sha(blob('home.ppm'))==sha(blob('home-after-verification.ppm'))
            assert all(x['nvme_bytes_preserved'] and x['counter_deltas']['sentinel']['wr_operations']==0 and x['counter_deltas']['sentinel']['unmap_operations']==0 for x in r['intervals'])
            assert r['snapshots'][1]['vars_sha256']==r['snapshots'][2]['vars_sha256']
            disk=sha(blob('internal.raw'))
            assert disk==r['nvme_sha256_after_quit']
            pair[tag]=dict(home_sha256=sha(blob('home.ppm')),serial_sha256=sha(blob('serial.txt')),disk_sha256=disk,
                           display=next(s for s in serial if s.startswith('display:')),address=r.get('framebuffer_address'),
                           startup=71,final=72,exit=r['exit'])
        for k in ('home_sha256','disk_sha256'):
            assert pair['local'][k]==pair['hosted'][k]
        hardware[case]=pair
for tag in ('local','hosted'):
    assert hardware['ramfb-128'][tag]['address']!=hardware['ramfb-256'][tag]['address']
def pieces(p):
    return ((p/'serial.txt').read_text(),(p/'firmware.txt').read_text().splitlines(),p/'home.ppm')
base=list(pieces(root/'ramfb-128'))
address_base=u.loader_picture(*base)
assert address_base[1]==hardware['ramfb-128']['local']['address']
old=root.parent/'a3-merged316/virtio'
cases={'other_ramfb_firmware':[base[0],pieces(root/'ramfb-256')[1],base[2]],
       'other_home_capture':[base[0],base[1],pieces(root/'virtio-vga')[2]],'older_virtio_4096_KiB':pieces(old)}
neg={}
for name,args in cases.items():
    try:u.loader_picture(*args)
    except ValueError as e:neg[name]=str(e)
    else:raise ValueError('unexpected acceptance of '+name)
assert len(neg)==3
out=root/'usb-readback.json'
out.write_text(json.dumps(dict(head=rev('HEAD'),tree=rev('HEAD^{tree}'),artifact=14713207690,run=44920327496,artifact_sha256=sha(zfile.read_bytes()),usb_sha256=sha((root/'hosted-usb.img').read_bytes()),firmware_code_sha256=sha((root.parent/'a3-313-review/dependencies/usr/share/OVMF/OVMF_CODE_4M.fd').read_bytes()),older_control_commit='70dc1b4092d421e7f77b08072ad5fa056bded5ed',pairs=hardware,rejected_observations=neg),indent=2)+'\n')
files=[root/n for n in ['run_usb.py','read_trials.py','usb-readback.json','image.json']]
for case in profiles:
    files.extend(p for p in (root/case).iterdir() if p.suffix in {'.txt','.json','.ppm','.fd','.raw'})
    files.extend(root/(case+e) for e in ['.exit','.log'])
seen={}
with tarfile.open(root/'five-usb-guests.tar.xz','w:xz',preset=1) as t:
    for name,p in [(str(f.relative_to(root)),f) for f in files]+[('previous-virtio/'+n,old/n) for n in ('serial.txt','firmware.txt','home.ppm')]:
        h=sha(p.read_bytes())
        if h in seen:
            m=t.gettarinfo(str(p),name);m.type=tarfile.LNKTYPE;m.linkname=seen[h];m.size=0;t.addfile(m)
        else:
            t.add(p,arcname=name,recursive=False);seen[h]=name
with tarfile.open(root/'five-usb-guests.tar.xz') as t:
    for m in t:
        if m.islnk():assert m.linkname in seen.values()
        else:assert hashlib.file_digest(t.extractfile(m),'sha256').hexdigest() in seen
print(neg);print([(k,hex(hardware[k]['local']['address']),hex(hardware[k]['hosted']['address'])) for k in ['ramfb-128','ramfb-256']])

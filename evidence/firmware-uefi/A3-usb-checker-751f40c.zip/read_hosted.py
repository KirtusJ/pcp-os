from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import struct, json, runpy, re, subprocess
source=Path('source').resolve()
dest=Path('evidence')
def load_file(path):
    return runpy.run_path(str(source/path))
checker=load_file('examples/tester-cd/check.py')
glyphs=checker['kernel_glyphs']()
opt=load_file('examples/optical-disk-check/check.py')
variables=load_file('examples/firmware-owned-uefi/usb_observer.py')['variables']
measure=load_file('PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py')['measure']
def digest(data):return sha256(data).hexdigest()
def doc(z,n):return json.loads(z.read(n))
def efi(img):
    u16=lambda b,o:struct.unpack_from('<H',b,o)[0]
    bps=u16(img,11);spc=img[13];reserved=u16(img,14);fats=img[16];entries=u16(img,17);fatsecs=u16(img,22)
    root=(reserved+fats*fatsecs)*bps; start=root+((32*entries+bps-1)//bps)*bps
    fat=img[reserved*bps:(reserved+fatsecs)*bps]
    assert b'FAT12' in img[:96]
    def chain(cluster):
        parts=[];seen=set()
        while 2<=cluster<0xff0:
            assert cluster not in seen
            seen.add(cluster);ofs=start+(cluster-2)*bps*spc;parts.append(img[ofs:ofs+bps*spc])
            pair=u16(fat,cluster*3//2);cluster=pair>>4 if cluster%2 else pair&4095
        assert cluster>=0xff8
        return b''.join(parts)
    directory=img[root:root+32*entries]
    for name in (b'EFI        ', b'BOOT       ', b'BOOTX64 EFI'):
        matches=[directory[i:i+32] for i in range(0,len(directory),32) if directory[i:i+11]==name]
        assert len(matches)==1
        ent=matches[0];directory=chain(u16(ent,26))
    return directory[:struct.unpack_from('<I',ent,28)[0]]
with ZipFile(dest/'full-heap-usb-observations.zip') as z, ZipFile(dest/'full-heap-ownership.zip') as optical:
    base='usb-observations/'; control='usb-write-control/'; img=doc(z,base+'image.json')
    assert img['experiment_commit']==subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
    assert img['experiment_tree']==subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD^{tree}'],text=True).strip() and img['experiment_dirty'] is False
    usb=z.read(base+'usb.img'); loader=efi(usb)
    assert digest(usb)==img['usb_sha256'] and digest(loader)==img['efi_sha256'] and loader[:2]==b'MZ'
    kernel=optical.read('kernel.elf32')
    assert digest(kernel)==img['elf_sha256'] and measure(kernel)==img['measurement']
    baseline,marker=opt['make_gpt_disk'](512); c=doc(z,control+'result.json')
    ctrl=[z.read(control+s['vars_snapshot']) for s in c['stages']]
    assert variables(ctrl[0])=={} and len(variables(ctrl[1]))==24 and len(variables(ctrl[2]))==25
    assert set(variables(ctrl[2]))-set(variables(ctrl[1]))=={'86a1bff3-4b7c-4860-99da-1056de89abaa/PcpUsbObserverControl'}
    assert sum(a!=b for a,b in zip(ctrl[1],ctrl[2]))==124 and ctrl[2]==ctrl[3]==z.read(control+'vars.fd')
    raw=z.read(control+'internal.raw'); offsets=[i for i,(a,b) in enumerate(zip(baseline,raw)) if a!=b]
    assert len(offsets)==7 and marker in offsets and offsets==c['changed_disk_offsets']
    assert c['stages'][2]['counters']['sentinel']['wr_bytes']-c['stages'][1]['counters']['sentinel']['wr_bytes']==65536
    for ram in ['128','256']:
        p=base+ram+'/';r=doc(z,p+'result.json');snaps=r['snapshots'];log=z.read(p+'serial.txt').decode()
        assert r['exit']==0 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'} and 'USB(0x0,0x0)' in r['firmware_boot_device']
        assert img['measurement']+' (measured; equal' in log and len(re.findall(r'^  pass ',log,re.M))==72
        assert len(re.findall(r'^  pass ',log.split('desktop:')[0],re.M))==71
        assert z.read(p+'internal.raw')==baseline
        assert all(s['nvme_sha256']==digest(baseline) and not any(v for k,v in s['counters']['sentinel'].items() if k.startswith(('wr_','unmap_','failed_wr','invalid_wr','failed_unmap','invalid_unmap'))) for s in snaps)
        v=[z.read(p+s['vars_snapshot']) for s in snaps]
        assert all(digest(b)==s['vars_sha256'] and variables(b)==s['variables'] for b,s in zip(v,snaps))
        assert v[0]==ctrl[0] and v[1]==ctrl[1] and sum(a!=b for a,b in zip(v[0],v[1]))==16248 and v[1]==v[2]==z.read(p+'vars.fd')
        assert z.read(p+'home.ppm')==z.read(p+'home-after-verification.ppm')
        verify=checker['read_screen'](z.read(p+'home-verification.ppm'),glyphs)
        assert checker['verification_screen'](verify)
        power=checker['read_screen'](z.read(p+'power.ppm'),glyphs)
        assert [power[i].strip() for i in (1,3,5,6,-2)]==['POWER OFF','Switch PCP OS off?','The register is closed and verified first. Files of this session that were','not saved by a program are lost.','Enter switch off    Esc go back']
        print(ram,verify[6],len(variables(v[1])),digest(v[1]),flush=True)
    for folder in ('128-G','256-R','128-X'):
        r=doc(optical,folder+'/result.json')
        if folder.endswith('X'):assert r['refused_before_write']
        else:assert r['exit_code']==0 and r['nvs_at_launcher']==r['nvs_after_stop']
    print('separate control changed',len(offsets),'disk bytes, 124 VARS bytes; all assertions passed')

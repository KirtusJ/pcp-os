"""Exercise the unchanged USB trial with its current hosted image and a real changed-Home control."""
from pathlib import Path
from hashlib import sha256
import json
import sys
import time

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'source/examples/firmware-owned-uefi'))
import usb_trial

case = sys.argv[1]
ram = 256 if case == 'changed-home' else int(case)
out = root / case
firmware = root / 'dependencies/usr/share/OVMF'
qemu = '/workspace/scratch/7c7df1723510/work/emulator/qemu-system-x86_64'
usb = root / 'candidate.img'
image = json.loads((root / 'image.json').read_bytes())
assert sha256(usb.read_bytes()).hexdigest() == image['usb_sha256']
if case == 'changed-home':
    class PinBeforeVerification(usb_trial.OPTICAL['DesktopScreens']):
        def verification(self, prefix):
            self.monitor.key('ret')
            self.wait('open-programs', lambda rows: any('surf.elf' in r for r in rows) and any('may use:' in r for r in rows))
            self.monitor.key('ctrl', 'p')
            time.sleep(.4)
            self.monitor.key('esc')
            self.home('after-real-pin')
            original = (self.directory / 'home.ppm').read_bytes()
            changed = (self.directory / 'after-real-pin.ppm').read_bytes()
            assert original != changed
            super().verification(prefix)
    usb_trial.OPTICAL['DesktopScreens'] = PinBeforeVerification

rejection = None
try:
    usb_trial.trial(qemu, firmware / 'OVMF_CODE_4M.fd', firmware / 'OVMF_VARS_4M.fd', usb, image, out, ram)
except ValueError as err:
    if case != 'changed-home' or str(err) != 'Esc from Verification did not restore the original Home frame':
        raise
    rejection = str(err)
result = json.loads((out / 'result.json').read_bytes())
files = ('home.ppm','home-after-verification.ppm')
frames = [sha256((out / f).read_bytes()).hexdigest() for f in files]
if case == 'changed-home':
    assert rejection and result['passed'] is False and frames[0] != frames[1]
    assert not (out / 'power.ppm').exists()
    assert sha256((out / 'after-real-pin.ppm').read_bytes()).hexdigest() == frames[1]
else:
    assert frames[0] == frames[1] and result['passed'] and result['self_tests'] == 72
    assert result['exit'] == 0 and result['shutdown'] == {'guest':True,'reason':'guest-shutdown'}
print(json.dumps({'case':case,'frames':frames,'passed':result['passed'],'rejection':rejection,'checks':result.get('self_tests'),'exit':result.get('exit')}))

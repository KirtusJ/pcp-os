"""Verify the original exhibit and read the guest evidence without relying on its summary."""
from pathlib import Path
import hashlib
import json
import struct
import tarfile

def sha(b):
    return hashlib.sha256(b).hexdigest()
archive=Path('b3.tar.xz')
git_blob=hashlib.sha1(f'blob {archive.stat().st_size}\0'.encode()+archive.read_bytes()).hexdigest()
assert git_blob=='b4438805aa2931a98d7a2ec1fd0f8b699bcf53d6'
out={'b3_archive_sha256':sha(archive.read_bytes()),'b3_archive_git_blob':git_blob,'b3_modes':{}}
with tarfile.open(archive) as t:
    def read(path):
        file=t.extractfile(path)
        assert file is not None
        return file.read()
    entries={}
    for line in read('SHA256SUMS').decode().splitlines():
        expected,path=line.split('  ',1)
        assert path not in entries and sha(read(path))==expected
        entries[path]=expected
    assert set(entries)=={m.name for m in t if m.isfile()}-{'SHA256SUMS'}
    out['verified_manifest_files']=len(entries)
    img=json.loads(read('image.json'))
    for mode in ('std','ramfb','virtio-vga'):
        pref='guests/'+mode+'/'
        rec=json.loads(read(pref+'result.json'))
        log=read(pref+'serial.txt').decode(errors='replace')
        checks=[ln.removeprefix('  pass ') for ln in log.splitlines() if ln.startswith('  pass ')]
        assert rec['measurement']+' (measured; equal' in log and 'ALL SELF-TESTS PASS.' in log
        assert len(checks)==rec['pass_lines'] and rec['exit']==0 and rec['shutdown']=={'guest':True,'reason':'guest-shutdown'}
        original,final=[read(pref+name+'.ppm') for name in ('firmware-window','kernel-display')]
        equal=original==final
        assert equal==(mode!='std')
        assert rec['usb_sha256']==rec['usb_after']==img['usb_sha256']
        out['b3_modes'][mode]={'checks':len(checks),'check_names':checks,'automatic_shutdown':mode!='std','recorded_exit':rec['exit'],'firmware_frame_equals_final_frame':equal,'final_frame_sha256':sha(final)}
    h=read('header-control/ramfb/boot-info.bin')
    flags,=struct.unpack_from('<I',h,0)
    modules,=struct.unpack_from('<I',h,20)
    assert flags==0x4c and not(flags&(1<<12)) and modules==3 and h[88:110]==bytes(22)
    out['b3_ramfb_handoff']={'bytes':len(h),'flags':hex(flags),'module_count':modules,'framebuffer_flag_set':bool(flags&(1<<12)),'raw_framebuffer_fields':h[88:110].hex()}
ref=out['b3_modes']['std']['check_names']
for d in out['b3_modes'].values():
    d['std_checks_absent']=[a for a in ref if a not in d['check_names']]
    del d['check_names']
Path('originals-readback.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({m:v['std_checks_absent'] for m,v in out['b3_modes'].items()}))

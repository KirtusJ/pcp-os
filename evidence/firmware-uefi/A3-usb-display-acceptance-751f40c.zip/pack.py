from pathlib import Path
from hashlib import sha256
import json
import zipfile

root=Path('.')
def digest(p):
    return sha256(p.read_bytes()).hexdigest()
b=json.loads(Path('originals-readback.json').read_bytes())
summary={'source':'751f40c5be636b474b9fe92f2608621acdf72040','checker_git_blob':'726ba33295681153adad7be2351283d786ae14eb','usb_source':'https://github.com/KirtusJ/pcp-os/actions/runs/44903435629/artifacts/14706499167','comparison':'https://github.com/KirtusJ/pcp-os/blob/43effee02dfc296e824c2575cbace350b009d7c8/evidence/firmware-uefi/B3-USB-display-handoff-751f40c.tar.xz','originals_readback':b,'fresh_guests':{}}
files=[Path(s) for s in ('usb_display.py','inspect_originals.py','pack.py','originals-readback.json')]
for mode in ('std','ramfb','virtio-vga'):
    d=Path(mode)
    r=json.loads((d/'readback.json').read_bytes())
    reference=b['b3_modes'][mode]
    same=r['last_frame_sha256']==reference['final_frame_sha256']
    assert same and r['measurement_matched'] and r['all_self_tests_pass'] and r['serial_checks']==reference['checks']
    assert r['checker_passed']==r['power_screen_seen']==(mode=='std')
    if mode=='std':
        assert r['checker_error'] is None and r['checker_recorded_exit']==0 and r['checker_recorded_shutdown']['guest']
        assert (d/'home.ppm').read_bytes()==(d/'home-after-verification.ppm').read_bytes()
    else:
        assert r['checker_error']=={'type':'TimeoutError','message':'waiting for home framebuffer'}
        assert r['desktop'] is None and r['checker_recorded_exit'] is None
        assert not (d/'home-after-verification.ppm').exists() and not (d/'power.ppm').exists()
    r['last_frame_matches_b3_guest']=same
    summary['fresh_guests'][mode]=r
    files.extend(p for p in sorted(d.iterdir()) if p.suffix in ('.ppm','.txt','.json'))
p=Path('A3-usb-display-acceptance-751f40c.json')
p.write_text(json.dumps(summary,indent=2)+'\n')
files.append(p)
archive=Path('A3-usb-display-acceptance-751f40c.zip')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for p in files:z.write(p)
    z.writestr('SHA256SUMS',''.join(digest(p)+'  '+str(p)+'\n' for p in files))
    z.writestr('README.md','Use a new directory and check out KirtusJ/pcp-os at the source commit in the JSON. Extract usb-observations/usb.img and usb-observations/image.json from the linked hosted USB artifact. Run python3 usb_display.py VIDEO --source CHECKOUT --qemu QEMU-BINARY --firmware OVMF-DIRECTORY --usb usb.img --receipt image.json --out VIDEO once for std, ramfb, and virtio-vga. Use a fresh output directory per mode. The tracked usb_trial.trial function, Home detector and original timeout are unchanged. Each result.json preserves the emulator command. The home.ppm for a timed-out trial contains the last sampled framebuffer. Download the linked B3 exhibit as b3.tar.xz to run python3 inspect_originals.py and python3 pack.py.\n')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(len(files),archive.stat().st_size,digest(archive))

"""Run the source USB acceptance check with one selected virtual display."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('video', choices=('std', 'ramfb', 'virtio-vga'))
parser.add_argument('--source', required=True, type=Path)
parser.add_argument('--qemu', required=True, type=Path)
parser.add_argument('--firmware', required=True, type=Path)
parser.add_argument('--usb', required=True, type=Path)
parser.add_argument('--receipt', required=True, type=Path)
parser.add_argument('--out', required=True, type=Path)
args = parser.parse_args()
source = args.source.resolve()
sys.path.insert(0, str(source/'examples/firmware-owned-uefi'))
import usb_trial

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
commit = '751f40c5be636b474b9fe92f2608621acdf72040'
version = subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'], text=True).strip()
assert version == commit
program = Path(usb_trial.__file__).resolve()
assert subprocess.check_output(['git','-C',str(source),'hash-object',str(program)],text=True).strip() == '726ba33295681153adad7be2351283d786ae14eb'
receipt = json.loads(args.receipt.read_bytes())
assert receipt['experiment_commit'] == commit and digest(args.usb) == receipt['usb_sha256']
firmware = args.firmware.resolve()
code = firmware/'OVMF_CODE_4M.fd'
template = firmware/'OVMF_VARS_4M.fd'
out = args.out.resolve()
make_command = usb_trial.usb_command
def with_display(*params):
    cmd = make_command(*params)
    pos = cmd.index('-vga')
    assert cmd[pos:pos+2] == ['-vga','std']
    if args.video != 'std':
        cmd[pos:pos+2] = ['-vga','none','-device',args.video]
    return cmd
usb_trial.usb_command = with_display
start = time.monotonic()
error = None
try:
    usb_trial.trial(str(args.qemu.resolve()), code, template, args.usb.resolve(), receipt, out, 128)
except Exception as ex:
    error = {'type': type(ex).__name__, 'message': str(ex)}
raw = json.loads((out/'result.json').read_bytes())
serial = (out/'serial.txt').read_text(errors='replace')
frame = out/'home.ppm'
report = {
    'source':commit, 'video':args.video, 'checker_error':error, 'checker_passed':raw['passed'],
    'usb_sha256':digest(args.usb), 'kernel_measurement':receipt['measurement'],
    'measurement_matched': receipt['measurement']+' (measured; equal to the value the loader named)' in serial,
    'firmware_code_sha256':digest(code),'initial_firmware_vars_sha256':digest(template),
    'serial_checks':sum(ln.startswith('  pass ') for ln in serial.splitlines()),
    'all_self_tests_pass': 'ALL SELF-TESTS PASS.' in serial,
    'display': next((ln for ln in serial.splitlines() if ln.startswith('display:')),None),
    'desktop':next((ln for ln in serial.splitlines() if ln.startswith('desktop:')),None),
    'last_frame_size':frame.read_bytes().split(b'\n',3)[1].decode() if frame.is_file() else None,
    'last_frame_sha256':digest(frame) if frame.is_file() else None,
    'power_screen_seen':(out/'power.ppm').is_file(),'checker_recorded_exit':raw.get('exit'),
    'checker_recorded_shutdown':raw.get('shutdown'),'elapsed_seconds':round(time.monotonic()-start,1)}
(out/'readback.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)

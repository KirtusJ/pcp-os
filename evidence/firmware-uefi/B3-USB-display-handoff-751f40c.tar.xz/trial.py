"""Boot the #313 USB with one selected display, retaining QMP, serial and screen observations."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

p = argparse.ArgumentParser()
for name in ("source", "qemu", "firmware", "vars", "usb", "image", "out"):
    p.add_argument("--" + name, type=Path, required=True)
p.add_argument("--capture-header",action="store_true",help="Save the USB recipe’s 128-byte Multiboot header after the measured kernel has entered.")
p.add_argument("video", choices=("std","ramfb","virtio-vga"))
a=p.parse_args()
out=a.out.resolve()/a.video
out.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(a.source.resolve()/"examples/firmware-owned-uefi"))
import usb_trial
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def readlog(path):
    return path.read_text(errors="replace") if path.is_file() else ""
usb=a.usb.resolve()
manifest=json.loads(a.image.read_text())
assert digest(usb)==manifest["usb_sha256"]
args=usb_trial.usb_command(str(a.qemu.resolve()),a.firmware.resolve(),a.vars.resolve(),usb,out,128)
if a.video!="std":
    pos=args.index("-vga")
    args[pos:pos+2]=["-vga","none","-device",a.video]
record={"argv":args,"video":a.video,"usb_sha256":digest(usb),"measurement":manifest["measurement"],
        "firmware_sha256":digest(a.firmware),"template_sha256":digest(a.vars),
        "qemu":subprocess.check_output([str(a.qemu),"--version"],text=True).splitlines()[0],
        "disk_before":digest(out/"internal.raw")}
with (out/"stderr.txt").open("wb") as errors:
    vm=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors)
    try:
        monitor=usb_trial.OPTICAL["Monitor"](vm)
        call=monitor.call
        call("qmp_capabilities")
        blocks=call("query-block")
        medium=next(b for b in blocks if b["device"]=="stick")
        assert medium["inserted"]["ro"] and Path(medium["inserted"]["file"])==usb
        record["pci"]=call("query-pci")
        call("cont")
        start=time.monotonic()
        serial=out/"serial.txt"; trace=out/"firmware.txt"
        firmware_frame=False
        while time.monotonic()-start<70:
            log=readlog(serial)
            if not firmware_frame and "BdsDxe:" in log:
                call("screendump",filename=str(out/"firmware-window.ppm"))
                (out/"firmware-window-serial.txt").write_text(readlog(serial))
                firmware_frame=True
            if "desktop: " in log or "ALL SELF-TESTS PASS." in log or "SELF-TEST(S) FAILED" in log:
                break
            time.sleep(.08)
        log=readlog(serial)
        record["firmware_usb"]=next((x for x in log.splitlines() if "BdsDxe: starting" in x and "USB" in x),None)
        assert record["firmware_usb"] and "owned-handoff" in readlog(trace)
        assert manifest["measurement"]+" (measured; equal" in log
        if a.capture_header:
            from struct import unpack_from
            address=manifest["arena"][1] - 48*1024
            header=out/"boot-info.bin"
            call("pmemsave",val=address,size=128,filename=str(header))
            data=header.read_bytes()
            assert len(data)==128
            flags=unpack_from("<I",data)[0]
            modules=unpack_from("<I",data,20)[0]
            map_size,map_addr=unpack_from("<II",data,44)
            assert modules==3 and map_size>0 and map_addr>address
            record["runtime_header"]={"capture":"after kernel entry","address":address,"flags":flags,
                                      "modules":modules,"map_bytes":map_size,"map_address":map_addr,
                                      "framebuffer_flag":bool(flags & 0x1000),"framebuffer_fields_hex":data[88:116].hex()}
        record["display"]=next(x for x in log.splitlines() if x.startswith("display: "))
        record["desktop"]=next((x for x in log.splitlines() if x.startswith("desktop: ")),None)
        if record["desktop"]:
            screens=usb_trial.OPTICAL["DesktopScreens"](monitor,out,40)
            screens.home("kernel-display")
            monitor.key("f10")
            screens.wait("power", lambda rows: rows[1]=="  POWER OFF" and rows[3]=="  Switch PCP OS off?")
            monitor.key("ret")
        else:
            call("screendump",filename=str(out/"kernel-display.ppm"))
        usb_trial.OPTICAL["wait_for"](lambda: call("query-status")["status"]=="shutdown","guest power off",40)
        record["shutdown"]=next(e["data"] for e in monitor.events if e["event"]=="SHUTDOWN")
        call("quit")
        record["exit"]=vm.wait(timeout=10)
        assert record["shutdown"]=={"guest":True,"reason":"guest-shutdown"} and record["exit"]==0
    finally:
        if vm.poll() is None:
            vm.kill(); vm.wait()
        record["elapsed"]=round(time.monotonic()-start,2) if "start" in locals() else None
        log=readlog(out/"serial.txt")
        record["pass_lines"]=sum(x.startswith("  pass ") for x in log.splitlines())
        record["all_pass"]="ALL SELF-TESTS PASS." in log
        record["disk_after"]=digest(out/"internal.raw")
        record["usb_after"]=digest(usb)
        (out/"result.json").write_text(json.dumps(record,indent=2)+"\n")
assert record["disk_before"]==record["disk_after"] and record["usb_sha256"]==record["usb_after"]
print(record["video"],record["display"],record["desktop"],record["pass_lines"],record["all_pass"])

"""Verify four original QEMU results and compare the tested display paths."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import struct

root = Path(__file__).resolve().parent
cases = ("guests/std", "guests/ramfb", "guests/virtio-vga", "header-control/ramfb")
expected_sizes = ((1920, 1080), (800, 600), (1280, 800), (800, 600))
checks = []
for case, dimensions in zip(cases, expected_sizes):
    d = root / case
    r = json.loads((d / "result.json").read_text())
    serial = (d / "serial.txt").read_text()
    usb = "edb9466101f5ff9451192b907fca593fd70448f8e3be356492bc835800ef3730"
    measurement = "8be588744953d5d5eaa9f259f9db9d90b7a7cff455a6b14f0a3c08a6df06765e"
    assert r["usb_sha256"] == r["usb_after"] == usb and r["measurement"] == measurement
    assert measurement + " (measured; equal" in serial and "ALL SELF-TESTS PASS." in serial
    assert "BdsDxe: starting Boot" in r["firmware_usb"] and "USB" in r["firmware_usb"]
    assert "owned-handoff" in (d / "firmware.txt").read_text()
    assert r["exit"] == 0 and r["shutdown"] == {"guest": True, "reason": "guest-shutdown"}
    assert r["disk_before"] == r["disk_after"]
    assert "PCP OS kernel" not in (d / "firmware-window-serial.txt").read_text()
    final = (d / "kernel-display.ppm").read_bytes()
    w, h = dimensions
    header = f"P6\n{w} {h}\n255\n".encode()
    assert final.startswith(header) and len(final) == len(header) + 3*w*h
    rows = [s.strip() for s in serial.splitlines() if s.startswith("  pass ")]
    assert len(rows) == r["pass_lines"]
    checks.append(Counter(rows))
    if case == "guests/std":
        assert len(rows) == 72 and "display: Bochs, 1920x1080" in serial
        assert "desktop: 1920x1080" in serial
        assert final != (d / "firmware-window.ppm").read_bytes()
    else:
        assert len(rows) == 71 and "display: none this kernel can drive" in serial
        assert "desktop: " not in serial
        if case.startswith("guests/"):
            assert final == (d / "firmware-window.ppm").read_bytes()
    print(case, len(rows), r["display"], hashlib.sha256(final).hexdigest())
extra = {"pass with the display mapped, the kernel's memory map is as it was plus the display's memory, which is never executable"}
assert checks[1] == checks[2] == checks[3] == checks[0] - Counter(extra)
r = json.loads((root / cases[-1] / "result.json").read_text())
data = (root / cases[-1] / "boot-info.bin").read_bytes()
m = json.loads((root / "image.json").read_text())
assert r["runtime_header"]["address"] == m["arena"][1]-48*1024
assert len(data) == 128 and struct.unpack_from("<I",data,0)[0] == 0x4c
assert struct.unpack_from("<I",data,20)[0] == 3 and int.from_bytes(data[44:48], "little") > 0
assert data[88:116] == bytes(28)
print("Saved 128-byte boot information: flags 0x4c, three modules, zero framebuffer fields.")

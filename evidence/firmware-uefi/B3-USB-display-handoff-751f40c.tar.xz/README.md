# USB boot with three virtual displays

B3 booted the same read-only USB at PCP OS commit 751f40c5be636b474b9fe92f2608621acdf72040 using QEMU 10.0.13, Q35/TCG, 128 MiB, ordinary OVMF, a fresh firmware variable store and a disposable internal NVMe image in each run. The three main cases changed only the selected display device and per-run paths. All three reached the same measured kernel and requested shutdown. Only the standard VGA guest reached Home. Its shutdown followed F10 and Enter. The other two guests reached shutdown without input.

| Virtual display | Last observed screen | Kernel serial | Passing checks |
|---|---|---|---|
| Standard VGA (Bochs) | PCP OS Home at 1920×1080, then the power question | Bochs display and desktop | 72 |
| RAM framebuffer | OVMF at 800×600 | No display the kernel can drive | 71 |
| Virtio VGA | OVMF at 1280×800 | No display the kernel can drive | 71 |

In the RAM framebuffer and virtio VGA comparison guests, the terminal display captures were byte-identical to the captures taken while the serial port was still showing firmware output. The single additional self-test in the standard VGA guest examined the mapped display memory. All three serial logs reported that every self-test passed.

In a fourth RAM framebuffer guest a QMP physical-memory read captured the loader’s 128-byte boot-information header after the measured kernel entered. The flags were 0x4c; the framebuffer flag was clear and the framebuffer fields were zero. The independent run also recorded the three-module count and the populated memory-map fields. Its two screen captures bracket a different portion of firmware drawing. The identical-screen result above refers to the two main comparison guests.

To verify the originals after extraction, run `python3 -I verify.py`. To repeat a boot, check out PCP OS at the commit above and extract the exact USB from [B3’s earlier image archive](https://github.com/KirtusJ/pcp-os/blob/63ba2ddd41489c6711c781559e1862a2232206f1/evidence/firmware-uefi/B3-USB-two-profiles-751f40c.tar.xz). Use this command for std, ramfb and virtio-vga. For the separate header measurement, add `--capture-header` and use a fresh output directory.

```sh
python3 -IB trial.py ramfb --source /path/to/checkout --qemu /path/to/qemu-system-x86_64 --firmware /path/to/OVMF_CODE_4M.fd --vars /path/to/OVMF_VARS_4M.fd --usb /path/to/usb.img --image image.json --out ./fresh
```

The on-disk USB SHA-256 is edb9466101f5ff9451192b907fca593fd70448f8e3be356492bc835800ef3730. The original guest commands, device lists, input hashes, final disk hashes and exit events are in the result files. These observations cover the virtual displays listed here. Physical laptop display support remains open.

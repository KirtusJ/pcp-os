"""Reopen byte-for-byte copies of the first ordinary boot's private files in the c99e428 USB observer."""
from pathlib import Path
import argparse,hashlib,json,shutil,sys

root=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source', type=Path, default=root/'usb-published')
parser.add_argument('--prior', type=Path, default=root/'usb-cross-host/256')
parser.add_argument('--inputs', type=Path, default=root/'usb-cross-host/inputs.json')
parser.add_argument('--usb', type=Path, default=root/'usb-cross-host/hosted-usb.img')
parser.add_argument('--qemu', type=Path, default=root/'validation/bin/qemu-system-x86_64')
parser.add_argument('--ovmf', type=Path, default=root/'validation/pkg/root/usr/share/OVMF/OVMF_CODE_4M.fd')
parser.add_argument('--output', type=Path, required=True)
args=parser.parse_args()
src=args.source.resolve()/'examples/firmware-owned-uefi' 
sys.path.insert(0,str(src))
import usb_trial
import usb_observer

out=args.output.resolve()
old=args.prior.resolve()
media=args.usb.resolve()
prior=json.loads((old/'result.json').read_text())
inputs=json.loads(args.inputs.read_text())
image=inputs['input']
qemu=args.qemu.resolve()
firmware=args.ovmf.resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sources():
 return {n:sha(old/n) for n in ('internal.raw','vars.fd','shutdown-vars.fd')}
original=sources()
assert prior['passed'] and prior['self_tests']==72 and prior['exit']==0
assert original['internal.raw']==prior['nvme_sha256_after_quit']
assert original['shutdown-vars.fd']==original['vars.fd']==prior['vars_sha256_after_quit']
assert sha(media)==image['usb_sha256']==prior['usb_sha256_after']
assert sha(firmware)==inputs['firmware_sha256']
# The first-boot helper makes the QEMU arguments while attaching only temporary files.
# Replace its new disk with the saved copy before QEMU opens it. The private VARS comes
# directly from the saved file passed as the template argument.
original_command=usb_trial.usb_command
def reopened_command(qemu, code, template, volume, trialdir, ram):
 cmd=original_command(qemu,code,template,volume,trialdir,ram)
 shutil.copyfile(old/'internal.raw',trialdir/'internal.raw')
 assert sha(trialdir/'internal.raw')==original['internal.raw'] and sha(trialdir/'vars.fd')==original['vars.fd']
 return cmd
usb_trial.usb_command=reopened_command
run=out
usb_trial.trial(str(qemu),firmware,old/'vars.fd',media,image,run,256)
assert sources()==original
doc=json.loads((run/'result.json').read_text());assert doc['passed'] and doc['snapshots'][0]['vars_sha256']==original['vars.fd']
assert len(doc['snapshots'])==3 and doc['self_tests']==72 and doc['shutdown']=={'guest':True,'reason':'guest-shutdown'}
assert doc['usb_sha256_after']==sha(media)==image['usb_sha256']
for snap in doc['snapshots']:
 raw=(run/snap['vars_snapshot']).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==snap['vars_sha256'] and usb_observer.variables(raw)==snap['variables'] and snap['nvme_sha256']==original['internal.raw']
def intervals(receipt):
 return [{**{k:i[k] for k in ('from','to','nvme_bytes_preserved','vars_bytes_changed','variables_added','variables_removed','variables_modified')},
          'writes':{dev:(ds['wr_operations'],ds['wr_bytes']) for dev,ds in i['counter_deltas'].items()}} for i in receipt['intervals']]
summary={'source_head':'c99e428ab21cf5726e1711ca586966c44bf12473','usb_sha256':sha(media),
         'firmware_sha256':sha(firmware),'first_boot_source_files_before_and_after':original,
         'first_boot':intervals(prior),'second_boot':intervals(doc),
         'second_active_counts':[len(s['variables']) for s in doc['snapshots']],
         'second_nvme_sha256_after_exit':doc['nvme_sha256_after_quit'],'second_vars_sha256_after_exit':doc['vars_sha256_after_quit'],
         'self_tests':doc['self_tests'],'shutdown':doc['shutdown'],'exit':doc['exit'],
         'screens':{p.name:sha(p) for p in run.glob('*.ppm')}}
(out/'reopen-readback.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['second_boot'],indent=2))

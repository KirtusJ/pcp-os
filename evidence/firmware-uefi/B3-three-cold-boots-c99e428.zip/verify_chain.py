"""Read the raw snapshots and verify the predecessor chain without starting a VM."""
import hashlib,json,re,struct,sys
from pathlib import Path
from uuid import UUID

base=Path(sys.argv[1]).resolve()
folders=[base/n for n in ('first-boot','second-boot','third-boot')]
if not folders[0].exists():
    folders[0]=base.parents[1]/'usb-cross-host/256'
sha=lambda b:hashlib.sha256(b).hexdigest()
mtc_guid='eb704011-1402-11d3-8e77-00a0c969723b/MTC'
def active(raw):
    h=struct.unpack_from('<H',raw,48)[0];end=h+struct.unpack_from('<I',raw,h+16)[0]
    at=(h+28+3)&~3;values={};transition={}
    while at<end and raw[at:at+2]!=b'\xff\xff':
        assert raw[at:at+2]==b'\xaa\x55'
        state,attr=struct.unpack_from('<BxI',raw,at+2)
        nl,vl=struct.unpack_from('<II',raw,at+36);assert nl%2==0 and nl>=2
        guid=str(UUID(bytes_le=raw[at+44:at+60])); name=raw[at+60:at+60+nl].decode('utf-16le').rstrip('\x00')
        data=raw[at+60+nl:at+60+nl+vl]
        if state in (0x3f,0x3e):
            (values if state==0x3f else transition)[guid+'/'+name]=(attr,data)
        at=(at+60+nl+vl+3)&~3
    assert at<=end and all(x==255 for x in raw[at:end]);return transition|values

final=None;rows=[];nvhash=None
for n,d in enumerate(folders,1):
    log=(d/'serial.txt').read_text();doc=json.loads((d/'result.json').read_text())
    assert doc['passed'] and doc['self_tests']==72 and doc['exit']==0 and doc['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    assert sum(l.startswith('  pass ') for l in log.splitlines())==72 and 'ALL SELF-TESTS PASS.' in log
    assert (d/'home.ppm').read_bytes()==(d/'home-after-verification.ppm').read_bytes()
    assert (d/'home.ppm').read_bytes()!=(d/'home-verification.ppm').read_bytes()
    snaps=doc['snapshots'];pre,home,stop=[(d/s['vars_snapshot']).read_bytes() for s in snaps]
    assert [s['qemu_status'] for s in snaps]==['prelaunch','paused','shutdown']
    if final is not None:assert final==pre
    assert home==stop==(d/'vars.fd').read_bytes();final=stop
    assert [s['vars_sha256'] for s in snaps]==[sha(x) for x in (pre,home,stop)]
    raw_nv=(d/'internal.raw').read_bytes()
    if nvhash is None:nvhash=sha(raw_nv)
    assert doc['nvme_sha256_after_quit']==nvhash==sha(raw_nv)
    for i,s in enumerate(snaps):
        assert s['nvme_sha256']==nvhash
        v=active((pre,home,stop)[i]);assert s['variables']=={k:{'attributes':a,'bytes':len(b),'sha256':sha(b)}for k,(a,b) in v.items()}
    a,b=active(pre),active(home)
    def value(v):return int.from_bytes(v[mtc_guid][1],'little') if mtc_guid in v else None
    changes=[k for k in a.keys()&b.keys() if a[k]!=b[k]]
    i=doc['intervals'][0]; boot_diff=sum(x!=y for x,y in zip(pre,home))
    assert i['vars_bytes_changed']==boot_diff and sorted(changes)==i['variables_modified']
    assert sorted(b.keys()-a.keys())==i['variables_added'] and sorted(a.keys()-b.keys())==i['variables_removed']
    assert doc['intervals'][1]['vars_bytes_changed']==0
    counter_rows=[]
    for s in snaps:
      c={name:{k:v for k,v in row.items() if k in ('wr_operations','wr_bytes','failed_wr_operations','invalid_wr_operations')} for name,row in s['counters'].items()}
      assert all(not value for row in c.values() for value in row.values())
      counter_rows.append(c)
    rows.append({'boot':n,'before_vars_sha256':sha(pre),'home_and_shutdown_vars_sha256':sha(stop),'startup_bytes_changed':boot_diff,
                 'home_to_shutdown_bytes_changed':0,'active_before_home_shutdown':[len(a),len(b),len(active(stop))],
                 'added':i['variables_added'],'removed':i['variables_removed'],'modified':sorted(changes),'MTC_values_before_home_shutdown':[value(a),value(b),value(active(stop))],
                 'nvme_sha256_at_every_checkpoint':nvhash,'usb_sha256_after':doc['usb_sha256_after'],'qmp_write_counts_pre_home_off':counter_rows,
                 'serial_passes':72,'exit':0,'shutdown':doc['shutdown'],'firmware_usb_entry':doc['firmware_boot_device']})
print(json.dumps({'scope':'Three consecutive disposable 256 MiB Q35/OVMF processes, same FAT USB and writable NVMe fixture; each reopen starts from copies of the previous final bytes.',
                  'checkpoint_comparison':'Firmware variable bytes are raw net differences, not write counts. QMP write counters on these backend attachments did not reflect the raw pre-Home flash changes.',
                  'boots':rows},indent=2))

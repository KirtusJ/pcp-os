from pathlib import Path
import sys, json, hashlib, subprocess
root=Path(__file__).resolve().parent
s=root/'src'
g=lambda *a: subprocess.check_output(['git','-C',str(s),*a],text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=root.parent/'a3-316'
usb=old/'usb.img'
receipt=json.loads((old/'image.json').read_text())
target=g('rev-parse','HEAD')
tree=g('rev-parse','HEAD^{tree}')
assert target=='70dc1b4092d421e7f77b08072ad5fa056bded5ed'
assert tree==receipt['experiment_tree']==g('rev-parse','926c888^{tree}')
assert g('rev-parse','751f40c^{tree}')==g('rev-parse','26496f4^{tree}')
assert sha(usb)==receipt['usb_sha256']
sys.path.insert(0,str(s/'examples/firmware-owned-uefi'))
import usb_trial
qemu='/workspace/scratch/7c7df1723510/work/emulator/qemu-system-x86_64'
fw=root.parent/'a3-313-review/dependencies/usr/share/OVMF'
out=root/'virtio'
usb_trial.trial(qemu,fw/'OVMF_CODE_4M.fd',fw/'OVMF_VARS_4M.fd',usb,receipt,out,128,'virtio-vga')
r=json.loads((out/'result.json').read_text())
assert r['passed'] and r['self_tests']==72 and r['exit']==0 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
assert sha(out/'home.ppm')==sha(out/'home-after-verification.ppm')
summary=dict(merge=target,tree=tree,parents=g('show','-s','--format=%P','HEAD').split(),pr313_merge_tree=g('rev-parse','26496f4^{tree}'),pr313_tested_tree=g('rev-parse','751f40c^{tree}'),pr316_tested_tree=g('rev-parse','926c888^{tree}'),delta=g('diff','--name-only','26496f4',target).splitlines(),usb_origin=receipt['experiment_commit'],usb_sha256=sha(usb),home_sha256=sha(out/'home.ppm'),returned_home_sha256=sha(out/'home-after-verification.ppm'),display=r['loader_display'],self_tests=r['self_tests'],shutdown=r['shutdown'],exit=r['exit'],qemu=r['argv'])
(root/'readback.json').write_text(json.dumps(summary,indent=2)+'\n')
print(target,tree,summary['display'],r['self_tests'],r['shutdown'])

/* Observe active QEMU firmware graphics modes without requesting a mode change. */
#include <efi.h>
#include <efilib.h>
#include <cpuid.h>

static int qemu_tcg(void) {
    unsigned a, b, c, d;
    __cpuid(1, a, b, c, d);
    if (!(c & (1u << 31))) return 0;
    __cpuid(0x40000000, a, b, c, d);
    return b == 0x54474354 && c == 0x43544743 && d == 0x47435447;
}

static void emit(char c) {
    __asm__ volatile("outb %0, %1" : : "a"(c), "Nd"((UINT16)0xe9));
}

static void text(const char *s) {
    while (*s) emit(*s++);
}

static void field(const char *name, UINT64 value) {
    static const char digits[] = "0123456789abcdef";
    text(name);
    emit('=');
    for (int shift = 60; shift >= 0; shift -= 4) emit(digits[(value >> shift) & 15]);
    emit('\n');
}

EFI_STATUS efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *system) {
    if (!qemu_tcg()) return EFI_UNSUPPORTED;
    InitializeLib(image, system);
    EFI_BOOT_SERVICES *bs = system->BootServices;
    EFI_GUID gop_guid = EFI_GRAPHICS_OUTPUT_PROTOCOL_GUID;
    EFI_HANDLE *handles = NULL;
    UINTN count = 0;
    EFI_STATUS status = uefi_call_wrapper(bs->LocateHandleBuffer, 5, ByProtocol,
                                          &gop_guid, NULL, &count, &handles);
    text("PROBE-BEGIN\n");
    field("locate_status", status);
    field("handle_count", count);
    if (!EFI_ERROR(status)) {
        for (UINTN i = 0; i < count; ++i) {
            EFI_GRAPHICS_OUTPUT_PROTOCOL *gop = NULL;
            status = uefi_call_wrapper(bs->HandleProtocol, 3, handles[i], &gop_guid, (void **)&gop);
            field("handle_index", i);
            field("console_out_handle", handles[i] == system->ConsoleOutHandle);
            field("handle_status", status);
            if (EFI_ERROR(status) || !gop || !gop->Mode || !gop->Mode->Info) continue;
            EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE *mode = gop->Mode;
            EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *info = mode->Info;
            field("mode",mode->Mode);
            field("mode_info_size", mode->SizeOfInfo);
            if (mode->SizeOfInfo < sizeof(*info)) continue;
            field("width",info->HorizontalResolution);
            field("height",info->VerticalResolution);
            field("pixel_format",info->PixelFormat);
            field("pixels_per_scanline",info->PixelsPerScanLine);
            field("base",mode->FrameBufferBase);
            field("size",mode->FrameBufferSize);
        }
        uefi_call_wrapper(bs->FreePool, 1, handles);
    }
    text("PROBE-END\n");
    uefi_call_wrapper(system->RuntimeServices->ResetSystem, 4, EfiResetShutdown, EFI_SUCCESS, 0, NULL);
    return EFI_SUCCESS;
}

# Active OVMF framebuffers

A separate QEMU-only EFI diagnostic read the active UEFI Graphics Output Protocol mode on every handle offering that protocol. It used the same three virtual display configurations, 128 MiB guest memory and OVMF code and variable templates as [the #313 USB comparison](https://github.com/KirtusJ/pcp-os/blob/43effee02dfc296e824c2575cbace350b009d7c8/evidence/firmware-uefi/B3-USB-display-handoff-751f40c.tar.xz). The diagnostic USB replaced the PCP USB for these three measurements. It queried the active modes, wrote the values to QEMU's diagnostic port and requested shutdown. Both handles in each guest agreed on their active framebuffer; exactly one was the console output handle. All three reported blue, green, red and reserved bytes with a four-byte pixel.

| Display | Firmware mode | Pixel stride | Linear framebuffer base | Reported bytes |
|---|---|---:|---:|---:|
| Standard VGA | 1280×800 | 1280 | 0x80000000 | 4,096,000 |
| RAM framebuffer | 800×600 | 800 | 0x06a3f000 | 3,145,728 |
| Virtio VGA | 1280×800 | 1280 | 0x80000000 | 4,096,000 |

The RAM framebuffer base falls below the current kernel’s 1 GiB lower bound and between its 2 MiB boundaries. The virtio VGA base meets both address conditions, making it a candidate for a separate virtual handoff test. The deployed USB’s missing framebuffer flag, its visible results, and its measured kernel were recorded in the comparison linked above. This survey did not run a modified PCP loader or establish an end-to-end working framebuffer handoff.

Run `python3 -I verify.py` after extraction to check the raw debug streams against the recorded values. The archive includes the diagnostic C source, its binary and exact USB. To rerun the measurements, use the source tree from KirtusJ/pcp-os at 751f40c5be636b474b9fe92f2608621acdf72040, the OVMF input files with the hashes recorded in the results, and a QEMU installation with the three display devices. For binaries installed in a private prefix, make their module directory available to QEMU.

```sh
python3 -IB run.py --source /path/to/checkout --qemu /path/to/qemu-system-x86_64 --firmware /path/to/OVMF_CODE_4M.fd --vars /path/to/OVMF_VARS_4M.fd --image build/probe.img --out ./fresh
```

To build a new diagnostic image, use `sh build.sh /path/to/gnu-efi-prefix ./fresh-build` with gcc, binutils and mtools available. A fresh build can have a different binary or filesystem digest.

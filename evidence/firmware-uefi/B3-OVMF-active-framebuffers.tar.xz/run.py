"""Measure every active UEFI graphics protocol handle on three QEMU devices."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

p=argparse.ArgumentParser()
for name in ("source","qemu","firmware","vars","image","out"):
    p.add_argument("--"+name,type=Path,required=True)
a=p.parse_args()
sys.path.insert(0,str(a.source.resolve()/"examples/firmware-owned-uefi"))
import usb_trial
def digest(f):
    return hashlib.sha256(f.read_bytes()).hexdigest()
image=a.image.resolve()
for display in ("std","ramfb","virtio-vga"):
    out=a.out.resolve()/display
    out.mkdir(parents=True,exist_ok=False)
    cmd=usb_trial.usb_command(str(a.qemu.resolve()),a.firmware.resolve(),a.vars.resolve(),image,out,128)
    if display!="std":
        i=cmd.index("-vga")
        cmd[i:i+2]=["-vga","none","-device",display]
    record={"display":display,"argv":cmd,"diagnostic_usb":digest(image),"firmware":digest(a.firmware),"vars_template":digest(a.vars)}
    with (out/"stderr.txt").open("wb") as err:
        vm=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
        try:
            monitor=usb_trial.OPTICAL["Monitor"](vm)
            rpc=monitor.call
            rpc("qmp_capabilities")
            blocks=rpc("query-block")
            assert next(b for b in blocks if b["device"]=="stick")["inserted"]["ro"]
            rpc("cont")
            usb_trial.OPTICAL["wait_for"](lambda:rpc("query-status")["status"]=="shutdown","diagnostic shutdown",50)
            trace=(out/"firmware.txt").read_text()
            lines=trace.split("PROBE-BEGIN\n")[1].split("PROBE-END\n")[0].splitlines()
            handles=[]
            target=record
            for line in lines:
                name,value=line.split("=")
                if name=="handle_index":
                    target={}
                    handles.append(target)
                target[name]=int(value,16)
            assert record["locate_status"]==0 and len(handles)==record["handle_count"]>0
            assert all(h["handle_status"]==0 and "size" in h for h in handles)
            record["handles"]=handles
            record["shutdown"]=next(e["data"] for e in monitor.events if e["event"]=="SHUTDOWN")
            rpc("quit")
            record["exit"]=vm.wait(timeout=10)
            assert record["exit"]==0 and record["shutdown"]=={"guest":True,"reason":"guest-shutdown"}
        finally:
            if vm.poll() is None:
                vm.kill();vm.wait()
            (out/"result.json").write_text(json.dumps(record,indent=2)+"\n")
    assert digest(image)==record["diagnostic_usb"]
    print(display,[(h["console_out_handle"],h["width"],h["height"],h["pixel_format"],hex(h["base"]),h["size"]) for h in handles],flush=True)

"""Read the device geometry from the UEFI program's original debug output."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
usb=root/"build/probe.img"
digest=hashlib.sha256(usb.read_bytes()).hexdigest()
for display,expected in (("std",(1280,800,0x80000000)),("ramfb",(800,600,0x06a3f000)),("virtio-vga",(1280,800,0x80000000))):
    case=root/"guests"/display
    result=json.loads((case/"result.json").read_text())
    raw=(case/"firmware.txt").read_text().splitlines()
    assert raw[0]=="PROBE-BEGIN" and raw[-1]=="PROBE-END"
    assert raw[1:3]==["locate_status=0000000000000000","handle_count=0000000000000002"]
    handles=[]
    for line in raw[3:-1]:
        name,encoded=line.split("=")
        if name=="handle_index": handles.append({})
        handles[-1][name]=int(encoded,16)
    assert handles==result["handles"] and {h["console_out_handle"] for h in handles}=={0,1}
    for h in handles:
        assert h["handle_status"]==0 and (h["width"],h["height"],h["base"])==expected
        assert h["mode_info_size"]>=36 and h["pixel_format"]==1
        assert h["pixels_per_scanline"]==h["width"] and h["size"]>=4*h["pixels_per_scanline"]*h["height"]
    assert result["diagnostic_usb"]==digest and result["exit"]==0
    assert result["shutdown"]=={"guest":True,"reason":"guest-shutdown"}
    assert "BdsDxe: starting Boot" in (case/"serial.txt").read_text()
    print(display, h["width"],h["height"],hex(h["base"]),h["size"])

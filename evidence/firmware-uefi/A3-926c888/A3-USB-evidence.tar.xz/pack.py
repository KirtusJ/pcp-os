"""Keep originals for all local read-backs and the exact references to the hosted originals."""
import json, hashlib, tarfile, subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def load(n):return json.loads((root/n).read_text())
r=load('readback.json')
r['headers']={n:{k:v for k,v in load('header-'+n+'/result.json').items() if k!='command'} for n in ['virtio-vga','ramfb']}
r['secure_boot']={k:v for k,v in load('secure-boot/result.json').items() if k!='argv'}
r['local_qemu']=subprocess.check_output(['/workspace/scratch/7c7df1723510/work/emulator/qemu-system-x86_64','--version'],text=True).splitlines()[0]
r['hosted_qemu']=load('image.json')['qemu_version']
r['hosted_artifacts']={'usb_observations':14709620766,'usb_zip_sha256':sha(root/'hosted.zip'),'ownership':14709860464,'ownership_zip_sha256':sha(root/'ownership.zip'),'run':44910215712}
r['scope']='Read-only unsigned USB fixture under Q35/OVMF and QEMU TCG. Four ordinary interactive boots, a RAMFB control, two raw-header confirmations and a factory-enrolled Secure Boot refusal. Changing the advertised virtio size to 1600x900 still produced 1280x800.'
assert r['headers']['virtio-vga']['framebuffer']=='0x80000000' and r['headers']['ramfb']['framebuffer']=='0x6a3f000'
assert r['secure_boot']['pe_certificate_size']==0 and r['secure_boot']['denial']
(root/'A3-USB-readback.json').write_text(json.dumps(r,indent=2)+'\n')
names=['std-128','std-256','virtio-vga','virtio-edid','ramfb','header-virtio-vga','header-ramfb','secure-boot']
files=[p for n in names for p in (root/n).iterdir() if p.is_file()]
files += [p for p in root.iterdir() if p.is_file() and p.suffix in {'.py','.json','.log'}]
files += [root/'usb.img']
checks=root/'SHA256SUMS'
checks.write_text(''.join(sha(p)+'  '+str(p.relative_to(root))+'\n' for p in sorted(set(files))))
with tarfile.open(root/'A3-USB-evidence.tar.xz','w:xz',preset=2) as t:
    for p in sorted(set(files+[checks])):t.add(p,arcname=p.relative_to(root))
with tarfile.open(root/'A3-USB-evidence.tar.xz') as t:
    for m in t:
        assert hashlib.file_digest(t.extractfile(m),'sha256').hexdigest()==sha(root/m.name)
print(sha(root/'A3-USB-evidence.tar.xz'),(root/'A3-USB-evidence.tar.xz').stat().st_size)

"""Try the hosted read-only USB with the packaged secure firmware and factory-enrolled variable store."""
from pathlib import Path
import json, re, sys, subprocess, hashlib, struct
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'source/examples/firmware-owned-uefi'))
import usb_trial, usb_observer
from fat_reader import efi
out=root/'secure-boot'
out.mkdir()
qemu=str(Path(sys.argv[1]).resolve())
fw=Path(sys.argv[2]).resolve()
code,template=fw/'OVMF_CODE_4M.secboot.fd',fw/'OVMF_VARS_4M.ms.fd'
usb=root/'usb.img'
image=json.loads((root/'image.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(usb.read_bytes())==image['usb_sha256']
loader=efi(usb.read_bytes())
offset=struct.unpack_from('<I',loader,0x3c)[0]
assert loader[offset:offset+4]==b'PE\x00\x00' and struct.unpack_from('<H',loader,offset+24)[0]==0x20b
certificate=struct.unpack_from('<II',loader,offset+24+112+4*8)
assert certificate==(0,0)
variables=usb_observer.variables(template.read_bytes())
enrolled=[v.rsplit('/',1)[-1] for v in variables]
assert all(n in enrolled for n in ('PK','KEK','db'))
cmd=usb_trial.usb_command(qemu,code,template,usb,out,128,'virtio-vga')
cmd[cmd.index('q35')]='q35,smm=on'
cmd.extend(['-global','driver=cfi.pflash01,property=secure,value=on'])
def read(name):
    p=out/name
    return p.read_text(errors='replace') if p.exists() else ''
with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
    try:
        mon=usb_trial.OPTICAL['Monitor'](guest)
        mon.call('qmp_capabilities')
        mon.call('cont')
        usb_trial.OPTICAL['wait_for'](lambda: any('USB' in s and 'Access Denied' in s for s in read('serial.txt').splitlines()),'firmware refused USB',60)
        mon.call('stop')
        mon.call('screendump',filename=str(out/'denial.ppm'))
        disposition=[s for s in read('serial.txt').splitlines() if 'USB' in s and 'Access Denied' in s]
        assert disposition and 'owned-handoff' not in read('firmware.txt') and 'removable-vm' not in read('firmware.txt')
        assert image['measurement'] not in read('serial.txt')
        mon.call('quit')
        exit_code=guest.wait(timeout=10)
    finally:
        if guest.poll() is None:
            guest.kill()
            guest.wait()
assert exit_code==0
r=dict(argv=cmd,firmware_sha256=sha(code.read_bytes()),vars_template_sha256=sha(template.read_bytes()),usb_sha256=image['usb_sha256'],efi_sha256=sha(loader),pe_certificate_offset=certificate[0],pe_certificate_size=certificate[1],enrolled_names=[n for n in enrolled if n in ('PK','KEK','db')],denial=disposition,owned_handoff_seen=False,measurement_seen=False,stopped_by='Controller via QMP after USB refusal',qemu_exit=exit_code)
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
print(disposition)

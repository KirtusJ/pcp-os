"""Read only the declared Multiboot header of the test guest after the firmware handoff."""
import sys, json, hashlib, struct, subprocess, time
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'source/examples/firmware-owned-uefi'))
import usb_trial
qemu=str(Path(sys.argv[1]).resolve())
fw=Path(sys.argv[2]).resolve()
volume=root/'usb.img'
image=json.loads((root/'image.json').read_text())
assert hashlib.sha256(volume.read_bytes()).hexdigest()==image['usb_sha256']
info=(max(end for _,end in image['modules'].values())+4095)//4096*4096
assert info==image['arena'][1]-(32+16)*1024
for video in ('virtio-vga','ramfb'):
    out=root/('header-'+video)
    out.mkdir()
    cmd=usb_trial.usb_command(qemu,fw/'OVMF_CODE_4M.fd',fw/'OVMF_VARS_4M.fd',volume,out,128,'virtio-vga')
    if video=='ramfb':cmd[cmd.index('virtio-vga')]='ramfb'
    def read(n):
        p=out/n
        return p.read_text(errors='replace') if p.exists() else ''
    with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
        try:
            mon=usb_trial.OPTICAL['Monitor'](guest)
            rpc=mon.call
            rpc('qmp_capabilities')
            rpc('cont')
            normal=video=='virtio-vga'
            needle='desktop: ' if normal else 'ALL SELF-TESTS PASS.'
            usb_trial.OPTICAL['wait_for'](lambda:needle in read('serial.txt'),'guest read-back',60)
            if normal:rpc('stop')
            else:usb_trial.OPTICAL['wait_for'](lambda:rpc('query-status')['status']=='shutdown','guest shutdown',20)
            path=out/'multiboot-header.bin'
            rpc('pmemsave',val=info,size=116,filename=str(path))
            if normal:
                rpc('cont')
                time.sleep(.8)
                mon.key('f10')
                time.sleep(.65)
                mon.key('ret')
                usb_trial.OPTICAL['wait_for'](lambda:rpc('query-status')['status']=='shutdown','confirmed power-off',30)
            event=next(m['data'] for m in mon.events if m.get('event')=='SHUTDOWN')
            rpc('quit')
            code=guest.wait(timeout=10)
        finally:
            if guest.poll() is None:
                guest.kill()
                guest.wait()
    data=path.read_bytes()
    flags,=struct.unpack_from('<I',data)
    addr,pitch,w,h,bpp,kind,rp,rn,gp,gn,bp,bn=struct.unpack_from('<QIII8B',data,88)
    assert len(data)==116 and flags & (1<<12)
    assert (bpp,kind,rp,rn,gp,gn,bp,bn)==(32,1,16,8,8,8,0,8)
    assert pitch==4*w and addr>0 and h>0
    assert 'console_framebuffer=%016x'%addr in read('firmware.txt') and 'console_pitch=%016x'%pitch in read('firmware.txt')
    assert code==0 and event=={'guest':True,'reason':'guest-shutdown'}
    outcome=dict(device=video,command=cmd,info_address=hex(info),flags=hex(flags),framebuffer=hex(addr),width=w,height=h,pitch_bytes=pitch,bpp=bpp,type=kind,RGB=[(rp,rn),(gp,gn),(bp,bn)],self_tests=sum(l.startswith('  pass ') for l in read('serial.txt').splitlines()),shutdown=event,exit=code)
    (out/'result.json').write_text(json.dumps(outcome,indent=2)+'\n')
    print(video,hex(addr),w,h,pitch,bpp,flush=True)

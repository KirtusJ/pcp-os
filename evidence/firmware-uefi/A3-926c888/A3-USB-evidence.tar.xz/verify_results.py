"""Recompute the identities, screen read-backs and observer results of the hosted and local USB guests."""
import hashlib, json, re, runpy, subprocess, zipfile
from pathlib import Path
from fat_reader import efi

sha=lambda b:hashlib.sha256(b).hexdigest()
root=Path(__file__).resolve().parent
source=root/'source'
opt=runpy.run_path(str(source/'examples/optical-disk-check/check.py'))
screen=opt['SCREEN']
glyphs=screen['kernel_glyphs']()
baseline,marker=opt['make_gpt_disk'](512)
variables=runpy.run_path(str(source/'examples/firmware-owned-uefi/usb_observer.py'))['variables']
def inspect(get):
    r=json.loads(get('result.json'))
    home,back,verify,power=(get(n+'.ppm') for n in ['home','home-after-verification','home-verification','power'])
    assert home==back
    assert screen['verification_screen'](screen['read_screen'](verify,glyphs))
    visible=screen['read_screen'](home,glyphs)
    assert any('Programs' in l for l in visible) and any(re.search(r'\bverified[ ?]*$',l) or 'PCP OS | DESKTOP' in l for l in visible)
    assert any('Enter switch off    Esc go back' in l for l in screen['read_screen'](power,glyphs))
    serial=get('serial.txt').decode(errors='replace').splitlines()
    assert r['self_tests']==sum(l.startswith('  pass ') for l in serial)==72 and r['exit']==0 and r['passed'] is True
    assert r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    assert any(image['measurement']+' (measured; equal' in l for l in serial)
    firmware=dict(line.split('=',1) for line in get('firmware.txt').decode().splitlines() if line.startswith(('console_framebuffer=','console_pitch=')))
    display=next(line for line in serial if line.startswith('display: '))
    mode=home.split(b'\n',2)[1].decode()
    if r['video']=='virtio-vga':
        match=re.fullmatch(r'display: Loader, (\d+)x(\d+), 1 page\(s\), \d+ KiB of its memory mapped at (0x[0-9a-f]+)',display)
        assert match and mode==f'{match[1]} {match[2]}' and int(firmware['console_framebuffer'],16)==int(match[3],16)
        assert int(firmware['console_pitch'],16)>=4*int(match[1])
    else: assert 'display: Bochs' in display
    snaps=r['snapshots']
    raw=[get(s['vars_snapshot']) for s in snaps]
    assert [s['stage'] for s in snaps]==['before','home','shutdown']
    assert all(sha(v)==s['vars_sha256'] and variables(v)==s['variables'] for s,v in zip(snaps,raw))
    assert raw[0]!=raw[1] and raw[1]==raw[2]==get('vars.fd')
    assert baseline==get('internal.raw') and all(s['nvme_sha256']==sha(baseline) for s in snaps)
    return dict(display=display,home_pixels=mode,framebuffer=firmware['console_framebuffer'],pitch_bytes=int(firmware['console_pitch'],16),home_sha256=sha(home),verified_return=True,self_tests=r['self_tests'],exit=r['exit'],shutdown=r['shutdown'],nvme_sha256=sha(baseline),before_to_home_variable_bytes=sum(a!=b for a,b in zip(raw[0],raw[1])),home_to_shutdown_variable_bytes=0)

image=json.loads((root/'image.json').read_text())
firmware_path=root.parent/'a3-313-review/dependencies/usr/share/OVMF'
digest=lambda p:sha(p.read_bytes())
output=dict(commit=image['experiment_commit'],tree=image['experiment_tree'],hosted={},local={},kernel_measurement=image['measurement'],usb_sha256=image['usb_sha256'],kernel_elf_sha256=image['elf_sha256'],efi_sha256=image['efi_sha256'],local_ovmf_code=digest(firmware_path/'OVMF_CODE_4M.fd'),hosted_ovmf_code=image['ovmf_code_sha256'])
assert digest(root/'hosted.zip')=='1b9729ac4a7cbb28141a7aa40b5b33ccf462d4acebb4ec78910c0dda2928f75d'
assert digest(root/'ownership.zip')=='25a37eb8e9c95280c810c47a2b98210453224be9b5a0b291cf52e52741e07f5a'
assert digest(root/'usb.img')==image['usb_sha256'] and sha(efi((root/'usb.img').read_bytes()))==image['efi_sha256']
with zipfile.ZipFile(root/'ownership.zip') as z:
    kernel=z.read('kernel.elf32')
    measure=runpy.run_path(str(source/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure']
    assert sha(kernel)==image['elf_sha256'] and measure(kernel)==image['measurement']
with zipfile.ZipFile(root/'hosted.zip') as z:
    for case in ['128','256','virtio-vga']:
        output['hosted'][case]=inspect(lambda n:z.read(f'usb-observations/{case}/'+n))
    control=json.loads(z.read('usb-write-control/result.json'))
    different=[i for i,(x,y) in enumerate(zip(baseline,z.read('usb-write-control/internal.raw'))) if x!=y]
    assert different==control['changed_disk_offsets'] and different
    v=[z.read('usb-write-control/'+s['vars_snapshot']) for s in control['stages']]
    changes=sum(x!=y for x,y in zip(v[1],v[2]))
    assert changes==control['changes'][1]['vars_bytes_changed'] and changes>0
    output['hosted_observer_control']=dict(changed_disk_bytes=len(different),changed_variable_store_bytes=changes)
for case in ['std-128','std-256','virtio-vga','virtio-edid']:
    output['local'][case]=inspect(lambda n:(root/case/n).read_bytes())
raw=json.loads((root/'ramfb/result.json').read_text())
assert raw['shutdown']=={'guest':True,'reason':'guest-shutdown'} and raw['self_tests']==71 and raw['exit']==0
ramrows=screen['read_screen']((root/'ramfb/last.ppm').read_bytes(),glyphs)
assert not any('Programs' in l for l in ramrows)
output['ramfb']={k:v for k,v in raw.items() if k!='command'}
(root/'readback.json').write_text(json.dumps(output,indent=2)+'\n')
print([(k,v['home_pixels'],v['self_tests']) for k,v in output['local'].items()],output['ramfb']['console'],output['hosted_observer_control'])

"""Replay the hosted USB in the tracked checker and read one alternate display with QMP."""
import argparse, hashlib, json, subprocess, sys, time, zipfile
from pathlib import Path

root=Path(__file__).resolve().parent
source=root/'source'
sys.path.insert(0,str(source/'examples/firmware-owned-uefi'))
import usb_trial

p=argparse.ArgumentParser()
p.add_argument('case',choices=['std-128','std-256','virtio-vga','virtio-edid','ramfb'])
p.add_argument('qemu',type=Path)
p.add_argument('ovmf',type=Path)
a=p.parse_args()
qemu=str(a.qemu.resolve())
code,template=(a.ovmf.resolve()/n for n in ('OVMF_CODE_4M.fd','OVMF_VARS_4M.fd'))
image=json.loads((root/'image.json').read_text())
volume=root/'usb.img'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(volume)==image['usb_sha256']
assert image['experiment_commit']==subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],text=True).strip()
assert image['experiment_tree']==subprocess.check_output(['git','-C',source,'rev-parse','HEAD^{tree}'],text=True).strip() and image['experiment_dirty'] is False
out=root/a.case
if a.case=='virtio-edid':
    original=usb_trial.usb_command
    def edid(*args):
        cmd=original(*args)
        at=cmd.index('virtio-vga')
        cmd[at]='virtio-vga,xres=1600,yres=900'
        return cmd
    usb_trial.usb_command=edid
if a.case!='ramfb':
    ram=256 if a.case=='std-256' else 128
    usb_trial.trial(qemu,code,template,volume,image,out,ram,'std' if a.case.startswith('std') else 'virtio-vga')
    r=json.loads((out/'result.json').read_text())
    assert r['passed'] and r['self_tests']==72 and r['exit']==0 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    assert sha(out/'home.ppm')==sha(out/'home-after-verification.ppm')
    print(a.case,r['self_tests'],r['shutdown'],r.get('loader_display'))
else:
    out.mkdir()
    cmd=usb_trial.usb_command(qemu,code,template,volume,out,128,'virtio-vga')
    cmd[cmd.index('virtio-vga')]='ramfb'
    log=lambda n:(out/n).read_text(errors='replace') if (out/n).is_file() else ''
    with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as guest:
        try:
            mon=usb_trial.OPTICAL['Monitor'](guest)
            rpc=mon.call
            rpc('qmp_capabilities')
            rpc('cont')
            usb_trial.OPTICAL['wait_for'](lambda:'ALL SELF-TESTS PASS.' in log('serial.txt'),'guest completed',60)
            usb_trial.OPTICAL['wait_for'](lambda:rpc('query-status')['status']=='shutdown','shutdown',25)
            rpc('screendump',filename=str(out/'last.ppm'))
            shutdown=next(m['data'] for m in mon.events if m.get('event')=='SHUTDOWN')
            rpc('quit')
            exit_code=guest.wait(timeout=12)
        finally:
            if guest.poll() is None:guest.kill();guest.wait()
    serial=log('serial.txt').splitlines()
    firmware=log('firmware.txt').splitlines()
    fields = [l for l in firmware if l.startswith(('console_framebuffer=','console_pitch='))]
    assert len(fields)==2 and 'owned-handoff' in firmware
    assert shutdown=={'guest':True,'reason':'guest-shutdown'} and exit_code==0
    assert any(image['measurement']+' (measured; equal' in l for l in serial)
    assert 'display: none this kernel can drive' in serial and not any(l.startswith('desktop:') for l in serial)
    r=dict(command=cmd,console=fields,exit=exit_code,shutdown=shutdown,self_tests=sum(l.startswith('  pass ') for l in serial),screen_sha256=sha(out/'last.ppm'),screen_size=(out/'last.ppm').read_bytes().split(b'\n',2)[1].decode(),serial_display='display: none this kernel can drive')
    (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
    print(a.case,r['console'],r['self_tests'],r['shutdown'])

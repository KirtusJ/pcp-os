"""Read BOOTX64.EFI from the removable FAT12 test volume."""
import struct
def efi(img):
    u16=lambda b,o:struct.unpack_from('<H',b,o)[0]
    bps=u16(img,11);spc=img[13];reserved=u16(img,14);fats=img[16];entries=u16(img,17);fatsecs=u16(img,22)
    root=(reserved+fats*fatsecs)*bps; start=root+((32*entries+bps-1)//bps)*bps
    fat=img[reserved*bps:(reserved+fatsecs)*bps]
    assert b'FAT12' in img[:96]
    def chain(cluster):
        parts=[];seen=set()
        while 2<=cluster<0xff0:
            assert cluster not in seen
            seen.add(cluster);ofs=start+(cluster-2)*bps*spc;parts.append(img[ofs:ofs+bps*spc])
            pair=u16(fat,cluster*3//2);cluster=pair>>4 if cluster%2 else pair&4095
        assert cluster>=0xff8
        return b''.join(parts)
    directory=img[root:root+32*entries]
    for name in (b'EFI        ', b'BOOT       ', b'BOOTX64 EFI'):
        matches=[directory[i:i+32] for i in range(0,len(directory),32) if directory[i:i+11]==name]
        assert len(matches)==1
        ent=matches[0];directory=chain(u16(ent,26))
    return directory[:struct.unpack_from('<I',ent,28)[0]]

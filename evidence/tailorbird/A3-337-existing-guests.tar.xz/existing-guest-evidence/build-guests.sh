#!/bin/bash
set -euo pipefail
rt=$(cd "$(dirname "$0")/.." && pwd)
w="$rt/a3-337-media"
export PATH="$rt/register-live/rust197/bin:$rt/register-live/rust197/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$rt/root/usr/bin:$PATH"
export LD_LIBRARY_PATH="$rt/lib" CARGO_HOME="$w/cargo" CARGO_NET_OFFLINE=true
export PCPOS_TESTER_CD_STAGE="$w/comparison-stage"
python3 -B "$w/reuse-kernel.py" "$2/examples/tester-cd/build.py" "$rt/a3-tailor-media/limine" "$w/$1" --queue-desk

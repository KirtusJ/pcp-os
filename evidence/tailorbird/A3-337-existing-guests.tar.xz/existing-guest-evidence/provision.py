import concurrent.futures
import hashlib
import json
import os
from io import BytesIO
from pathlib import Path
from urllib.request import urlopen
import tarfile
import time
import tomllib

w=Path(__file__).resolve().parent
prior=w.parent/"a3-331-run/vendor"
vendor=w/"vendor";vendor.mkdir(exist_ok=True)
home=w/"cargo";home.mkdir(exist_ok=True)
for p in prior.iterdir():
    if not (vendor/p.name).exists():(vendor/p.name).symlink_to(p.resolve(),target_is_directory=True)
pinned={}
osroot=w.parent/"a3-tailor-media/os-master"
for path in ["apps/surfbird/guest/Cargo.lock","PCP_OS_Rust/Cargo.lock","store/apps/parrots-all-the-way-down/guest/Cargo.lock"]:
    f=osroot/path
    for p in tomllib.loads(f.read_text())["package"]:
        if "checksum" in p:
            tag=f"{p['name']}-{p['version']}"
            if tag in pinned:assert pinned[tag]['checksum']==p['checksum']
            pinned[tag]=p
def obtain(item):
    tag,p=item
    base=vendor/tag;receipt=base/".cargo-checksum.json"
    if receipt.exists():
        if json.loads(receipt.read_text())["package"]==p["checksum"]:return 'present'
        raise ValueError(tag+' vendor mismatch')
    url=f"https://static.crates.io/crates/{p['name']}/{tag}.crate"
    for t in range(3):
        try:
            with urlopen(url,timeout=20) as r:data=r.read()
            assert hashlib.sha256(data).hexdigest()==p["checksum"],tag
            break
        except Exception:
            if t==2:raise
            time.sleep(.25*(t+1))
    with tarfile.open(fileobj=BytesIO(data),mode='r:gz') as a:
        for m in a.getmembers():
            path=Path(m.name)
            if path.parts[0]!=tag or '..' in path.parts or not (m.isdir() or m.isfile()):raise ValueError(m.name)
        a.extractall(vendor,filter='data')
    digests={str(f.relative_to(base)):hashlib.sha256(f.read_bytes()).hexdigest() for f in base.rglob('*') if f.is_file()}
    receipt.write_text(json.dumps(dict(files=digests,package=p['checksum'])))
    return 'added'
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    results=list(pool.map(obtain,pinned.items()))
(home/'config.toml').write_text('[source.crates-io]\nreplace-with="offline"\n[source.offline]\ndirectory='+json.dumps(str(vendor))+'\n')
print(len(pinned),'locked archives verified;',results.count('added'),'downloaded or newly provisioned')

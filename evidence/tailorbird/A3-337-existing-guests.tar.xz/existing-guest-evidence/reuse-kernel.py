import hashlib,runpy,shutil,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
root=w.parent/'a3-tailor-media'
script=Path(sys.argv.pop(1)).resolve()
verified=runpy.run_path(str(script))
kernel=root/'iso-stage/source/PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32'
assert hashlib.sha256(kernel.read_bytes()).hexdigest()=='e3157e48ebb886fe04a321dd5d5050592b232a08b452f7544e184a13f5912481'
subprocess.run(['git','diff','--exit-code','53a551a297ec35f50917c12efada45f3150ece35','HEAD','--','PCP_OS_Rust'],cwd=script.parents[2],check=True)
run=verified['run']
def delegate(*args,**opts):
    if len(args)==3 and args[0]=='sh' and Path(args[1]).name=='run.sh' and args[2]=='build':
        output=Path(args[1]).parent/'target/pcpos-kernel.elf32'
        output.parent.mkdir(exist_ok=True)
        shutil.copy2(kernel,output)
        return ''
    return run(*args,**opts)
verified['main'].__globals__['run']=delegate
verified['main']()

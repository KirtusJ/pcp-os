import hashlib
import json
from pathlib import Path
import re
from PIL import Image
from pixel_reader import label

root=Path(__file__).resolve().parent
def sha(buf):return hashlib.sha256(buf).hexdigest()

def optical_files(image):
    block=2048
    desc=image[16*block:17*block]
    if desc[1:6]!=b'CD001':raise ValueError('missing ISO9660 volume')
    loc=lambda data:int.from_bytes(data,'little')
    beginning=loc(desc[158:162])*block
    directory=image[beginning:beginning+loc(desc[166:170])]
    files={};pos=0
    while pos<len(directory):
        size=directory[pos]
        if not size:
            pos=(pos//block+1)*block
            continue
        entry=directory[pos:pos+size];pos+=size
        if entry[25]&2:continue
        length=entry[32];field=33+length+(1-length%2)
        name=entry[33:33+length].decode().split(';')[0]
        while field+4<=size and entry[field+2]:
            count=entry[field+2]
            if entry[field:field+2]==b'NM':name=entry[field+5:field+count].decode()
            field+=count
        start=loc(entry[2:6])*block;files[name]=image[start:start+loc(entry[10:14])]
    return files

for cd in sorted(root.glob('cd[12]')):
    meta=json.loads((cd/'media.json').read_text())
    iso=(cd/'tester.iso').read_bytes()
    if sha(iso)!=meta['iso']:raise ValueError('ISO hash')
    files=optical_files(iso)
    if {k:sha(v) for k,v in files.items()}!=meta['disc_files']:raise ValueError('file readback')
    assert sha(files['tailorbird.elf'])==meta['app']
    for run in sorted(cd.glob('boot-*')):
        result=json.loads((run/'result.json').read_text())
        frame_names={name for name,entry in result.items() if isinstance(entry,dict) and 'dimensions' in entry}
        assert {p.stem for p in run.glob('*.png')} == frame_names
        for png in run.glob('*.png'):
            with Image.open(png) as im:
                width,height=im.size;rgb=im.tobytes()
            ppm=f'P6\n{width} {height}\n255\n'.encode()+rgb
            assert sha(ppm)==result[png.stem]['sha256'], png
            probes={'app':(737,27,12,20,'NO SERVICE',0xf08a72,0x18364f),
                    'compact':(418,513,6,10,'F6: COMPACT',0x41bad7,0x10283f,True),
                    'restored-fit':(418,513,6,10,'F6: FIT',0x41bad7,0x10283f),
                    'typed':(140,460,10,20,'hello',0xf2f7fc,0x18364f),
                    'submit':(535,513,6,10,'NO MODEL SERVICE - OS STILL USABLE',0xe3a24b,0x10283f)}
            if png.stem in probes:label((width,height),rgb,*probes[png.stem])
        record=(run/'serial.txt').read_bytes()
        assert sha(record)==result['serial_sha256']
        serial=record.decode()
        assert f"starting tailorbird.elf ({meta['app_bytes']} bytes, SHA-256 {meta['app']})" in serial
        assert 'Tailorbird first frame presented' in serial and result['return_record'] in serial
        assert 'tailorbird.elf ended DONE: exit 0' in result['return_record']
        assert 'ALL SELF-TESTS PASS.' in serial and result['exit']==0 and len(re.findall('^  pass ',serial,re.M))==result['passes']==72
        print(cd.name,run.name,'verified',meta['app'][:12],result['passes'],'self-tests')

import hashlib
import json
import os
import runpy
import subprocess
import sys
from pathlib import Path
w=Path(__file__).resolve().parent
rt=w.parent
label,release,elf_path,pinned_sha=sys.argv[1:]
out=w/label
out.mkdir(exist_ok=True)
osrepo=w/'os-master'
media=runpy.run_path(str(osrepo/'examples/tester-cd/build.py'))
prior=rt/'a3-309-fallback/cd'
receipt=json.loads((prior/'receipt.json').read_text())
image=(prior/'pcp-os-tester.iso').read_bytes()
assert media['sha'](image)==receipt['iso_sha256']
files=media['read_back'](image)
assert {k:media['sha'](v) for k,v in files.items()}=={k:v['sha256'] for k,v in receipt['on_disc'].items()}
del files['boot.cat']
boot='limine-bios-cd.bin'
files[boot]=(w/'limine'/boot).read_bytes()
assert media['sha'](files[boot])==media['LOADER'][boot]
subprocess.run(['git','diff','--quiet',receipt['source_commit'],'HEAD','--','apps/surfbird/guest','store/native/guest','store/games/flux-rink/guest.ld','PCP_OS_Rust/crates/pcpos-kernel/src/font.rs'],cwd=osrepo,check=True)
kernel=w/'iso-stage/source/PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32'
measurement=subprocess.check_output(['python3',osrepo/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py',kernel],text=True).split()[-1]
elf=Path(elf_path).read_bytes()
assert media['sha'](elf)==pinned_sha
files['kernel.elf32']=kernel.read_bytes()
files['tailorbird.elf']=elf
files['limine.conf']=files['limine.conf'].replace(receipt['kernel_measurement'].encode(),measurement.encode())+b'    module_path: boot():/tailorbird.elf\n    module_string: tailorbird.elf\n'
files['readme.txt']=f"""Director A3 disposable BIOS tester disc. Start Programs, select tailorbird.elf, press Enter. Esc returns to the launcher. The Tailorbird UI is disconnected.
PCP OS kernel 53a551a297ec35f50917c12efada45f3150ece35. Tailorbird {release}. PCP OS guest dependency 745e8831cb25090ce478fcf246dcf6c8a65ec7b2.
Surfbird demo, clips and notices carried by tester disc {receipt['iso_sha256']}. See notice.md, notices.txt and limine.txt.
""".encode()
env={**os.environ,'PATH':str(rt/'root/usr/bin')+':'+os.environ['PATH'],'LD_LIBRARY_PATH':str(rt/'lib'),'SOURCE_DATE_EPOCH':str(media['EPOCH']),'TZ':'UTC','LC_ALL':'C'}
for copy in ['first','second']:
    root=out/('tree-'+copy);root.mkdir(exist_ok=True)
    for name,data in files.items():(root/name).write_bytes(data)
    media['assemble'](root,out/(copy+'.iso'),env)
assert (out/'first.iso').read_bytes()==(out/'second.iso').read_bytes()
cd=(out/'first.iso').read_bytes()
readback=media['read_back'](cd)
assert set(readback)==set(files)|{'boot.cat'}
for name,data in files.items():
    if name==boot:
        assert data[:8]+data[64:]==readback[name][:8]+readback[name][64:]
    else:assert readback[name]==data,name
res=dict(revision=release,app=media['sha'](elf),app_bytes=len(elf),kernel=media['sha'](files['kernel.elf32']),measurement=measurement,base_iso=receipt['iso_sha256'],base_commit=receipt['source_commit'],iso=media['sha'](cd),iso_bytes=len(cd),disc_files={k:media['sha'](v) for k,v in sorted(readback.items())})
(out/'media.json').write_text(json.dumps(res,indent=2)+'\n')
print(res['iso'],len(cd),measurement,len(readback))

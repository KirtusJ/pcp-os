# Tailorbird optical tester evidence

Director A3, 21 November 2026. The two CDs are disposable, diskless BIOS emulator fixtures. Each retains the Surfbird demo and adds the separately built Tailorbird guest. Each was assembled twice identically. Every file was read back from the ISO 9660 directory. The current PCP OS kernel was built from master `53a551a297ec35f50917c12efada45f3150ece35`. Limine is 10.8.5 at `7a9013f305de0bea1f6310e76e7baba30499fef0`.

| Directory | Tailorbird source | ELF bytes | ELF SHA-256 |
| --- | --- | ---: | --- |
| cd1 | `312c6273d911887711b20d49087119444cc33df1` | 149304 | `f67d41ab467690545f1fc53760503c3ca399f68557760d433775e7da7b6e60b7` |
| cd2 | `9efd5352c3877418765a7fc05d215bae01f44306` | 149384 | `c1e79cee1b5a645062d15dc2cd9de2cf2d4306d9de34edc395052a7c2b727b00` |

Both builds pin the guest library at `745e8831cb25090ce478fcf246dcf6c8a65ec7b2`. The Rust 1.97.0 compiler ran from two filesystem locations with the same toolchain files. Cargo placed outputs in four separate target directories. Each revision reproduced its documented hash in both and its script identified the correct output. The offline library tests passed in debug and release for both locations, 99 per run for cd1 and 111 for cd2.

The tester builder produced the kernel before its full baseline build stopped on a missing offline Surfbird dependency. Each fixture therefore uses the Surfbird binary, demo clips and notices read back from the prior tester disc identified in media.json. The Surfbird guest source, guest library, linker script and font on which that prior Surfbird build depended are identical between its source revision and this master. The Limine boot file was restored from the original pinned binary release before mastering. The two Tailorbird images do not add a model or installer.

On PC and Q35, each guest received one read-only optical medium and no network device. At 1920×1080 the operator entered Programs, selected Tailorbird, switched to compact view with F6, restored fit view, typed `hello`, pressed Enter and saw `NO MODEL SERVICE - OS STILL USABLE`. Esc returned to the launcher. F10 followed by Enter shut down the guest. All four serial logs report exit 0 for the application and 72 passing kernel checks. These tests cover the public UI and emulated BIOS optical boot. C3 owns the separate workflow and connected-source investigation.

Run `python3 -B replay.py` from any directory with Python 3 and Pillow. It reads each disc’s file directory and digests, reconstructs the original QEMU P6 bytes from lossless PNGs, checks the captured labels against the pinned font, and verifies the corresponding serial records. Each `media.json` and `result.json` preserves the observed digests. The other scripts and commands are the original build and run records and contain paths from the verification workspace.

A new manual boot uses `qemu-system-x86_64 -machine pc -accel tcg -cpu qemu64 -m 64M -boot order=d -cdrom cd2/tester.iso -vga std -nic none`. Use `q35` for the second machine. Distribution notices are on the media and in `font/NOTICE.md`.

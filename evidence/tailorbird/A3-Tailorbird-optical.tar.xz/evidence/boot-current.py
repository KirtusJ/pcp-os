import ast
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import sys
import time

w=Path(__file__).resolve().parent
out=w/sys.argv[2]
repo=w/sys.argv[3]
checker=runpy.run_path(str(w/'os-master/examples/tester-cd/check.py'))
smoke=runpy.run_path(str(repo/'guest/tests/qemu_smoke.py'))
Qemu=smoke['Qemu']
fontsrc=repo/'pcp-os/PCP_OS_Rust/crates/pcpos-kernel/src'
small=ast.literal_eval('['+(fontsrc/'font.rs').read_text().split(' = [',1)[1].split('];',1)[0]+']')
large=(fontsrc/'font-2x.bin').read_bytes()
def label(dims, pixels, x, y, cellw, cellh, text, fg, bg, compact=False):
    width,height=dims
    whole=min(width//960,height//540)
    if whole: scale,div=(1 if compact else whole),1
    elif width*540<height*960: scale,div=width,960
    else: scale,div=height,540
    left=(width-960*scale//div)//2
    top=(height-540*scale//div)//2
    def pos(x,y):return left+x*scale//div, top+y*scale//div
    hits=0
    for i,ch in enumerate(text):
        x0,y0=pos(x+i*cellw,y);x1,y1=pos(x+(i+1)*cellw,y+cellh)
        dw,dh=x1-x0,y1-y0
        index=ord(ch)-32
        if dw>10 or dh>20:sw,sh,mask=20,40,large[index*800:(index+1)*800]
        else:sw,sh,mask=10,20,small[index]
        for j in range(dh):
            a=j*sh//dh;b=max(a+1,(j+1)*sh//dh)
            for k in range(dw):
                c=k*sw//dw;d=max(c+1,(k+1)*sw//dw)
                alpha=sum(sum(mask[n*sw+c:n*sw+d]) for n in range(a,b))//((b-a)*(d-c))
                expected=bytes((((bg>>shift)&255)*(255-alpha)+((fg>>shift)&255)*alpha+127)//255 for shift in (16,8,0))
                off=3*((y0+j)*width+x0+k)
                if pixels[off:off+3]!=expected:
                    raise ValueError(f"{text!r} differs at {x0+k},{y0+j}: {pixels[off:off+3].hex()} vs {expected.hex()}")
                hits+=bool(alpha)
    if not hits: raise ValueError("blank test string")
    return hits
class Optical(Qemu):
    def __init__(self,machine,folder):
        self.folder=folder
        self.serial_path=folder/'serial.txt'
        cmd=[str(w.parent/'bin/qemu-system-x86_64'),'-machine',machine,'-accel','tcg','-cpu','qemu64','-m','64M','-boot','order=d','-cdrom',str(out/'first.iso'),'-vga','std','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(self.serial_path)]
        (folder/'argv.json').write_text(json.dumps(cmd,indent=2))
        self.proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(folder/'stderr.txt').open('wb'),bufsize=0)
        self._response();self.qmp('qmp_capabilities')
def main(machine):
    folder=out/('boot-'+machine);folder.mkdir(exist_ok=True)
    m=Optical(machine,folder)
    report={}
    meta=json.loads((out/'media.json').read_text())
    glyphs=checker['kernel_glyphs']()
    def wait(s,timeout=65):
        deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            if s in m.serial():return
            if m.proc.poll() is not None:break
            time.sleep(.12)
        raise RuntimeError('serial missing '+s+'; tail '+m.serial()[-500:])
    def screen(tag):
        dims,img,h=m.screenshot(tag)
        report[tag]={'dimensions':dims,'sha256':h}
        return dims,img
    def desktop(tag,word):
        for _ in range(15):
            time.sleep(.20);screen(tag)
            rows=checker['read_screen']((folder/(tag+'.ppm')).read_bytes(),glyphs) or []
            if any(word in line for line in rows):
                (folder/(tag+'.txt')).write_text('\n'.join(rows)+'\n')
                return rows
        raise ValueError(tag+' missing '+word+'; '+str(rows)[:750])
    try:
        media=[b['inserted'] for b in m.qmp('query-block')['return'] if 'inserted' in b]
        assert len(media)==1 and media[0]['ro'] and Path(media[0]['file']).resolve()==(out/'first.iso').resolve()
        wait(meta['measurement']+' (measured; equal to the value the loader named)')
        wait('leaves no memory behind')
        desktop('home','Programs');m.key('ret');desktop('list','surf.elf');m.key('down');rows=desktop('selected','tailorbird.elf')
        m.key('ret');wait('Tailorbird first frame presented')
        time.sleep(.35);dims,img=screen('app')
        report['no-service-ink']=label(dims,img,737,27,12,20,'NO SERVICE',0xf08a72,0x18364f)
        report['fit-ink']=label(dims,img,418,513,6,10,'F6: FIT',0x41bad7,0x10283f)
        m.key('f6');dims,img=screen('compact')
        report['compact-ink']=label(dims,img,418,513,6,10,'F6: COMPACT',0x41bad7,0x10283f,compact=True)
        m.key('f6');dims,img=screen('restored-fit')
        report['restored-fit-ink']=label(dims,img,418,513,6,10,'F6: FIT',0x41bad7,0x10283f)
        for key in ['h','e','l','l','o']:m.key(key)
        dims,img=screen('typed')
        report['typed-ink']=label(dims,img,140,460,10,20,'hello',0xf2f7fc,0x18364f)
        m.key('ret');dims,img=screen('submit')
        report['refusal-ink']=label(dims,img,535,513,6,10,'NO MODEL SERVICE - OS STILL USABLE',0xe3a24b,0x10283f)
        m.key('esc');wait('tailorbird.elf ended DONE: exit 0')
        desktop('returned','tailorbird.elf')
        m.key('esc');desktop('home-return','Programs')
        m.key('f10');desktop('confirm','POWER OFF');m.key('ret')
        wait('ALL SELF-TESTS PASS.')
        assert m.proc.wait(timeout=15)==0
        serial=m.serial()
        assert meta['app'] in serial and not any(line.startswith('  FAIL ') for line in serial.splitlines())
        report.update(machine=machine,elf=meta['app'],iso=meta['iso'],exit=0,serial_sha256=hashlib.sha256(m.serial_path.read_bytes()).hexdigest(),return_record=next(x for x in serial.splitlines() if 'tailorbird.elf ended DONE: exit 0' in x),passes=sum(x.startswith('  pass ') for x in serial.splitlines()))
        (folder/'result.json').write_text(json.dumps(report,indent=2)+'\n')
        print(machine, report['return_record'], report['passes'],'passes')
    finally: m.stop()
main(sys.argv[1])

#!/bin/bash
set -euo pipefail
rt=$(cd "$(dirname "$0")/.." && pwd)
w="$rt/a3-tailor-media"; app="$1"; tool="$2"; label="$3"
export PATH="$tool/bin:$tool/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$PATH"
export CARGO_HOME="$rt/a3-331-run/cargo" CARGO_NET_OFFLINE=true CARGO_TARGET_DIR="$w/$label-output"
cd "$app"
checkout=$(git rev-parse HEAD); pin=$(git ls-tree HEAD pcp-os | awk '{print $3}')
test "$(git -C pcp-os rev-parse HEAD)" = "$pin"
cargo test --locked --offline --lib > "$w/$label-debug.log"
cargo test --locked --offline --release --lib > "$w/$label-release.log"
sh build.sh --offline > "$w/$label-digest.txt"
sha256sum -c "$w/$label-digest.txt"
test "$(cut -c 67- "$w/$label-digest.txt")" = "$CARGO_TARGET_DIR/x86_64-unknown-none/release/tailorbird"

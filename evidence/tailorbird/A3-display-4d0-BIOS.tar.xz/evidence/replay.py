import hashlib,json
from pathlib import Path
from PIL import Image
from pixel_reader import label

root=Path(__file__).resolve().parent
def sha(data):return hashlib.sha256(data).hexdigest()

expected_frames={}
app='c1e79cee1b5a645062d15dc2cd9de2cf2d4306d9de34edc395052a7c2b727b00'
texts={'app':(737,27,12,20,'NO SERVICE',0xf08a72,0x18364f),
       'typed':(140,460,10,20,'hello',0xf2f7fc,0x18364f),
       'submit':(535,513,6,10,'NO MODEL SERVICE - OS STILL USABLE',0xe3a24b,0x10283f)}
for case in ('parent-pc','os-pc','os-q35'):
    folder=root/case
    result=json.loads((folder/'result.json').read_text())
    meta=json.loads((folder/'media.json').read_text())
    serial=(folder/'serial.txt').read_bytes()
    assert sha(serial)==result['serial_sha256']
    serial=serial.decode()
    assert result['iso']==meta['iso'] and result['kernel']==meta['disc_files']['kernel.elf32']
    assert result['elf']==meta['app']==meta['disc_files']['tailorbird.elf']==app
    for message in (meta['measurement']+' (measured; equal to the value the loader named)',
                    'Bochs, 800x600, 2 page(s)',f'starting tailorbird.elf (149384 bytes, SHA-256 {app})',
                    'Tailorbird first frame presented','tailorbird.elf ended DONE: exit 0','ALL SELF-TESTS PASS.'):
        assert message in serial, (case,message)
    assert result['passes']==sum(line.startswith('  pass ') for line in serial.splitlines())==72
    assert not any(line.startswith('  FAIL ') for line in serial.splitlines())
    assert '"reason": "guest-shutdown"' in (folder/'host.log').read_text()
    for key,value in result.items():
        if not isinstance(value,dict) or 'dimensions' not in value:continue
        with Image.open(folder/(key+'.png')) as im:
            assert im.size==(800,600)
            rgb=im.tobytes()
        assert sha(b'P6\n800 600\n255\n'+rgb)==value['sha256']
        if key in texts:
            assert label((800,600),rgb,*texts[key])>0
            assert expected_frames.setdefault(key,value['sha256'])==value['sha256']
    print(case, '72 checks, three identical application frames, guest shutdown')

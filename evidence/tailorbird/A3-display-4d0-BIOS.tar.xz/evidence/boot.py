import hashlib,json,re,runpy,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent
prior=root.parent/'a3-tailor-media'
mode=sys.argv[1]
machine, revision = sys.argv[2:4]
out=root/(revision+'-media')
meta=json.loads((out/'media.json').read_text())
scope={'__file__':str(prior/'boot-current.py')}
orig_argv=sys.argv[:]
sys.argv=['boot-current.py','pc',str(out),'app2']
source=(prior/'boot-current.py').read_text().removesuffix('main(sys.argv[1])\n')
exec(compile(source,str(prior/'boot-current.py'),'exec'),scope)
sys.argv=orig_argv
folder=out/('boot-'+machine);folder.mkdir(exist_ok=True)
m=scope['Optical'](machine,folder)
probe=scope['label']
glyphs=scope['checker']['kernel_glyphs']()
read=runpy.run_path(str(prior/'os-master/examples/tester-cd/check_compact_pins.py'))['read']
result={'requested':mode,'machine':machine,'kernel':meta['kernel'],'kernel_revision':meta['kernel_revision'],'iso':meta['iso'],'elf':meta['app']}
def screen(tag):
    dims,img,h=m.screenshot(tag)
    assert dims==tuple(map(int,mode.split('x'))),(tag,dims,mode)
    result[tag]={'sha256':h,'dimensions':dims}
    return dims,img
def rows(tag,word):
    for i in range(15):
        time.sleep(.2)
        dims,img=screen(tag)
        seen=read((folder/(tag+'.ppm')).read_bytes(),glyphs)
        if word in ' '.join(seen):
            (folder/(tag+'.txt')).write_text('\n'.join(seen)+'\n')
            return
    raise ValueError(tag+': '+str(seen)[:1000])
def wait(predicate):
    end=time.monotonic()+45
    while time.monotonic()<end:
        serial=m.serial()
        if predicate(serial):return serial
        if m.proc.poll() is not None: break
        time.sleep(.15)
    raise RuntimeError('guest wait expired: '+m.serial()[-450:])
try:
    blocks=[b['inserted'] for b in m.qmp('query-block')['return'] if 'inserted' in b]
    assert len(blocks)==1 and blocks[0]['ro'] and Path(blocks[0]['file']).resolve()==(out/'first.iso').resolve()
    wait(lambda s:meta['measurement']+' (measured; equal to the value the loader named)' in s and 'leaves no memory behind' in s)
    rows('desktop','Programs')
    m.key('ret');rows('list','surf.elf');m.key('down');rows('selected','tailorbird.elf');m.key('ret')
    serial=wait(lambda s:'Tailorbird first frame presented' in s or 'tailorbird.elf ended ' in s)
    if 'Tailorbird first frame presented' in serial:
        time.sleep(.35);dims,img=screen('app')
        probe(dims,img,737,27,12,20,'NO SERVICE',0xf08a72,0x18364f)
        for key in ['h','e','l','l','o']:m.key(key)
        dims,img=screen('typed');probe(dims,img,140,460,10,20,'hello',0xf2f7fc,0x18364f)
        m.key('ret');dims,img=screen('submit');probe(dims,img,535,513,6,10,'NO MODEL SERVICE - OS STILL USABLE',0xe3a24b,0x10283f)
        m.key('esc');wait(lambda s:'tailorbird.elf ended DONE: exit 0' in s)
        result['first_frame']=True
    else:result['first_frame']=False
    result['return_record']=next(l for l in m.serial().splitlines() if 'tailorbird.elf ended ' in l)
    rows('returned','tailorbird.elf');m.key('esc');rows('returned-desktop','Programs')
    m.key('f10');rows('confirm','POWER OFF');m.key('ret')
    serial=wait(lambda s:'ALL SELF-TESTS PASS.' in s)
    assert m.proc.wait(timeout=20)==0
    assert meta['app'] in serial and not any(x.startswith('  FAIL ') for x in serial.splitlines())
    result['passes']=sum(x.startswith('  pass ') for x in serial.splitlines())
    assert 'display: Bochs, 800x600, 2 page(s)' in serial and result['first_frame'] and result['passes'] >= 72
    result['serial_sha256']=hashlib.sha256(m.serial_path.read_bytes()).hexdigest()
    (folder/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(mode,result['first_frame'],result['passes'],result['return_record'])
finally:m.stop()

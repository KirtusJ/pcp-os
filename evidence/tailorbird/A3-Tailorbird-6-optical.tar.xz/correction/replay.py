from pathlib import Path
from PIL import Image
import hashlib,json
from pixel_reader import label
root=Path(__file__).resolve().parent
meta=json.loads((root/'media.json').read_text())
cases={c['name'] for c in json.loads((root/'cases.json').read_text())}
empty={
    'early_stop_requested':('No preview received yet','Waiting for the worker to stop','Waiting for the worker to stop',0xe3a24b),
    'early_stopped':('No preview received','Worker stopped before a preview arrived','Worker stopped before any preview arrived',0x8fe0c2),
    'early_disconnected':('No preview received','Connection lost; work status unknown','No preview received; work status unknown',0xe3a24b),
    'early_failed':('No preview received','Work failed before a preview arrived','Sample build check failed',0xf08a72),
}
assert len(cases)==16 and meta['source']=='cd89f12f39ec80e891062f7fd8545f72105d2000'
for machine in ('pc','q35'):
    p=root/machine
    result=json.loads((p/'result.json').read_text())
    assert result['passed'] and result['elf']==meta['app'] and result['iso']==meta['iso'] and cases<=result['frames'].keys()
    assert result['checks']==dict(literal_font_checks=16,adverse_controls=64,empty_copy_checks=12,empty_copy_adverse_controls=24)
    serial=(p/'serial.txt').read_bytes()
    assert hashlib.sha256(serial).hexdigest()==result['serial_sha256'] and meta['app'].encode() in serial
    assert sum(x.startswith(b'  pass ') for x in serial.splitlines())==72 and b'demo.elf ended DONE: exit 0' in serial
    assert '"reason": "guest-shutdown"' in (p/'host.log').read_text()
    snapshots={}
    for tag,digest in result['frames'].items():
        with Image.open(p/(tag+'.png')) as im:
            assert im.size==(800,600)
            size=im.size;data=im.tobytes()
            if tag in cases:snapshots[tag]=im.crop((324,226,642,425)).tobytes()
        assert hashlib.sha256(b'P6\n800 600\n255\n'+data).hexdigest()==digest
        if tag in cases:
            assert label(size,data,20,7,8,16,'PCP OS > TAILORBIRD > UI DEMO / sample events / no files written',0x10283f,0xe3a24b)>0
        if tag in empty:
            heading,message,detail,colour=empty[tag]
            for spec in [(400,298,8,16,heading,0xf2f7fc,0x18364f),(360,324,8,16,message,0x9fb4c8,0x18364f),(24,487,8,16,detail,colour,0x10283f)]:
                assert label(size,data,*spec)>0
    assert snapshots['built']==snapshots['stopped']==snapshots['failed']==snapshots['disconnected']
    assert snapshots['draft']!=snapshots['preview']
    assert result['frames']['disconnected']==result['frames']['late_after_disconnect']
    print(machine,'16 disclosures, 12 empty text lines, retained earlier preview, 72 checks and guest shutdown')

import hashlib,json
from pathlib import Path
from PIL import Image
root=Path(__file__).resolve().parent
receipts={b:json.loads((root/(b+'-receipt.json')).read_text()) for b in ('parent','candidate')}
assert receipts['parent']['source_commit']=='070c9d5925a2c208c33c60db92e51156555407c8'
assert receipts['candidate']['source_commit']=='1670a53b3d4673cd79eeff093cf8d4326bb3344f'
for b,r in receipts.items():
    assert not r['uncommitted_changes'] and r['on_disc']['kernel.elf32']['sha256']=='927c841c825390b8d7b7d6a6296ab8a501b12f15ac7a0bc5acc4749f0d54f452'
for app in ('surf.elf','rdesk.elf'):
    assert receipts['parent']['inputs'][app]['sha256']!=receipts['candidate']['inputs'][app]['sha256']
for p in sorted(i.parent for i in root.glob('*/result.json')):
    r=json.loads((p/'result.json').read_text())
    receipt=receipts[p.name.split('-')[0]]
    serial=(p/'serial.txt').read_text()
    assert r['passed'] and not r['problems'] and not r['register_problems']
    assert r['home_activity']==['DONE','STOPPED'] and r['final_pass_lines']==72
    assert r['shutdown']=={'guest':True,'reason':'guest-shutdown'} and 'SURFBIRD media drained' in serial
    for app in ('surf.elf','rdesk.elf'):
        meta=receipt['inputs'][app]
        assert f"starting {app} ({meta['bytes']} bytes, SHA-256 {meta['sha256']})" in serial
    for name,digest in json.loads((p/'original-frames.json').read_text()).items():
        with Image.open(p/(name+'.png')) as im:
            width,height=im.size
            assert hashlib.sha256(f'P6\n{width} {height}\n255\n'.encode()+im.tobytes()).hexdigest()==digest
    print(p.name,'verified both app digests, playback/stop, original frames and shutdown')

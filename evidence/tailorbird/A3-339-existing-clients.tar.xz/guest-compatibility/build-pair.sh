set -eu
w=$(cd "$(dirname "$0")" && pwd)
rt=$(dirname "$w")
export PATH="$rt/register-live/rust197/bin:$rt/register-live/rust197/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$rt/root/usr/bin:$PATH"
export LD_LIBRARY_PATH="$rt/lib" CARGO_HOME="$rt/a3-337-media/cargo" CARGO_NET_OFFLINE=true CARGO_BUILD_JOBS=1
export PCPOS_TESTER_CD_STAGE="$w/work"
for ref in parent candidate; do
  python3 -B "$w/build-media.py" "$ref" "$rt/a3-tailor-media/limine" "$w/$ref-disc" --queue-desk > "$w/$ref-build.log"
done

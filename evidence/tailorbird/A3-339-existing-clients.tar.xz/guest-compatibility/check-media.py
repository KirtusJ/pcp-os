import difflib,json,sys
from pathlib import Path
w=Path(__file__).resolve().parent
name,machine=sys.argv[1:]
source=w/'candidate/examples/tester-cd/check.py'
initial=source.read_text()
code=initial.replace('"unix:%s,server=on,wait=off" % sock','"stdio"').replace('guest = subprocess.Popen(cmd, stderr=err)','guest = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True, stderr=err)')
start=code.index('        end = time.monotonic() + 20\n        while not sock.exists():')
end=code.index('        events = []', start)
code=code[:start]+code[end:]
code=code.replace('stream.readline()', 'guest.stdout.readline()').replace('stream.write(', 'guest.stdin.write(').replace('stream.flush()', 'guest.stdin.flush()')
assert 'stream.' not in code and 'channel.' not in code
(w/'optical-transport.diff').write_text(''.join(difflib.unified_diff(initial.splitlines(True),code.splitlines(True),fromfile='tracked/check.py',tofile='local/check.py')))
scope={'__name__':'optical','__file__':str(source)}
exec(compile(code,str(source),'exec'),scope)
built=w/name
receipt=json.loads((built/'receipt.json').read_text())
res=scope['session'](str(w.parent/'bin/qemu-system-x86_64'),(built/'pcp-os-tester.iso').resolve(),w/(name+'-'+machine),machine,False,receipt['kernel_measurement'],90,scope['kernel_glyphs'](),{k:v['sha256'] for k,v in receipt['inputs'].items() if k.endswith('.elf')},set(receipt['kernel_features'].split()))
print(json.dumps({k:res.get(k) for k in ('passed','problems','error','final_pass_lines','exit_code')}))
if not res.get('passed'): raise SystemExit(1)

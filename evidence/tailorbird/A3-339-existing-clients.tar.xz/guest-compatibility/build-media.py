import hashlib,runpy,shutil,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
source=w/sys.argv.pop(1)
script=source/'examples/tester-cd/build.py'
helper=runpy.run_path(str(script))
kernel=w/'candidate/PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32'
sha=hashlib.sha256(kernel.read_bytes()).hexdigest()
source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
subprocess.run(['git','diff','--exit-code','1670a53b3d4673cd79eeff093cf8d4326bb3344f',source_sha,'--','PCP_OS_Rust'],cwd=source,check=True)
old=helper['run']
def use_built(*args,**kwargs):
    if len(args)==3 and args[0]=='sh' and Path(args[1]).name=='run.sh' and args[2]=='build':
        out=Path(args[1]).parent/'target/pcpos-kernel.elf32';out.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(kernel,out)
        assert hashlib.sha256(out.read_bytes()).hexdigest()==sha
        return ''
    return old(*args,**kwargs)
helper['main'].__globals__['run']=use_built
helper['main']()

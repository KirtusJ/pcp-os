set -eu
w=$(cd "$(dirname "$0")" && pwd)
rt=$(dirname "$w")
d="$1"
export PATH="$rt/register-live/rust197/bin:$rt/register-live/rust197/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$PATH"
export CARGO_HOME="$rt/a3-331-run/cargo" CARGO_NET_OFFLINE=true CARGO_TARGET_DIR="$w/$d-target"
export TAILORBIRD_SHOT="$w/$d-frames"
mkdir -p "$TAILORBIRD_SHOT"
cd "$w/$d"
cargo test --locked --offline --lib > "$w/$d-debug.log"
cargo test --locked --offline --release --lib > "$w/$d-release.log"
sh build.sh --offline --bin tailorbird > "$w/$d-normal.sha"
sha256sum -c "$w/$d-normal.sha"
if [ "$d" = four ]; then
  sh build.sh --offline --features live-work-demo --bin tailorbird-work-demo > "$w/four-demo.sha"
  sha256sum -c "$w/four-demo.sha"
  cargo run --locked --offline --release --example live_work_frames -- "$TAILORBIRD_SHOT"
fi

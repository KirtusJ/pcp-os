import json,hashlib
from pathlib import Path
from PIL import Image
from pixel_reader import label
root=Path(__file__).resolve().parent
ref=json.loads((root/'reference.json').read_text())
for dest in sorted(p.parent for p in root.glob('*/result.json')):
    meta=json.loads((dest/'media.json').read_text())
    r=json.loads((dest/'result.json').read_text())
    serial=(dest/'serial.txt').read_bytes()
    assert r['passed'] and hashlib.sha256(serial).hexdigest()==r['serial_sha256']
    assert r['elf']==meta['app']==meta['disc_files']['tailorbird.elf']
    assert r['iso']==meta['iso'] and meta['kernel']==meta['disc_files']['kernel.elf32']
    assert meta['measurement'].encode() in serial and r['elf'].encode() in serial
    assert sum(s.startswith(b'  pass ') for s in serial.splitlines())==72 and b'ALL SELF-TESTS PASS.' in serial
    assert b'tailorbird.elf ended DONE: exit 0' in serial and '"reason": "guest-shutdown"' in (dest/'host.log').read_text()
    for tag,digest in r['frames'].items():
        with Image.open(dest/(tag+'.png')) as im:
            assert im.size==(800,600)
            rgb=im.tobytes()
        assert hashlib.sha256(b'P6\n800 600\n255\n'+rgb).hexdigest()==digest
        if dest.name.startswith('five') and tag=='breadcrumb':
            for spec in ((22,52,6,12,'PCP OS > Programs > Tailorbird (Esc returns to Programs)',0x9fb4c8,0x18364f),(370,420,6,12,'returns to Programs',0x9fb4c8,0x18364f)):
                assert label((800,600),rgb,*spec)>0
        if dest.name.startswith('os338') and tag in ('app','typed','submit'):
            assert digest==ref[tag]['sha256']
    assert 'surf.elf' in (dest/'one-escape.txt').read_text() and 'tailorbird.elf' in (dest/'one-escape.txt').read_text()
    assert 'PCP OS | DESKTOP' in (dest/'two-escapes.txt').read_text()
    print(dest.name,meta['kernel_revision'][:7],meta['source'][:7],'frames, both destinations and shutdown verified')

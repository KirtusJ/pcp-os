import ast
from pathlib import Path
fontsrc=Path(__file__).resolve().parent/'font'
small=ast.literal_eval('['+(fontsrc/'font.rs').read_text().split(' = [',1)[1].split('];',1)[0]+']')
large=(fontsrc/'font-2x.bin').read_bytes()
def label(dims, pixels, x, y, cellw, cellh, text, fg, bg, compact=False):
    width,height=dims
    whole=min(width//960,height//540)
    if whole: scale,div=(1 if compact else whole),1
    elif width*540<height*960: scale,div=width,960
    else: scale,div=height,540
    left=(width-960*scale//div)//2
    top=(height-540*scale//div)//2
    def pos(x,y):return left+x*scale//div, top+y*scale//div
    hits=0
    for i,ch in enumerate(text):
        x0,y0=pos(x+i*cellw,y);x1,y1=pos(x+(i+1)*cellw,y+cellh)
        dw,dh=x1-x0,y1-y0
        index=ord(ch)-32
        if dw>10 or dh>20:sw,sh,mask=20,40,large[index*800:(index+1)*800]
        else:sw,sh,mask=10,20,small[index]
        for j in range(dh):
            a=j*sh//dh;b=max(a+1,(j+1)*sh//dh)
            for k in range(dw):
                c=k*sw//dw;d=max(c+1,(k+1)*sw//dw)
                alpha=sum(sum(mask[n*sw+c:n*sw+d]) for n in range(a,b))//((b-a)*(d-c))
                expected=bytes((((bg>>shift)&255)*(255-alpha)+((fg>>shift)&255)*alpha+127)//255 for shift in (16,8,0))
                off=3*((y0+j)*width+x0+k)
                if pixels[off:off+3]!=expected:
                    raise ValueError(f"{text!r} differs at {x0+k},{y0+j}: {pixels[off:off+3].hex()} vs {expected.hex()}")
                hits+=bool(alpha)
    if not hits: raise ValueError("blank test string")
    return hits

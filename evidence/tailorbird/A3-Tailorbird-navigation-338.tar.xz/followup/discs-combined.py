import hashlib,json,os,runpy,shutil,subprocess,sys
from pathlib import Path
w=Path(__file__).resolve().parent
rt=w.parent
base=rt/'a3-display-4d0/os338-media'
helper=runpy.run_path(str(rt/'a3-display-4d0/parent/examples/tester-cd/build.py'))
sha=helper['sha']
meta=json.loads((base/'media.json').read_text())
original=(base/'first.iso').read_bytes()
assert sha(original)==meta['iso']
baseline=helper['read_back'](original)
assert {k:sha(v) for k,v in baseline.items()}==meta['disc_files']
env=dict(os.environ,PATH=str(rt/'root/usr/bin')+':'+os.environ['PATH'],LD_LIBRARY_PATH=str(rt/'lib'),SOURCE_DATE_EPOCH=str(helper['EPOCH']),LC_ALL='C',TZ='UTC')
for name,build,filename,receipt in [('four','four','tailorbird-work-demo','four-demo'),('five','five','tailorbird','five-normal'),('os338-four-normal','four','tailorbird','four-normal'),('five-main','five-main','tailorbird','five-main-normal'),('four-new','four-new','tailorbird-work-demo','four-new-demo')]:
    if name not in sys.argv[1:]:continue
    out=w/(name+'-disc');out.mkdir(exist_ok=True)
    tree=out/'tree';shutil.copytree(base/'tree',tree,dirs_exist_ok=True)
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w/build,text=True).strip()
    file='demo.elf' if name in ('four','four-new') else 'tailorbird.elf'
    binary=(w/(build+'-target')/'x86_64-unknown-none/release'/filename).read_bytes()
    assert sha(binary)==(w/(receipt+'.sha')).read_text().split()[0]
    (tree/'tailorbird.elf').unlink()
    (tree/file).write_bytes(binary)
    (tree/'limine.conf').write_bytes(baseline['limine.conf'].replace(b'tailorbird.elf',file.encode()))
    (tree/'readme.txt').write_text('Disposable read-only BIOS compatibility test. Tailorbird source '+commit+'; executable '+filename+'.\n')
    for copy in ('first.iso','second.iso'):helper['assemble'](tree,out/copy,env)
    image=(out/'first.iso').read_bytes()
    assert image==(out/'second.iso').read_bytes()
    files=helper['read_back'](image)
    assert set(files)==(set(baseline)-{'tailorbird.elf'})|{file}
    for k,v in files.items():
        if k not in ('boot.cat','limine-bios-cd.bin'):
            assert v==(tree/k).read_bytes()
        if k not in ('boot.cat','limine-bios-cd.bin','limine.conf','readme.txt',file):
            assert v==baseline[k]
    assert files[file]==binary and files['kernel.elf32']==baseline['kernel.elf32']
    result=dict(kernel_revision=meta['kernel_revision'],kernel=meta['kernel'],measurement=meta['measurement'],app=sha(binary),source=commit,filename=file,iso=sha(image),disc_files={k:sha(v) for k,v in files.items()})
    (out/'media.json').write_text(json.dumps(result,indent=2)+'\n')
    print(name,result['iso'],result['app'])

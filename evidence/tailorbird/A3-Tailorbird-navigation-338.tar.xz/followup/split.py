from pathlib import Path
import subprocess,yaml
w=Path(__file__).resolve().parent
repo=w.parent.parent/'pcp-os'
def cmd(*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True)
a,b='2b9ee3aa852045758f31598a6293d9d1734dc26a','0ea12c77bd1a39b2e73925c237f5010c6e10ce78'
file='.github/workflows/tester-cd.yml'
assert cmd('diff','--name-only',a,b).strip()==file
old,new=[yaml.safe_load(cmd('show',x+':'+file))['jobs'] for x in (a,b)]
before=old['build-and-boot']
cd=new['build-and-boot']
keys=new['keyboard-and-stopped-screen']
name1='A keyboard controller that does not replay keys'
name2='Check swapped stopped screens and altered reason pixels'
orig=[s for s in before['steps'] if s.get('name') in (name1,name2)]
assert len(orig)==2 and not keys.get('needs')
assert {k:v for k,v in before.items() if k!='steps'}=={k:v for k,v in cd.items() if k!='steps'}
assert [s for s in before['steps'] if s not in orig]==cd['steps']
for s in orig:
    match=next(z for z in keys['steps'] if z.get('name')==s['name'])
    assert {k:v for k,v in s.items() if k!='if'}==match
    subprocess.run(['bash','-n'],input=match['run'],text=True,check=True)
assert keys['steps'][0]==cd['steps'][0]
assert keys['steps'][-1]['if']=='always()'
assert keys['steps'][-1]['with']['name']=='keyboard-and-stopped-screen-evidence'
assert keys['steps'][-1]['with']['path']=='${{ runner.temp }}/evidence'
print('2 identical moved commands, 12 unchanged CD steps, same head checkout, independent job, dedicated failure evidence')

import hashlib,json,runpy,sys,time
from pathlib import Path
w=Path(__file__).resolve().parent
rt=w.parent
name,machine=sys.argv[1:3]
out=w/(name+'-disc'); meta=json.loads((out/'media.json').read_text())
folder=out/machine; folder.mkdir(exist_ok=True)
prior=rt/'a3-tailor-media'
common=prior/'boot-current.py'
scope={'__file__':str(common)}
sys.argv=['boot-current.py',machine,str(out),'app2']
exec(compile(common.read_text().removesuffix('main(sys.argv[1])\n'),str(common),'exec'),scope)
m=scope['Optical'](machine,folder)
label=scope['label']
glyphs=scope['checker']['kernel_glyphs']()
read=runpy.run_path(str(rt/'a3-display-4d0/parent/examples/tester-cd/check_compact_pins.py'))['read']
base=json.loads((rt/'a3-display-4d0/parent-media/boot-pc/result.json').read_text())
app=meta['filename']
frames={}
record={'machine':machine,'elf':meta['app'],'iso':meta['iso'],'source':meta['source'],'frames':frames}
def screen(tag,check):
    end=time.monotonic()+35
    error=''
    while time.monotonic()<end:
        dims,img,digest=m.screenshot(tag)
        if dims==(800,600):
            try:
                if check(dims,img,digest):
                    frames[tag]=digest
                    return
            except (ValueError,AssertionError) as e:error=str(e)
        time.sleep(.15)
    raise RuntimeError(f'{tag} did not match; latest {error}, console {m.serial()[-350:]}')
def rows(tag,*words):
    def check(dims,img,digest):
        lines=read((folder/(tag+'.ppm')).read_bytes(),glyphs)
        if all(word in ' '.join(lines) for word in words):
            (folder/(tag+'.txt')).write_text('\n'.join(lines)+'\n')
            return True
        return False
    screen(tag,check)
def expected(tag,path):
    h=hashlib.sha256(path.read_bytes()).hexdigest()
    screen(tag,lambda dims,img,digest:digest==h)
def ink(tag,*specs):
    screen(tag,lambda dims,img,digest:all(label(dims,img,*s)>0 for s in specs))
try:
    drives=[x['inserted'] for x in m.qmp('query-block')['return'] if 'inserted' in x]
    assert len(drives)==1 and drives[0]['ro'] and Path(drives[0]['file']).resolve()==(out/'first.iso').resolve()
    rows('desktop','Programs','all 71 self-tests passed')
    m.key('ret');rows('programs','surf.elf')
    m.key('down');rows('selected',app)
    m.key('ret')
    if name in ('five','five-new'):
        expected('app',w/(name+'-frames')/'first-800x600.ppm')
        ink('breadcrumb',(22,52,6,12,'PCP OS > Programs > Tailorbird (Esc returns to Programs)',0x9fb4c8,0x18364f),(370,420,6,12,'returns to Programs',0x9fb4c8,0x18364f))
        for k in 'hello':m.key(k)
        ink('typed',(140,460,10,20,'hello',0xf2f7fc,0x18364f))
        m.key('ret')
        ink('submit',(535,513,6,10,'NO MODEL SERVICE - OS STILL USABLE',0xe3a24b,0x10283f))
    elif name=='four-normal':
        for tag in ('app','typed','submit'):
            if tag=='typed':
                for k in 'hello':m.key(k)
            if tag=='submit':m.key('ret')
            screen(tag,lambda dims,img,digest:digest==base[tag]['sha256'])
    else:
        source=w/'four-frames/800x600'
        expected('idle',source/'idle.ppm');m.key('spc'); expected('started',source/'started.ppm')
        m.key('s');m.key('c')
        ink('early-stop',(40,81,8,16,'Stopped',0x8fe0c2,0x10283f),
            (24,487,8,16,'Worker stopped; partial preview retained',0x8fe0c2,0x10283f),
            (432,298,8,16,'Preview will appear here',0xf2f7fc,0x18364f))
        m.key('r');expected('reset',source/'idle.ppm')
        for tag in ('started','draft','preview','built'):
            m.key('spc');expected('normal-'+tag,source/(tag+'.ppm'))
        m.key('s');expected('stop-requested',source/'stop_requested.ppm')
        m.key('c');expected('stopped-with-preview',source/'stopped.ppm')
    m.key('esc');rows('one-escape','surf.elf',app)
    assert app+' ended DONE: exit 0' in m.serial()
    m.key('esc');rows('two-escapes','Programs','all 71 self-tests passed')
    m.key('f10');rows('confirm','POWER OFF');m.key('ret')
    assert m.proc.wait(timeout=30)==0
    serial=m.serial()
    assert meta['app'] in serial and 'ALL SELF-TESTS PASS.' in serial and meta['measurement'] in serial
    assert sum(s.startswith('  pass ') for s in serial.splitlines())==72 and not any(s.startswith('  FAIL ') for s in serial.splitlines())
    record['serial_sha256']=hashlib.sha256(m.serial_path.read_bytes()).hexdigest()
    record['passed']=True
    print(name,machine,app,'72 checks',len(frames),'verified frames')
finally:
    (folder/'result.json').write_text(json.dumps(record,indent=2)+'\n')
    m.stop()

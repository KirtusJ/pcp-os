set -eu
w=/workspace/scratch/0b232ed980b3
e=$w/b3-job-evidence
d=$w/b3-tailor-job
r=/workspace/scratch/6fbc6fd5187a/runtime
tc=$r/register-live/rust197
export PATH="$tc/bin:$tc/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$PATH" LD_LIBRARY_PATH="$r/lib" CARGO_HOME=/tmp/b3-341-build/registry-cache CARGO_TARGET_DIR="$e/build" CARGO_NET_OFFLINE=true
cd "$d"
cargo test --locked --offline --lib > "$e/tests.log" 2>&1
rg 'test result:' "$e/tests.log"
cargo test --release --locked --offline --lib > "$e/release.log" 2>&1
rg 'test result:' "$e/release.log"
cargo run --locked --offline --example project_location_frames -- "$e/upstream" > "$e/render.log" 2>&1
python3 -B guest/tests/project_location_display.py "$e/upstream"
rustc --edition 2021 -O --crate-type rlib --crate-name tailorbird_ui guest/src/lib.rs -o "$e/libtailorbird_ui.rlib"
rustc --edition 2021 -O "$e/varied.rs" --extern tailorbird_ui="$e/libtailorbird_ui.rlib" -o "$e/varied-render"
"$e/varied-render" "$e/varied"
export PYTHONPATH="$d/guest/tests"
python3 -B - <<'PY'
from pathlib import Path
import project_location_display as v
folder=Path('/workspace/scratch/0b232ed980b3/b3-job-evidence')
v.TARGET=(folder/'path.txt').read_text().strip()
assert len(v.TARGET)==120
print(v.check(folder/'varied'))
PY

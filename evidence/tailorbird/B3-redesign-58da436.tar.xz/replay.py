"""Check all captured guest scanout pixels against the nominated renderer, compiled for the host."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile

root=Path(__file__).resolve().parent
source=Path(sys.argv[1]).resolve()
def rgb(p):
    header,dim,levels,data=p.read_bytes().split(b'\n',3)
    assert header==b'P6' and levels==b'255'
    w,h=map(int,dim.split())
    assert len(data)==w*h*3
    return w,h,data
with tempfile.TemporaryDirectory() as tmp:
    temp=Path(tmp)
    rlib=temp/'libtailorbird_ui.rlib'
    render=temp/'render'
    subprocess.run(['rustc','--edition','2021','-O','--crate-type','rlib','--crate-name','tailorbird_ui',source/'guest/src/lib.rs','-o',rlib],check=True)
    subprocess.run(['rustc','--edition','2021','-O',root/'render.rs','--extern','tailorbird_ui='+str(rlib),'-o',render],check=True)
    for run in ('800x600','1920x1080-selected','current-pc','current-q35'):
        folder=root/run
        r=json.loads((folder/'result.json').read_text())
        pairs={'initial':'home'} if run.startswith('current') else {'first':'home','typed':'typed','cleared':'home'}
        if run.startswith('current'):assert r['passed']
        else:assert r['shutdown']==33 and r['checks']==72
        for tag,state in pairs.items():
            frame=folder/(tag+'.ppm')
            w,h,pixels=rgb(frame)
            expected=subprocess.check_output([render,str(w),str(h),state])
            assert pixels==expected,(run,tag)
            if 'frames' in r:assert hashlib.sha256(frame.read_bytes()).hexdigest()==r['frames'][tag]
        print(run,'complete scanout matches for',', '.join(pairs))

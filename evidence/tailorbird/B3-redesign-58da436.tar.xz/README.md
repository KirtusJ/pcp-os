# Tailorbird #5 native design readback

Tailorbird head 58da436d067eb0e7cc5e8600f46177e2cb0af75f, PCP OS submodule 070c9d5925a2c208c33c60db92e51156555407c8. The independently linked 147,880-byte release guest has SHA-256 668ac60a6cb21c6edfbb1c544de14df24a3191eca3792d1e7ecebf21bbb970d9.

Two Q35 desktop boots from the pinned kernel at 800×600 and 1920×1080 compare the complete initial, typed and cleared guest scanouts with the host build of the same Rust view. Esc returns to Programs with Tailorbird selected; the next Esc returns to the desktop. Both guests shut down with 72 passing kernel checks. The upstream PC and Q35 smoke tests at 1024×768 also passed, with both initial frames compared in full.

Use Rust 1.97.0, the exact Tailorbird checkout above with its pinned PCP OS submodule initialized, and Python 3. Run python replay.py /path/to/tailorbird from the extracted directory. The test compares frame bytes directly and checks the sizes of the PPM payloads. SHA256SUMS covers the complete archive. Captures are from QEMU; they do not measure human readability. This guest has a disconnected UI.

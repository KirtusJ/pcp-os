set -eu
w=/workspace/scratch/0b232ed980b3
r=/workspace/scratch/6fbc6fd5187a/runtime
tc=$r/register-live/rust197
export PATH="$tc/bin:$tc/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$PATH" LD_LIBRARY_PATH="$r/lib" CARGO_NET_OFFLINE=true CARGO_HOME=/tmp/b3-341-build/registry-cache CARGO_TARGET_DIR="$w/b3-design-evidence/build"
cd "$w/b3-tailor-design"
sh build.sh --offline --bin tailorbird
for profile in debug release; do
   case "$profile" in release) set -- --release;; debug) set --;; esac
   cargo test --locked --offline --lib --manifest-path guest/Cargo.toml "$@" > "$w/b3-design-evidence/$profile.log" 2>&1
   rg 'test result:' "$w/b3-design-evidence/$profile.log"
done

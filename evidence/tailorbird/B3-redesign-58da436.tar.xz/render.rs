use std::io::{self, Write};
use tailorbird_ui::{frame::Frame, ordered_keys::OrderedKeyboard, palette::GROUND, view::paint_frame, Ui};

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let w: usize = args[1].parse().unwrap();
    let h: usize = args[2].parse().unwrap();
    let mut ui = Ui::new();
    if args[3] == "typed" {
        let mut keys = OrderedKeyboard::new();
        keys.event(0x1e, true, &mut ui);
        keys.event(0x1e, false, &mut ui);
    }
    let mut pixels = vec![0u32; w*h];
    let mut frame = Frame::new(&mut pixels, w, h, w, GROUND, ui.compact_view);
    paint_frame(&mut frame, &ui);
    let mut bytes = Vec::with_capacity(w*h*3);
    for pixel in pixels { bytes.extend_from_slice(&pixel.to_be_bytes()[1..]); }
    io::stdout().lock().write_all(&bytes).unwrap();
}

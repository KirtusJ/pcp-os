set -eu
w=/workspace/scratch/0b232ed980b3
rt=/workspace/scratch/6fbc6fd5187a/runtime
tc=$rt/register-live/rust197
export PATH="$tc/bin:$tc/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$PATH" LD_LIBRARY_PATH="$rt/lib"
export CARGO_NET_OFFLINE=true CARGO_HOME=/tmp/b3-341-build/registry-cache PCPOS_KERNEL_STAGE="$w/b3-frozen-builds/$1-stage"
export PCPOS_KERNEL_FEATURES="$2"
cd "$w/b3-tailor-design/pcp-os"
sh PCP_OS_Rust/crates/pcpos-kernel/run.sh build > "$w/b3-frozen-builds/$1.log" 2>&1 || { tail -15 "$w/b3-frozen-builds/$1.log"; exit 1; }
cp PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32 "$w/b3-frozen-builds/$1.elf32"
sha256sum "$w/b3-frozen-builds/$1.elf32"

from pathlib import Path
import hashlib
import json
import runpy
import subprocess
import sys
import time

w=Path('/workspace/scratch/0b232ed980b3')
src=w/'b3-tailor-design'
evidence=w/'b3-design-evidence'
api=runpy.run_path(str(src/'guest/tests/qemu_smoke.py'))
osapi=runpy.run_path('/tmp/b3-proposal-access/examples/optical-disk-check/check.py')
size=sys.argv[1]
width,height=map(int,size.split('x'))
out=evidence/(size+('' if len(sys.argv)==2 else '-'+sys.argv[2]))
out.mkdir()
kernel=w/'b3-frozen-builds/design-pinned.elf32'
guest=evidence/'build/x86_64-unknown-none/release/tailorbird'
measurement=subprocess.check_output([sys.executable,src/'pcp-os/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py',kernel],text=True).strip()
m=api['Qemu'](kernel,guest,out,'q35',f'image={measurement} desktop={size} ui_scale=1',['-vga','none','-device','VGA,vgamem_mb=32'])
font=osapi['SCREEN']['kernel_glyphs']()
frames={}
def capture(tag,predicate):
    until=time.monotonic()+45
    while time.monotonic()<until:
        dims,rgb,digest=m.screenshot(tag)
        if dims==(width,height) and predicate(rgb):
            frames[tag]=digest
            return
        time.sleep(.15)
    raise RuntimeError('capture failed: '+tag)
def desktop(tag, pred):
    def accepts(rgb):
        rows=osapi['SCREEN']['read_screen']((out/(tag+'.ppm')).read_bytes(),font)
        if rows and pred(' '.join(' '.join(rows).split())):
            (out/(tag+'.txt')).write_text('\n'.join(rows)+'\n')
            return True
        return False
    capture(tag,accepts)
def render(tag,state):
    expected=subprocess.check_output([evidence/'render',str(width),str(height),state])
    capture(tag,lambda rgb:rgb==expected)
try:
    desktop('home',lambda t:'Programs' in t)
    m.key('ret')
    desktop('launcher',lambda t:'tailorbird' in t and ('may use:' in t or 'Access:' in t))
    m.key('ret')
    render('first','home')
    m.key('a')
    render('typed','typed')
    m.key('backspace')
    render('cleared','home')
    assert frames['first']==frames['cleared']!=frames['typed']
    m.key('esc')
    desktop('programs-after',lambda t:'tailorbird' in t and ('may use:' in t or 'Access:' in t) and ('> tailorbird' in t or '?tailorbird' in t))
    assert 'tailorbird ended DONE: exit 0' in m.serial()
    m.key('esc')
    desktop('home-after',lambda t:'Programs' in t)
    m.key('f10')
    desktop('power',lambda t:'Switch PCP OS off?' in t)
    m.key('ret')
    assert m.proc.wait(timeout=20)==33 and 'ALL SELF-TESTS PASS.' in m.serial()
    (out/'result.json').write_text(json.dumps(dict(size=size,expected_guest=hashlib.sha256(guest.read_bytes()).hexdigest(),kernel=hashlib.sha256(kernel.read_bytes()).hexdigest(),frames=frames,shutdown=33,checks=sum(l.startswith('  pass ') for l in m.serial().splitlines())),indent=2)+'\n')
    print(size,'initial, typed and cleared scanouts match the host render at every pixel; two Esc returns and shutdown passed')
finally:m.stop()

import hashlib,json,re
from pathlib import Path
from PIL import Image
from pixel_reader import label
root=Path(__file__).resolve().parent
def sha(x):return hashlib.sha256(x).hexdigest()
for mode in ['640x480','800x600','1024x768','1280x720']:
    d=root/mode; result=json.loads((d/'result.json').read_text()); meta=json.loads((d/'media.json').read_text())
    width,height=map(int,mode.split('x'))
    serial=(d/'serial.txt').read_bytes()
    if sha(serial)!=result['serial_sha256']:raise ValueError('serial digest')
    serial=serial.decode(); rows=serial.splitlines()
    for text in ['desktop='+mode,f'display: Bochs, {mode}, 2 page(s)',f"starting tailorbird.elf ({meta['app_bytes']} bytes, SHA-256 {meta['app']})",'Tailorbird first frame presented',result['return_record'],'ALL SELF-TESTS PASS.']:
        if text not in serial:raise ValueError((mode,text))
    if 'tailorbird.elf ended DONE: exit 0' not in result['return_record'] or sum(s.startswith('  pass ') for s in rows)!=72 or any(s.startswith('  FAIL ') for s in rows):raise ValueError((mode,'guest result'))
    for stage,data in result.items():
        if not isinstance(data,dict) or 'dimensions' not in data:continue
        with Image.open(d/(stage+'.png')) as im:
            if im.size!=(width,height):raise ValueError('dimensions')
            rgb=im.tobytes()
        if sha(f'P6\n{width} {height}\n255\n'.encode()+rgb)!=data['sha256']:raise ValueError('frame digest')
        tests={'app':(737,27,12,20,'NO SERVICE',0xf08a72,0x18364f),'typed':(140,460,10,20,'hello',0xf2f7fc,0x18364f),'submit':(535,513,6,10,'NO MODEL SERVICE - OS STILL USABLE',0xe3a24b,0x10283f)}
        if stage in tests:label((width,height),rgb,*tests[stage])
    print(mode,'Bochs 2 pages, prompt and refusal verified, exit 0, 72 checks')

from pathlib import Path
import hashlib, json, os, runpy, shutil, sys
w=Path(__file__).resolve().parent
media=w.parent/'a3-tailor-media'
helper=runpy.run_path(str(media/'os-master/examples/tester-cd/build.py'))
origin=media/'cd2'
base_info=json.loads((origin/'media.json').read_text())
a=(origin/'first.iso').read_bytes()
assert hashlib.sha256(a).hexdigest()==base_info['iso']
baseline=helper['read_back'](a)
env={**os.environ,'PATH':str(w.parent/'root/usr/bin')+':'+os.environ['PATH'],'LD_LIBRARY_PATH':str(w.parent/'lib'),'SOURCE_DATE_EPOCH':str(helper['EPOCH']),'TZ':'UTC','LC_ALL':'C'}
for mode in sys.argv[1:]:
    out=w/mode; out.mkdir(exist_ok=True)
    tree=out/'tree';tree.mkdir(exist_ok=True)
    for file in (origin/'tree-first').iterdir():shutil.copy2(file,tree/file.name)
    cfg=tree/'limine.conf';data=cfg.read_text().replace('image='+base_info['measurement'],'image='+base_info['measurement']+' desktop='+mode)
    assert data.count('desktop='+mode)==1
    cfg.write_text(data)
    helper['assemble'](tree,out/'first.iso',env)
    buf=(out/'first.iso').read_bytes()
    files=helper['read_back'](buf)
    assert files.keys()==baseline.keys()
    assert files['limine.conf']==data.encode()
    for n in files:
        if n not in ('limine.conf','boot.cat','limine-bios-cd.bin'):assert baseline[n]==files[n]
    (out/'media.json').write_text(json.dumps({**base_info,'iso':helper['sha'](buf),'requested':mode,'original_iso':base_info['iso']},indent=2))

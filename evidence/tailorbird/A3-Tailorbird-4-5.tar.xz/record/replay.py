from pathlib import Path
import json,hashlib
from PIL import Image
from pixel_reader import label
root=Path(__file__).resolve().parent
def sha(data):return hashlib.sha256(data).hexdigest()
for case in ('four','four-normal','five'):
    p=root/case
    r=json.loads((p/'result.json').read_text())
    m=json.loads((p/'media.json').read_text())
    serial=(p/'serial.txt').read_bytes()
    assert sha(serial)==r['serial_sha256'] and r['passed']
    assert r['iso']==m['iso'] and r['elf']==m['disc_files'][m['filename']]
    assert r['elf'].encode() in serial and (m['filename']+' ended DONE: exit 0').encode() in serial
    assert b'ALL SELF-TESTS PASS' in serial and sum(x.startswith(b'  pass ') for x in serial.splitlines())==72
    assert '"reason": "guest-shutdown"' in (p/'host.log').read_text()
    for tag,encoded in r['frames'].items():
        with Image.open(p/(tag+'.png')) as im:
            assert im.size==(800,600)
            size=im.size;rgb=im.tobytes()
        assert sha(b'P6\n800 600\n255\n'+rgb)==encoded
        if case=='four' and tag=='early-stop':
            for spec in [(40,81,8,16,'Stopped',0x8fe0c2,0x10283f),(24,487,8,16,'Worker stopped; partial preview retained',0x8fe0c2,0x10283f),(432,298,8,16,'Preview will appear here',0xf2f7fc,0x18364f)]:
                assert label(size,rgb,*spec)>0
        if case=='five' and tag=='breadcrumb':
            assert label(size,rgb,22,52,6,12,'PCP OS > Tailorbird (a program; Esc returns to the desktop)',0x9fb4c8,0x18364f)>0
        if case=='four-normal' and tag in ('app','typed','submit'):
            assert encoded==json.loads((root/'reference.json').read_text())[tag]['sha256']
    assert 'surf.elf' in (p/'one-escape.txt').read_text()
    assert 'PCP OS | DESKTOP' in (p/'two-escapes.txt').read_text()
    print(case, 'original frames, launcher return and guest shutdown verified')

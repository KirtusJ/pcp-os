"""Replay the native results saved here. Only Python's standard library is required."""
import hashlib
import json
from pathlib import Path
root=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected=hashlib.sha256(b'garden note\n').hexdigest()
for name,outcome in json.loads((root/'cases.json').read_text()).items():
 folder=root/name
 serial=next(folder.glob('serial.*')).read_text()
 if outcome in ('original','published runner original'):
  assert 'tailorbird: Not made: you said no.' in serial and 'note-2.txt' not in serial
  if outcome=='original':assert (folder/'declined.ppm').read_bytes()==(folder/'preview-2.ppm').read_bytes()
 elif outcome=='refused launch':
  r=json.loads((folder/'result.json').read_text())
  assert r['verified'] and r['passed']==72 and r['application']=='exit 2 before first frame'
  assert 'tailorbird.elf ended FAILED: exit 2' in serial and 'Tailorbird first frame presented' not in serial
  assert 'No program has written a file.' in (folder/'files.txt').read_text()
 elif outcome in ('two notes','published runner'):
  for no,answer in [(1,'DENIED'),(2,'CREATED')]:
   needle=f'proposal 1 of attempt {no}: taylor/my-first-project/note-{no}.txt (12 bytes, SHA-256 {expected})'
   assert sum(line.startswith(needle) and answer in line for line in serial.splitlines())==1
  assert 'tailorbird: Not made: you said no.' in serial and 'tailorbird: Made taylor/my-first-project/note-2.txt. Kept until power-off.' in serial
  assert 'the store holds 1 file(s), 12 bytes' in serial and 'ALL SELF-TESTS PASS.' in serial
  if outcome=='two notes':
   files=(folder/'files.txt').read_text()
   assert 'taylor/my-first-project/note-2.txt' in files and 'note-1.txt' not in files
   r=json.loads((folder/'result.json').read_text())
   assert r.get('shutdown')==33 or r.get('verified') and r.get('passed')==72
   for tag,sha in r['frames'].items():assert digest(folder/(tag+'.ppm'))==sha
 else:
  r=json.loads((folder/'result.json').read_text())
  assert r['verified'] and r['passed']==72
  assert (folder/'first.ppm').read_bytes()==(root/'job-render/1920x1080.ppm').read_bytes()
 print(name,outcome)
for backend in ['bochs','ramfb']:
 old=json.loads((root/f'fixed-800x600-{backend}/result.json').read_text())
 new=json.loads((root/f'repin-800x600-{backend}/result.json').read_text())
 assert old['loader_display']==new['loader_display']
 assert old['image']['elf_sha256']==new['image']['elf_sha256']
 assert old['image']['measurement']==new['image']['measurement']

"""Read back two ordinary requests from one Tailorbird launch using real keyboard input."""
import hashlib
import subprocess

def exercise(width,height,evidence,paint,screen,key,serial,wait):
    contents="garden note"
    folder="taylor/my-first-project"
    digest=hashlib.sha256((contents+"\n").encode()).hexdigest()
    def app(tag,entered="",notice=""):
        rgb=subprocess.check_output([evidence/"note-render",str(width),str(height),entered,notice])
        paint(tag,rgb)
    app("greeting")
    for c in contents:key("spc" if c==" " else c)
    app("typed",contents)
    def preview(number):
        key("alt","n")
        rows=screen("preview-"+str(number),lambda s:"PCP OS ASKS YOU" in s and f"note-{number}.txt" in s)
        full=" ".join(" ".join(rows).split())
        assert f"Folder: {folder}" in full and f"File: note-{number}.txt" in full
        assert contents in [r.strip() for r in rows] and "(end of the file)" in full
        assert "Size: 12 characters" in full and "Page 1 of 1" in full
    preview(1)
    key("esc")
    declined="Not made: you said no."
    wait("tailorbird: "+declined)
    app("declined",contents,declined)
    preview(2)
    key("f12")
    screen("approval-question",lambda s:"Now press Enter to allow it." in s)
    key("ret")
    path=folder+"/note-2.txt"
    made="Made "+path+". Kept until power-off."
    wait("tailorbird: "+made)
    app("created",contents,made)
    key("esc")
    wait("tailorbird.elf ended DONE: exit 0")
    screen("returned",lambda s:"tailorbird.elf" in s and ("may use:" in s or "Access:" in s))
    key("esc")
    screen("home-after",lambda s:"Programs" in s)
    key("f3")
    rows=screen("files",lambda s:path in s)
    full=" ".join(" ".join(rows).split())
    assert "note-1.txt" not in full and "1 to 1 of 1" in full and "1 KiB" in full,full
    key("esc")
    screen("home-final",lambda s:"Programs" in s)
    log=serial()
    assert any("note-1.txt" in line and digest in line and "DENIED" in line for line in log.splitlines())
    assert any("note-2.txt" in line and digest in line and "CREATED" in line for line in log.splitlines())
    assert "the store holds 1 file(s), 12 bytes" in log
    return dict(content_sha256=digest,declined=folder+"/note-1.txt",created=path,bytes_written=12)

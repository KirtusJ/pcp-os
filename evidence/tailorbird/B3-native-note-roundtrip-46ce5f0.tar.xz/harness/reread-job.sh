set -eu
w=/workspace/scratch/0b232ed980b3
e=$w/b3-job-native
d=$w/b3-tailor-job-064b
r=/workspace/scratch/6fbc6fd5187a/runtime
export PATH="$r/register-live/rust197/bin:$PATH" LD_LIBRARY_PATH="$r/lib"
rustc --edition 2021 -O --crate-type rlib --crate-name tailorbird_ui "$d/guest/src/lib.rs" -o "$e/libjobfinal.rlib"
rustc --edition 2021 -O "$w/b3-job-evidence/varied.rs" --extern tailorbird_ui="$e/libjobfinal.rlib" -o "$e/final-job-renderer"
"$e/final-job-renderer" "$e/final-varied"
for wh in 640x480 800x600 1024x768 1920x1080; do cmp "$e/final-varied/$wh.ppm" "$w/b3-job-evidence/varied/$wh.ppm"; done
cmp "$e/final-varied/1920x1080.ppm" "$e/path-1920x1080-bochs/first.ppm"

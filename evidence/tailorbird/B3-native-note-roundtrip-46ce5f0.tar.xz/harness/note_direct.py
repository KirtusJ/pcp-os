import hashlib, json, os, re, runpy, subprocess, sys, time
from pathlib import Path
from note_flow import exercise
base=Path(__file__).resolve().parent
kernel=base.parent/'b3-frozen-builds/b3-proposal-c5b.elf32'
guest=Path(os.environ.get('B3_NOTE_GUEST',base/'note-media/tailorbird.elf'))
mode=sys.argv[1]
width,height=map(int,mode.split('x'))
out=base/('note-direct-'+mode+os.environ.get('B3_TAG',''));out.mkdir()
src=base.parent/'b3-taylor-note'
q=runpy.run_path(str(src/'guest/tests/qemu_smoke.py'))
a=runpy.run_path('/tmp/b3-proposal-access/examples/optical-disk-check/check.py')
glyph=a['SCREEN']['kernel_glyphs']()
dg=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pin=subprocess.check_output([sys.executable,base.parent/'b3-proposal-c5b/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py',kernel],text=True).strip()
vm=q['Qemu'](kernel,guest,out,'q35',f'image={pin} desktop={mode} ui_scale=1 propose_image={dg(guest)}',['-vga','none','-device','VGA,vgamem_mb=32'])
frames={}
def take(tag,test):
    def sample():
        dims,rgb,digest=vm.screenshot(tag)
        if dims!=(width,height):return None
        v=test(rgb)
        if v:frames[tag]=digest
        return v
    return a['wait_for'](sample,tag,30)
def screen(tag,test):
    def judge(rgb):
        rows=a['SCREEN']['read_screen']((out/(tag+'.ppm')).read_bytes(),glyph)
        if rows and test(" ".join(" ".join(rows).split())):
            (out/(tag+'.txt')).write_text('\n'.join(rows)+'\n')
            return rows
    return take(tag,judge)
def paint(tag,expected):return take(tag,lambda rgb:rgb==expected)
def see(marker):return a['wait_for'](lambda:marker in vm.serial(),marker,25)
try:
    screen("home",lambda t:"Programs" in t)
    vm.key("ret");screen("launcher",lambda t:"tailorbird.elf" in t and "Creating a file needs your approval." in t)
    vm.key("ret");see("Tailorbird first frame presented")
    res=exercise(width,height,base,paint,screen,vm.key,vm.serial,see)
    vm.key("f10");screen("power",lambda t:"Switch PCP OS off?" in t);vm.key("ret")
    assert vm.proc.wait(timeout=25)==33 and "ALL SELF-TESTS PASS." in vm.serial()
    report=dict(mode=mode,frames=frames,guest=dg(guest),kernel=dg(kernel),**res,shutdown=33)
    (out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
    print(mode,res)
finally:vm.stop()

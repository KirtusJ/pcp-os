use std::io::{self,Write};
use tailorbird_ui::{frame::Frame,palette::GROUND,view::paint_frame,Text,Ui};
fn main() {
    let args:Vec<_>=std::env::args().collect();
    let width=args[1].parse().unwrap();
    let height=args[2].parse().unwrap();
    let mut ui=Ui::new();
    for byte in args[3].bytes() { assert!(ui.input.push_ascii(byte)); }
    if !args[4].is_empty(){ui.notice=Text::display(&args[4]);}
    let mut pixels=vec![0u32;width*height];
    paint_frame(&mut Frame::new(&mut pixels,width,height,width,GROUND,ui.compact_view),&ui);
    let mut bytes=Vec::with_capacity(width*height*3);
    for pixel in pixels{bytes.extend_from_slice(&pixel.to_be_bytes()[1..]);}
    io::stdout().lock().write_all(&bytes).unwrap();
}

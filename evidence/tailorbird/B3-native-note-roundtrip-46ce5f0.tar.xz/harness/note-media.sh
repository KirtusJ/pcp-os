set -eu
e=/workspace/scratch/0b232ed980b3/b3-job-native
rt=/workspace/scratch/6fbc6fd5187a/runtime
val=/workspace/scratch/15ccefba7c7d/validation
export B3_TAILORBIRD_ELF="$e/bin/$1.elf"
python3 -B "$e/make_media.py" "$e/src-$1" /workspace/scratch/0b232ed980b3/b3-frozen-builds/note-uefi-c5b.elf32 "$rt/dist-landed/PCP-OS.iso" "$val/pkg/root/usr" "$e/media-$1" > "$e/media-$1.log" 2>&1 || { tail -20 "$e/media-$1.log"; exit 1; }

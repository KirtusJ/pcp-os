from pathlib import Path
import hashlib,json,os
b=Path(__file__).resolve().parent
src=b.parent/'b3-job-native'
def take(p,out):
 out.parent.mkdir(parents=True,exist_ok=True)
 if not out.exists():os.link(p,out)
cases = {
 'note-direct-800x600':'original', 'note-direct-1280x720':'original',
 'note-direct-800x600-fixed':'two notes','note-direct-1280x720-fixed':'two notes',
 'fixed-1920x1080-bochs':'two notes','fixed-800x600-bochs':'refused launch',
 'fixed-800x600-ramfb':'refused launch','repin-800x600-bochs':'two notes','repin-800x600-ramfb':'two notes',
 'stock-800x600-bochs':'refused launch','stock-800x600-ramfb':'refused launch',
 'path-1920x1080-bochs':'destination sample',
 'portable-final':'published runner','portable-original':'published runner original',
}
for name in cases:
 folder=src/name
 for p in folder.iterdir():
  if p.suffix in ('.ppm','.txt','.log','.json') and not p.name.startswith('qemu.'):
   take(p,b/name/p.name)
for n in ['note_uefi.py','note_direct.py','note_flow.py','note-render.rs','fixture.patch','varied.rs','media.sh','note-media.sh','make_media.py','reread-job.sh']:
 p=src/n
 if p.exists():take(p,b/'harness'/n)
w=src.parent
for name in ['guest/src/ordered_keys.rs','guest/tests/note_roundtrip.py']:
 p=w/'b3-shortcut-final'/name;take(p,b/'patch'/name)
for d in ['stock','fixed','repin']:
 for n in ['loader.c','image.py']:
  take(src/('src-'+d)/'examples/firmware-owned-uefi'/n,b/'media-fixtures'/d/n)
 take(src/('media-'+d)/'image.json',b/'media-fixtures'/d/'image.json')
for p in ['stock','fixed','repin','path']:
 take(src/'bin'/(p+'.elf'),b/'binaries'/(p+'.elf'))
take(w/'b3-job-evidence/varied.rs',b/'harness/varied.rs')
for size in ['640x480','800x600','1024x768','1920x1080']:
 take(src/'final-varied'/(size+'.ppm'),b/'job-render'/(size+'.ppm'))
(b/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')

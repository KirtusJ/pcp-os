"""Boot the same disposable VM with a genuine one-file journal under a chosen name."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys

root = Path(__file__).resolve().parent
label, rawname, mode = sys.argv[1:]
name = rawname.encode('ascii')
out = root/label
out.mkdir()
sys.path.insert(0, str(root/'frozen/examples/vm-store'))
from check_queue import check_journal, saved_queue_visible, Monitor, optical
src = root/'positioned-guest'
serial = out/'serial.txt'
baseline = (src/'save.raw').read_bytes()
check_journal(baseline)
disk = bytearray(baseline)
offset = 130 * 512
data_start = offset+512
gen,old_length=struct.unpack_from('<QI',disk,offset+8)
assert gen==2
old = disk[data_start:data_start+old_length]
old_name,body_length=struct.unpack_from('<HI',old)
assert old[6:6+old_name]==b'parrots.queue'
payload=struct.pack('<HI',len(name),body_length)+name+old[6+old_name:]
sha=lambda b:hashlib.sha256(b).digest()
header=b'PCPSLOT1'+struct.pack('<QI',gen,len(payload))+sha(payload)
disk[offset:offset+84]=header+sha(header)
disk[data_start:data_start+len(payload)]=payload
path=out/'fixture.raw'
path.write_bytes(disk)
try:
    check_journal(disk)
    journal='accepted'
except RuntimeError as error:
    assert str(error)=='wrong stored filename'
    journal=str(error)
assert (journal=='accepted')==(name==b'parrots.queue')
identity=(src/'volume/volume-id.txt').read_text().strip()
measurement=json.loads((src/'results.json').read_text())['kernel_measurement']
qemu='/workspace/scratch/7c7df1723510/work/emulator/qemu-system-x86_64'
cmd=[qemu,'-machine','pc','-accel','tcg','-cpu','max','-m','256M','-smp','1','-nic','none','-display','none','-vga','std','-qmp','stdio','-monitor','none','-no-reboot','-kernel',str(src/'kernel.elf'),'-initrd',str(src/'queue.elf'),'-append',f'store=ide0 store_id={identity} image={measurement} desktop={mode}','-serial','file:'+str(serial),'-drive','if=none,id=store,format=raw,file='+str(path),'-device','ide-hd,drive=store,bus=ide.0,unit=0,serial=PCP-VM-STORE','-device','isa-debug-exit,iobase=0xf4,iosize=4']
with (out/'stderr.txt').open('wb') as err,subprocess.Popen(cmd,cwd=out,stdout=subprocess.PIPE,stdin=subprocess.PIPE,stderr=err) as guest:
    try:
        mon=Monitor(guest)
        mon.call('qmp_capabilities')
        desktop=optical['DesktopScreens'](mon,out,45)
        desktop.home('home')
        mon.key('f3')
        rows=desktop.wait('files',lambda r:r[2].strip()=='VM files | saved when an app syncs' and 'parrots.queue' in r[4])
        frame=(out/'files.ppm').read_bytes()
        width,height=map(int,frame.split(b'\n',2)[1].split())
        assert f'{width}x{height}'==mode
        screen=saved_queue_visible(rows,frame)
        assert screen==(not rawname.startswith(' '))
        if mode=='1920x1080':
            assert (frame==(src/'restore-files.ppm').read_bytes()) == (not rawname.startswith(' '))
        mon.key('esc')
        desktop.home('restored-home')
        mon.key('f10')
        desktop.wait('power',lambda r:any('POWER OFF' in l for l in r))
        mon.key('ret')
        exit_code=guest.wait(timeout=35)
    finally:
        if guest.poll() is None:
            guest.kill()
            guest.wait()
assert exit_code==33 and 'ALL SELF-TESTS PASS.' in serial.read_text()
assert path.read_bytes()==bytes(disk)
result=dict(stored_name=rawname,display=mode,first_name_column=rows[4].index('parrots.queue'),size_column=rows[4].index('3 KiB'),display_matched=screen,journal_verdict=journal,files_frame_sha256=sha(frame).hex(),source_disk_sha256=sha(baseline).hex(),fixture_disk_sha256=sha(disk).hex(),pass_lines=sum(line.startswith('  pass ') for line in serial.read_text().splitlines()),qemu_exit=exit_code,command=cmd)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(rawname,mode,screen,journal,exit_code)

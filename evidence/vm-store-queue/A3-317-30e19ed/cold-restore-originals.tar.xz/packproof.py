"""Verify the hosted download, guest journals, rendered frames and conclusions before publishing."""
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import sys
import tarfile
from zipfile import ZipFile
root=Path(__file__).resolve().parent
source=root/'frozen'
sha=lambda data:hashlib.sha256(data).hexdigest()
def read(name):
    return json.loads((root/name).read_text())
def git(ref):
    return subprocess.check_output(['git','-C',source,'rev-parse',ref],text=True).strip()
head=git('HEAD');tree=git('HEAD^{tree}')
sys.path.insert(0,str(source/'examples/vm-store'))
from check_queue import check_journal,check_frame,saved_queue_visible
screen=runpy.run_path(str(source/'examples/tester-cd/check.py'))
glyphs=screen['kernel_glyphs']()
def screen_ok(raw):
    rows=screen['read_screen'](raw,glyphs)
    assert rows
    return saved_queue_visible(rows,raw)
def record(get):
    receipt=json.loads(get('results.json'))
    assert receipt['label']=='cold morning'
    kernel=get('kernel.elf');queue=get('queue.elf')
    assert runpy.run_path(str(source/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py'))['measure'](kernel)==receipt['kernel_measurement']
    data=[]
    for entry,stage,verdict in zip(receipt['boots'],('save','restore'),('Disk save','Queue restored'),strict=True):
        assert entry['boot']==stage and entry['status']==verdict
        disk=get(stage+'.raw');image=get(stage+'.ppm');serial=get(stage+'.serial').decode()
        assert sha(disk)==entry['disk_sha256'] and sha(image)==entry['screenshot_sha256']
        check_journal(disk);check_frame(image,verdict)
        count=sum(s.startswith('  pass ') for s in serial.splitlines())
        assert count==72 and 'ALL SELF-TESTS PASS.' in serial and 'queue.elf ended DONE: exit 0' in serial
        data.append(dict(boot=stage,status=verdict,pass_lines=count,disk_sha256=sha(disk),serial_sha256=sha(serial.encode()),app_frame_sha256=sha(image)))
    assert get('save.raw')==get('restore.raw')==get('volume/data.raw')
    raw=get('restore-files.ppm'); assert screen_ok(raw)
    return dict(kernel_sha256=sha(kernel),queue_sha256=sha(queue),kernel_measurement=receipt['kernel_measurement'],boots=data,files_frame_sha256=sha(raw),save_restore_disk_equal=True)
local=record(lambda n:(root/'positioned-guest'/n).read_bytes())
meta=read('hosted-origin.json')
assert meta['source']==head and meta['conclusion']=='success'
assert all(s['conclusion'] in ('success','skipped') for s in meta['steps'])
artifact=(root/'hosted-queue.zip')
assert 'sha256:'+sha(artifact.read_bytes())==meta['artifact']['digest']
with ZipFile(artifact) as z:
    assert z.testzip() is None
    hosted=record(z.read)
    assert z.read('restore-files.ppm')==(root/'positioned-guest/restore-files.ppm').read_bytes()
hold=read('positioned-comparison.json')
assert hold['revisions_in_order'][-1]==head and all(hold['original_accepted'])
assert hold['original_sha256']==local['files_frame_sha256']
for case in hold['controls']:
    raw=(root/'positioned-pixels'/(case['label']+'.ppm')).read_bytes()
    assert sha(raw)==case['sha256'] and not screen_ok(raw)
counts=[sum(c['accepted'][i] for c in hold['controls']) for i in range(4)]
assert counts==[10,6,3,0]
names=[]
for label in ('confirmed-leading','confirmed-trailing','confirmed-smaller'):
    p=root/label;rec=read(label+'/result.json')
    raw=(p/'files.ppm').read_bytes()
    assert sha(raw)==rec['files_frame_sha256'] and screen_ok(raw)==rec['display_matched']
    stored=(p/'fixture.raw').read_bytes()
    assert sha(stored)==rec['fixture_disk_sha256'] and rec['qemu_exit']==33 and rec['pass_lines']==72
    try:
        check_journal(stored); outcome='accepted'
    except RuntimeError as err:
        outcome=str(err)
    assert outcome==rec['journal_verdict']
    rec.pop('command');names.append(rec)
assert names[0]['display_matched'] is False and names[1]['files_frame_sha256']==local['files_frame_sha256']
assert [n['journal_verdict'] for n in names]==['wrong stored filename','wrong stored filename','accepted']
for fn in ('worker-status.json','names-status.json'):
    assert all(n['state']=='Finished' for n in read(fn)['nodes'])
summary=dict(head=head,tree=tree,base=hold['revisions_in_order'][0],ci=meta,local=local,hosted=hosted,native_name_controls=names,original_and_altered=hold,altered_frames_accepted_by_revision=counts,commands=['python3 -B examples/vm-store/check_queue.py KERNEL.ELF QUEUE.ELF OUT','python3 -B examples/vm-store/check_queue_files.py OUT/restore-files.ppm'])
(root/'readback.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[root/n for n in ['readback.json','compare_all.py','name_guest.py','packproof.py','positioned-comparison.json','positioned-compare.log','hosted-queue.zip','hosted-origin.json','hosted-controls.log','positioned-guest.log','positioned-live-controls.log','worker-status.json','names-status.json']]
for folder in ('positioned-guest','positioned-pixels','confirmed-leading','confirmed-trailing','confirmed-smaller'):
    files += [f for f in (root/folder).rglob('*') if f.is_file() and f.suffix in {'.ppm','.serial','.stderr','.txt','.json','.raw'}]
if (root/'hosted-job-excerpt.txt').exists():
    files.append(root/'hosted-job-excerpt.txt')
archive=root/'cold-restore-originals.tar.xz'
with tarfile.open(archive,'w:xz',preset=3) as t:
    for f in sorted(set(files)):
        t.add(f,arcname=f.relative_to(root),recursive=False)
with tarfile.open(archive) as t:
    for m in t:
        assert hashlib.file_digest(t.extractfile(m),'sha256').hexdigest()==sha((root/m.name).read_bytes())
print('accepted altered frames by revision',counts,'local and hosted pass lines',[d['pass_lines'] for d in local['boots']],[d['pass_lines'] for d in hosted['boots']],'archive',sha(archive.read_bytes()))

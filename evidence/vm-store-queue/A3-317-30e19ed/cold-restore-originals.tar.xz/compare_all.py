"""Read captured Files pixels through the three historical predicates and the reviewed one."""
from pathlib import Path
import ast
import hashlib
import json
import runpy
import subprocess
import sys
root=Path(__file__).resolve().parent
source=root/'frozen'
script='examples/vm-store/check_queue.py'
def rev(ref):
    return subprocess.check_output(['git','-C',source,'rev-parse',ref],text=True).strip()
def at(ref):
    return subprocess.check_output(['git','-C',source,'show',ref+':'+script],text=True)
history=[rev(ref) for ref in ('HEAD~3','HEAD~2','HEAD^','HEAD')]
assert history[0]=='8a7611c6ee0200c111638da92c468f16bdc1bbd4'
predicates=[]
for commit in history[:3]:
    tree=ast.parse(at(commit))
    if commit==history[0]:
        call=next(n for n in ast.walk(tree) if isinstance(n,ast.Call) and n.args and isinstance(n.args[0],ast.Constant) and n.args[0].value=='restore-files')
        check=eval(compile(ast.Expression(call.args[1]),script,'eval'))
    else:
        f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='saved_queue_visible')
        scope={}
        exec(compile(ast.Module(body=[f],type_ignores=[]),script,'exec'),scope)
        check=scope['saved_queue_visible']
    predicates.append(check)
sys.path.insert(0,str(source/'examples/vm-store'))
current=runpy.run_path(str(source/script))['saved_queue_visible']
paint=runpy.run_path(str(source/'examples/tester-cd/check_launcher_grants.py'))
glyphs=paint['SCREEN']['kernel_glyphs'](); shapes={c:s for s,c in glyphs.items()}
read=paint['SCREEN']['read_screen']
raw=(root/'positioned-guest/restore-files.ppm').read_bytes()
rows=read(raw,glyphs)
def verdicts(rowset,frame):
    return [f(rowset) for f in predicates]+[current(rowset,frame)]
assert verdicts(rows,raw)==[True]*4
hashit=lambda raw:hashlib.sha256(raw).hexdigest()
out=root/'positioned-pixels';out.mkdir(exist_ok=True)
name=rows[4].index('parrots.queue');size=rows[4].index('3 KiB')
cases=[
    ('different-file',4,name,'parrots.queue','parrots.queue-old'),
    ('different-size',4,size,'3 KiB','13 KiB'),
    ('extra-heading',1,len(rows[1]),'',' pending'),
    ('extra-sync',2,len(rows[2]),'',' pending'),
    ('extra-entry',5,name,'','other.queue  1 KiB'),
    ('above-list',3,name,'','other.queue  1 KiB'),
    ('beside-footer',len(rows)-2,len(rows[-2]),'','  other.queue  1 KiB'),
    ('below-footer',len(rows)-1,name,'','other.queue  1 KiB'),
    ('leading-space',4,name,'parrots.queue',' parrots.queue'),
    ('misplaced-size',4,size-1,' 3 KiB','3 KiB '),
    ('split-size',4,size,'3 KiB','3  KiB')]
results=[]
for index,(label,line,col,before,after) in enumerate(cases):
    image=paint['replace_text'](raw,line,col,before,after,shapes)
    decoded=read(image,glyphs)
    expected=rows.copy(); span=max(len(before),len(after));old=rows[line].ljust(col+span)
    expected[line]=(old[:col]+after.ljust(span)+old[col+span:]).rstrip()
    assert decoded==expected and decoded!=rows
    answers=verdicts(decoded,image)
    assert answers==[index!=10,index>=5,index>=8,False],(label,answers)
    (out/(label+'.ppm')).write_bytes(image)
    results.append(dict(label=label,row=line,column=col,decoded=decoded[line],sha256=hashit(image),accepted=answers))
report=dict(revisions_in_order=history,original_sha256=hashit(raw),original_accepted=verdicts(rows,raw),controls=results)
(root/'positioned-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print('accepted altered controls by revision:',[sum(r['accepted'][i] for r in results) for i in range(4)])

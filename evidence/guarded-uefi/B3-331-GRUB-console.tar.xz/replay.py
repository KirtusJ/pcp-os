from pathlib import Path
from collections import Counter
import json
root=Path(__file__).resolve().parent
counts=Counter()
for f in sorted(root.glob('*/result.json')):
 if f.parent.name.startswith('hosted'):continue
 r=json.loads(f.read_text());raw=(f.parent/'serial.bin').read_bytes()
 assert b'FIRMWARE-efi' in raw and b'ATTEMPT-HANDOFF' not in raw and b'PCP OS kernel' not in raw
 tail=raw.rsplit(b'AWAIT-PLACEMENT',1)[1].strip(b'\r\n')
 if r.get('passed'):
  assert tail==b'DENY' and r['observations'][-1][0]=='exit' and r['observations'][-1][-1]==0
  counts[(r['style'],'full echo and exit')]+=1
 else:
  assert r['observations'][-1][0] in ('wrote 59','wrote 45')
  assert tail in (b'DEN',b'D');counts[(r['style'],'partial echo')]+=1
 if r['style']=='prefix':
  stalled=next(s for s in r['observations'] if s[0].startswith('20 second'))
  assert stalled[1]>=20 and bytes.fromhex(stalled[2]).strip()==b'DEN' and stalled[-1] is None
for (kind,result),v in sorted(counts.items()):print(kind,result,v)
assert sum(counts.values())==29
assert counts['burst','full echo and exit']==17
assert counts['prefix','full echo and exit']==1
for i,exp in ((1,b'DEN'),(2,b'DENY')):
 folder=root/f'hosted{i}';raw=(folder/'serial.txt').read_bytes();r=json.loads((folder/'result.json').read_text())
 assert not r['admitted'] and any('ACPI non-volatile storage RAM' in c['types'] for c in r['conflicts'])
 assert raw.rsplit(b'AWAIT-PLACEMENT',1)[1].strip()==exp
 assert b'ATTEMPT-HANDOFF' not in raw and b'PCP OS kernel' not in raw
 print('hosted public-128 attempt',i,'console suffix',exp.decode())

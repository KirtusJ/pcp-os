from pathlib import Path
import hashlib,json,os,re,runpy,shutil,subprocess,sys,time
root=Path(__file__).resolve().parent
v=Path('/workspace/scratch/15ccefba7c7d/validation')
snapshot=root.parent/'tailor/src/examples/optical-disk-check/check.py'
monitor=runpy.run_path(str(snapshot))['Monitor']
dist=Path('/workspace/scratch/6fbc6fd5187a/runtime/dist-landed/audit/public-live-cd/uefi-probe')
sys.path.insert(0,str(dist));import inventory
def run(label,style):
 out=root/label;out.mkdir();console=out/'console';fifo=console.with_suffix('.in');os.mkfifo(fifo);log=out/'serial.bin';log.touch();console.with_suffix('.out').symlink_to(log)
 fw=v/'pkg/root/usr/share/OVMF';var=out/'vars.fd';shutil.copyfile(fw/'OVMF_VARS_4M.fd',var)
 argv=[v/'bin/qemu-system-x86_64','-machine','q35','-accel','tcg','-cpu','max','-m','128','-smp','1','-vga','std','-nic','none','-display','none','-monitor','none','-chardev',f'pipe,id=console,path={console}','-serial','chardev:console','-qmp','stdio','-audiodev','none,id=snd','-device','AC97,audiodev=snd','-drive',f'if=pflash,unit=0,format=raw,readonly=on,file={fw}/OVMF_CODE_4M.fd','-drive',f'if=pflash,unit=1,format=raw,file={var}','-boot','order=d,strict=on','-cdrom',root/'guarded.iso','-icount','shift=3,align=off,sleep=off']
 note={'case':label,'style':style,'observations':[]};now=time.monotonic
 if style.endswith('-realtime'):argv=argv[:-2]
 persistent=style.startswith('held')
 style=style.removesuffix('-realtime')
 with (out/'stderr').open('wb') as e,subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=e) as vm:
  try:
   m=monitor(vm);m.call('qmp_capabilities')
   def until(f,timeout=20):
    end=now()+timeout
    while not f():
     if now()>=end or vm.poll() is not None:
      if vm.poll() is None:
       note['stall']={'tail':log.read_bytes()[-90:].hex(),'status':m.call('query-status'),'chardev':m.call('query-chardev'),'cpus':m.call('query-cpus-fast')}
      raise RuntimeError('missing observation '+repr(log.read_bytes()[-85:]))
     time.sleep(.025)
   until(lambda:b'AWAIT-PLACEMENT' in log.read_bytes())
   initial=log.read_text(errors='replace');assert 'FIRMWARE-efi' in initial
   pages=[(a//4096*4096,(b+4095)//4096*4096) for a,b in inventory.load_ranges((root/'cd/kernel.elf32').read_bytes())]
   assert any('ACPI non-volatile storage RAM' in c['types'] for c in inventory.conflicts(pages, inventory.memory_ranges(initial)))
   t=now(); held=fifo.open('wb',buffering=0) if persistent else None
   def record(tag):
    note['observations'].append([tag,round(now()-t,3),log.read_bytes().split(b'AWAIT-PLACEMENT')[-1].hex(),vm.poll()])
   def send(x):
    if held is not None:assert held.write(x)==len(x)
    else:
     with fifo.open('wb',buffering=0) as stream:assert stream.write(x)==len(x)
    record('wrote '+x.hex())
   if style in ('burst','heldburst'):send(b'DENY\r')
   elif style=='prefix':
    send(b'DEN');until(lambda:log.read_bytes().endswith(b'DEN'));record('complete partial echo')
    try:vm.wait(timeout=20)
    except subprocess.TimeoutExpired:record('20 second deadline elapsed while waiting for remainder')
    else:raise AssertionError('incomplete line quit guest')
    send(b'Y\r')
   else:
    prefix=b''
    for c in b'DENY':
     prefix+=bytes([c]);send(bytes([c]));until(lambda:log.read_bytes().endswith(prefix));record('echo '+prefix.decode())
    send(b'\r')
   try:rc=vm.wait(timeout=20)
   except subprocess.TimeoutExpired:
    record('timed out after full host write');note['stall']={'tail':log.read_bytes()[-90:].hex(),'status':m.call('query-status'),'cpus':m.call('query-cpus-fast')};raise
   record('exit');assert rc==0
   raw=log.read_bytes();assert raw.endswith(b'DENY') and b'ATTEMPT-HANDOFF' not in raw and b'PCP OS kernel' not in raw
   note['passed']=True;print(label,round(now()-t,3),repr(raw[-7:]),flush=True)
  finally:
   if vm.poll() is None:vm.kill();vm.wait()
   (out/'result.json').write_text(json.dumps(note,indent=2)+'\n')
for n,kind in enumerate(sys.argv[1:],1):
 try:run(f'stock-{n}-{kind}',kind)
 except Exception as exc:print(n,kind,type(exc).__name__,str(exc),flush=True)

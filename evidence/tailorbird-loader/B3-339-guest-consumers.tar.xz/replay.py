from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
from collections import defaultdict
import re

root = Path(__file__).resolve().parent
archive = root / 'native.zip'
expected = 'f2a6073ba88694b1f7fc2f8a4a1bd034e210599da391caccb1d653cd060b3a9c'
assert sha256(archive.read_bytes()).hexdigest() == expected
with ZipFile(archive) as z:
    assert z.testzip() is None
    arms = defaultdict(dict)
    for name in z.namelist():
        _, arm, item = name.split('/')
        assert item not in arms[arm]
        arms[arm][item] = name
    assert set(arms) == {'order', 'focus', 'fragment', 'history', 'allowed'}
    images = {'kernel.elf32': set(), 'surf.elf': set()}
    total = 0
    for arm, paths in sorted(arms.items()):
        serial = z.read(paths['serial.log']).decode()
        assert 'display: Bochs, 1920x1080, 2 page(s)' in serial
        match = re.search(r'^surf\.elf ended DONE: exit 0[^\n]*?; (\d+) frames shown', serial, re.M)
        assert match and 'ended FAILED' not in serial
        frames = int(match[1])
        assert frames >= 2
        total += frames
        for item in images:
            images[item].add(sha256(z.read(paths[item])).hexdigest())
        seen = set()
        captures = 0
        for name, path in paths.items():
            if not name.endswith('.ppm'):
                continue
            img = z.read(path)
            header, size, maxval, payload = img.split(b'\n', 3)
            width, height = map(int, size.split())
            assert header == b'P6' and maxval == b'255' and len(payload) == 3 * width * height
            captures += 1
            if not name.startswith('kernel-'):
                seen.add(sha256(payload).digest())
        assert {'kernel-launcher.ppm', 'kernel-returned.ppm', 'kernel-power-question.ppm'} <= paths.keys()
        if arm == 'allowed':
            assert not seen
        else:
            assert len(seen) >= 2
        same = {
            'focus': [('focus-second', 'focus-reverse'), ('focus-wrap', 'focus-back')],
            'history': [('dock-focused', 'back-dock'), ('home-focused', 'branch-back'), ('shelf', 'forward-shelf')],
            'order': [('back', 'last-focused'), ('direct', 'wharf')],
            'fragment': [('home', 'up'), ('scroll', 'back')],
        }
        for earlier, later in same.get(arm, []):
            assert z.read(paths[earlier+'.ppm']) == z.read(paths[later+'.ppm'])
        print(arm, frames, 'presentations,', captures, 'valid captures,', len(seen), 'distinct guest screens')
    assert all(len(s)==1 for s in images.values())
    print(total, 'frame presentations from the same guest and kernel across all five arms')

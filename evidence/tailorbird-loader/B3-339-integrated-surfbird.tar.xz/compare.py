from zipfile import ZipFile
from pathlib import Path
from collections import defaultdict
from hashlib import sha256
import re
import sys
old, new = map(Path, sys.argv[1:])
for path,digest in ((old,'f2a6073ba88694b1f7fc2f8a4a1bd034e210599da391caccb1d653cd060b3a9c'), (new,'dc87387d9f9827289a22935fa12d7031fc4765634faecc1b84c7d4cae18119ea')):
    assert sha256(path.read_bytes()).hexdigest()==digest
def members(archive):
    rows={tuple(p.split('/')[1:]):p for p in archive.namelist()}
    assert len(rows)==len(archive.namelist())
    return rows
with ZipFile(old) as previous, ZipFile(new) as current:
    a,b=members(previous),members(current)
    assert set(a)==set(b)
    images=defaultdict(list)
    kernels=set()
    guests=set()
    for (arm, name), newer in sorted(b.items()):
        older=a[arm,name]
        if name=='surf.elf':
            assert previous.read(older)==current.read(newer)
            guests.add(sha256(current.read(newer)).hexdigest())
        elif name=='kernel.elf32':
            kernels.add(tuple(sha256(z.read(p)).hexdigest() for z,p in ((previous,older),(current,newer))))
        elif name.endswith('.ppm'):
            images['kernel' if name.startswith('kernel-') else 'guest'].append((arm,name,previous.read(older)==current.read(newer)))
        elif name=='serial.log':
            for z,p in ((current,newer),(previous,older)):
                log=z.read(p).decode()
                result=re.search(r'surf\.elf ended DONE: exit 0.*?(\d+) free before and (\d+) after',log)
                assert result and result[1]==result[2]
    assert len(kernels)==len(guests)==1
    assert next(iter(kernels))[0]!=next(iter(kernels))[1]
    print('kernels (old and integrated)',*next(iter(kernels)))
    print('identical guest',*guests)
    for kind,rows in images.items():
        print(kind, sum(equal for _,_,equal in rows), 'of',len(rows),'captures byte-identical across kernels')
        print('differences',[(arm,name) for arm,name,equal in rows if not equal])

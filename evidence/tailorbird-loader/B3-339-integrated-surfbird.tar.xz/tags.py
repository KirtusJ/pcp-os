"""Compare all Surfbird guest captures with only each fixture's independently observed nonce normalized."""
import ast
import hashlib
import re
import sys
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile
from PIL import Image, ImageChops

root = Path(__file__).resolve().parent
table = (root / "font.rs").read_text().split("= [", 1)[1].split("];", 1)[0]
glyphs = ast.literal_eval("[" + table + "]")
def word_image(word, ink):
    background = (16, 42, 51)
    output = Image.new("RGB", (120, 20), background)
    for index, character in enumerate(word):
        for offset, alpha in enumerate(glyphs[ord(character)-32]):
            x, y = offset % 10, offset // 10
            output.putpixel((index * 10 + x, y), tuple((fg*alpha+bg*(255-alpha))//255 for fg,bg in zip(ink, background)))
    return output

def normalize(old, new, tags):
    bounds = ImageChops.difference(old,new).getbbox()
    if bounds is None:
        return False
    options = [(39,(165,185,188))] + [(104+22*n,(203,218,221)) for n in range(9)]
    for y, ink in options:
        if not y <= bounds[1] <= bounds[3] <= y+20:
            continue
        for x in range(26, 200, 10):
            region = (x,y,x+120,y+20)
            if not x <= bounds[0] <= bounds[2] <= x+120:
                continue
            if all(im.crop(region).tobytes() == word_image(tag,ink).tobytes() for im,tag in zip((old,new),tags)):
                return True
    raise AssertionError(f"pixel differences outside confirmed nonce text: {bounds}")

def index(archive):
    return {tuple(name.split("/")[1:]):name for name in archive.namelist()}

outputs = []
for file, digest in zip(sys.argv[1:],("f2a6073ba88694b1f7fc2f8a4a1bd034e210599da391caccb1d653cd060b3a9c","dc87387d9f9827289a22935fa12d7031fc4765634faecc1b84c7d4cae18119ea")):
    assert hashlib.sha256(Path(file).read_bytes()).hexdigest() == digest
    outputs.append(ZipFile(file))
assert len(outputs) == 2
indices = [index(z) for z in outputs]
assert indices[0].keys() == indices[1].keys()
for arm in ("allowed", "focus", "fragment", "history", "order"):
    tags = []
    for z, idx in zip(outputs, indices):
        capture = z.read(idx[arm,"guest.pcap"])
        seen = set(re.findall(rb"(?:shelf-|dock-|jetty-|wharf-|Map |Tide |bar-)([0-9a-f]{12})", capture))
        assert len(seen)==1
        tags.append(seen.pop().decode("ascii"))
    assert tags[0] != tags[1]
    exact = tagged = 0
    for scenario,name in indices[0]:
        if scenario!=arm or name.startswith("kernel-") or not name.endswith(".ppm"):
            continue
        images = [Image.open(BytesIO(z.read(idx[arm,name]))).convert("RGB") for z,idx in zip(outputs,indices)]
        if normalize(*images,tags):
            tagged += 1
        else:
            exact += 1
    print(arm, exact, "identical,", tagged, "differ only in confirmed fixture nonce")
    outputs_count = exact + tagged
    assert outputs_count == dict(allowed=0,focus=7,fragment=6,history=10,order=6)[arm]

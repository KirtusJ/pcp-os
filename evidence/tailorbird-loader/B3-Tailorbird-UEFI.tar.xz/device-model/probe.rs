#![allow(dead_code)]
use std::cell::RefCell;
use std::panic::{catch_unwind, AssertUnwindSafe};
mod device;

const FILL: u32 = 0x515151;
#[derive(Default)]
struct Model {
    info: [u32; 6],
    requested: Option<(u32,u32)>,
    operations: Vec<usize>,
    flips: Vec<usize>,
    buffer: Vec<u32>,
    mapped: Vec<usize>,
}
thread_local! {static FB: RefCell<Model> = RefCell::new(Model::default());}
fn open(path: &[u8], _: usize) -> isize {
    match path {b"/dev/fb0\0"=>8,b"/dev/kbd\0"=>9,_=>-1}
}
fn log(_: &[u8]) {}
fn exit(code: i32) -> ! {assert_eq!(code,2);std::panic::panic_any(code)}
fn ioctl(fd: isize, req: usize, arg: usize) -> isize {
    assert_eq!(fd,8);
    FB.with_borrow_mut(|m| {
        m.operations.push(req);
        match req {
            0x5001|0x5002 => {
                let info = unsafe {&mut *(arg as *mut [u32;6])};
                if req==0x5002 {m.requested=Some((info[0],info[1]));}
                *info=m.info;
            }
            0x5003 => {assert!(arg < m.info[3] as usize);m.flips.push(arg);}
            _=>panic!("unexpected ioctl"),
        }
    });0
}
fn call(n: usize,_: usize,size: usize,prot: usize,flags: usize,fd: usize,_: usize) -> isize {
    assert_eq!((n,prot,flags,fd),(9,3,1,8));
    FB.with_borrow_mut(|m| {assert_eq!(size,m.buffer.len()*4);m.mapped.push(size);m.buffer.as_mut_ptr() as isize})
}
fn reset(info: [u32;6], words: usize) {
    FB.with_borrow_mut(|m|*m=Model{info,buffer:vec![FILL;words],..Default::default()});
}
fn valid(pages:u32,front:u32,request:bool){
    reset([3,2,20,pages,front,0],(10*pages) as usize);
    let mut d=if request {device::Display::new(3,2)} else {device::Display::current()};
    let page=if pages==1 {0} else {1-front};
    d.show(&[1,2,3,4,5,6]);
    FB.with_borrow(|m|{
        assert_eq!(m.requested, request.then_some((3,2)));
        let which=if request {0x5002} else {0x5001};
        assert_eq!(m.operations, if pages==1 {vec![which]} else {vec![which,0x5003]});
        assert_eq!(m.mapped,vec![(10*pages*4) as usize]);
        for i in 0..pages {
            let expected=if i==page {[1,2,3,FILL,FILL,4,5,6,FILL,FILL]} else {[FILL;10]};
            assert_eq!(&m.buffer[(i*10) as usize..(i*10+10) as usize],expected);
        }
    });
    d.draw(|surface,w,h,pitch|{assert_eq!((w,h,pitch,surface.len()),(3,2,5,10));surface[0]=77;});
    FB.with_borrow(|m|{
        assert_eq!(m.flips, if pages==1 {vec![]} else {vec![page as usize,front as usize]});
        assert_eq!(m.buffer[if pages==1 {0} else {(front*10) as usize}],77);
    });
    println!("accepted request={request} pages={pages} front={front}; retained padding, mapped stride and flipped correctly");
}
fn refused(info:[u32;6], request:bool){
    reset(info,0);
    let fail=catch_unwind(AssertUnwindSafe(||{
        if request {device::Display::new(3,2)} else {device::Display::current()}
    }));
    assert_eq!(fail.err().and_then(|e|e.downcast::<i32>().ok()).map(|n|*n),Some(2));
    FB.with_borrow(|m|assert!(m.mapped.is_empty()));
    println!("refused before mapping {info:?}, request={request}");
}
fn main(){
    std::panic::set_hook(Box::new(|_|{}));
    for request in [true,false] {for (pages,front) in [(1,0),(2,0),(2,1)] {valid(pages,front,request);}}
    for a in [[0,2,20,1,0,0],[3,0,20,1,0,0],[3,2,15,1,0,0],[3,2,8,1,0,0],
              [3,2,20,0,0,0],[3,2,20,3,0,0],[3,2,20,1,1,0],[3,2,20,2,2,0],
              [10,u32::MAX,u32::MAX-3,2,0,0]] {refused(a,false);}
    refused([4,2,20,1,0,0],true);
}

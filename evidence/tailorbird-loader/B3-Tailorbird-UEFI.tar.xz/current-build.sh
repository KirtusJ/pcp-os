set -eu
d=$1; w=$2; t=$(cat "$w/build-path"); rt=/workspace/scratch/6fbc6fd5187a/runtime
export CARGO_HOME="$w/cargo" CARGO_NET_OFFLINE=true RUSTUP_TOOLCHAIN=1.97.0
export PATH="$rt/register-live/rust197/bin:$rt/register-live/rust197/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$rt/root/usr/bin:$PATH" LD_LIBRARY_PATH="$rt/lib"
for item in 'one 312c6273d911887711b20d49087119444cc33df1' 'two 9efd5352c3877418765a7fc05d215bae01f44306'; do
    read -r name rev <<< "$item"
    folder="$t/current-$name"; mkdir -p "$folder"; git -C "$d/upstream.git" archive "$rev" | tar -xf - -C "$folder"
    cp -r "$t/tailor-first/pcp-os/." "$folder/pcp-os/"
    cd "$folder"; export CARGO_TARGET_DIR="$t/current-target-$name"
    sh build.sh > "$d/$name-build.log" 2>&1
    cargo test --release --lib --locked --offline >> "$d/$name-build.log" 2>&1
    rustc --edition=2021 --test guest/tests/display_pages.rs -o "$t/display-pages-$name"
    "$t/display-pages-$name" >> "$d/$name-build.log"
    cp "$CARGO_TARGET_DIR/x86_64-unknown-none/release/tailorbird" "$d/bin/$name.elf"
    sha256sum "$d/bin/$name.elf"
done

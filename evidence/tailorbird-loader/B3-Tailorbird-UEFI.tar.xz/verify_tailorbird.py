"""Replay the saved public Tailorbird UEFI guest runs. Run with Python 3 from any folder."""
import hashlib
import json
from pathlib import Path
import re
import runpy
import sys
import titles

root = Path(__file__).resolve().parent
system = root / 'src/examples'
readout = runpy.run_path(str(system / 'tester-cd/check.py'))
observer = runpy.run_path(str(system / 'firmware-owned-uefi/usb_observer.py'))
glyphs = readout['kernel_glyphs']()
expected = {
    'one': 'f67d41ab467690545f1fc53760503c3ca399f68557760d433775e7da7b6e60b7',
    'two': 'c1e79cee1b5a645062d15dc2cd9de2cf2d4306d9de34edc395052a7c2b727b00',
}
cases = ['one-1920x1080-bochs-serial', 'two-800x600-ramfb-retry', 'two-800x600-bochs-retry',
         'two-1024x768-ramfb', 'two-1280x720-bochs-serial', 'two-1920x1080-bochs-serial',
         'two-2560x1440-bochs-serial']


def digest(data):
    return hashlib.sha256(data).hexdigest()


for version, pin in expected.items():
    media = root / ('media-' + version)
    manifest = json.loads((media / 'image.json').read_text())
    binary = (root / 'bin' / (version + '.elf')).read_bytes()
    assert digest(binary) == pin
    assert digest((media / 'usb.img').read_bytes()) == manifest['usb_sha256']
    assert (media / 'usb.img').read_bytes().count(binary) == 1
    assert manifest['measurement'] == '9903b119dc99fe4849ec9323d2bf9067c09ddddec2dca9f944f80940869a2450'

for case in cases:
    version, size, device, *repeat = case.split('-')
    folder = root / case
    report = json.loads((folder / 'result.json').read_text())
    width, height = map(int, size.split('x'))
    kernel = (folder / 'serial.txt').read_text()
    firmware = (folder / 'firmware.txt').read_text()
    cfg = report['qemu']
    assert any(('bochs-display' in s if device == 'bochs' else s == 'ramfb') for s in cfg)
    assert any('id=stick,' in s and 'readonly=on' in s for s in cfg)
    source = json.loads((root / ('media-' + version) / 'image.json').read_text())
    assert source == report['image'] and expected[version] == report['guest_sha256']
    assert f'SHA-256 {expected[version]})' in kernel
    assert f'display: Loader, {size}, 1 page(s)' in kernel
    pitch = int(re.search(r'^console_pitch=([0-9a-f]+)', firmware, re.M)[1],16)
    address = int(re.search(r'^console_framebuffer=([0-9a-f]+)', firmware, re.M)[1],16)
    assert pitch == report['pitch'] and pitch >= width*4 and hex(address) == report['framebuffer']
    assert report['loader_display'].endswith(hex(address))
    negative = size == '800x600'
    assert report['verified'] and len(report['frames']) == (6 if negative else 9)
    assert sum(s.startswith('  pass ') for s in kernel.splitlines()) == 72
    assert not any(s.startswith('  FAIL ') for s in kernel.splitlines())
    assert report['passed'] == 72
    for tag, pin in report['frames'].items():
        img = (folder / (tag + '.ppm')).read_bytes()
        assert digest(img) == pin
        if tag in ('fit','compact','fit-back'):
            assert titles.verify(img, compact=tag == 'compact') == [width,height]
        else:
            rows = readout['read_screen'](img, glyphs)
            assert '\n'.join(rows) + '\n' == (folder / (tag + '.txt')).read_text()
    assert 'tailorbird.elf' in (folder / 'returned.txt').read_text()
    assert 'chain intact' in (folder / 'register.txt').read_text()
    assert 'Switch PCP OS off?' in (folder / 'power.txt').read_text()
    if negative:
        assert pitch * height % 4096 == 3072 and len(report['frames']) == 6
        assert 'tailorbird.elf ended FAILED: exit 2' in kernel and '0 frames shown' in kernel
        assert 'Tailorbird first frame presented' not in kernel
        assert report['launch_outcome'] == 'exit 2 before first frame'
    else:
        assert 'Tailorbird first frame presented' in kernel and 'tailorbird.elf ended DONE: exit 0' in kernel
        assert report['frames']['fit'] == report['frames']['fit-back'] != report['frames']['compact']
    snapshots = report['snapshots']
    assert [s['stage'] for s in snapshots] == ['before','home','returned','shutdown']
    assert all(digest((folder/'internal.raw').read_bytes()) == s['nvme_sha256'] for s in snapshots)
    for snap in snapshots:
        variables = (folder/snap['vars_snapshot']).read_bytes()
        assert digest(variables) == snap['vars_sha256'] and observer['variables'](variables) == snap['variables']
    intervals = [observer['compare'](folder,a,b) for a,b in zip(snapshots,snapshots[1:])]
    assert intervals == report['intervals']
    assert all(v['nvme_bytes_preserved'] and not any(v['counter_deltas']['sentinel'].values()) for v in intervals)
    assert all(v['vars_bytes_changed'] == 0 for v in intervals[1:])
    assert [(e['data']['guest'],e['data']['reason']) for e in report['events'] if e['event']=='SHUTDOWN'] == [(True,'guest-shutdown')]
    print(case, report['launch_outcome'], '72 passes; NVMe preserved')

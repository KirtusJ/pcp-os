"""Compare two complete UI labels against coverage masks shipped with the audited guest."""
import ast
from pathlib import Path
base = Path(__file__).resolve().parent
font = base/"src/PCP_OS_Rust/crates/pcpos-kernel/src"
masks = ast.literal_eval("[" + (font/"font.rs").read_text().split(" = [",1)[1].split("];",1)[0] + "]")
double = (font/"font-2x.bin").read_bytes()
def verify(frame,compact=False):
    head, size, depth, pixels = frame.split(b"\n",3)
    w,h=map(int,size.split()); assert head==b"P6" and depth==b"255" and len(pixels)==3*w*h
    whole=min(w//960,h//540)
    if whole: scale,div=(1 if compact else whole),1
    else: scale,div=(w,960) if w*540<h*960 else (h,540)
    left=(w-960*scale//div)//2
    top=(h-540*scale//div)//2
    panel=(24,54,79)
    for word,x,y,n,ink in (("TAILORBIRD",22,16,3,(65,186,215)),("NO SERVICE",737,27,2,(240,138,114))):
        for i,ch in enumerate(word):
            x0=left+(x+i*6*n)*scale//div
            x1=left+(x+(i+1)*6*n)*scale//div
            y0=top+y*scale//div; y1=top+(y+10*n)*scale//div
            dw,dh=x1-x0,y1-y0
            index=ord(ch)-32
            sw,sh=(20,40) if dw>10 or dh>20 else (10,20)
            mask=double[index*800:(index+1)*800] if sw==20 else masks[index]
            for dy in range(dh):
                sy=dy*sh//dh; ey=max(sy+1,(dy+1)*sh//dh)
                for dx in range(dw):
                    sx=dx*sw//dw;ex=max(sx+1,(dx+1)*sw//dw)
                    alpha=sum(sum(mask[j*sw+sx:j*sw+ex]) for j in range(sy,ey))//((ex-sx)*(ey-sy))
                    expected=bytes((a*(255-alpha)+b*alpha+127)//255 for a,b in zip(panel,ink))
                    at=((y0+dy)*w+x0+dx)*3
                    if pixels[at:at+3]!=expected:
                        raise ValueError(f"{word} differs at {x0+dx},{y0+dy}")
    return [w,h]

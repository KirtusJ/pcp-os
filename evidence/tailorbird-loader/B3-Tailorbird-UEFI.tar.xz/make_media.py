"""Build a virtual removable fixture with the repository recipe and an alternate GNU-EFI prefix."""
import argparse
import json
import os
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
for key in ('source', 'kernel', 'distribution', 'prefix', 'output'):
    p.add_argument(key, type=Path)
a = p.parse_args()
output = a.output.resolve()
output.mkdir()
source = a.source.resolve()
loader = source / 'examples/firmware-owned-uefi'
recipe = loader / 'image.py'
prefix = a.prefix.resolve()
os.environ['PATH'] = f"{prefix}/bin:{prefix}/sbin:" + os.environ['PATH']
os.environ['LD_LIBRARY_PATH'] = str(prefix / 'lib/x86_64-linux-gnu')
recipe_text = recipe.read_text().replace('/usr/include/efi', str(prefix / 'include/efi')).replace('/usr/lib', str(prefix / 'lib'))
module = {'__name__': 'vm_image'}
exec(compile(recipe_text, str(recipe), 'exec'), module)
image = module['make'](a.distribution.resolve(), a.kernel.resolve(),
                       source / 'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py',
                       output, loader, usb_vm=True)
(output / 'image.json').write_text(json.dumps(image, indent=2) + '\n')
print(image['usb_sha256'], image['measurement'])

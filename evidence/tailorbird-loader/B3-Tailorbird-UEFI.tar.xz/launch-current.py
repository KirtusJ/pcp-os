from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import os,subprocess,sys
d=Path(__file__).resolve().parent
exe='/workspace/scratch/6fbc6fd5187a/runtime/desk-build/release/pcp-delegate'
q='/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64';fw='/workspace/scratch/15ccefba7c7d/validation/pkg/root/usr/share/OVMF'
def run(config):
    ver,screen,driver=config.split('/')
    key='-'.join((ver,screen,driver))+os.environ.get('B3_RUN_TAG','')
    with (d/(key+'.log')).open('w') as stream:
        proc=subprocess.run([exe,d/'canonical.redb','b3-current-'+key,'Boot '+key+' and record launch and safe return','--',sys.executable,'-B',d/'boot_current.py',screen,q,fw,ver],env={**os.environ,'B3_VIDEO':driver},stdout=stream,stderr=subprocess.STDOUT)
    print(key,proc.returncode,flush=True)
with ThreadPoolExecutor(max_workers=int(os.getenv("B3_JOBS","1"))) as pool:
    list(pool.map(run,sys.argv[1:]))

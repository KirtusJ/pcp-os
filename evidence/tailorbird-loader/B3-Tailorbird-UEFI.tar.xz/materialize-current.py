from pathlib import Path
import hashlib,os,subprocess,sys
d=Path(__file__).resolve().parent
src=d/'src/examples/firmware-owned-uefi/image.py'
template=src.read_text()
old=hashlib.sha256((d/'bin/tailorbird.elf').read_bytes()).hexdigest()
assert template.count(old)==1
try:
    for name in ("one","two"):
        elf=d/'bin'/(name+'.elf');digest=hashlib.sha256(elf.read_bytes()).hexdigest()
        src.write_text(template.replace(old,digest))
        with (d/(name+'-media.log')).open('w') as out:
            subprocess.run([sys.executable,'-B',d/'make_media.py',d/'src',d/'kernel/kernel.elf32',
                            '/workspace/scratch/6fbc6fd5187a/runtime/dist-landed/PCP-OS.iso',
                            '/workspace/scratch/15ccefba7c7d/validation/pkg/root/usr',d/('media-'+name)],
                           env={**os.environ,'B3_TAILORBIRD_ELF':str(elf)},stdout=out,stderr=subprocess.STDOUT,check=True)
finally:
    src.write_text(template)

"""Replay the native edge-test baseline and check that a one-pixel error in the final row is visible."""
from pathlib import Path
from hashlib import sha256
import json
from edge import pixels
r=Path(__file__).resolve().parent
digest=lambda data:sha256(data).hexdigest()
pin=digest((r/'bin/edge.elf').read_bytes())
for driver,size in [('ramfb','1024x768'),('ramfb','800x600'),('bochs','800x600')]:
    path=r/f'edge-{size}-{driver}-baseline'
    report=json.loads((path/'result.json').read_text())
    serial=(path/'serial.txt').read_text()
    assert report['verified'] and report['passed']==72 and report['guest_sha256']==pin
    assert f'SHA-256 {pin}' in serial
    assert [e['data'].get('reason') for e in report['events'] if e['event']=='SHUTDOWN']==['guest-shutdown']
    if size=='1024x768':
        for tag,inv in [('pattern-a',False),('pattern-b',True)]:
            raw=(path/(tag+'.ppm')).read_bytes()
            assert digest(raw)==report['frames'][tag] and pixels.verify(raw,1024,768,inv)
        assert 'B3 edge pattern B presented' in serial and 'ended DONE: exit 0' in serial
        print(size,driver,'two complete 786432-pixel source patterns reproduced')
    else:
        assert 'ended FAILED: exit 2' in serial and 'B3 edge pattern A presented' not in serial
        assert report['pitch']==3200 and report['launch_outcome']=='exit 2 before first frame'
        print(size,driver,'legacy client failed explicitly before first frame')
for inverted in (False,True):
    width,height=800,600
    head=b'P6\n800 600\n255\n'
    reference=bytearray(head+pixels.expected(width,height,inverted))
    assert pixels.verify(reference,width,height,inverted)
    for x in (0,31,32,799):
        altered=reference[:];altered[len(head)+3*((height-1)*width+x)]^=1
        assert not pixels.verify(altered,width,height,inverted)
print('Eight one-pixel errors rejected across both patterns at x=0,31,32,799 of row 599')

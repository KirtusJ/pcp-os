#![no_std]
#![no_main]
use pcp_game_guest::{exit, log, sleep_us, Display};

pcp_game_guest::entry!(edge_main);

fn paint(display: &mut Display, inverted: bool) {
    display.draw(|pixels, width, height, pitch| {
        for y in 0..height {
            for x in 0..width {
                let color = ((x & 255) << 16) | ((y & 255) << 8) | ((x ^ y) & 255);
                pixels[y * pitch + x] = color as u32 ^ if inverted { 0x00ff_ffff } else { 0 };
            }
        }
    });
}

#[no_mangle]
pub extern "C" fn edge_main() -> ! {
    let mut display = Display::current();
    paint(&mut display, false);
    log(b"B3 edge pattern A presented\n");
    loop {
        if let Some(key) = display.next_press() {
            match key {
                1 => exit(0),
                0x3b => {
                    paint(&mut display, true);
                    log(b"B3 edge pattern B presented\n");
                }
                _ => {}
            }
        }
        sleep_us(1000);
    }
}

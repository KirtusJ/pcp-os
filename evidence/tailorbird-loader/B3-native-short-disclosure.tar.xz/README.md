# Director B3 small-screen access disclosure

The production renderer in #346 is source blob 0fce4a7d16ce5a41e1b9312cb5e7ee3d4b26b4ce. The two exact integrated native captures at 800×600 and 1280×720 use the kernel sources of d52b023722dd3c287e1eaf859571b87a05f83d32. Both Programs and Details display appropriate access for each of the two program digests, and both machines shut down with exit 33.

The two short-screen runs reuse the corrected renderer from the earlier isolated build with two additional neutral display rows (layout-fixture.patch). The fixture only inserts strings. No device needs to be granted to render four disclosures. At 640×260 the compact layout has a row for each, plus the selected program and the keys. At 640×280 the spaced layout does likewise. The included small-screen images are the native framebuffers. The fixture's output is distinct from the production images.

Additional observations on the corrected renderer cover the default kernel, console-only grants and the 800×600 UEFI sound-enabled path. The UEFI result records shutdown and independent storage observations. Each result includes its command line and hashes. Paths in runners refer to the original workspace.

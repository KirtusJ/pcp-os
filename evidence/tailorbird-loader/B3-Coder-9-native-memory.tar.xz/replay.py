"""Replay four native file-sized and KV-sized allocations with no model present."""
from pathlib import Path
import hashlib, json, re
root=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
guest=digest(root/'bin/plain.elf')
assert guest=='44c640e94e61c031fd567a96e7aeb96387169510edda1be691dacefb5fb7e14b'
media=json.loads((root/'media-plain/image.json').read_text())
assert digest(root/'media-plain/usb.img')==media['usb_sha256']=='3fda7cb7be06fed04938b20e6ac2f6beb8aa061711214970737e88f31338048c'
assert digest(root/'kernel.elf32')==media['elf_sha256']=='bd984a3dc4eab27e599a0bc3d935be807b61855a73206bccca47ca029f0efa92'
sizes=(491400064,50331648)
pages=sum((n+4095)//4096 for n in sizes)
assert pages==132259
for ram,free in ((1024,231919),(2048,248815)):
    for action,state in (('done','DONE'),('stop','STOPPED')):
        d=root/f'plain-1920x1080-bochs-{ram}-{action}'
        r=json.loads((d/'result.json').read_text())
        log=(d/'serial.txt').read_text()
        assert r['verified'] and r['image']==media and r['guest_sha256']==guest
        assert 'B3 verified simultaneous private mappings of 491400064 and 50331648 bytes' in log
        assert f'memcheck.elf ended {state}' in log and 'the store holds 0 file(s), 0 bytes' in r['outcome']
        assert r['outcome'] in log and f'132783 frames given back, {free} free before and {free} after' in log
        assert r['free_before']==r['free_after']==free and r['frames_reclaimed']==132783
        assert f'id T15; outcome {state}' in (d/'register.txt').read_text()
        assert sum(l.startswith('  pass ') for l in log.splitlines())==r['passed']==72 and 'ALL SELF-TESTS PASS.' in log
        assert [(e['data']['guest'],e['data']['reason']) for e in r['events'] if e['event']=='SHUTDOWN']==[(True,'guest-shutdown')]
        assert all(i['nvme_bytes_preserved'] and not any(i['counter_deltas']['sentinel'].values()) for i in r['intervals'])
        assert set(r['frames'])=={'home','launcher','returned','register','back','power'}
        assert all(digest(d/(tag+'.ppm'))==h for tag,h in r['frames'].items())
        print(ram,state,pages,'private data pages checked, all',132783,'frames restored')

#![no_std]
#![no_main]
#[allow(dead_code)]
mod abi;

const PAGE: usize = 4096;
const FILE_BYTES: usize = 491_400_064;
const CACHE_BYTES: usize = 2_048 * 24_576;
const SIZES: [usize; 2] = [FILE_BYTES, CACHE_BYTES];

core::arch::global_asm!(".global _start", ".section .text.start", "_start:", "and rsp, -16", "call run", "ud2");

fn page_marker(region: usize, page: usize) -> u64 {
    0xB300_0000_0000_0000 | ((region as u64) << 40) | page as u64
}

#[no_mangle]
pub extern "C" fn run() -> ! {
    let mut bases = [0usize; 2];
    for (i, &bytes) in SIZES.iter().enumerate() {
        let map = abi::call(9, 0, bytes, 3, 0x22, usize::MAX, 0);
        if map < 0 { abi::exit(1); }
        bases[i] = map as usize;
        for page in 0..bytes.div_ceil(PAGE) {
            let word = (bases[i] + page * PAGE) as *mut u64;
            unsafe { word.write_volatile(page_marker(i, page)); }
        }
        unsafe { ((bases[i] + bytes - 1) as *mut u8).write_volatile(0xA0 + i as u8); }
    }
    for (i, &bytes) in SIZES.iter().enumerate().rev() {
        if unsafe { ((bases[i] + bytes - 1) as *const u8).read_volatile() } != 0xA0 + i as u8 {
            abi::exit(2);
        }
        for page in (0..bytes.div_ceil(PAGE)).rev() {
            let word = (bases[i] + page * PAGE) as *const u64;
            if unsafe { word.read_volatile() } != page_marker(i, page) { abi::exit(3); }
        }
    }
    abi::log(b"B3 verified simultaneous private mappings of 491400064 and 50331648 bytes\n");
    let delay = [3i64, 0i64];
    if abi::call(35, delay.as_ptr() as usize, 0, 0, 0, 0, 0) < 0 { abi::exit(4); }
    abi::exit(0)
}

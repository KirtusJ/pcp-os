"""Recompute the frozen Coder tensor byte spans, KV sizes and exact-copy results."""
import base64
import collections
import hashlib
import json
import math
from pathlib import Path
import sys

source = Path(sys.argv[1]) / "qa/model-reference"
def load(name):
    return json.loads((source / (name + ".json")).read_bytes())
profile, layout, identity = load("model-profile"), load("tensor-layout"), load("identity")["model"]
assert all(identity[k] == profile[k] for k in ("repository","revision","filename","bytes","sha256"))
assert identity["sha256"] == "1d9614638d18024d0fbb36575a15f1302a3adf044df10345688ec4f6e1c4ff32"
assert hashlib.sha256((source/"model-profile.json").read_bytes()).hexdigest()==layout["profile_sha256"]
types = {0:("F32",1,4), 6:("Q5_0",32,22), 8:("Q8_0",32,34), 12:("Q4_K",256,144), 14:("Q6_K",256,210)}
totals = collections.Counter()
names = set()
end = 0
for t in sorted(profile["tensors"],key=lambda x:x["offset"]):
    assert t["name"] not in names
    names.add(t["name"])
    assert t["offset"] == end
    name, elements, nbytes = types[t["ggml_type"]]
    assert t["shape"][0] % elements == 0
    size = math.prod(t["shape"]) // elements * nbytes
    totals[name] += size
    end += size
assert len(names)==291 and dict(totals)==layout["tensor_bytes_by_type"]
assert end == layout["total_tensor_bytes"] == 485452288
assert profile["tensor_data_offset"] + end == identity["bytes"] == 491400064
m=profile["metadata"]
kv=2*m["qwen2.block_count"]*m["qwen2.attention.head_count_kv"]*(m["qwen2.embedding_length"]//m["qwen2.attention.head_count"])*4
assert kv==24576 and kv*2048==50331648
print(f"{len(names)} unique, contiguous tensors in five formats: {end} tensor bytes + {profile['tensor_data_offset']} leading bytes = {identity['bytes']}. F32 KV: {kv} bytes/token, {kv*2048} bytes at 2048 tokens.")
reference=load("reference")
scores=collections.defaultdict(list)
peaks=[]
for trial in reference["trials"]:
    if not trial["exact_input"]:continue
    peaks.append(trial["result"]["sampled_peak_working_set_bytes"])
    if not trial["result"]["schema_constrained"] or trial["expected"]["kind"] != "create_text":continue
    raw=base64.b64decode(trial["stdout_base64"],validate=True)
    assert hashlib.sha256(raw).hexdigest()==trial["stdout_sha256"]
    output=json.loads(raw.decode().strip().removesuffix("[end of text]").strip())
    scores[trial["series"]].append(output==trial["expected"])
assert [(k,sum(v),len(v)) for k,v in sorted(scores.items())] == [("exact-baseline",0,4),("exact-revised",2,5)]
assert len(peaks)==16 and (min(peaks),max(peaks))==(507858944,531415040)
print("Confirmed 0/4 and 2/5 exact document drafts; corrected host working-set samples 507858944..531415040 bytes.")

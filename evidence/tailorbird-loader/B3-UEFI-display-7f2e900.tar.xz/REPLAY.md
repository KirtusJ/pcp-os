# Replaying the UEFI display check

Run `python3 -B replay.py` from the unpacked archive with Python 3.10 or later. Allow 1 GiB of temporary space. The script first verifies the original GitHub Actions ZIP against the digest in `origin.json`. It then reads all nine serial logs, framebuffer captures, state snapshots and shutdown events. `replay.log` records the result from the independent PCP worker.

The native run used kernel `7f2e9008b3365722a4fdcf87b3c78b06d5af3fff`, the pinned Tailorbird checkout in diagnostic revision `ba3b03953e011b5252c1f7a925f7a5c90a5fdba7`, and candidate guest display blob `e5cd92eb3fc3e1fd6d42c6d377c997cb4ca8fa9e`. The 1024×768 control uses the earlier `B3-display-present-baseline.tar.xz` on the evidence branch. Hardware coverage is limited to QEMU UEFI ramfb and Bochs.

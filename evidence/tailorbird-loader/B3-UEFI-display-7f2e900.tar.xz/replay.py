"""Verify the original B3 UEFI shadow trial artifact using the earlier independent pixel observers."""
import hashlib
import json
from pathlib import Path
import re
import runpy
import sys
import tempfile
import zipfile

base = Path(__file__).resolve().parent
sys.path.insert(0, str(base / "modules"))
import pixels
import titles

def digest(data):
    return hashlib.sha256(data).hexdigest()

def verify(folder, case, previous, reader, glyphs, observer):
    guest, size, model = case.split("-")
    width, height = map(int, size.split("x"))
    d = folder / case
    r = json.loads((d / "result.json").read_text())
    raw = (d / "serial.txt").read_text()
    usb = json.loads((folder / ("media-" + guest + ".json")).read_text())
    pin = digest((folder / (guest + ".elf")).read_bytes())
    assert usb == r["image"] and r["guest_sha256"] == pin
    assert f"SHA-256 {pin})" in raw and f"display: Loader, {size}, 1 page(s)" in raw
    assert r["verified"] and r["passed"] == 72
    assert sum(l.startswith("  pass ") for l in raw.splitlines()) == 72
    assert not any(l.startswith("  FAIL ") for l in raw.splitlines())
    fw = (d / "firmware.txt").read_text()
    pitch = int(re.search(r"^console_pitch=([a-f0-9]+)", fw, re.M)[1],16)
    address = int(re.search(r"^console_framebuffer=([a-f0-9]+)",fw,re.M)[1],16)
    assert pitch == r["pitch"] == width*4 and r["framebuffer"] == hex(address)
    assert any("id=stick," in item and "readonly=on" in item for item in r["qemu"])
    assert any(("bochs-display" in item if model == "bochs" else item == "ramfb") for item in r["qemu"])
    expected_tags = {"home","launcher","returned","register","back","power"}
    if guest == "app":
        expected_tags |= {"fit","compact","fit-back"}
    if guest == "edge":
        expected_tags |= {"pattern-a","pattern-b"}
    assert set(r["frames"]) == expected_tags
    for tag, sha in r["frames"].items():
        img = (d / (tag+".ppm")).read_bytes()
        assert digest(img) == sha
        if tag.startswith("pattern-"):
            assert pixels.verify(img,width,height,tag == "pattern-b")
            if size=="1024x768":
                assert sha == previous["frames"][tag]
        elif tag in ("fit","compact","fit-back"):
            assert titles.verify(img,compact=tag == "compact") == [width,height]
        else:
            assert "\n".join(reader(img,glyphs)) + "\n" == (d/(tag+".txt")).read_text()
    assert "tailorbird.elf" in (d/"returned.txt").read_text()
    assert "chain intact" in (d/"register.txt").read_text()
    assert "Switch PCP OS off?" in (d/"power.txt").read_text()
    if guest == "legacy":
        assert "ended FAILED: exit 2" in raw and "0 frames shown" in raw
        assert "B3 edge pattern A presented" not in raw
    else:
        assert "ended DONE: exit 0" in raw
    if guest == "app":
        assert "Tailorbird first frame presented" in raw
        assert r["frames"]["fit"] == r["frames"]["fit-back"] != r["frames"]["compact"]
    if guest == "edge" and size == "800x600":
        for line in ["B3 opt-in shadow; early present returned EINVAL","B3 nonzero shadow page returned EINVAL",
                     "B3 repeated shadow mapping returned EINVAL","B3 edge pattern A presented","B3 edge pattern B presented"]:
            assert raw.splitlines().count(line) == 1, line
        assert pitch*height % 4096 == 3072
    if guest == "edge" and size == "1024x768":
        assert raw.splitlines().count("B3 opt-in direct") == 1
    snaps=r["snapshots"]
    assert [s["stage"] for s in snaps] == ["before","home","returned","shutdown"]
    nvme=digest((d/"internal.raw").read_bytes())
    for s in snaps:
        b=(d/s["vars_snapshot"]).read_bytes()
        assert s["nvme_sha256"] == nvme and s["vars_sha256"] == digest(b)
        assert observer["variables"](b) == s["variables"]
    intervals=[observer["compare"](d,a,b) for a,b in zip(snaps,snaps[1:])]
    assert intervals == r["intervals"]
    assert all(i["nvme_bytes_preserved"] and not any(i["counter_deltas"]["sentinel"].values()) for i in intervals)
    assert all(i["vars_bytes_changed"] == 0 for i in intervals[1:])
    assert [(e["data"]["guest"],e["data"]["reason"]) for e in r["events"] if e["event"]=="SHUTDOWN"] == [(True,"guest-shutdown")]
    print(case, r["launch_outcome"], len(r["frames"]),"verified frames",flush=True)
    return len(r["frames"])

def main():
    archive=base/"native.zip"
    manifest=json.loads((base/"origin.json").read_text())
    assert digest(archive.read_bytes()) == manifest["artifact_sha256"]
    src=base/"modules/src/examples"
    screen=runpy.run_path(str(src/"tester-cd/check.py"))
    observer=runpy.run_path(str(src/"firmware-owned-uefi/usb_observer.py"))
    glyphs=screen["kernel_glyphs"]()
    previous=json.loads((base/"direct-baseline.json").read_text())
    cases = {"edge-800x600-ramfb","edge-800x600-bochs","legacy-800x600-ramfb","edge-1024x768-ramfb",
             "app-800x600-ramfb","app-800x600-bochs","app-1280x720-bochs","app-1920x1080-bochs","app-2560x1440-bochs"}
    with tempfile.TemporaryDirectory() as tmp:
        dest=Path(tmp)
        with zipfile.ZipFile(archive) as z:
            assert len(z.namelist()) == len(set(z.namelist())) and z.testzip() is None
            for name in z.namelist():
                assert (dest/name).resolve().is_relative_to(dest)
            z.extractall(dest)
        summary=json.loads((dest/"summary.json").read_text())
        assert len(summary)==9 and all(s["passed"] for s in summary)
        assert {"-".join((s["guest"],s["size"],s["driver"])) for s in summary} == cases
        count=sum(verify(dest,k,previous,screen["read_screen"],glyphs,observer) for k in sorted(cases))
        print("All nine cases, all", count,"frames and all nine shutdowns verified.")

if __name__=="__main__":
    main()

"""Read a native QEMU P6 screen and check every visible pixel of the edge-test guest."""
from functools import lru_cache

@lru_cache(maxsize=12)
def expected(width,height,inverted):
    masks = []
    for y in range(min(256,height)):
        row = bytes(component for x in range(256)
                    for component in (x, y, x ^ y))
        masks.append((row * ((width+255)//256))[:3*width])
    content = b''.join(masks[y%256] for y in range(height))
    if inverted:
        return content.translate(bytes(255-x for x in range(256)))
    return content

def verify(raw,width,height,inverted):
    magic, dimensions, maximum, pixels = raw.split(b'\n',3)
    return (magic == b'P6' and dimensions == f'{width} {height}'.encode()
            and maximum == b'255' and pixels == expected(width,height,inverted))

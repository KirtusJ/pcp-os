# Native guest working set and reclamation

Director B3 ran four isolated Q35/OVMF USB boots of PCP OS commit 2a2c6db56d35c1a47ec6ce1e8ee394888bdaa7d0. The launcher ran a purpose-built diagnostic, memcheck.elf. Its entire source, the guest ABI and linker script, exact guest and kernel binaries, and the read-only USB fixture are included. No model weights, Tailorbird application code, effects, or persistence were involved.

The guest allocates 64 private anonymous mappings of 8 MiB. It writes one unique 64-bit marker per 4 KiB page, retaining all mappings, and rereads all 131,072 markers in reverse order before logging success. It then sleeps with all pages live. The normal case exits zero after five seconds. In the Stop case, the observer sends the kernel Ctrl+Alt+Delete chord after the completed marker and before the guest exits. Stop during loading, UI latency, inference performance and the largest feasible allocation are separate measurements.

Run python3 -B replay.py from the extracted directory. The replay checks the USB, kernel and guest SHA-256, original serial records, startup checks, frame counts, F4 register outcomes, all 24 original screenshots, unchanged sentinel counters and guest-originated shutdowns. Each result.json also holds the actual QEMU command and snapshots. All four boots used the same binaries. The isolated source copies in boot.py and the firmware fixture identify the launch path. The binary at bin/plain.elf is the diagnostic delivered on the media as memcheck.elf.

The standalone guest can be rebuilt with Rust 1.97.0 for x86_64-unknown-none. In this directory run the following command.

    rustc --edition=2021 --target=x86_64-unknown-none -C opt-level=2 -C panic=abort -C relocation-model=static -C code-model=large -C link-arg=-Tguest.ld -C link-arg=--build-id=none -C strip=symbols -o /tmp/memcheck.elf memcheck.rs

#![no_std]
#![no_main]
#[allow(dead_code)]
mod abi;

const PAGE_BYTES: usize = 4096;
const CHUNK_BYTES: usize = 8 * 1024 * 1024;
const PAGES_PER_CHUNK: usize = CHUNK_BYTES / PAGE_BYTES;
const CHUNKS: usize = 64;

core::arch::global_asm!(".global _start", ".section .text.start", "_start:", "and rsp, -16", "call run", "ud2");

fn marker(chunk: usize, page: usize) -> u64 {
    0xB300_0000_0000_0000 | (chunk * PAGES_PER_CHUNK + page) as u64
}

#[no_mangle]
pub extern "C" fn run() -> ! {
    let mut starts = [0usize; CHUNKS];
    for (chunk, start) in starts.iter_mut().enumerate() {
        let result = abi::call(9, 0, CHUNK_BYTES, 3, 0x22, usize::MAX, 0);
        if result < 0 {
            abi::log(b"B3 memory allocation failed\n");
            abi::exit(1);
        }
        *start = result as usize;
        for page in 0..PAGES_PER_CHUNK {
            let word = (*start + page * PAGE_BYTES) as *mut u64;
            unsafe { word.write_volatile(marker(chunk, page)); }
        }
    }
    for (chunk, start) in starts.iter().enumerate().rev() {
        for page in (0..PAGES_PER_CHUNK).rev() {
            let word = (*start + page * PAGE_BYTES) as *const u64;
            if unsafe { word.read_volatile() } != marker(chunk, page) {
                abi::log(b"B3 page readback failed\n");
                abi::exit(2);
            }
        }
    }
    abi::log(b"B3 verified 131072 distinct pages across 512 MiB; holding until timeout or kernel Stop\n");
    let delay = [5i64, 0i64];
    if abi::call(35, delay.as_ptr() as usize, 0, 0, 0, 0, 0) < 0 {
        abi::exit(3);
    }
    abi::exit(0)
}

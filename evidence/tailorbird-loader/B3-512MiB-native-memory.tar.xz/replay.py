"""Verify the four frozen firmware boots from the supplied evidence using Python 3."""
import hashlib
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parent
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

media = json.loads((root / "media-plain/image.json").read_text())
guest = digest(root / "bin/plain.elf")
assert guest == "40c9cbcde4e62e77186172c558a6d8f8334512670c9745ac91e4c527ce958685"
assert digest(root / "media-plain/usb.img") == media["usb_sha256"] == "0a0cee17b61db6fde54a4e7dedcf4103bc076547d6644cf73b5fd87b89a61ac7"
assert digest(root / "kernel.elf32") == media["elf_sha256"] == "bd984a3dc4eab27e599a0bc3d935be807b61855a73206bccca47ca029f0efa92"

for ram, free in ((1024, 231919), (2048, 248815)):
    for ending, label in (("done", "DONE"), ("stop", "STOPPED")):
        directory = root / f"plain-1920x1080-bochs-{ram}-{ending}"
        record = json.loads((directory / "result.json").read_text())
        serial = (directory / "serial.txt").read_text()
        register = (directory / "register.txt").read_text()
        args = record["qemu"]
        assert args[args.index("-m")+1] == str(ram) and "q35" in " ".join(args)
        assert any("id=stick," in arg and "readonly=on" in arg for arg in args)
        assert record["verified"] and record["image"] == media and record["guest_sha256"] == guest
        assert "display: Loader, 1920x1080, 1 page(s)" in serial
        assert f"starting memcheck.elf (8656 bytes, SHA-256 {guest})" in serial
        marker = "B3 verified 131072 distinct pages across 512 MiB"
        outcome = record["outcome"]
        assert marker in serial and serial.index(marker) < serial.index(outcome)
        assert outcome.startswith("memcheck.elf ended " + label)
        why = "exit 0" if ending == "done" else "stopped by the person with Ctrl+Alt+Delete"
        assert why in outcome and f"131594 frames given back, {free} free before and {free} after" in outcome
        assert record["free_before"] == record["free_after"] == free and record["frames_reclaimed"] == 131594
        assert "TASK_STARTED" in register and "label memcheck.elf; id T15" in register
        assert re.search(r"TASK_ENDED\s+id T15; outcome " + label, register) and "chain intact" in register
        assert sum(line.startswith("  pass ") for line in serial.splitlines()) == record["passed"] == 72
        assert not any(line.startswith("  FAIL") for line in serial.splitlines())
        assert [(e["data"]["guest"], e["data"]["reason"]) for e in record["events"] if e["event"] == "SHUTDOWN"] == [(True,"guest-shutdown")]
        assert all(i["nvme_bytes_preserved"] and not any(i["counter_deltas"]["sentinel"].values()) for i in record["intervals"])
        assert set(record["frames"]) == {"home","launcher","returned","register","back","power"}
        assert all(digest(directory / (tag + ".ppm")) == expected for tag,expected in record["frames"].items())
        print(f"{ram} MiB, {label}: 131072 data pages verified, 131594 frames returned, {free} free before and after, 72 checks and six captures")

"""Replay the Q35 UEFI guest-memory budget from the four original boots using the Python standard library."""
from pathlib import Path
import hashlib
import json
import re
import sys

root = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

media = json.loads((root/'media-plain/image.json').read_text())
assert sha(root/'media-plain/usb.img') == media['usb_sha256']
assert sha(root/'kernel.elf32') == media['elf_sha256']
guest = sha(root/'bin/plain.elf')
assert guest == 'a942d5b62a476d4508a76bdcd74716a6b8626252e2cf9fdefa9e74e6d213f17b'
cases=[]
controls=json.loads((root/'baseline-1024.json').read_text())
for ram in [1024,2048,4096]:
    d=root/f'plain-1920x1080-bochs-{ram}'
    r=json.loads((d/'result.json').read_text())
    assert r['image']==media and r['guest_sha256']==guest
    qemu=r['qemu']
    assert qemu[qemu.index('-m')+1]==str(ram) and 'q35' in ' '.join(qemu)
    assert any('id=stick,' in arg and 'readonly=on' in arg for arg in qemu)
    assert any('bochs-display' in arg for arg in qemu)
    serial=(d/'serial.txt').read_text()
    assert 'display: Loader, 1920x1080, 1 page(s)' in serial
    assert sum(s.startswith('  pass ') for s in serial.splitlines()) == r['passed']
    pool=re.search(r'^memory for programs: (\d+) frames of 4 KiB, (0x[0-9a-f]+)\.\.(0x[0-9a-f]+)',serial,re.M)
    receipt=re.search(r'^tailorbird\.elf ended DONE: exit 0[^\n]*? (\d+) free before and (\d+) after',serial,re.M)
    total=int(pool[1]);lo=int(pool[2],16);hi=int(pool[3],16)
    assert total*4096==hi-lo and 0<lo<hi<=2**30
    assert r['launch_outcome']=='rendered and exited 0' and r['verified'] and r['passed']==72
    assert not any(line.startswith('  FAIL') for line in serial.splitlines())
    assert f'SHA-256 {guest})' in serial and receipt
    free=int(receipt[1])
    assert 0<free<=total and free==int(receipt[2])
    assert (lo <= (1<<30)-4096 < hi) == (ram >= 2048)
    assert all(r['frames'][tag]==sha_expected for tag,sha_expected in controls['frames'].items())
    assert r['frames']['fit']==r['frames']['fit-back']!=r['frames']['compact']
    assert '  pass memory the kernel does not use is not mapped' in serial
    assert all(sha(d/(tag+'.ppm'))==digest for tag,digest in r['frames'].items())
    assert all(x['nvme_bytes_preserved'] for x in r['intervals'])
    assert [(e['data']['guest'],e['data']['reason']) for e in r['events'] if e['event']=='SHUTDOWN']==[(True,'guest-shutdown')]
    cases.append(dict(qemu_ram_mib=ram,pool_start=hex(lo),pool_end=hex(hi),pool_frames=total,free_before=free,free_after=free,free_mib=free/256,launch_outcome=r['launch_outcome'],verified_frame_captures=len(r['frames'])))
print(json.dumps(cases,indent=2))

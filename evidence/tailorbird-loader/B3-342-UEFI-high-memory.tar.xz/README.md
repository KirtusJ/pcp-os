# PR 342 UEFI acceptance

Kernel 2a2c6db56d35c1a47ec6ce1e8ee394888bdaa7d0, built from a fresh stage with Rust 1.97.0 and the repository's high-load-address UEFI validation patch. The ordinary Tailorbird ELF is the 94847b59b9209a7c4c22b0cb16329866bdb4d7d5 release build pinned to PCP OS 070c9d5. The frozen PR changes kernel startup verification. The read-only Q35/OVMF USB used one guest and one kernel for the three runs; only the assigned RAM changed.

Run `python3 -B replay.py` after extracting. It checks the original USB and kernel digests, frame-pool bounds, per-boot startup and exit records, nine captured frames per boot and the guest-requested power events. All three guest presentation frames are compared with the passing 1,024 MiB baseline from B3-Tailorbird-boot-memory.tar.xz. The 2,048 MiB baseline went SAFE before guest admission. These are emulator results using the disconnected guest; the laptop and a resident Qwen model were not exercised.

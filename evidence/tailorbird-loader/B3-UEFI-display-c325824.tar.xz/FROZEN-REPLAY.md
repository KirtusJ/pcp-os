# Frozen #338 UEFI display replay

This package reconstructs the byte-for-byte original ZIP from GitHub Actions for kernel `c3258242fea6371784f796e0fb8b6677d0dd217d`. It uses the previous test archive in the same evidence directory as its base. Download both tar.xz files and run the following in an empty directory with Python 3.10+, tar, xz and zstd 1.5+.

```sh
tar -xJf ../B3-UEFI-display-7f2e900.tar.xz
mv native.zip previous.zip
tar -xJf ../B3-UEFI-display-c325824.tar.xz
zstd -d --patch-from=previous.zip frozen-native.zip.zstpatch -o native.zip
python3 -B replay.py
```

The replay verifies the reconstructed ZIP against the SHA-256 from GitHub in the frozen run's origin.json before it opens the captures. The script and baseline are identical for the two runs. Allow 1 GiB of temporary space.

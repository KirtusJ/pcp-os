import json
import re
import subprocess
import sys
import time
from hashlib import sha256
from pathlib import Path
import runpy

base=Path(__file__).resolve().parent
api=runpy.run_path(str(base/"src/examples/optical-disk-check/check.py"))
mode,variant,qemu=sys.argv[1:]
out=base/("labels-"+mode+"-"+variant)
out.mkdir(exist_ok=True)
active=variant=="proposal"
limited=variant=="none"
kernel=base/("default.elf32" if variant=="default" else "uefi.elf32")
guests=[base/"bin/garden.elf",base/"bin/reader.elf"]
digest=lambda p: sha256(p.read_bytes()).hexdigest()
measure=subprocess.check_output([sys.executable,base/"src/PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py",kernel],text=True).strip()
args=f"image={measure} desktop={mode} propose_image={digest(guests[0])}"+(" grant=none" if limited else "")
cmd=[qemu,"-machine","pc","-accel","tcg","-cpu","max","-m","256M","-smp","1","-kernel",str(kernel),"-initrd",",".join(str(p)+" "+p.name for p in guests),"-append",args,"-vga","std","-display","none","-nic","none","-serial","file:"+str(out/"serial.txt"),"-no-reboot","-device","isa-debug-exit,iobase=0xf4,iosize=0x04","-qmp","stdio"]
approval="Creating a file needs your approval."
def words(s):return " ".join(s.split())
def block(rows,first,last):
    content=words(" ".join(rows))
    assert first in content,content
    return content.split(first,1)[1].split(last,1)[0]
def check(chunk,requires,store):
    assert (approval in chunk)==requires,chunk
    assert bool(re.search(r"\bstore\b",chunk))==store,chunk
    if limited:assert "console only" in chunk,chunk
captured={}
with (out/"qemu.stderr").open("wb") as err, subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        monitor=api["Monitor"](vm)
        monitor.call("qmp_capabilities")
        screens=api["DesktopScreens"](monitor,out,40)
        def key(*keys):
            monitor.key(*keys)
            time.sleep(.35)
        def snap(tag,ready):
            rows=screens.wait(tag,lambda r:ready(words(" ".join(r))))
            (out/(tag+".txt")).write_text("\n".join(rows)+"\n")
            captured[tag]=digest(out/(tag+".ppm"))
            return rows
        snap("home",lambda s:"Programs" in s)
        key("ret")
        compact=int(mode.split("x")[0])<960
        rows=snap("programs",lambda s:"garden.elf" in s and "reader.elf" in s and ("Access:" in s or "may use:" in s))
        if compact:
            check(block(rows,"Access:","Up/Down"),active,not active and not limited)
            key("down")
            rows=snap("reader-selected",lambda s:"?reader.elf" in s and "Access:" in s)
            check(block(rows,"Access:","Up/Down"),False,not limited)
        else:
            check(block(rows,"garden.elf","reader.elf"),active,not active and not limited)
            check(block(rows,"reader.elf","Esc"),False,not limited)
        key("ctrl","d")
        rows=snap("details",lambda s:"starting it lets it use" in s and "reader.elf" in s)
        check(block(rows,"garden.elf","reader.elf"),active,not active and not limited)
        check(block(rows,"reader.elf","FILES FROM THE LOADER"),False,not limited)
        key("esc")
        key("f10")
        snap("power",lambda s:"Switch PCP OS off?" in s)
        key("ret")
        assert vm.wait(timeout=20) == 33
        serial=(out/"serial.txt").read_text()
        assert "ALL SELF-TESTS PASS." in serial and mode in serial
        (out/"result.json").write_text(json.dumps(dict(mode=mode,variant=variant,verified=True,kernel=digest(kernel),guests={p.name:digest(p) for p in guests},captures=captured,command=cmd),indent=2)+"\n")
        print(mode,variant,"Programs and Details passed for both digests")
    finally:
        if vm.poll() is None:vm.kill();vm.wait()

set -eu
d=/tmp/b3-access-verification
rt=/workspace/scratch/6fbc6fd5187a/runtime
tc=$rt/register-live/rust197
export PATH="$tc/bin:$tc/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$PATH" LD_LIBRARY_PATH="$rt/lib"
export CARGO_NET_OFFLINE=true CARGO_HOME=/tmp/b3-341-build/registry-cache PCPOS_KERNEL_STAGE="$d/default-build"
unset PCPOS_KERNEL_FEATURES
cd /tmp/b3-proposal-access
sh PCP_OS_Rust/crates/pcpos-kernel/run.sh build > "$d/default.log" 2>&1 || { tail -15 "$d/default.log"; exit 1; }
cp PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32 "$d/default.elf32"
sha256sum "$d/default.elf32"

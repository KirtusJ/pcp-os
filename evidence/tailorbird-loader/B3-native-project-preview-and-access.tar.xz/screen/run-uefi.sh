set -eu
cd /tmp/b3-344-screen
val=/workspace/scratch/15ccefba7c7d/validation
export B3_RAM_MIB=512 B3_VIDEO=$1
python3 -B firmware.py 800x600 "$val/bin/qemu-system-x86_64" "$val/pkg/root/usr/share/OVMF" garden

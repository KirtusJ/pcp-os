"""Confirm the displayed characters from the frozen RGB frames, including the screen-width-dependent line count."""
from pathlib import Path
from PIL import Image
import ast
import hashlib
import json
import re

root = Path(__file__).resolve().parent
data = json.loads((root / "expected.json").read_text())
note = data["content"]
assert len(note.encode()) == 1364 and note.count("\n") == 35 and note.endswith("\n")
assert note.encode() == (root / "fixture/examples/proposals/guest/src/garden.txt").read_bytes()
font = (root / "font.rs").read_text().split("= [",1)[1].split("];",1)[0]
glyphs = ast.literal_eval("[" + font + "]")
ground = (16,40,63)
cells = {}
for color in ((242,247,252), (159,180,200), (227,162,75)):
    palette = [bytes((b*(255-a)+f*a+127)//255 for b,f in zip(ground,color)) for a in range(256)]
    for code,glyph in enumerate(glyphs,32):
        pix = b"".join(palette[a] for a in glyph)
        assert pix not in cells or cells[pix] == chr(code)
        cells[pix] = chr(code)

def decode(path):
    with Image.open(path) as frame:
        w,h=frame.size
        rows = []
        for y in range(0,h-19,20):
            line = "".join(cells[frame.crop((x,y,x+10,y+20)).tobytes()] for x in range(0,w-9,10))
            rows.append(line.rstrip())
        return w,h,rows

scenarios = [("garden-800x600-bochs",800,600,37),("garden-800x600-ramfb",800,600,37),
             ("direct-800x600",800,600,37),("direct-1024x768",1024,768,37),
             ("direct-1280x720",1280,720,36)]
first_800 = {}
for name,w,h,count in scenarios:
    directory = root/name
    across=w//10-4
    wrapped = []
    for line in note.split("\n"):
        wrapped.extend([line[i:i+across] for i in range(0,len(line),across)] or [""])
    assert len(wrapped) == count
    images = {}
    for tag in ("preview-1","preview-2","preview-back"):
        path=directory/(tag+".ppm")
        width,height,rows=decode(path)
        assert (width,height)==(w,h)
        saved=(directory/(tag+".txt")).read_text().splitlines()
        assert rows==saved
        assert rows[0].strip()=="PCP OS ASKS YOU"
        assert rows[2].strip()=="Name: "+data["name"]
        assert f"Size: 1364 characters, {count} lines." in rows[3]
        assert "It will last until the computer is switched off." in " ".join(" ".join(rows[:6]).split())
        first_body=next(i for i in range(3,len(rows)) if rows[i]=="")+1
        foot=next(i for i,s in enumerate(rows) if 'Page ' in s)
        assert ('Page 2 of 2.' if tag=='preview-2' else 'Page 1 of 2.') in rows[foot]
        images[tag]=[r[2:] for r in rows[first_body:foot]]
        if w==800:
            digest=hashlib.sha256(path.read_bytes()).hexdigest()
            assert first_800.setdefault(tag,digest)==digest
    first_page=images["preview-1"]
    assert first_page==images["preview-back"]
    while not first_page[-1]:first_page.pop()
    assert first_page==wrapped[:len(first_page)]
    rest=wrapped[len(first_page):]
    assert images["preview-2"][:len(rest)]==rest
    assert not any(images["preview-2"][len(rest):])
    serial=(directory/"serial.txt").read_text()
    assert hashlib.sha256(note.encode()).hexdigest() in serial and "DENIED by the person; nothing made" in serial
    assert "probe: outcome 2" in serial and "the store holds 0 file(s), 0 bytes" in serial
    assert "ALL SELF-TESTS PASS." in serial
    result=json.loads((directory/"result.json").read_text())
    if name.startswith("garden"):
        assert result["verified"] and result["passed"]==72 and result["proposal_outcome"]==2
    else:
        assert result["status"]==33 and "2 page(s)" in result["display"]
    print(name, "all 3 RGB frames decoded exactly;",count,"displayed lines; cancellation and shutdown confirmed")

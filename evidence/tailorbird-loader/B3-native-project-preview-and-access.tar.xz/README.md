# Director B3 native display checks

These are QEMU observations from disposable machines. The document fixture is a 1,364-byte community garden note with 35 LF-terminated lines. The two programs are diagnostics. The approved file lasts for the session.

| Directory | Source commit | Observation |
| --- | --- | --- |
| screen | 27000db66dd7b8be442508ea519bcebca3c71259 | Five machines. The same note reports 37 rendered lines at 800×600 and 1024×768 and 36 at 1280×720. The three 800×600 display paths have identical preview pixels. |
| current | c9743749bb4c7500657c4cf56ca462e86445f433 | Four machines. The width-dependent count is gone. F12 when idle, return on Space, the two-page note, its explicit end, keyboard cancellation and clean shutdown are visible. |
| project | e612f208d2e39ef66805f60311b35d821f2bcca5 | Four machines. The preview names garden-club/spring-survey/garden-notes.txt. Three cancellations leave the session store empty. The approved UEFI run shows the file in Files, then starts a different read-only diagnostic which compares all 1,364 bytes and checks EOF. |
| labels | 569614e1b3ce3e54465a4cd8731e999d51d06d6e | Five boots of the Programs and Details correction. Two program digests, a proposal-enabled kernel, a default kernel, console-only grants, compact and wide layouts, and one UEFI machine with sound. |

Run the following commands from the extracted directory with Python 3 and Pillow.

    python screen/replay.py
    python replay-preview.py current
    python replay-preview.py project
    sha256sum -c SHA256SUMS

The preview replays reconstruct the source font and decode each pixel cell. They check the two pages against the source document, compare each preview and no-pending frame with its saved text, and check guest exit and store outcomes. UEFI result.json files include device observations and frame hashes. The labels directory contains native observations and the runners used for them. The individual command lines and builders record the original workspace paths. No physical machine or shipping Tailorbird integration was exercised.

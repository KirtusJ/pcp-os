"""Boot the bounded diagnostic guest from a guarded Q35/OVMF removable fixture."""
from pathlib import Path
import hashlib, json, re, struct, subprocess, sys, time, uuid
import titles
base=Path(__file__).resolve().parent
sys.path.insert(0,str(base/"src/examples/firmware-owned-uefi"))
import usb_trial as usb
from usb_observer import capture, compare

mode,qemu,fwpath,version=sys.argv[1:];width,height=map(int,mode.split("x"))
import os
backend=os.getenv("B3_VIDEO","bochs")
out=base/(version+"-"+mode+"-"+backend+os.environ.get("B3_RUN_TAG",""));out.mkdir()
fw=Path(fwpath)
template=bytearray((fw/"OVMF_VARS_4M.fd").read_bytes())
head=struct.unpack_from("<H",template,0x30)[0]
assert uuid.UUID(bytes_le=bytes(template[head:head+16]))==uuid.UUID("aaf32c78-947b-439a-a180-2e144ec37792")
name=("PlatformConfig"+chr(0)).encode("utf-16-le")
data=struct.pack("<II",width,height)
vendor=uuid.UUID("7235c51c-0c80-4cab-87ac-3b084a6304b1").bytes_le
record=struct.pack("<HBBIQ16sIII16s",0x55aa,0x3f,0,7,0,bytes(16),0,len(name),len(data),vendor)+name+data
offset=(head+31)&~3
assert offset==100 and all(c==255 for c in template[offset:offset+len(record)])
template[offset:offset+len(record)]=record
var=out/"template.fd";var.write_bytes(template)
medium=base/"media-final";image=medium/"usb.img";manifest=json.loads((medium/"image.json").read_text())
video="ramfb" if backend=="ramfb" else "virtio-vga"
cmd=usb.usb_command(qemu,fw/"OVMF_CODE_4M.fd",var,image,out,int(os.environ["B3_RAM_MIB"]),video)
if video=="virtio-vga":
    cmd[cmd.index("virtio-vga")]=f"bochs-display,vgamem=64M,edid=on,xres={width},yres={height}"
receipt={"requested":mode,"qemu":cmd,"image":manifest,"guest_sha256":usb.digest(base/"bin"/(version+".elf")),"snapshots":[],"frames":{}}
def save():
    (out/"result.json").write_text(json.dumps(receipt,indent=2)+"\n")
def serial():return (out/"serial.txt").read_text(errors="replace")
def see(marker): usb.OPTICAL["wait_for"](lambda:marker in serial(),marker,80)
with (out/"qemu.stderr").open("wb") as err,subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        m=usb.OPTICAL["Monitor"](vm);rpc=m.call;rpc("qmp_capabilities")
        receipt["snapshots"].append(capture(rpc,out,"before")); rpc("cont")
        scr=usb.OPTICAL["DesktopScreens"](m,out,40)
        def snap(stage):
            rpc("stop");receipt["snapshots"].append(capture(rpc,out,stage));rpc("cont")
        def desktop(tag,condition):
            rows=scr.wait(tag,lambda rows:condition(" ".join(" ".join(rows).split())))
            (out/(tag+".txt")).write_text("\n".join(rows)+"\n")
            receipt["frames"][tag]=usb.digest(out/(tag+".ppm"));save()
        def key(k): m.key(k);time.sleep(.27)
        desktop("home",lambda t:"Programs" in t)
        display=re.search(r"^display: Loader, (\d+)x(\d+), (\d+) page\(s\), (\d+) KiB of its memory mapped at (0x[0-9a-f]+)",serial(),re.M)
        assert display and tuple(map(int,display.groups()[:3]))==(width,height,1),(display.groups() if display else None)
        trace=(out/"firmware.txt").read_text()
        address=int(re.search(r"^console_framebuffer=([0-9a-f]+)",trace,re.M)[1],16)
        pitch=int(re.search(r"^console_pitch=([0-9a-f]+)",trace,re.M)[1],16)
        assert int(display[5],16)==address and pitch>=4*width
        assert usb.digest(medium/"garden.elf")==receipt["guest_sha256"]
        receipt.update(loader_display=display.group(0),pitch=pitch,framebuffer=hex(address))
        snap("home")
        key("ret");desktop("launcher",lambda t:"garden.elf" in t and ("SHA-256" in t or "Access:" in t))
        key("ret")
        see("B3 garden idle")
        key("f12");desktop("no-pending",lambda t:"No file is waiting for your approval." in t)
        key("spc");see("B3 garden preview ready")
        def page(tag, num):
            desktop(tag,lambda t: "PCP OS ASKS YOU" in t and f"Page {num} of 2" in t)
        page("preview-1",1)
        key("down");page("preview-2",2)
        key("up");page("preview-back",1)
        key("esc");see("garden.elf ended DONE: exit 0")
        outcome = next(line for line in serial().splitlines() if line.startswith("garden.elf ended "))
        assert "probe: outcome 2" in serial() and "nothing made" in serial()
        assert "the store holds 0 file(s), 0 bytes" in outcome
        desktop("returned",lambda t:"garden.elf" in t and ("SHA-256" in t or "Access:" in t))
        receipt.update(outcome=outcome,proposal_outcome=2)
        snap("returned")
        key("f10");desktop("power",lambda t:"Switch PCP OS off?" in t)
        key("ret");usb.OPTICAL["wait_for"](lambda:rpc("query-status")["status"]=="shutdown","guest shutdown",25)
        receipt["snapshots"].append(capture(rpc,out,"shutdown")); receipt["events"]=list(m.events)
        rpc("quit"); assert vm.wait(timeout=10)==0
        log=serial().splitlines();receipt["passed"]=sum(s.startswith("  pass ") for s in log)
        assert receipt["passed"]==72 and not any(s.startswith("  FAIL") for s in log)
        assert [(e["data"]["guest"],e["data"]["reason"]) for e in receipt["events"] if e["event"]=="SHUTDOWN"]==[(True,"guest-shutdown")]
        intervals=[compare(out,a,b) for a,b in zip(receipt["snapshots"],receipt["snapshots"][1:])]
        assert all(i["nvme_bytes_preserved"] and not any(i["counter_deltas"]["sentinel"].values()) for i in intervals)
        assert all(i["vars_bytes_changed"]==0 for i in intervals[1:]) and usb.digest(image)==manifest["usb_sha256"]
        receipt["intervals"]=intervals;receipt["verified"]=True
    finally:
        save()
        if vm.poll() is None:vm.kill();vm.wait()

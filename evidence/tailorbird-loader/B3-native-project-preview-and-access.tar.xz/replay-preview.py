"""Confirm the displayed characters from the frozen RGB frames, including the screen-width-dependent line count."""
from pathlib import Path
from PIL import Image
import ast
import hashlib
import json
import re

import sys
root = Path(__file__).resolve().parent / sys.argv[1]
data = json.loads((root / "expected.json").read_text())
note = data["content"]
assert len(note.encode()) == 1364 and note.count("\n") == 35 and note.endswith("\n")
assert note.encode() == (root / "fixture/examples/proposals/guest/src/garden.txt").read_bytes()
font = (root / "font.rs").read_text().split("= [",1)[1].split("];",1)[0]
glyphs = ast.literal_eval("[" + font + "]")
ground = (16,40,63)
cells = {}
for color in ((242,247,252), (159,180,200), (227,162,75), (143,224,194)):
    palette = [bytes((b*(255-a)+f*a+127)//255 for b,f in zip(ground,color)) for a in range(256)]
    for code,glyph in enumerate(glyphs,32):
        pix = b"".join(palette[a] for a in glyph)
        assert pix not in cells or cells[pix] == chr(code)
        cells[pix] = chr(code)

def decode(path):
    with Image.open(path) as frame:
        w,h=frame.size
        rows = []
        for y in range(0,h-19,20):
            line = "".join(cells[frame.crop((x,y,x+10,y+20)).tobytes()] for x in range(0,w-9,10))
            rows.append(line.rstrip())
        return w,h,rows

for directory in sorted(d for d in root.iterdir() if (d/"result.json").exists()):
    frames={}
    for path in sorted(directory.glob("*.ppm")):
        tag=path.stem
        if not tag.startswith(("preview","choice","no-pending")):continue
        w,h,rows=decode(path)
        assert rows==(directory/(tag+".txt")).read_text().splitlines()
        if tag=="no-pending":
            assert "No file is waiting for your approval." in " ".join(" ".join(rows).split())
            continue
        assert rows[0].strip()=="PCP OS ASKS YOU"
        if root.name=="project":
            assert rows[2].strip()=="Folder: garden-club/spring-survey File: garden-notes.txt"
        else:
            assert rows[2].strip()=="Name: "+data["name"]
        assert "Size: 1364 characters. It will last until the computer is switched off." in " ".join(" ".join(rows[:6]).split())
        body=next(i for i in range(3,len(rows)) if not rows[i])+1
        foot=next(i for i,line in enumerate(rows) if "Page " in line or "Now press Enter" in line)
        if tag!="choice":
            assert ("Page 1 of 2" if tag in ("preview-1","preview-back") else "Page 2 of 2") in rows[foot]
        frames[tag]=[r[2:] for r in rows[body:foot]]
    assert frames["preview-back"]==frames["preview-1"]
    first=frames["preview-1"][:]
    while not first[-1]:first.pop()
    across=w//10-4
    expected=[part for line in note.splitlines() for part in ([line[i:i+across] for i in range(0,len(line),across)] or [""])]
    expected.append("(end of the file)")
    assert first==expected[:len(first)]
    last=frames["preview-2"]
    assert last[:len(expected)-len(first)]==expected[len(first):] and not any(last[len(expected)-len(first):])
    for tag in ("preview-final","choice"):
        if tag in frames:assert frames[tag]==last
    r=json.loads((directory/"result.json").read_text())
    serial=(directory/"serial.txt").read_text()
    assert hashlib.sha256(note.encode()).hexdigest() in serial and "ALL SELF-TESTS PASS." in serial
    if directory.name.startswith("direct"):
        assert r["status"]==33 and "2 page(s)" in r["display"]
    else:assert r["verified"] and r["passed"]==72
    if "confirmed" in directory.name:
        assert "probe: outcome 1" in serial and "the store holds 1 file(s), 1364 bytes" in serial
        assert "all 1364 bytes and EOF match" in serial
        assert "garden-club/spring-survey/garden-notes.txt" in (directory/"files.txt").read_text()
    else:
        assert "probe: outcome 2" in serial and "the store holds 0 file(s), 0 bytes" in serial
    print(root.name,directory.name,"verified")

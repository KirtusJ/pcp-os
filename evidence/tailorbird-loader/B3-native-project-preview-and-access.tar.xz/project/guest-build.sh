set -eu
cd /tmp/b3-344-project
sh fixture-build.sh
rt=/workspace/scratch/6fbc6fd5187a/runtime
toolchain=$rt/register-live/rust197
export PATH="$toolchain/bin:$toolchain/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$PATH" LD_LIBRARY_PATH="$rt/lib"
rustc --edition=2021 --target=x86_64-unknown-none -C opt-level=2 -C panic=abort -C relocation-model=static -C code-model=large -C link-arg=-Tguest.ld -C link-arg=--build-id=none -C strip=symbols -o bin/reader.elf reader.rs

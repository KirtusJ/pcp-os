set -eu
d=/tmp/b3-344-project
rt=/workspace/scratch/6fbc6fd5187a/runtime
toolchain=$rt/register-live/rust197
export PATH="$toolchain/bin:$toolchain/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$PATH" LD_LIBRARY_PATH="$rt/lib"
export CARGO_NET_OFFLINE=true CARGO_HOME=/tmp/b3-341-build/registry-cache PCPOS_KERNEL_STAGE="$d/uefi-build" PCPOS_KERNEL_FEATURES=proposals
cd "$d"
sh uefi-src/PCP_OS_Rust/crates/pcpos-kernel/run.sh build > uefi-kernel.log 2>&1 || { tail -15 uefi-kernel.log; exit 1; }
cp uefi-src/PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32 uefi.elf32
export B3_READER_ELF="$d/bin/reader.elf"
export B3_TAILORBIRD_ELF="$d/bin/garden.elf"
python3 -B make_media.py src uefi.elf32 "$rt/dist-landed/PCP-OS.iso" /workspace/scratch/15ccefba7c7d/validation/pkg/root/usr media-built > media-built.log 2>&1 || { tail -20 media-built.log; exit 1; }
mv media-built media-final
sha256sum uefi.elf32 bin/garden.elf media-final/usb.img

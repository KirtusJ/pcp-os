set -eu
d=/tmp/b3-344-project
repo=/tmp/b3-proposal-e612f2
rt=/workspace/scratch/6fbc6fd5187a/runtime
toolchain=$rt/register-live/rust197
export PATH="$toolchain/bin:$toolchain/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$PATH" LD_LIBRARY_PATH="$rt/lib"
export CARGO_NET_OFFLINE=true CARGO_HOME=/tmp/b3-341-build/registry-cache PCPOS_KERNEL_STAGE="$d/kernel-build" PCPOS_KERNEL_FEATURES=proposals
cd "$repo/examples/proposals/guest"
CARGO_TARGET_DIR="$d/probe-build" cargo build --locked --release --target x86_64-unknown-none > "$d/probe.log" 2>&1 || { tail -15 "$d/probe.log"; exit 1; }
cat Cargo.toml | head -6
cp "$d/probe-build/x86_64-unknown-none/release/proposal-probe" "$d/bin/upstream.elf"
cd "$repo"
sh PCP_OS_Rust/crates/pcpos-kernel/run.sh build > "$d/kernel.log" 2>&1 || { tail -15 "$d/kernel.log"; exit 1; }
cp PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32 "$d/kernel.elf32"
sha256sum "$d/kernel.elf32" "$d/bin/upstream.elf"

"""Read the regular multi-page preview on the native two-page Bochs display and cancel it."""
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
repo=Path('/tmp/b3-proposal-e612f2')
api=runpy.run_path(str(repo/'examples/optical-disk-check/check.py'))
mode=sys.argv[1]
out=base/('direct-'+mode)
out.mkdir()
guest=base/'bin/garden.elf'
kernel=base/'kernel.elf32'
digest=hashlib.sha256(guest.read_bytes()).hexdigest()
measure=subprocess.check_output([sys.executable,repo/'PCP_OS_Rust/crates/pcpos-kernel/tools/measure.py',kernel],text=True).strip()
cmd=[sys.argv[2],'-machine','pc','-accel','tcg','-cpu','max','-m','256M','-smp','1','-kernel',str(kernel),'-initrd',str(guest)+' garden.elf','-append',f'image={measure} desktop={mode} auto=garden.elf then=off propose_image={digest}','-vga','std','-display','none','-nic','none','-serial','file:'+str(out/'serial.txt'),'-no-reboot','-device','isa-debug-exit,iobase=0xf4,iosize=0x04','-qmp','stdio']
def serial(): return (out/'serial.txt').read_text(errors='replace')
with (out/'stderr').open('wb') as err, subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        m=api['Monitor'](vm);m.call('qmp_capabilities')
        api['wait_for'](lambda:'B3 garden idle' in serial(),'garden idle',50)
        scr=api['DesktopScreens'](m,out,25)
        m.key('f12')
        rows=scr.wait('no-pending',lambda rows:'No file is waiting for your approval.' in ' '.join(' '.join(rows).split()))
        (out/'no-pending.txt').write_text('\n'.join(rows)+'\n')
        m.key('spc')
        api['wait_for'](lambda:'B3 garden preview ready' in serial(),'guest launch',50)
        scr=api['DesktopScreens'](m,out,25)
        def capture(tag,number):
            def match(rows):
                text=' '.join(' '.join(rows).split())
                return 'PCP OS ASKS YOU' in text and f'Page {number} of ' in text
            rows=scr.wait(tag,match)
            (out/(tag+'.txt')).write_text('\n'.join(rows)+'\n')
            return int(re.search(r'Page \d+ of (\d+)',' '.join(rows))[1])
        pages=capture('preview-1',1)
        for i in range(2,pages+1):
            m.key('down');time.sleep(.25);capture('preview-'+str(i),i)
        if pages>1:
            m.key('up');time.sleep(.25);capture('preview-back',pages-1)
        m.key('esc')
        status=vm.wait(timeout=20)
        assert status==33 and 'probe: outcome 2' in serial() and 'the store holds 0 file(s), 0 bytes' in serial()
        dimensions=re.search(r'^display: (.+)$',serial(),re.M)[1].strip()
        assert mode in dimensions and '2 page(s)' in dimensions
        result=dict(mode=mode,display=dimensions,pages=pages,guest_sha256=digest,status=status,command=cmd)
        (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
        print(dimensions,pages,'preview pages, cancelled, exited',status)
    finally:
        if vm.poll() is None:vm.kill();vm.wait()

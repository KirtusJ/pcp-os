#![no_std]
#![no_main]
#[allow(dead_code)]
mod abi;
core::arch::global_asm!(".global _start", ".section .text.start", "_start:", "and rsp, -16", "call run", "ud2");
const CONTENT: &[u8] = include_bytes!("fixture/examples/proposals/guest/src/garden.txt");
#[no_mangle]
pub extern "C" fn run() -> ! {
    let fd = abi::open(b"garden-club/spring-survey/garden-notes.txt\0", 0);
    if fd < 0 { abi::log(b"B3 read-only viewer could not open garden notes\n"); abi::exit(1); }
    let mut buffer = [0u8; 256];
    let mut offset = 0;
    loop {
        let count = abi::call(0, fd as usize, buffer.as_mut_ptr() as usize, buffer.len(), 0, 0, 0);
        if count < 0 { abi::exit(2); }
        if count == 0 { break; }
        let n = count as usize;
        if CONTENT.get(offset..offset + n) != Some(&buffer[..n]) { abi::exit(3); }
        offset += n;
    }
    if offset != CONTENT.len() { abi::exit(4); }
    abi::log(b"B3 read-only viewer reopened garden-club/spring-survey/garden-notes.txt; all 1364 bytes and EOF match\n");
    abi::exit(0)
}

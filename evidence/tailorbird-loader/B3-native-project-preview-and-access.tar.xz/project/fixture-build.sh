set -eu
d=/tmp/b3-344-project
rt=/workspace/scratch/6fbc6fd5187a/runtime
toolchain=$rt/register-live/rust197
export PATH="$toolchain/bin:$toolchain/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$PATH" LD_LIBRARY_PATH="$rt/lib"
export CARGO_NET_OFFLINE=true CARGO_HOME=/tmp/b3-341-build/registry-cache CARGO_TARGET_DIR="$d/garden-build"
cd "$d/fixture/examples/proposals/guest"
cargo build --locked --release --target x86_64-unknown-none
cp "$CARGO_TARGET_DIR/x86_64-unknown-none/release/proposal-probe" "$d/bin/garden.elf"

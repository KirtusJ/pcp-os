set -eu
d=/tmp/b3-model-boot
rt=/workspace/scratch/6fbc6fd5187a/runtime
val=/workspace/scratch/15ccefba7c7d/validation
export CARGO_HOME=/tmp/b3-341-build/registry-cache CARGO_NET_OFFLINE=true LD_LIBRARY_PATH="$rt/lib"
export PATH="$rt/register-live/rust197/bin:$rt/register-live/rust197/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$PATH"
export PCPOS_KERNEL_STAGE="$d/fresh-kernel-build"
sh "$d/kernel-src/PCP_OS_Rust/crates/pcpos-kernel/run.sh" build > "$d/kernel.log" 2>&1 || { tail -20 "$d/kernel.log"; exit 1; }
export B3_TAILORBIRD_ELF="$d/bin/plain.elf"
python3 -B "$d/make_media.py" "$d/src" "$d/kernel-src/PCP_OS_Rust/crates/pcpos-kernel/target/pcpos-kernel.elf32" "$rt/dist-landed/PCP-OS.iso" "$val/pkg/root/usr" "$d/media-plain" > "$d/media.log" 2>&1 || { tail -20 "$d/media.log"; exit 1; }
for ram in 256 512 1024 2048; do
  B3_VIDEO=bochs B3_RUN_TAG="-$ram" B3_RAM_MIB="$ram" python3 -B "$d/boot_current.py" 1920x1080 "$val/bin/qemu-system-x86_64" "$val/pkg/root/usr/share/OVMF" plain > "$d/run-$ram.log" 2>&1 || { tail -22 "$d/run-$ram.log"; exit 1; }
  printf '%s MiB boot completed\n' "$ram"
done

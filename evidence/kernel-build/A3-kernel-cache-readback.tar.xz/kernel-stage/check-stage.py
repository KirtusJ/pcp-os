import hashlib,os,subprocess
from pathlib import Path
w=Path(__file__).resolve().parent
rt=w.parent
tool=rt/'register-live/rust197'
env=dict(os.environ,PATH=':'.join([str(tool/'bin'),str(tool/'lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld'),str(rt/'root/usr/bin'),os.environ['PATH']]),LD_LIBRARY_PATH=str(rt/'lib'),CARGO_HOME=str(rt/'a3-331-run/cargo'),CARGO_NET_OFFLINE='true',CARGO_BUILD_JOBS='1',PCPOS_KERNEL_STAGE=str(rt/'a3-tailor-media/iso-stage/kernel'))
base='927c841c825390b8d7b7d6a6296ab8a501b12f15ac7a0bc5acc4749f0d54f452'
guard='fc484829704cdbdcc6a138730929861909bdcb3536b0ab18df3d1203e8af280f'
for source,fixed,expected in [('candidate',False,guard),('candidate',True,base),('serial340',True,guard)]:
    k=w/source/'PCP_OS_Rust/crates/pcpos-kernel'
    script=k/'run.sh'
    command=['sh',str(script),'build']
    if fixed:
        original=script.read_text()
        fragment='| tar -xf - -C "$STAGE"'
        assert original.count(fragment)==1
        test_script=original.replace(fragment,'| tar -xmf - -C "$STAGE"')
        command=['sh','-c',test_script,str(script),'build']
    with (w/('probe-'+source+('-fresh' if fixed else '-stock')+'.log')).open('w') as f:
        subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
    digest=hashlib.sha256((k/'target/pcpos-kernel.elf32').read_bytes()).hexdigest()
    print(source,'fresh times' if fixed else 'stock',digest,flush=True)
    assert digest==expected

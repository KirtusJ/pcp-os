# B3 framebuffer USB read-back at 9da8173

B3 read the corrected page grant and aligned-pitch checks at commit 9da817367f8a7493d333f88dc1bc12444f4ebb45 on PR 318. The full Rust and firmware source directories matched their Git tree IDs before the repository’s full-heap load-base.patch was applied. The kernel and two independently created USB images were built locally. The official distribution ISO supplied the three pinned media payloads.

Eight instrumented boots exercised Bochs at 128 and 256 MiB, virtio VGA at 128 MiB four times, and RAMFB at 128 and 256 MiB. The original Multiboot maps and PCI records, native Home, Verification and power confirmation pictures, disk and firmware snapshot bytes, and QMP shutdown records are included. The source grant review and its nine tracked host unit tests are separate from the ordinary desktop guest observations.

B3’s proposed tracked trial also built a new USB from the same ELF and ran all five profiles through its usual command-line entry point. Its local Git receipt identifies the host test fixture. The review-source file separately identifies the exact kernel revision. The first attempt at this local command stopped at C compiler startup before producing an image or starting a guest. Correcting the local toolchain path resolved it. No repository build change was needed for that retry.

Run sha256sum -c SHA256SUMS and python3 -B verify.py after extraction. Repeated original files are tar hard links. The comparison baseline and evidence for the withdrawn candidate are in B3-USB-mapper-81b2674.tar.xz at 1b7c1ad4be1f35be89763086ed8214960da24c5b. The tests cover QEMU/OVMF guests.

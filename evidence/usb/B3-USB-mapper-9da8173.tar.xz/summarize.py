"""Summarize a set of completed ordinary USB guest observations."""
from pathlib import Path
import argparse
import hashlib
import json
import struct
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('root',type=Path)
a=p.parse_args()
cases=[]
for f in sorted(a.root.glob('*/*/result.json')):
    r=json.loads(f.read_text())
    if 'memory_map' not in r:
        continue
    d=f.parent
    h=(d/'boot-info.bin').read_bytes()
    base,pitch,width,height,bpp,kind=struct.unpack_from('<QIIIBB',h,88)
    raw=(d/'multiboot-map.bin').read_bytes()
    extent=pitch*height
    lo=base//4096*4096; hi=(base+extent+4095)//4096*4096
    overlapping=[(hex(begin),hex(begin+size),typ) for stride,begin,size,typ in struct.iter_unpack('<IQQI',raw) if begin<hi and begin+size>lo]
    assert kind==1 and bpp==32 and r['runtime_header']['flags']==0x104c and 'USB' in r['firmware_usb']
    assert r['all_pass'] and r['exit']==0 and r['shutdown']['guest']
    assert r['startup_pass_lines']==71 and r['pass_lines']==72
    assert r['settled_home_comparison']['equal'] and r['disk_before']==r['disk_after']
    assert r['usb_sha256']==r['usb_after'] and 'ALL SELF-TESTS PASS.' in (d/'serial.txt').read_text()
    case={'case':str(d.relative_to(a.root)),'display':r['display'],'fb_address':hex(base),
          'size':[width,height],'pages':(hi-lo)//4096,'pad':hi-(base+extent),
          'ranges':overlapping,'initial_vs_return':r['immediate_home_comparison'],
          'settled_delta':r['settled_home_comparison']['pixels'],
          'nvme_writes':sum(x['counter_deltas']['sentinel']['wr_operations'] for x in r['intervals']),
          'nvme_discards':sum(x['counter_deltas']['sentinel']['unmap_operations'] for x in r['intervals']),
          'vars_boot':r['intervals'][0]['vars_bytes_changed'],'vars_after_home':r['intervals'][1]['vars_bytes_changed']}
    assert case['nvme_writes']==case['nvme_discards']==case['vars_after_home']==0
    cases.append(case)
print(json.dumps(cases,indent=2))

"""Recompute the corrected candidate's guest evidence and proposed tracked USB matrix."""
from pathlib import Path
import json
import hashlib
import struct
import subprocess
import sys
root=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
candidate=root/'candidate'
summary=json.loads(subprocess.check_output([sys.executable,'-B',root/'summarize.py',candidate],text=True))
assert len(summary)==8 and summary==read(root/'summary.json')
image=read(candidate/'image.json')
assert sha(candidate/'usb.img')==image['usb_sha256'] and sha(candidate/'kernel.elf32')==image['elf_sha256']
for case in summary:
    d=candidate/case['case']
    r=read(d/'result.json')
    for snap in r['snapshots']:
        assert sha(d/snap['vars_snapshot'])==snap['vars_sha256']
    assert sha(d/'internal.raw')==r['disk_before']==r['disk_after']
    for sample in ('home_samples','return_samples'):
        for filename,report in r[sample].items():
            assert sha(d/filename)==report['sha256']
    assert r['measurement']==image['measurement'] and image['measurement']+' (measured; equal' in (d/'serial.txt').read_text()
    assert r['usb_after']==image['usb_sha256']
    assert r['startup_pass_lines']==71 and r['pass_lines']==72 and r['exit']==0
    assert all(s['vars_bytes_changed']==0 for s in r['intervals'] if s['from']=='home')
    if r['video']=='ramfb':
        assert case['size']==[800,600] and case['pages']==469 and case['pad']==1024
        assert len(case['ranges'])==1 and case['ranges'][0][2]==2
        assert '1876 KiB' in case['display']
    if r['video']=='std':assert 'Bochs, 1920x1080, 2 page(s), 16384 KiB' in case['display']
    if r['video']=='virtio-vga':assert case['pages']==1000 and not case['ranges'] and '4000 KiB' in case['display']
    assert r['settled_home_comparison']['equal']
    assert sha(d/'kernel-display.ppm')!=sha(d/'verification.ppm')
p=candidate/'profiles'
profile_image=read(p/'image.json')
assert sha(p/'usb.img')==profile_image['usb_sha256']
assert image['elf_sha256']==profile_image['elf_sha256'] and image['measurement']==profile_image['measurement']
profile_results={f.parent.name:read(f) for f in p.glob('*/result.json')}
assert set(profile_results)=={'128','256','virtio-vga','ramfb-128','ramfb-256'}
for name,r in profile_results.items():
    assert r['passed'] and r['self_tests']==72 and r['exit']==0 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    assert r['usb_sha256_after']==profile_image['usb_sha256']
    assert sha(p/name/'home.ppm')==sha(p/name/'home-after-verification.ppm')
    assert sha(p/name/'internal.raw')==r['nvme_sha256_after_quit']
    assert sha(p/name/'vars.fd')==r['vars_sha256_after_quit']
assert profile_results['ramfb-128']['framebuffer_address']!=profile_results['ramfb-256']['framebuffer_address']
assert '9 passed; 0 failed' in (root/'host-unit.log').read_text()
print('Verified 8 instrumented boots, 5 proposed tracked boots, binary provenance and host result.')

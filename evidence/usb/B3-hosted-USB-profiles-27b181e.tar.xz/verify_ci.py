"""Read each retained hosted USB receipt directly from its downloaded workflow artifact."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('archive',type=Path)
p.add_argument('archive_sha')
p.add_argument('head')
p.add_argument('tree')
a=p.parse_args()
def sha(data):return hashlib.sha256(data).hexdigest()
assert sha(a.archive.read_bytes())==a.archive_sha
with zipfile.ZipFile(a.archive) as z:
    names=z.namelist()
    images=[n for n in names if n.endswith('image.json') and n[:-10]+'usb.img' in names]
    assert len(images)==1,images
    base=images[0][:-10]
    def read(path):return z.read(base+path)
    image=json.loads(read('image.json'))
    assert image['experiment_commit']==a.head and image['experiment_tree']==a.tree and not image['experiment_dirty']
    assert sha(read('usb.img'))==image['usb_sha256']
    output={}
    for case in ('128','256','virtio-vga','ramfb-128','ramfb-256'):
        def data(name):return read(case+'/'+name)
        r=json.loads(data('result.json'))
        assert r['passed'] and r['exit']==0 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
        assert r['self_tests']==72 and r['usb_sha256_after']==image['usb_sha256']
        text=data('serial.txt').decode(errors='replace')
        assert sum(l.startswith('  pass ') for l in text.splitlines())==72
        assert 'ALL SELF-TESTS PASS.' in text and image['measurement']+' (measured; equal' in text
        assert data('home.ppm')==data('home-after-verification.ppm')
        assert data('home.ppm')!=data('home-verification.ppm')
        assert r['intervals'][-1]['vars_bytes_changed']==0
        for snap in r['snapshots']:
            assert sha(data(snap['vars_snapshot']))==snap['vars_sha256']
            assert snap['nvme_sha256']==r['nvme_sha256_after_quit']
        for interval in r['intervals']:
            assert interval['nvme_bytes_preserved']
            assert all(count==0 for name,count in interval['counter_deltas']['sentinel'].items() if 'wr_' in name or 'unmap' in name)
        display=next(line for line in text.splitlines() if line.startswith('display: '))
        addr=r.get('framebuffer_address')
        if addr:
            hand=data('firmware.txt').decode().splitlines()
            fields=dict(l.split('=',1) for l in hand if l.startswith(('console_framebuffer=','console_pitch=')))
            assert int(fields['console_framebuffer'],16)==addr and display==r['loader_display']
            dimensions=data('home.ppm').split(b'\n',2)[1].decode().split()
            w,h=map(int,dimensions); assert f'Loader, {w}x{h}, 1 page(s)' in display
            size=((addr+int(fields['console_pitch'],16)*h+4095)//4096-addr//4096)*4
            assert f', {size} KiB ' in display
        else:
            assert 'display: Bochs, ' in display and '2 page(s)' in display
        output[case]={'display':display,'framebuffer_address':addr,'pass_count':r['self_tests'],'home_sha':sha(data('home.ppm')),'disk_sha':r['nvme_sha256_after_quit'],'firmware_bytes_changed_boot':r['intervals'][0]['vars_bytes_changed']}
    assert output['ramfb-128']['framebuffer_address']!=output['ramfb-256']['framebuffer_address']
    print(json.dumps({'head':a.head,'tree':a.tree,'workflow_artifact':a.archive_sha,'usb':image['usb_sha256'],'kernel':image['elf_sha256'],'measurement':image['measurement'],'guests':output},indent=2))

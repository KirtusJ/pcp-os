"""Compare five replay receipts with the workflow's original USB artifact and its recorded digest."""
from pathlib import Path
import hashlib
import json
import sys
root=Path(sys.argv[1]).resolve()
report=json.loads((root/'report.json').read_text())
image=json.loads((root/'image.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/'usb.img')==report['usb']==image['usb_sha256']
rows={}
for case,original in report['guests'].items():
    d=root/'local-reboot'/case
    r=json.loads((d/'result.json').read_text())
    assert r['passed'] and r['self_tests']==original['pass_count']==72 and r['exit']==0
    assert sha(d/'home.ppm')==sha(d/'home-after-verification.ppm')
    assert r['usb_sha256_after']==report['usb'] and sha(d/'internal.raw')==r['nvme_sha256_after_quit']
    serial=(d/'serial.txt').read_text()
    assert image['measurement']+' (measured; equal' in serial
    display=next(s for s in serial.splitlines() if s.startswith('display: '))
    addr=r.get('framebuffer_address')
    assert display.split(' mapped at ')[0]==original['display'].split(' mapped at ')[0]
    assert all(i['nvme_bytes_preserved'] and all(v==0 for k,v in i['counter_deltas']['sentinel'].items() if 'wr_' in k or 'unmap' in k) for i in r['intervals'])
    assert r['intervals'][-1]['vars_bytes_changed']==0
    rows[case]={'display':display,'address':addr,'same_home_as_hosted':sha(d/'home.ppm')==original['home_sha'],'same_internal_as_hosted':r['nvme_sha256_after_quit']==original['disk_sha']}
assert rows['ramfb-128']['address']!=rows['ramfb-256']['address']
print(json.dumps(rows,indent=2))

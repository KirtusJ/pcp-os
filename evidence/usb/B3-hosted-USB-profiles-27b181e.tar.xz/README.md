# B3 read-back of the tracked RAMFB USB profiles

Source commit 27b181e100e5dacd334090b7839ed5c920eb9845, tree baf61afb8d2f69949fc43dbd8d4a6c6b51525a69. GitHub Actions run 44920327496 published artifact 14713207690. Its unchanged observations.zip SHA-256 is 106ef6eea5788ed0c238fd52ed332253eb6977130bfca1dddbb26f200d8df22a.

The five workflow guests used the same read-only USB as the five independent local reboots. Each reported 72 final checks, opened Verification, restored identical Home pixels, and powered off on confirmation. Each pair of corresponding guests had matching Home screenshots and internal disk bytes. The virtual firmware chose different RAMFB addresses on the two hosts. The native USB contents, dimensions, mapped size and active pixels matched.

After extraction run sha256sum -c SHA256SUMS and sh verify.sh. The original artifact and the independent local serial, screenshots, internal disk and OVMF checkpoints are included. QEMU paths in replay_ci.py describe the B3 workspace.

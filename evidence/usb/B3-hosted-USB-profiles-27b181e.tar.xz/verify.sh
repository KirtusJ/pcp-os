set -eu
cd "$(dirname "$0")"
python3 -B verify_ci.py observations.zip 106ef6eea5788ed0c238fd52ed332253eb6977130bfca1dddbb26f200d8df22a 27b181e100e5dacd334090b7839ed5c920eb9845 baf61afb8d2f69949fc43dbd8d4a6c6b51525a69 | cmp - report.json
python3 -B check_replay.py . | cmp - replay-report.json

"""Boot the verified GitHub-built read-only USB in fresh local guests."""
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import sys
import zipfile
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'examples/firmware-owned-uefi'))
from usb_trial import trial
host=root/'hosted'
report=json.loads((host/'report.json').read_text())
import hashlib
with zipfile.ZipFile(host/'observations.zip') as z:
    candidates=[n for n in z.namelist() if n.endswith('image.json') and n[:-10]+'usb.img' in z.namelist()]
    assert len(candidates)==1
    base=candidates[0][:-10]
    usb=z.read(base+'usb.img')
    assert hashlib.sha256(usb).hexdigest()==report['usb']
    (host/'usb.img').write_bytes(usb)
    (host/'image.json').write_bytes(z.read(base+'image.json'))
image=json.loads((host/'image.json').read_text())
v=Path('/workspace/scratch/15ccefba7c7d/validation')
fw=v/'pkg/root/usr/share/OVMF'
out=host/'local-reboot';out.mkdir()
def replay(case):
    name,mem,video=case
    r=trial(str(v/'bin/qemu-system-x86_64'),fw/'OVMF_CODE_4M.fd',fw/'OVMF_VARS_4M.fd',host/'usb.img',image,out/name,mem,video)
    assert r['passed'] and r['self_tests']==72
    return name,r['self_tests'],r.get('loader_display','Bochs')
cases=[('128',128,'std'),('256',256,'std'),('virtio-vga',128,'virtio-vga'),('ramfb-128',128,'ramfb'),('ramfb-256',256,'ramfb')]
with ThreadPoolExecutor(max_workers=2) as workers:
    for row in workers.map(replay,cases):
        print(*row,flush=True)

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
d = Path(__file__).resolve().parent
def boot(profile):
    video, memory = profile
    with (d / f'{video}-{memory}.log').open('w') as log:
        subprocess.run(['sh',d/'run.sh',video,str(memory)],stdout=log,stderr=subprocess.STDOUT,check=True)
with ThreadPoolExecutor(max_workers=2) as workers:
    list(workers.map(boot,[('std',128),('virtio-vga',128),('ramfb',128),('ramfb',256)]))

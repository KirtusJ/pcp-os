# B3 USB observations for the withdrawn framebuffer candidate

B3 tested draft PR 318 at commit 81b26748b435d6d5aa5a14c3d4fe45fb5e3093d8. The comparison uses the kernel and firmware recipe from 8a7611c6ee0200c111638da92c468f16bdc1bbd4. PR 317 changed only the host VM-store checker and its workflow. Both USB fixtures were built locally using the tracked full-heap load-base.patch, the project's pinned distribution ISO, and the same compiler and GNU EFI installation. The included image receipts identify the kernel, firmware payloads, and the read-only media.

The four baseline boots covered Bochs, virtio and RAMFB at 128 and 256 MiB. The candidate had five distinct display/RAM configurations and three additional virtio repeats. Native Files are preserved from QEMU, including each Multiboot header and range map, PCI readout, F5 Verification, Esc to Home, confirmed power-off, guest serial output, writable internal disk and OVMF variable snapshots. A further four virtio boots used the unchanged repository trial with its immediate Home comparison. All eight virtio trials on the candidate passed. Z3's separate earlier Home mismatch remains unexplained.

The guest trials exercise ordinary display, storage and shutdown. The whole-page grant finding on PR 318 came from source review. These results are for emulated machines. All locations are guest physical addresses.

After extraction run sha256sum -c SHA256SUMS and python3 -B verify.py. Identical originals use tar hard links. Image receipts carry the measurement printed by each guest. The image build script changes only the local GNU EFI toolchain prefix. The GitHub source revision and exact changed blob IDs are in source.json.

"""Read the native handoff, guest output, pixels and disk/firmware records offline."""
import hashlib
import json
from pathlib import Path
import re
import struct

root=Path(__file__).resolve().parent
def read_json(path):
    return json.loads(path.read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def bar_covers(buses,vendor,device,base,size):
    for bus in buses:
        for item in bus['devices']:
            if (item['id']['vendor'],item['id']['device'])==(vendor,device):
                for reg in item['regions']:
                    if reg['bar']==0 and reg['address']==base and reg['size']==size:
                        return True
    return False

count=0
for part in ('baseline','candidate'):
    folder=root/part
    image=read_json(folder/'image.json')
    assert digest(folder/'usb.img')==image['usb_sha256']
    assert digest(folder/'kernel.elf32')==image['elf_sha256']
    for path in sorted(folder.glob('*/*/result.json')):
        case=path.parent
        r=read_json(path)
        video=r['video']; ram=int(case.name.split('-')[-1])
        log=(case/'serial.txt').read_text()
        assert r['exit']==0 and r['shutdown']==dict(guest=True,reason='guest-shutdown')
        assert 'ALL SELF-TESTS PASS.' in log and 'BdsDxe: starting' in r['firmware_usb']
        assert image['measurement']+' (measured; equal' in log
        assert image['usb_sha256']==r['usb_sha256']==r['usb_after']
        assert digest(case/'internal.raw')==r['disk_before']==r['disk_after']
        for snap in r['snapshots']:
            assert digest(case/snap['vars_snapshot'])==snap['vars_sha256']
            assert snap['nvme_sha256']==r['disk_before']
        for interval in r['intervals']:
            assert interval['nvme_bytes_preserved']
            assert all(value==0 for key,value in interval['counter_deltas']['sentinel'].items() if 'wr_' in key or 'unmap' in key)
            if interval['from']=='home':
                assert interval['vars_bytes_changed']==0
        h=(case/'boot-info.bin').read_bytes()
        raw=(case/'multiboot-map.bin').read_bytes()
        assert struct.unpack_from('<I',h)[0]==0x104c
        assert struct.unpack_from('<I',h,44)[0]==len(raw)
        addr,pitch,width,height,bits,kind=struct.unpack_from('<QIIIBB',h,88)
        assert bits==32 and kind==1 and pitch==width*4
        assert int(re.search(r'^console_framebuffer=([0-9a-f]+)',(case/'firmware.txt').read_text(),re.M)[1],16)==addr
        rounded=(addr+height*pitch+4095)//4096*4096
        entries=struct.iter_unpack('<IQQI',raw)
        overlap=[(base,base+length,typ) for sz,base,length,typ in entries if base<rounded and base+length>addr]
        candidate=part=='candidate'
        if video=='ramfb':
            assert (addr,width,height)==((0x6a3f000 if ram==128 else 0xea3f000),800,600)
            assert (rounded-addr)//4096==469 and rounded-(addr+height*pitch)==1024
            assert overlap==[(addr,addr+3*1024*1024,2)]
            line=f'display: Loader, 800x600, 1 page(s), 1876 KiB of its memory mapped at {addr:#x}' if candidate else 'display: none this kernel can drive'
        elif video=='virtio-vga':
            assert not overlap and (addr,width,height)==(0x80000000,1280,800)
            assert (rounded-addr)//4096==1000 and bar_covers(r['pci_after_handoff'],0x1af4,0x1050,addr,8<<20)
            size=4000 if candidate else 4096
            line=f'display: Loader, 1280x800, 1 page(s), {size} KiB of its memory mapped at 0x80000000'
        else:
            assert bar_covers(r['pci_after_handoff'],0x1234,0x1111,0x80000000,16<<20)
            line='display: Bochs, 1920x1080, 2 page(s), 16384 KiB of its memory mapped at 0x80000000'
        assert line==r['display'] and line in log
        if r['desktop']:
            assert r['startup_pass_lines']==71 and r['pass_lines']==72
            assert digest(case/'kernel-display.ppm')==digest(case/'restored-home.ppm')
            assert digest(case/'kernel-display.ppm')!=digest(case/'verification.ppm')
        else:
            assert part=='baseline' and video=='ramfb' and r['pass_lines']==71
        if candidate:
            assert r['settled_home_comparison']['equal']
            assert r['immediate_home_comparison']['equal']
            for key in ('home_samples','return_samples'):
                for filename,report in r[key].items():
                    assert digest(case/filename)==report['sha256']
        count+=1
assert count==12
official=list((root/'candidate').glob('official-*/result.json'))
assert len(official)==4
for p in official:
    r=read_json(p)
    assert r['passed'] and r['exit']==0 and r['self_tests']==72
    assert r['shutdown']==dict(guest=True,reason='guest-shutdown')
print('Verified four baseline boots, eight candidate boots, and four more unchanged tracked virtio trials.')

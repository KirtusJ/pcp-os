"""Run the five guest profiles plus three independent virtio repetitions."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
d = Path(__file__).resolve().parent
cases=[('std',128,'guests'),('virtio-vga',128,'guests'),('ramfb',128,'guests'),('ramfb',256,'guests'),('std',256,'guests')]
cases.extend(('virtio-vga',128,f'repeat-{i}') for i in range(1,4))
def boot(case):
    video, memory, group = case
    with (d / f'{group}-{video}-{memory}.log').open('w') as log:
        result = subprocess.run(['sh',d/'run.sh',video,str(memory),group],stdout=log,stderr=subprocess.STDOUT)
    return case,result.returncode
with ThreadPoolExecutor(max_workers=2) as workers:
    results=list(workers.map(boot,cases))
for case,code in results:
    print(*case,code)
if any(code for case,code in results):
    raise SystemExit(1)

set -eu
d=$(cd "$(dirname "$0")" && pwd)
v=/workspace/scratch/15ccefba7c7d/validation
export QEMU_MODULE_DIR="$v/pkg/root/usr/lib/x86_64-linux-gnu/qemu"
exec python3 -IB "$d/trial.py" "$1" --ram "$2" --capture-header --source "$d/../virtio-handoff/source" --qemu "$v/bin/qemu-system-x86_64" --firmware "$v/pkg/root/usr/share/OVMF/OVMF_CODE_4M.fd" --vars "$v/pkg/root/usr/share/OVMF/OVMF_VARS_4M.fd" --usb "$d/usb/usb.img" --image "$d/usb/image.json" --out "$d/${3:-guests}"

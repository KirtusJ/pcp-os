"""Read the integrated USB Multiboot framebuffer and published memory map in a disposable QEMU guest."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
from PIL import Image, ImageChops

p = argparse.ArgumentParser()
for name in ("source", "qemu", "firmware", "vars", "usb", "image", "out"):
    p.add_argument("--" + name, type=Path, required=True)
p.add_argument("--capture-header",action="store_true",help="Save the USB recipe’s 128-byte Multiboot header after the measured kernel has entered.")
p.add_argument("video", choices=("std","ramfb","virtio-vga"))
p.add_argument("--ram",type=int,choices=(128,256),default=128)
a=p.parse_args()
out=a.out.resolve()/f"{a.video}-{a.ram}"
out.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(a.source.resolve()/"examples/firmware-owned-uefi"))
import usb_trial
from usb_observer import capture, compare
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def readlog(path):
    return path.read_text(errors="replace") if path.is_file() else ""
def compare_frames(left,right):
    with Image.open(left) as a, Image.open(right) as b:
        diff=ImageChops.difference(a,b)
        box=diff.getbbox()
        count=0 if box is None else sum(pixel!=(0,0,0) for pixel in diff.crop(box).getdata())
        return {"equal":box is None,"pixels":count,"box":box}

def settle(call,label,initial):
    # Keep the first frame accepted by the official Home predicate, then require
    # three matching captures separated by 100 ms before calling Home settled.
    saved=[initial]
    stable=1
    for i in range(1,21):
        time.sleep(.10)
        path=out/f"{label}-{i:02d}.ppm"
        call("screendump",filename=str(path))
        stable=stable+1 if digest(path)==digest(saved[-1]) else 1
        saved.append(path)
        if stable==3:
            break
    assert stable==3, "Home did not settle across three consecutive frames"
    return saved[-1], {p.name:dict(sha256=digest(p),**compare_frames(p,saved[-1])) for p in saved}

usb=a.usb.resolve()
manifest=json.loads(a.image.read_text())
assert digest(usb)==manifest["usb_sha256"]
args=usb_trial.usb_command(str(a.qemu.resolve()),a.firmware.resolve(),a.vars.resolve(),usb,out,a.ram)
if a.video!="std":
    pos=args.index("-vga")
    args[pos:pos+2]=["-vga","none","-device",a.video]
record={"argv":args,"video":a.video,"usb_sha256":digest(usb),"measurement":manifest["measurement"],
        "firmware_sha256":digest(a.firmware),"template_sha256":digest(a.vars),
        "qemu":subprocess.check_output([str(a.qemu),"--version"],text=True).splitlines()[0],
        "disk_before":digest(out/"internal.raw")}
with (out/"stderr.txt").open("wb") as errors:
    vm=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors)
    try:
        monitor=usb_trial.OPTICAL["Monitor"](vm)
        call=monitor.call
        call("qmp_capabilities")
        blocks=call("query-block")
        medium=next(b for b in blocks if b["device"]=="stick")
        assert medium["inserted"]["ro"] and Path(medium["inserted"]["file"])==usb
        record["pci"]=call("query-pci")
        snapshots = [capture(call,out,"prelaunch")]
        record["snapshots"] = snapshots
        call("cont")
        start=time.monotonic()
        serial=out/"serial.txt"; trace=out/"firmware.txt"
        firmware_frame=False
        while time.monotonic()-start<70:
            log=readlog(serial)
            if not firmware_frame and "BdsDxe:" in log:
                call("screendump",filename=str(out/"firmware-window.ppm"))
                (out/"firmware-window-serial.txt").write_text(readlog(serial))
                firmware_frame=True
            if "desktop: " in log or "ALL SELF-TESTS PASS." in log or "SELF-TEST(S) FAILED" in log:
                break
            time.sleep(.08)
        log=readlog(serial)
        record["firmware_usb"]=next((x for x in log.splitlines() if "BdsDxe: starting" in x and "USB" in x),None)
        assert record["firmware_usb"] and "owned-handoff" in readlog(trace)
        assert manifest["measurement"]+" (measured; equal" in log
        if a.capture_header:
            from struct import unpack_from
            address=manifest["arena"][1] - 48*1024
            header=out/"boot-info.bin"
            call("pmemsave",val=address,size=128,filename=str(header))
            data=header.read_bytes()
            assert len(data)==128
            flags=unpack_from("<I",data)[0]
            modules=unpack_from("<I",data,20)[0]
            map_size,map_addr=unpack_from("<II",data,44)
            assert modules==3 and map_size>0 and map_addr>address
            record["runtime_header"]={"capture":"after kernel entry","address":address,"flags":flags,
                                      "modules":modules,"map_bytes":map_size,"map_address":map_addr,
                                      "framebuffer_flag":bool(flags & 0x1000),"framebuffer_fields_hex":data[88:116].hex()}
            assert flags & (1 << 6) and flags & (1 << 12)
            assert map_size % 24 == 0 and map_addr+map_size <= manifest['arena'][1]
            target=out/'multiboot-map.bin'
            call('pmemsave',val=map_addr,size=map_size,filename=str(target))
            blob=target.read_bytes()
            assert len(blob)==map_size
            base,pitch,width,height,bits,kind=unpack_from('<QIIIBB',data,88)
            assert pitch>=width*4 and bits==32 and kind==1
            size=pitch*height; lo=base//4096*4096; hi=((base+size+4095)//4096)*4096
            entries=[]
            for i in range(0,len(blob),24):
                n,start,length,typ=unpack_from('<IQQI',blob,i)
                assert n==20 and length>0 and start+length<=2**64
                entries.append(dict(start=start,end=start+length,type=typ))
            overlap=[entry for entry in entries if entry['start']<hi and entry['end']>lo]
            record['memory_map']=dict(base=base,pitch=pitch,width=width,height=height,bytes=size,
                                      page_start=lo,page_end=hi,overlap=overlap,entry_count=len(entries),
                                      raw_sha256=digest(target))
            (out/'entries.json').write_text(json.dumps(entries,indent=2)+'\n')
        record["pci_after_handoff"]=call("query-pci")
        record["display"]=next(x for x in log.splitlines() if x.startswith("display: "))
        record["desktop"]=next((x for x in log.splitlines() if x.startswith("desktop: ")),None)
        if record["desktop"]:
            screens=usb_trial.OPTICAL["DesktopScreens"](monitor,out,40)
            screens.home("kernel-display")
            first_home, record["home_samples"]=settle(call,"home-series",out/"kernel-display.ppm")
            call("stop")
            snapshots.append(capture(call,out,"home"))
            record["startup_pass_lines"] = sum(line.startswith("  pass ") for line in readlog(serial).splitlines())
            call("cont")
            monitor.key("f5")
            screens.wait("verification",screens.verification_screen)
            monitor.key("esc")
            screens.home("restored-home")
            last_home,record["return_samples"]=settle(call,"return-series",out/"restored-home.ppm")
            record["immediate_home_comparison"]=compare_frames(out/"kernel-display.ppm",out/"restored-home.ppm")
            record["settled_home_comparison"]=compare_frames(first_home,last_home)
            assert record["settled_home_comparison"]["equal"], "settled Home differs after F5/Esc"
            monitor.key("f10")
            screens.wait("power", lambda rows: rows[1]=="  POWER OFF" and rows[3]=="  Switch PCP OS off?")
            monitor.key("ret")
        else:
            call("screendump",filename=str(out/"kernel-display.ppm"))
        usb_trial.OPTICAL["wait_for"](lambda: call("query-status")["status"]=="shutdown","guest power off",40)
        record["shutdown"]=next(e["data"] for e in monitor.events if e["event"]=="SHUTDOWN")
        snapshots.append(capture(call,out,"shutdown"))
        record["intervals"] = [compare(out,a,b) for a,b in zip(snapshots,snapshots[1:])]
        for period in record["intervals"]:
            assert period["nvme_bytes_preserved"]
            assert not any(count for name,count in period["counter_deltas"]["sentinel"].items()
                           if "wr_" in name or "unmap" in name)
        call("quit")
        record["exit"]=vm.wait(timeout=10)
        assert record["shutdown"]=={"guest":True,"reason":"guest-shutdown"} and record["exit"]==0
    finally:
        if vm.poll() is None:
            vm.kill(); vm.wait()
        record["elapsed"]=round(time.monotonic()-start,2) if "start" in locals() else None
        log=readlog(out/"serial.txt")
        record["pass_lines"]=sum(x.startswith("  pass ") for x in log.splitlines())
        record["all_pass"]="ALL SELF-TESTS PASS." in log
        record["disk_after"]=digest(out/"internal.raw")
        record["usb_after"]=digest(usb)
        (out/"result.json").write_text(json.dumps(record,indent=2)+"\n")
assert record["disk_before"]==record["disk_after"] and record["usb_sha256"]==record["usb_after"]
print(record["video"],record["display"],record["desktop"],record["pass_lines"],record["all_pass"])

"""Exercise the unchanged tracked USB trial and its immediate Home comparison."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import sys
d=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('source',type=Path)
p.add_argument('qemu',type=Path)
p.add_argument('firmware',type=Path)
p.add_argument('count',type=int)
a=p.parse_args()
sys.path.insert(0,str(a.source.resolve()/'examples/firmware-owned-uefi'))
import usb_trial
image=json.loads((d/'usb/image.json').read_text())
def boot(index):
    dest=d/f'official-{index}'
    try:
        usb_trial.trial(str(a.qemu.resolve()),a.firmware/'OVMF_CODE_4M.fd',a.firmware/'OVMF_VARS_4M.fd',d/'usb/usb.img',image,dest,128,'virtio-vga')
        return index,'passed'
    except Exception as e:
        return index,str(e)
with ThreadPoolExecutor(max_workers=2) as pool:
    results=list(pool.map(boot,range(1,a.count+1)))
for row in results: print(*row)

"""Make a bootable NVMe control and a read-only USB copy missing only its normal boot filename."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import struct
import subprocess
import tempfile
import uuid
import zlib

parser = argparse.ArgumentParser(description=__doc__)
for name in ('source','usb','internal_efi','out'):
    parser.add_argument(name,type=Path)
args = parser.parse_args()
make = runpy.run_path(str(args.source/'examples/optical-disk-check/check.py'))['make_gpt_disk']
def sha(data):
    return hashlib.sha256(data).hexdigest()
source = args.usb.read_bytes()
assert sha(source)=='fe8bc66801f2eef6125bd03f7ec2b15fab1fc13307dd93a7f52c0cfdcdc827aa'
bad = args.out/'missing-usb.img'
bad.write_bytes(source)
# The control changes just the short name in the FAT directory entry, and preserves all other bytes.
old=b'BOOTX64 EFI'
new=b'ABSENT  EFI'
candidates=[i for i in range(0,len(source)-32,32) if source[i:i+11]==old and source[i+11] in (0x20,0x21)]
assert len(candidates)==1,candidates
with bad.open('r+b') as f:
    f.seek(candidates[0]);f.write(new)
disk, marker = make(512)
raw = bytearray(disk)
esp_type = uuid.UUID('c12a7328-f81f-11d2-ba4b-00a0c93ec93b').bytes_le
for sector in (1,len(raw)//512-1):
    hdr=sector*512
    size=struct.unpack_from('<I',raw,hdr+12)[0]
    table_lba,count,entry_size=struct.unpack_from('<QII',raw,hdr+72)
    start=table_lba*512
    raw[start:start+16]=esp_type
    struct.pack_into('<I',raw,hdr+88,zlib.crc32(raw[start:start+count*entry_size]))
    struct.pack_into('<I',raw,hdr+16,0)
    struct.pack_into('<I',raw,hdr+16,zlib.crc32(raw[hdr:hdr+size]))
    assert struct.unpack_from('<Q',raw,start+32)[0]==2048
internal=args.out/'bootable-nvme.raw'
internal.write_bytes(raw)
volume=str(internal)+'@@1048576'
subprocess.run(['mmd','-i',volume,'::/EFI','::/EFI/BOOT'],check=True)
subprocess.run(['mcopy','-i',volume,str(args.internal_efi),'::/EFI/BOOT/BOOTX64.EFI'],check=True)
def read_efi(image,path):
    return subprocess.check_output(['mtype','-i',str(image),path],stderr=subprocess.DEVNULL)
fallback='::/EFI/BOOT/BOOTX64.EFI'
assert read_efi(args.usb,fallback)==read_efi(bad,'::/EFI/BOOT/ABSENT.EFI')
assert subprocess.run(['mdir','-i',str(bad),fallback],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
assert read_efi(volume,fallback)==args.internal_efi.read_bytes()
assert read_efi(volume,'::/KEEP.TXT')==runpy.run_path(str(args.source/'examples/optical-disk-check/check.py'))['MARKER']
receipt={'usb':sha(source),'missing':sha(bad.read_bytes()),'internal':sha(internal.read_bytes()),'usb_efi':sha(read_efi(args.usb,fallback)),'internal_efi':sha(args.internal_efi.read_bytes()),'changed_entry':candidates[0],'usb_different_bytes':sum(a!=b for a,b in zip(source,bad.read_bytes())),'internal_size':len(raw)}
(args.out/'media.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))

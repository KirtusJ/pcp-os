"""Observe OVMF USB/NVMe boot selection in a disposable Q35 guest."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('profile',choices=('usb-first','internal-first','missing','missing-unlisted','usb-unlisted'))
for name in ('source','usb','media','qemu','firmware','vars','out','receipt'):
    p.add_argument('--'+name,type=Path,required=True)
a=p.parse_args()
sys.path.insert(0,str(a.source.resolve()/'examples/firmware-owned-uefi'))
import usb_trial as usb
from usb_observer import capture, compare
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return path.read_text(errors='replace') if path.is_file() else ''
media=json.loads((a.media/'media.json').read_text())
manifest=json.loads(a.receipt.read_text())
out=a.out.resolve()/a.profile
out.mkdir(parents=True,exist_ok=False)
missing=a.profile.startswith('missing')
unlisted=a.profile.endswith('-unlisted')
stick=(a.media/'missing-usb.img' if missing else a.usb).resolve()
assert sha(stick)==media['missing' if missing else 'usb']
cmd=usb.usb_command(str(a.qemu.resolve()),a.firmware.resolve(),a.vars.resolve(),stick,out,128)
shutil.copyfile(a.media/'bootable-nvme.raw',out/'internal.raw')
assert sha(out/'internal.raw')==media['internal']
for i,arg in enumerate(cmd):
    if arg.startswith('usb-storage') and a.profile=='internal-first':
        cmd[i]=arg.replace('bootindex=1','bootindex=2')
    if arg.startswith('nvme,') and not unlisted:
        cmd[i]=arg+',bootindex='+('1' if a.profile=='internal-first' else '2')
record={'profile':a.profile,'argv':cmd,'qemu':subprocess.check_output([str(a.qemu),'--version'],text=True).splitlines()[0],
        'firmware_sha256':sha(a.firmware),'vars_template_sha256':sha(a.vars),'usb_before':sha(stick),'snapshots':[]}
snaps=record['snapshots']
serial=out/'serial.txt'; trace=out/'firmware.txt'
with (out/'stderr.txt').open('wb') as errors:
    vm=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors)
    try:
        monitor=usb.OPTICAL['Monitor'](vm)
        call=monitor.call
        call('qmp_capabilities')
        record['block']=call('query-block')
        stick_device=next(bl for bl in record['block'] if bl.get('device')=='stick')
        assert stick_device['removable'] and stick_device['inserted']['ro']
        (out/'device-tree.txt').write_text(call('human-monitor-command',**{'command-line':'info qtree'}))
        snaps.append(capture(call,out,'before'))
        call('cont')
        start=time.monotonic()
        while time.monotonic()-start<40:
            if 'KEYBOARD-CONTROL-READY' in read(trace):
                record['outcome']='internal-efi'
                monitor.key('b')
                time.sleep(.25);monitor.key('3')
                break
            if 'desktop: ' in read(serial):
                record['outcome']='pcp-home'
                screens=usb.OPTICAL['DesktopScreens'](monitor,out,35)
                screens.home('home');call('stop');snaps.append(capture(call,out,'home'));call('cont')
                monitor.key('f5');screens.wait('verification',screens.verification_screen)
                monitor.key('esc');screens.home('restored')
                assert sha(out/'home.ppm')==sha(out/'restored.ppm')
                monitor.key('f10');screens.wait('power',lambda r:r[1]=='  POWER OFF' and r[3]=='  Switch PCP OS off?')
                monitor.key('ret')
                break
            if call('query-status')['status']=='shutdown':
                record['outcome']='early-shutdown'
                break
            time.sleep(.12)
        else:
            record['outcome']='no-test-image-started-in-40s'
        if record['outcome']=='no-test-image-started-in-40s':
            call('stop');snaps.append(capture(call,out,'deadline'))
            call('screendump',filename=str(out/'deadline.ppm'))
        else:
            usb.OPTICAL['wait_for'](lambda:call('query-status')['status']=='shutdown','guest power off',35)
            snaps.append(capture(call,out,'shutdown'))
            record['shutdown']=next(e['data'] for e in monitor.events if e['event']=='SHUTDOWN')
            assert record['shutdown']=={'guest':True,'reason':'guest-shutdown'}
        call('quit')
        record['exit']=vm.wait(timeout=10)
        assert record['exit']==0
        record['intervals']=[compare(out,left,right) for left,right in zip(snaps,snaps[1:])]
        record['usb_after']=sha(stick);record['internal_after']=sha(out/'internal.raw')
        record['boot_lines']=[line for line in read(serial).splitlines() if 'BdsDxe:' in line]
        record['pass_lines']=sum(s.startswith('  pass ') for s in read(serial).splitlines())
        marker='KEYBOARD-CONTROL-READY' in read(trace)
        handoff='owned-handoff' in read(trace)
        assert not (marker and handoff)
        if record['outcome']=='pcp-home':
            assert not missing and handoff and record['pass_lines']==72
            assert 'ALL SELF-TESTS PASS.' in read(serial) and manifest['measurement']+' (measured; equal' in read(serial)
            assert any('starting' in line and 'USB' in line for line in record['boot_lines'])
        elif record['outcome']=='internal-efi':
            assert marker and 'KEYBOARD-CONTROL-END' in read(trace) and not handoff and not record['pass_lines']
            assert any('starting' in line and ('NVME' in line.upper() or 'NVMe' in line) for line in record['boot_lines'])
        else:
            assert unlisted and missing and not marker and not handoff
        assert record['internal_after']==media['internal'] and record['usb_before']==record['usb_after']
        for interval in record['intervals']:
            stats=interval['counter_deltas']['sentinel']
            assert interval['nvme_bytes_preserved'] and not any(v for k,v in stats.items() if 'wr_' in k or 'unmap' in k)
        print(a.profile,record['outcome'],record['pass_lines'])
    finally:
        if vm.poll() is None:vm.kill();vm.wait()
        (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')

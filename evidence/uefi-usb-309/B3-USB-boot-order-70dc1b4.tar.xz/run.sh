set -eu
d=$(cd "$(dirname "$0")" && pwd)
v=/workspace/scratch/15ccefba7c7d/validation
export QEMU_MODULE_DIR="$v/pkg/root/usr/lib/x86_64-linux-gnu/qemu"
h="$d/../virtio-handoff"
for profile in "$@"; do
 python3 -IB "$d/boot.py" "$profile" --source "$h/source" --qemu "$v/bin/qemu-system-x86_64" --firmware "$v/pkg/root/usr/share/OVMF/OVMF_CODE_4M.fd" --vars "$v/pkg/root/usr/share/OVMF/OVMF_VARS_4M.fd" --usb "$h/hosted/usb.img" --receipt "$h/hosted/image.json" --out "$d/guests" --media "$d/media"
done

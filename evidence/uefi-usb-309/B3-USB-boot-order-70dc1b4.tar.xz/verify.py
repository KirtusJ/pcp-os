"""Verify the five boot-source controls against raw media, firmware messages, QMP snapshots and images."""
import hashlib
import json
from pathlib import Path
import re
import sys

base=Path(__file__).resolve().parent
media=json.loads((base/'media/media.json').read_text())
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def locate(name,local):
    saved=base/'media'/name
    return saved if saved.exists() else local
usb=locate('original-usb.img',base.parent/'virtio-handoff/hosted/usb.img')
assert sha(usb)==media['usb']=='fe8bc66801f2eef6125bd03f7ec2b15fab1fc13307dd93a7f52c0cfdcdc827aa'
assert sha(base/'media/bootable-nvme.raw')==media['internal']
a=usb.read_bytes()
b=(base/'media/missing-usb.img').read_bytes()
pos=media['changed_entry']
assert a[:pos]==b[:pos] and a[pos+11:]==b[pos+11:] and a[pos:pos+11]==b'BOOTX64 EFI' and b[pos:pos+11]==b'ABSENT  EFI'
assert len(a)==len(b) and sum(x!=y for x,y in zip(a,b))==7
assert sha(base/'media/missing-usb.img')==media['missing']
for profile,outcome in [('usb-first','pcp-home'),('usb-unlisted','pcp-home'),('missing','internal-efi'),('internal-first','internal-efi'),('missing-unlisted','no-test-image-started-in-40s')]:
    d=base/'guests'/profile
    r=json.loads((d/'result.json').read_text())
    assert r['outcome']==outcome and r['exit']==0
    assert r['usb_before']==r['usb_after']==media['missing' if profile.startswith('missing') else 'usb']
    assert r['internal_after']==sha(d/'internal.raw')==media['internal']
    trace=(d/'firmware.txt').read_text()
    log=(d/'serial.txt').read_text()
    assert r['pass_lines']==sum(s.startswith('  pass ') for s in log.splitlines())
    for snap in r['snapshots']:
        assert sha(d/snap['vars_snapshot'])==snap['vars_sha256'] and snap['nvme_sha256']==media['internal']
    for left,right,interval in zip(r['snapshots'],r['snapshots'][1:],r['intervals']):
        nv=interval['counter_deltas']['sentinel']
        assert nv=={k:v-left['counters']['sentinel'][k] for k,v in right['counters']['sentinel'].items()}
        assert not any(v for k,v in nv.items() if 'wr_' in k or 'unmap' in k)
        assert interval['nvme_bytes_preserved']
    if outcome=='pcp-home':
        assert r['pass_lines']==72 and 'ALL SELF-TESTS PASS.' in log and 'owned-handoff' in trace
        assert any('starting' in s and 'USB' in s for s in r['boot_lines'])
        assert sha(d/'home.ppm')==sha(d/'restored.ppm')!=sha(d/'verification.ppm')
        assert r['intervals'][-1]['vars_bytes_changed']==0
    elif outcome=='internal-efi':
        assert 'owned-handoff' not in trace and r['pass_lines']==0
        assert [int(v,16) for v in re.findall(r'^unicode=([0-9a-f]+)$',trace,re.M)]==[98,51]
        assert any('starting' in s and 'NVMe' in s for s in r['boot_lines'])
        if profile=='missing':
            assert any('failed to load' in s and 'USB' in s for s in r['boot_lines'])
    else:
        assert r.get('shutdown') is None and 'KEYBOARD-CONTROL-READY' not in trace and 'owned-handoff' not in trace
        assert any('starting' in s and 'EFI Internal Shell' in s for s in r['boot_lines'])
        assert 'Shell>' in log
    if outcome!='no-test-image-started-in-40s':
        assert r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    print(profile,outcome,sum(i['counter_deltas']['sentinel']['rd_operations'] for i in r['intervals']),'NVMe reads; zero writes/discards')

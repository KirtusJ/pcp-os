# USB and an independently bootable internal disk

Five disposable Q35 guests used the USB image integrated in 70dc1b4092d421e7f77b08072ad5fa056bded5ed, the same fresh OVMF variable template, and a bootable GPT/FAT16 NVMe control. Standard VGA, 128 MiB RAM, PS/2 input, TCG and strict QEMU boot order were common to all five. Only the QEMU boot indices and the filename on the USB control changed. The intact USB and its renamed copy were attached read-only. The internal disk was writable. Each guest had its own disk and firmware variables.

| USB | QEMU boot indices | Observed firmware or OS |
| --- | --- | --- |
| Intact | USB 1, internal 2 | Measured PCP OS Home; 72 checks; 12 internal reads before Home |
| Intact | USB 1, internal unlisted | Same measured Home; 72 checks; zero internal reads |
| Intact | Internal 1, USB 2 | Internal EFI application read the two diagnostic keys and shut down |
| EFI file renamed | USB 1, internal 2 | OVMF logged the failed USB load, then started the internal EFI application |
| EFI file renamed | USB 1, internal unlisted | OVMF started its built-in shell and displayed its prompt. The harness stopped the VM after 40 seconds. |

In both Home guests, F5 opened Verification, Esc restored identical Home pixels, and the guest confirmed power-off. In both internal-app guests, NVMe had 22 reads. Its separate EFI program reported Unicode b and 3 on the debug port. All five internal disks had zero write or discard operations and retained their original SHA-256. OVMF updated its private variable store before Home. Its contents did not change from Home through shutdown. These are measurements of the recorded QEMU/OVMF setup.

The original USB's BOOTX64.EFI bytes are present in the missing-file control under ABSENT.EFI. Seven name bytes in the FAT directory entry differ; every other byte is identical. The internal EFI binary was read back from the internal partition after copying. It is the QEMU-only firmware keyboard control from B3's #309 study, deliberately distinct from the PCP OS loader.

After extraction, run `python3 verify.py`. The archive includes the original media, source for both controls, before/after disk and firmware snapshots, QMP records, EFI/serial output, and Home, Verification, restore and shell images. To replay, use the integrated source tree, QEMU 10.0.13, and the OVMF firmware hashes recorded in each receipt. The exact command line for each guest is in its result.json. The Python runner accepts replacement paths via --help.

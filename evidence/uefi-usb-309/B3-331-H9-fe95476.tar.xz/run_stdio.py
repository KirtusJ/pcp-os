"""Run the repository guest checker with QMP on stdio on a host that denies Unix sockets."""
from pathlib import Path
import sys
path = Path(sys.argv.pop(1)).resolve()
source = path.read_text()
start = source.index("        end = time.monotonic() + 20\n")
end = source.index('        self.rpc("qmp_capabilities")', start)
source = source[:start] + "        self.process.stdout.readline()\n" + source[end:]
source = source.replace('"unix:%s,server=on,wait=off" % sock', '"stdio"').replace(
    "stdout=subprocess.DEVNULL", "text=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE")
for op, channel in (("readline", "stdout"), ("write", "stdin"), ("flush", "stdin")):
    source = source.replace("self.stream." + op + "(", "self.process." + channel + "." + op + "(")
exec(compile(source, str(path), "exec"), {"__name__": "__main__", "__file__": str(path)})

B3 independent native review of fe954767155ca660262466bc5d9a2137df91ac0b.
Run these from the extracted directory using Python 3:
python3 -IB h9/examples/tester-cd/check_stopped_captures.py h9-guests
python3 -IB exhaust_fragments.py h8 earlier.json
python3 -IB exhaust_fragments.py h9 corrected.json
cmp earlier.json compact-fragments-before.json
cmp corrected.json compact-fragments-after.json

The h8 directory contains the 364639a skip predicate with the #335 capture helpers. The h9 directory contains the combined fix. h9-guests contains eight fresh native serial records and screens. joined-guests contains the original native donor and recipient used for the exhaustive substring comparison. The expected counts are 1,070/1,084 and 0/1,084 admissions respectively. Edited capture controls do not represent genuine extra boots.

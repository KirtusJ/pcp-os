"""Replay every distinct nonblank native notice fragment that fits after the compact power instruction."""
from pathlib import Path
import json
import runpy
import sys
root = Path(__file__).resolve().parent
source = Path(sys.argv[1])
api = runpy.run_path(str(source / "examples/tester-cd/check_stopped_captures.py"))
stop = api["STOP"]
glyphs = stop["CHECK"]["kernel_glyphs"]()
recipient = api["CapturedBoot"](root / "joined-guests/nokbd-320", glyphs)
donor = api["CapturedBoot"](root / "joined-guests/nokbd-1080", glyphs)
notice = next(row.strip() for row in donor.rows if "Not run:" in row)
size = recipient.frame.split(b"\n",2)[1]
room = int(size.split()[0]) // 10 - len(recipient.rows[-1]) - 1
fragments = sorted({notice[i:i + length] for i in range(len(notice)) for length in range(1, room+1)
                    if len(notice[i:i + length]) == length and len(notice[i:i + length].strip()) == length
                    and any(c.isalnum() for c in notice[i:i+length])})
log = recipient.serial.read_text()
admitted = []
for fragment in fragments:
    ppm, expected_rows = api["skip_fragment"](donor, recipient, fragment)
    rows = stop["PINS"]["read"](ppm, glyphs)
    assert rows == expected_rows
    if not stop["skip_problems"](log, rows, stop["NO_CONTROLLER"], compact=True):
        admitted.append(fragment)
out = {"max_cells": room, "distinct_fragments": len(fragments), "admitted": admitted}
(root / sys.argv[2]).write_text(json.dumps(out, indent=2) + "\n")
print(len(fragments), "native fragments;", len(admitted), "admitted")

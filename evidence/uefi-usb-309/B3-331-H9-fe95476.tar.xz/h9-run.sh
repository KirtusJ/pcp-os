set -eu
w=$1
q=/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64
python3 -IB "$w/run_stdio.py" "$w/h9/examples/tester-cd/check_stopped_screen.py" "$w/bin/default.elf32" "$w/bin/no-key-replay-demo.elf32" "$w/h9-guests" --busy "$w/bin/keyboard-busy-demo.elf32" --silent "$w/bin/keyboard-silent-demo.elf32" --qemu "$q"
python3 -IB "$w/h9/examples/tester-cd/check_stopped_captures.py" "$w/h9-guests"

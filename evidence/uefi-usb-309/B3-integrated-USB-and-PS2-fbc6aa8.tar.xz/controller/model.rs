use std::collections::VecDeque;
use std::sync::{Mutex,atomic::{AtomicBool,AtomicU32,AtomicU64,Ordering}};
const ORDER: Ordering = Ordering::SeqCst;

mod arch {
    use super::*;
    pub struct Single<T>(Mutex<T>);
    impl<T> Single<T> {
        pub const fn new(v:T)->Self{ Self(Mutex::new(v)) }
        pub fn with<R>(&self,f:impl FnOnce(&mut T)->R)->R{ f(&mut *self.0.lock().unwrap()) }
    }
    pub fn without_interrupts<R>(f:impl FnOnce()->R)->R{ f() }
    pub fn interrupt_line_on(n:u8){ assert_eq!(n,1); IRQ.store(true,ORDER); }
    pub fn ticks()->u64{ TICKS.load(ORDER) }
    pub fn wait_until(n:u64){ TICKS.store(n,ORDER); }
}
mod user {
    pub fn sleeping_idle_ticks(_:u64)->Option<u64>{None}
    pub fn idle_in_key_read()->bool{false}
}
struct Keyboard {present:bool}
static KEYBOARD:arch::Single<Keyboard> = arch::Single::new(Keyboard{present:false});
static IRQ:AtomicBool=AtomicBool::new(false);
static TICKS:AtomicU64=AtomicU64::new(0);
static PROBE:AtomicU32=AtomicU32::new(0);
static PROBE_HIT:AtomicBool=AtomicBool::new(false);
fn keys_forget(){}
fn keys_waiting()->bool{false}

#[derive(Default)]
struct Bus {
    absent:bool,
    config:Option<u8>,
    keyboard_answer:Option<u8>,
    queue:VecDeque<u8>,
    writes:Vec<(u16,u8,bool)>,
    busy_before:Option<usize>,
    busy_samples:u32,
    last_busy:bool,
    replay_data:bool,
    accepted_script:usize,
}
thread_local! { static BUS:std::cell::RefCell<Bus> = std::cell::RefCell::new(Bus::default()); }
fn setup(config:Option<u8>,ack:Option<u8>) {
    BUS.with_borrow_mut(|b| *b=Bus{config,keyboard_answer:ack,..Default::default()});
    KEYBOARD.with(|k| k.present=false);
    IRQ.store(false,ORDER); TICKS.store(0,ORDER); PROBE.store(0,ORDER); PROBE_HIT.store(false,ORDER);
}
fn in8(port:u16)->u8{
    BUS.with_borrow_mut(|b| match port {
        0x64 if b.absent=>0xff,
        0x64=>{
            b.last_busy=b.busy_before==Some(b.writes.len()) && b.busy_samples>0;
            if b.last_busy { b.busy_samples-=1; }
            u8::from(!b.queue.is_empty()) | (u8::from(b.last_busy)<<1)
        }
        0x60=>b.queue.pop_front().expect("read of empty output buffer"),
        _=>panic!("unexpected port")
    })
}
fn out8(port:u16,v:u8) {
    BUS.with_borrow_mut(|b| {
        let took=!b.last_busy;
        b.writes.push((port,v,took));
        if !took{return;}
        match (port,v) {
            (0x64,0x20)=>b.queue.extend(b.config),
            (0x64,0xd2)=>b.replay_data=true,
            (0x60,_) if b.replay_data=>{
                b.replay_data=false;
                if PROBE.load(ORDER)==(0x100|v as u32) {
                    PROBE.store(0,ORDER); PROBE_HIT.store(true,ORDER);
                } else {b.accepted_script+=1;}
            }
            (0x60,0xf4)=>b.queue.extend(b.keyboard_answer),
            _=>()
        }
    });
}
fn busy(slot:usize,reads:u32){
    BUS.with_borrow_mut(|b| {b.busy_before=Some(slot);b.busy_samples=reads;});
}
fn init_case(label:&str, expected:bool, rejected:&[usize]){
    let result=keyboard_init();
    let marked=KEYBOARD.with(|k| k.present);
    let irq=IRQ.load(ORDER);
    let missed=BUS.with_borrow(|b| b.writes.iter().enumerate().filter_map(|(i,w)| (!w.2).then_some(i)).collect::<Vec<_>>());
    let writes=BUS.with_borrow(|b| b.writes.clone());
    assert_eq!((result,marked,irq),(expected,expected,expected));
    assert_eq!(missed,rejected);
    println!("init {label}: writes={writes:x?} return={result} present={marked} irq1={irq}");
}
fn script_case(label:&str, slot:Option<usize>, duration:u32, left1:usize, expected_accepted:usize){
    setup(Some(0),Some(0xfa));
    assert!(keyboard_replays(),"startup echo control failed");
    BUS.with_borrow_mut(|b|{ assert_eq!(b.writes,[(0x64,0xd2,true),(0x60,0xf4,true)]); b.writes.clear(); });
    if let Some(s)=slot {busy(s,duration);}
    keyboard_script(10,&[0x1e],KeyPacing::Timed);
    script_tick(10);
    assert_eq!(keyboard_script_left(),left1);
    let first=BUS.with_borrow(|b|b.writes.clone());
    script_tick(11);
    let (writes,accepted)=BUS.with_borrow(|b|(b.writes.clone(),b.accepted_script));
    assert_eq!(accepted,expected_accepted);
    assert_eq!(keyboard_script_left(),0);
    if expected_accepted==0 {
        assert_eq!(writes,[(0x64,0xd2,true),(0x60,0x1e,false)]);
        assert_eq!(writes,first);
    }
    println!("script {label}: probe=true first={first:x?} left_after_first={left1} after_next_tick={writes:x?} accepted={accepted}");
}
fn main(){
    setup(Some(0),Some(0xfa)); init_case("ready",true,&[]);
    setup(Some(0),Some(0xfa)); BUS.with_borrow_mut(|b|b.absent=true); init_case("absent",false,&[]);
    setup(None,Some(0xfa)); init_case("no-config",false,&[]);
    for (i,name) in ["disable-first","disable-second","read-config","select-config","config-data","enable-first","enable-scanning"].iter().enumerate(){
        setup(Some(0),Some(0xfa)); busy(i,u32::MAX);
        init_case(name,i!=2,&[i]);
    }
    for (answer,label) in [(None,"no-scan-answer"),(Some(0xfe),"resend"),(Some(0xfc),"failure-byte")]{
        setup(Some(0),answer); init_case(label,true,&[]);
    }
    script_case("ready",None,0,0,1);
    script_case("busy-on-entry-for-one-tick",Some(0),1,1,1);
    script_case("ready-on-final-parameter-poll",Some(1),99_999,0,1);
    script_case("busy-through-final-parameter-poll",Some(1),100_000,0,0);
}

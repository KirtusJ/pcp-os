#!/bin/sh
set -eu
here=$(cd "$(dirname "$0")" && pwd)
dir=$(mktemp -d)
trap 'rm -rf "$dir"' EXIT
python3 "$here/extract.py" "$here/dev.rs" "$here/model.rs" > "$dir/controller.rs"
rustc --edition=2021 "$dir/controller.rs" -o "$dir/controller"
"$dir/controller" > "$dir/observations.txt"
cmp "$here/observations.txt" "$dir/observations.txt"

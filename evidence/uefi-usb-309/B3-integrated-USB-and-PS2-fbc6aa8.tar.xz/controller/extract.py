"""Copy the integrated checkout's Rust functions unchanged into a host I/O model."""
from pathlib import Path
import sys

def function(source, declaration):
    start = source.index(declaration)
    return source[start:source.index("\n}", start) + 2]

src = Path(sys.argv[1]).read_text()
model = Path(sys.argv[2]).read_text()
types = src[src.index("#[derive(Clone, Copy, PartialEq, Eq)]\npub enum KeyPacing"):src.index("/// For the kernel's self-tests, which have nobody")]
pieces = [function(src, d) for d in (
    "fn controller_wait_write()", "fn controller_read()", "pub fn keyboard_init()",
    "pub fn keyboard_replays()", "pub fn keyboard_script(", "fn script_tick(",
    "pub fn keyboard_script_left()")]
print(model, types, *pieces, sep="\n")

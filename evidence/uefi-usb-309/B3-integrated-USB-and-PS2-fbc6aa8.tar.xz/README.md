# B3 USB and keyboard checks on fbc6aa8

Commit fbc6aa8d390779caa74905a08df118d1a45ab351 has tree 96ca6f9a9f72f5b798599c6d1db301668b5aa461. Only comments in the inventory differ from the approved da8abde. The guarded UEFI USB kernels were rebuilt from this tree with its tracked relocation patch. Three Q35/OVMF guests used 128 MiB, read-only removable media, an attached internal NVMe fixture omitted from boot order, and no network.

Normal and no-replay guests showed 71 and 65 passes on F5 and recorded 72 and 66 after register closure. Both accepted F5, Esc and F10/Enter. The USB-only guest booted the normal USB with an xHCI keyboard and no i8042. It reported no controller, skipped the desktop and finished 66 checks without injected input. Both media retained their hashes. Internal block counters stayed zero. Each variable store differed from its starting file in 6,047 bytes. These measurements concern the named VMs. Bootable-internal fallback measurements are in the separate 5537f9a evidence commit.

## Modeled controller behavior

The host model tested the existing initialization and scripted-key paths. extract.py copies seven exact functions and the script data structure from the integrated dev.rs. The model supplies port status, data, clock and a synthetic matched replay interrupt. It records and drops a write when the most recent status sample showed a full input buffer. This models one possible response. Physical controller behavior remains unmeasured.

- Initialization attempted each of its seven writes when that write’s readiness wait expired. An absent controller made zero writes. Without a configuration reply, initialization returned false after three writes. Given a configuration reply, it marked the keyboard present and enabled IRQ1 for a modeled acknowledgement, silence, a resend byte and a failure byte.
- In four scripted-key cases the actual startup probe first returned true. One scan code was delivered on a ready controller, after one initially busy tick, and when the parameter became writable on poll 100,000. When input stayed busy through that poll, the script still attempted the parameter and advanced its cursor. The model dropped the byte. The script reported zero bytes left and issued nothing on the next tick. This observation ends at that tick. A complete boot with a dropped byte was outside this model.
- The bodies of keyboard_init and script_tick match master a613950 byte for byte. The #326 repair addresses the preceding capability probe. For a hardware build, account for an outstanding parameter before sending another replay command and provide bounded completion if a waiting test never receives its key.

## Recheck

Run sha256sum --quiet -c SHA256SUMS, then python3 -B replay.py and compare the output with readback.json. Run sh controller/replay.sh to rebuild the Rust host model and compare all 17 records with observations.txt. Python with NumPy and rustc are required. The media receipts identify the USB and kernel bytes. The included scripts and relocation patch record the original tool paths and commands.

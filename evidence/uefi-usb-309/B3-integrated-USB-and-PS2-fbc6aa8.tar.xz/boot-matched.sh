set -eu
dir=$(cd "$(dirname "$0")" && pwd)
sdk=/workspace/scratch/15ccefba7c7d/validation/pkg/root/usr
qemu=/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64
iso=/workspace/scratch/6fbc6fd5187a/pcp/PCP-OS.iso
for mode in default no-replay
do
    python3 -B "$dir/make_media.py" "$dir/src" "$dir/$mode/kernel.elf32" "$iso" "$sdk" "$dir/$mode/media" > "$dir/$mode/image-build.log" 2>&1
    profile=stock
    if [ "$mode" = no-replay ]; then profile=no-replay; fi
    python3 -B "$dir/guest.py" "$dir/src" "$dir/$mode/media" "$qemu" "$sdk/share/OVMF" "$dir/$mode/guest" "$profile"
done
python3 -B "$dir/usb_only.py" "$dir/src" "$dir/default/media" "$qemu" "$sdk/share/OVMF" "$dir/usb-only"

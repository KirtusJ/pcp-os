# Director B3 keyboard delivery checks

Two working revisions of z3/keyboard-init were compared. The first was 4800892835342bb6ecdeac871c6fb4a0ef60502b. The second was 36209cb9d7ee51838163c471da3fdc4687d2dc4a. Each ran an unmodified kernel, a diagnostic kernel with ordinary controller behavior, and four cases on that same diagnostic executable. The test copy observes the first targeted operation and supplies only the specified busy status samples to the existing controller polls. Every guest reached register closure. All measurements here are virtual.

| Case | 4800892 | 36209cb |
|---|---|---|
| Unchanged, instrumented without injected waits, or ready on the last poll | 72 passed in each guest | 72 passed in each guest |
| Controller busy through the last parameter poll of the blocked read | 71 passes and one reported failure | 71 passes and one reported failure, four bytes unsent |
| Controller stays busy before the blocked reader's command | The timer stops the program 5,001 ticks after the first key was due | Same outcome, four bytes unsent |
| First trailing release times out during drain | 72 passes even though a release was lost | 71 passes and one reported failure, three release bytes unsent |

On 36209cb a seventh guest ran the unmodified kernel and an ordinary loader-provided copy of the repository's key reader. The host withheld input for 7.5 seconds after program start, then sent Shift down, Shift up and A down. The guest reported exit 0 after seven seconds with eight system calls. It closed at 72 passing checks.

Run sha256sum -c SHA256SUMS and python3 -B replay.py here. Each revision folder contains its original dev.rs and main.rs, measurement, observer, and the serial and exit records. To repeat a revision with its original Git checkout, build the unmodified kernel using the tracked run.sh build with Rust 1.97.0. For the diagnostic copy, apply instrument.py with the archived revision folder and a disposable kernel src folder as its two arguments, rebuild, and invoke run_profile.py with the kernel ELF, measure.py, QEMU path, a new output folder and the case name. The ordinary.py arguments are the unmodified kernel ELF, measure.py, QEMU path and a new output directory. Its module contains the same key_reader instructions included in the kernel's own self-tests and is loaded through the ordinary program path.

from pathlib import Path
import json,subprocess,sys
kernel,tool,qemu,folder,mode=sys.argv[1:]
out=Path(folder);out.mkdir()
val=subprocess.check_output([sys.executable,tool,kernel],text=True).strip()
cmd=[qemu,'-machine','pc','-cpu','max','-accel','tcg','-m','128M','-smp','1','-kernel',kernel,'-append',f'image={val} then=off b3fixture={mode}','-display','none','-nic','none','-monitor','none','-serial','file:'+str(out/'serial.txt'),'-device','isa-debug-exit,iobase=0xf4,iosize=0x04','-no-reboot']
with (out/'stderr.txt').open('wb') as e:
    p=subprocess.run(cmd,stderr=e,stdout=subprocess.DEVNULL,timeout=55,check=False)
log=(out/'serial.txt').read_text().splitlines()
v=dict(mode=mode,measurement=val,code=p.returncode,passed=sum(s.startswith('  pass ') for s in log),failures=[s for s in log if s.startswith('  FAIL')],observed=[s for s in log if s.startswith('OBS ')],closed=any(s.startswith("  pass the kernel's register") for s in log))
(out/'result.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps(v),flush=True)
assert v['closed'] and p.returncode in (33,35)

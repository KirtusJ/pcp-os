"""Run the repository's key_reader instructions as an ordinary loader module, and supply its keys manually."""
from pathlib import Path
import time,subprocess,struct,sys,json,re
kernel,measure,qemu,output=map(Path,sys.argv[1:]); output.mkdir(); log=output/'serial.txt'
raw=kernel.read_bytes()
assert raw[:5]==b'\x7fELF\x01'
symbols={n:int(v,16) for v,_,n in (row.split() for row in subprocess.check_output(['nm','-n',str(kernel)],text=True).splitlines() if row.endswith((' user_key_reader_start',' user_key_reader_end')))}
lo,hi=(symbols['user_key_reader_'+suffix] for suffix in ('start','end'))
phoff=struct.unpack_from('<I',raw,28)[0];stride,num=struct.unpack_from('<HH',raw,42)
segments=[struct.unpack_from('<8I',raw,phoff+i*stride) for i in range(num)]
seg,=[s for s in segments if s[0]==1 and s[2]<=lo and hi<=s[2]+s[4]]
start=seg[1]+lo-seg[2];code=raw[start:start+hi-lo]
size=120+len(code); ident=b'\x7fELF\x02\x01\x01'+bytes(9)
elf=struct.pack('<16sHHIQQQIHHHHHH',ident,3,62,1,120,64,0,0,64,56,1,0,0,0)+struct.pack('<IIQQQQQQ',1,5,0,0,0,size,size,4096)+code
module=output/'keyreader.elf';module.write_bytes(elf)
digest=subprocess.check_output([sys.executable,str(measure),str(kernel)],text=True).strip()
args=[str(qemu),'-machine','pc','-accel','tcg','-cpu','max','-m','128M','-kernel',str(kernel),'-initrd',str(module),'-append',f'image={digest} auto=keyreader.elf then=off','-nic','none','-display','none','-monitor','none','-qmp','stdio','-serial','file:'+str(log),'-device','isa-debug-exit,iobase=0xf4,iosize=0x04','-no-reboot']
with (output/'stderr.txt').open('wb') as e,subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=e,text=True) as vm:
    def rpc(cmd,**kw):
        vm.stdin.write(json.dumps(dict(execute=cmd,arguments=kw))+'\n');vm.stdin.flush()
        while True:
            msg=json.loads(vm.stdout.readline())
            if 'error' in msg:raise RuntimeError(msg)
            if 'return' in msg:return msg['return']
    try:
        vm.stdout.readline();rpc('qmp_capabilities')
        limit=time.monotonic()+25
        while not (log.exists() and 'starting keyreader.elf (' in log.read_text(errors='replace')):
            assert vm.poll() is None and time.monotonic()<limit,log.read_text(errors='replace')[-750:]
            time.sleep(.05)
        begin=time.monotonic();time.sleep(7.5)
        assert vm.poll() is None and 'keyreader.elf ended' not in log.read_text(errors='replace')
        for key,down in [('shift',True),('shift',False),('a',True)]:
            rpc('input-send-event',events=[{'type':'key','data':{'down':down,'key':{'type':'qcode','data':key}}}]);time.sleep(.04)
        rc=vm.wait(timeout=15)
        lines=log.read_text().splitlines()
        record=next(s for s in lines if 'keyreader.elf ended' in s)
        assert rc==33 and 'exit 0' in record and re.search(r'after (?:[6-9]|[1-9][0-9]+) s',record),record
        obs=dict(returncode=rc,withheld_seconds=7.5,serial_result=record,kernel_measurement=digest,passed=sum(s.startswith('  pass ') for s in lines))
        (output/'result.json').write_text(json.dumps(obs,indent=2)+'\n');print(obs)
    finally:
        if vm.poll() is None: vm.terminate();vm.wait(timeout=5)

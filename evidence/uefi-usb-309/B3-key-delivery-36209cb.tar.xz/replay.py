"""Check each serial record and compare the previous and current trailing-release outcomes."""
from pathlib import Path
import json,re
root=Path(__file__).resolve().parent
counts={}
for revision in ('4800892','36209cb'):
    folder=root/revision
    for mode in ('unchanged','healthy','edge','post','pre','trailing'):
        case=folder/mode; record=json.loads((case/'result.json').read_text())
        serial=(case/'serial.txt').read_text().splitlines()
        passed=sum(s.startswith('  pass ') for s in serial)
        failures=[s for s in serial if s.startswith('  FAIL')]
        assert record['closed'] and any(s.startswith("  pass the kernel's register") for s in serial)
        assert record['failures']==failures and record['passed']==passed
        bad=mode in ('post','pre') or (revision=='36209cb' and mode=='trailing')
        assert (passed,len(failures),record['code'])==((71,1,35) if bad else (72,0,33))
        if mode=='pre':
            tick,due=re.search(r'OBS deadline tick=(\d+) due=(\d+) waiting=true', '\n'.join(serial)).groups()
            assert int(tick)-int(due)==5001
        if mode in ('post','edge','trailing'):
            samples=99999 if mode=='edge' else 100000
            assert any(f'samples={samples}' in s for s in serial)
        if revision=='36209cb' and bad:
            unsent=3 if mode=='trailing' else 4
            assert f'OBS final result delivered=false unsent={unsent} stalled=true' in serial
        if revision=='4800892' and mode=='trailing':
            assert 'OBS drain completed=true initial_success=true now_stalled=true' in serial
        counts[revision+'/'+mode]=[passed,len(failures),record['code']]
ordinary=root/'36209cb/ordinary'
rec=json.loads((ordinary/'result.json').read_text()); log=(ordinary/'serial.txt').read_text()
assert rec['returncode']==33 and rec['passed']==72 and rec['withheld_seconds']==7.5
assert rec['serial_result'] in log and 'exit 0 after 7 s; 8 system calls' in log
print(json.dumps(counts,sort_keys=True))
print('Ordinary unscripted key reader: waited seven guest seconds, exited 0 after external input, register closed.')

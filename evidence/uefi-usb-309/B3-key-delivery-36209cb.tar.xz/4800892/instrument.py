"""Apply a one-shot busy-status input and serial instrumentation to the test copy."""
from pathlib import Path
import sys
src,dest=map(Path,sys.argv[1:])
def edit(t,a,b):
    assert t.count(a)==1,a
    return t.replace(a,b,1)
s=(src/'dev.rs').read_text()
s=edit(s,'fn in8(port: u16) -> u8 {','''use core::sync::atomic::AtomicU32;
static MODE: AtomicU32 = AtomicU32::new(0);
static BUSY_SAMPLES: AtomicU32 = AtomicU32::new(0);
static ARMED: AtomicBool = AtomicBool::new(false);
static IN_DRAIN: AtomicBool = AtomicBool::new(false);
pub fn b3_config(args:&str) {
    for arg in args.split_whitespace() { if let Some(m)=arg.strip_prefix("b3fixture=") {
        MODE.store(match m {"edge"=>1,"post"=>2,"pre"=>3,"trailing"=>4,_=>0}, Ordering::Relaxed);
    }}
}
pub fn b3_drain_observation() -> Option<bool> {
    if MODE.load(Ordering::Relaxed) == 4 && IN_DRAIN.swap(false,Ordering::Relaxed) {Some(SCRIPT.with(|s|s.stalled))}else{None}
}
fn in8(port: u16) -> u8 {
    if port==0x64 && BUSY_SAMPLES.load(Ordering::Relaxed)!=0 {
        BUSY_SAMPLES.fetch_sub(1,Ordering::Relaxed);
        return (unsafe {arch::port_in8(port)}) | 2;
    }''')
s=edit(s,'        s.pacing = KeyPacing::Timed;', '''        if MODE.load(Ordering::Relaxed)==4 && s.next<s.len && !ARMED.load(Ordering::Relaxed) {
            IN_DRAIN.store(true,Ordering::Relaxed);
            crate::log(format_args!("OBS drain begins with {} remaining",s.len-s.next));
        }
        s.pacing = KeyPacing::Timed;''')
s=edit(s,'        if s.limit != 0 && ticks > s.limit {','''        let m=MODE.load(Ordering::Relaxed);
        if m==3 && s.pacing==KeyPacing::BlockedRead && crate::user::idle_in_key_read() && !ARMED.swap(true,Ordering::Relaxed) {
            BUSY_SAMPLES.store(u32::MAX,Ordering::Relaxed);
            crate::log(format_args!("OBS busy before command start={} due={}",ticks,s.at));
        }
        if s.limit != 0 && ticks > s.limit {
            if m==3 && ARMED.load(Ordering::Relaxed) { BUSY_SAMPLES.store(0,Ordering::Relaxed); }
            crate::log(format_args!("OBS deadline tick={} due={} waiting={}",ticks,s.at,crate::user::idle_in_key_read()));''')
s=edit(s,'                out8(0x64, 0xD2);\n                // A byte is counted','''                out8(0x64, 0xD2);
                if (((m==1 || m==2) && s.pacing==KeyPacing::BlockedRead) || (m==4 && IN_DRAIN.load(Ordering::Relaxed))) && !ARMED.swap(true,Ordering::Relaxed) {
                    let n=if m==1 {99999} else {100000}; BUSY_SAMPLES.store(n,Ordering::Relaxed);
                    crate::log(format_args!("OBS busy after command tick={} samples={} next={} len={}",ticks,n,s.next,s.len));
                }
                // A byte is counted''')
s=edit(s,'                if !controller_wait_write() {\n                    s.stalled = true;', '''                if !controller_wait_write() {
                    crate::log(format_args!("OBS parameter refused tick={} blocked={} next={} len={}",ticks,crate::user::idle_in_key_read(),s.next,s.len));
                    s.stalled = true;''')
t=(src/'main.rs').read_text()
t=edit(t,'    let keyboard_start = dev::keyboard_init();','    dev::b3_config(&boot.command_line);\n    let keyboard_start = dev::keyboard_init();')
t=edit(t,'    if !done {\n        Err("the key script did not finish")','''    if let Some(now_stalled)=dev::b3_drain_observation() {
        crate::log(format_args!("OBS drain completed={} initial_success={} now_stalled={}",done,woke_on_interrupt,now_stalled));
    }
    if !done {
        Err("the key script did not finish")''')
(dest/'dev.rs').write_text(s);(dest/'main.rs').write_text(t)

set -eu
here=$(cd "$(dirname "$0")" && pwd)
sdk=$1
build=$(mktemp -d)
trap 'rm -rf "$build"' EXIT
for version in old new; do
    cc -std=c11 -Wall -Wextra -Werror -DGNU_EFI_USE_MS_ABI -fshort-wchar -mno-red-zone -I"$sdk/include/efi" -I"$sdk/include/efi/x86_64" "$here/queue-$version/check.c" -o "$build/test"
    for scenario in queued-enter refuse-confirm-reset; do "$build/test" "$scenario"; done > "$build/observed"
    cmp "$here/queue-$version/observed.txt" "$build/observed"
done

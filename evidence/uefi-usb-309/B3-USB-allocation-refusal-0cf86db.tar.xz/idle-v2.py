import hashlib,json,subprocess,sys,time
from pathlib import Path
d=Path(__file__).resolve().parent
sys.path.insert(0,str(d/'src/examples/firmware-owned-uefi'))
import usb_trial
from usb_observer import capture,compare
mode=sys.argv[1]
media=d/('old-src-media' if mode=='parent' else 'v2-media')
out=d/(mode+'-no-input')
out.mkdir()
fw=Path('/workspace/scratch/15ccefba7c7d/validation/pkg/root/usr/share/OVMF')
q='/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64'
cmd=usb_trial.usb_command(q,fw/'OVMF_CODE_4M.fd',fw/'OVMF_VARS_4M.fd',media/'usb.img',out,64)
cmd[cmd.index('-machine')+1]='q35,i8042=off'
cmd.extend(['-device','usb-kbd,id=external-keyboard,bus=xhci.0'])
r={'args':cmd,'mode':mode,'keys_sent':0}
with (out/'stderr.txt').open('w') as err,subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        mon=usb_trial.OPTICAL['Monitor'](vm)
        call=mon.call
        call('qmp_capabilities')
        before=capture(call,out,'before')
        call('cont')
        if mode=='parent':
            usb_trial.OPTICAL['wait_for'](lambda:call('query-status')['status']=='shutdown','parent shutdown',40)
        else:
            usb_trial.OPTICAL['wait_for'](lambda:'Press F10 to request power off.' in (out/'serial.txt').read_text(errors='replace'),'visible refusal',40)
            call('screendump',filename=str(out/'start.ppm'))
            start=time.monotonic()
            while time.monotonic()-start<310:
                time.sleep(min(5,310-(time.monotonic()-start)))
                assert call('query-status')['status']=='running'
            r['no_input_seconds']=time.monotonic()-start
            assert not any(e['event'] in ('RESET','SHUTDOWN') for e in mon.events)
            call('stop')
        call('screendump',filename=str(out/'end.ppm'))
        end=capture(call,out,'end')
        trace=(out/'firmware.txt').read_text().splitlines()
        assert 'handoff-refused' in trace and 'owned-handoff' not in trace and 'refusal-power-confirmed' not in trace
        assert ('refusal_watchdog_status=0000000000000000' in trace)==(mode!='parent')
        r.update(snapshots=[before,end],interval=compare(out,before,end),events=mon.events.copy())
        if mode=='parent':
            assert [e['data'] for e in r['events'] if e['event']=='SHUTDOWN']==[{'guest':True,'reason':'guest-shutdown'}]
        assert r['interval']['nvme_bytes_preserved'] and not any(r['interval']['counter_deltas']['sentinel'].values())
        assert hashlib.sha256((media/'usb.img').read_bytes()).hexdigest()==json.loads((media/'image.json').read_text())['usb_sha256']
        call('quit')
        r['exit']=vm.wait(timeout=10)
        assert r['exit']==0
    finally:
        if vm.poll() is None:
            vm.kill()
            vm.wait()
        (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')

#include <efi.h>
#include <efilib.h>
#include <assert.h>
#include <setjmp.h>
#include <stdio.h>
#include <string.h>
static jmp_buf halted;
static int cursor, dropped, confirmation_resets;
static const char *mode;
static int resets, watchdogs, reads, waits, confirmations, manual, question;
static void halt(void) __attribute__((noreturn));
static void halt(void) {longjmp(halted, 1);}
static void value(const char *s, UINT64 v) {(void)s; (void)v;}
static void word(const char *s) {assert(!strcmp(s,"refusal-power-confirmed\n")); ++confirmations;}
#include "handler.h"

static EFI_STATUS EFIAPI watchdog(UINTN t,UINT64 code,UINTN n,CHAR16 *data){
    assert(!t && !code && !n && !data);
    ++watchdogs; return !strcmp(mode,"watchdog-error") ? EFI_DEVICE_ERROR : EFI_SUCCESS;
}
static EFI_STATUS EFIAPI clear(SIMPLE_TEXT_OUTPUT_INTERFACE *out){(void)out;return EFI_SUCCESS;}
static EFI_STATUS EFIAPI output(SIMPLE_TEXT_OUTPUT_INTERFACE *out,CHAR16 *s){
    (void)out;
    if(s[0]=='P' && s[1]=='C') ++manual;
    if(s[0]=='S') ++question;
    return !strcmp(mode,"write-error") ? EFI_DEVICE_ERROR : EFI_SUCCESS;
}
static EFI_STATUS EFIAPI input_reset(SIMPLE_INPUT_INTERFACE *in,BOOLEAN extended){
    (void)in;assert(!extended);
    if(question){
        ++confirmation_resets;
        if(!strcmp(mode,"refuse-confirm-reset"))return EFI_DEVICE_ERROR;
        if(!strcmp(mode,"queued-enter") && cursor==1){++cursor; ++dropped;}
    }
    return !strcmp(mode,"input-reset-error") ? EFI_DEVICE_ERROR : EFI_SUCCESS;
}
static EFI_STATUS EFIAPI wait_event(UINTN n,EFI_EVENT *e,UINTN *i){
    assert(n==1 && e && *e); assert(++waits<15); *i=0;
    return !strcmp(mode,"wait-error") ? EFI_DEVICE_ERROR : EFI_SUCCESS;
}
static EFI_STATUS EFIAPI read_key(SIMPLE_INPUT_INTERFACE *in,EFI_INPUT_KEY *key){
    (void)in;
    if(!strcmp(mode,"queued-enter") || !strcmp(mode,"refuse-confirm-reset")){
        /* Key 1 was queued before the first prompt. The other Enter (key 4)
         * arrives at the wait after the second prompt is displayed. */
        const EFI_INPUT_KEY trace[]={{SCAN_F10,0},{0,13},{SCAN_ESC,0},{SCAN_F10,0},{0,13}};
        assert(cursor<5);
        *key=trace[cursor++]; ++reads; return EFI_SUCCESS;
    }
    const EFI_INPUT_KEY seq[]={{0,0},{0,13},{SCAN_F10,0},{0,'y'},{SCAN_ESC,0},{0,13},{SCAN_F10,0},{0,13}};
    if(!strcmp(mode,"read-error"))return EFI_DEVICE_ERROR;
    assert((UINTN)reads<sizeof(seq)/sizeof(seq[0]));
    *key=seq[reads++];
    return reads==1 ? EFI_NOT_READY : EFI_SUCCESS;
}
static EFI_STATUS EFIAPI power(EFI_RESET_TYPE t,EFI_STATUS s,UINTN n,CHAR16 *data){
    assert(t==EfiResetShutdown && s==EFI_SUCCESS && n==0 && data==NULL);
    ++resets; if(strcmp(mode,"queued-enter") && strcmp(mode,"refuse-confirm-reset"))assert(reads==8); return EFI_DEVICE_ERROR;
}
int main(int argc,char**argv){
    assert(argc==2); mode=argv[1];
    EFI_BOOT_SERVICES bs={.SetWatchdogTimer=watchdog,.WaitForEvent=wait_event};
    EFI_RUNTIME_SERVICES rt={.ResetSystem=power};
    SIMPLE_TEXT_OUTPUT_INTERFACE out={.OutputString=output,.ClearScreen=clear};
    SIMPLE_INPUT_INTERFACE in={.Reset=input_reset,.ReadKeyStroke=read_key,.WaitForKey=(EFI_EVENT)&in};
    EFI_SYSTEM_TABLE st={.BootServices=&bs,.RuntimeServices=&rt,.ConIn=&in,.ConOut=&out};
    if(!strcmp(mode,"no-out"))st.ConOut=NULL;
    if(!strcmp(mode,"no-in"))st.ConIn=NULL;
    if(!strcmp(mode,"no-event"))in.WaitForKey=NULL;
    if(!setjmp(halted))allocation_refusal(&st);
    if(!strcmp(mode,"queued-enter") || !strcmp(mode,"refuse-confirm-reset")){
        printf("%s cursor=%d ignored=%d prompts=%d confirm_resets=%d shutdowns=%d\n",mode,cursor,dropped,question,confirmation_resets,resets);
        return 0;
    }
    int confirmed=!strcmp(mode,"confirmed-reset-returned");
    assert(watchdogs==1 && resets==confirmed && confirmations==confirmed);
    assert((manual>0)==!!st.ConOut);
    if(confirmed)assert(question==2);
    printf("%s watchdog=%d key_reads=%d requested_shutdown=%d halted=1\n",mode,watchdogs,reads,resets);
}

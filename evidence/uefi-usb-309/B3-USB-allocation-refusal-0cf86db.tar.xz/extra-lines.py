from pathlib import Path
import runpy
root=Path(__file__).resolve().parent
old=runpy.run_path(str(root/'source/prior_refusal_screen.py'))
new=runpy.run_path(str(root/'source/refusal_screen.py'))
names=['refused','confirm','cancelled','confirm-again']
keys=list(new['ACTIONS'])
for folder in ('prior-frames','checked-64'):
    rows=[]
    for i,n in enumerate(names):
        p=(root/folder/(n+'.ppm')).read_bytes()
        other=(root/folder/(names[i^1]+'.ppm')).read_bytes()
        action=keys[i%2]
        assert old['matches'](p,action) and new['matches'](p,action)
        for source in (p,other):
            extra=new['with_extra_action'](p,source)
            assert old['matches'](extra,action) and not new['matches'](extra,action)
    print(folder,'4 intact frames accepted; parent accepted 4 opposite actions and 4 duplicate actions; corrected checker rejected all 8.')

from pathlib import Path
import hashlib,json,runpy
root=Path(__file__).resolve().parent
reader=runpy.run_path(str(root/'source/refusal_screen.py'))
matches=reader['matches']
first='Press F10 to request power off.'
confirm='Switch off? Enter switches off. Esc cancels.'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def get(d):
    r=json.loads((d/'result.json').read_text())
    for s in r['snapshots']:
        assert sha(d/s['vars_snapshot'])==s['vars_sha256']
    assert sha(d/'internal.raw')==r['snapshots'][-1]['nvme_sha256']==r['snapshots'][0]['nvme_sha256']
    assert sha(d/'vars.fd')==r['snapshots'][-1]['vars_sha256']
    for a,b in zip(r['snapshots'],r['snapshots'][1:]):
        assert a['counters']['sentinel']==b['counters']['sentinel']
    return r
parent=get(root/'parent-no-input')
assert parent['exit']==0 and parent['keys_sent']==0 and any(x['event']=='SHUTDOWN' for x in parent['events'])
assert 'handoff-refused' in (root/'parent-no-input/firmware.txt').read_text() and 'PCP OS could not start.' not in (root/'parent-no-input/serial.txt').read_text()
idle=get(root/'revised-no-input')
assert idle['exit']==0 and idle['keys_sent']==0 and idle['no_input_seconds']>=310
assert not any(e['event'] in ('RESET','SHUTDOWN') for e in idle['events'])
assert matches((root/'revised-no-input/start.ppm').read_bytes(),first) and matches((root/'revised-no-input/end.ppm').read_bytes(),first)
assert (root/'revised-no-input/firmware.txt').read_text().splitlines()[-2:]==['handoff-refused','refusal_watchdog_status=0000000000000000']
img=json.loads((root/'revised-media/image.json').read_text())
old=json.loads((root/'old-src-media/image.json').read_text())
assert img['elf_sha256']==old['elf_sha256'] and img['measurement']==old['measurement'] and img['usb_sha256']!=old['usb_sha256']
assert len(parent['snapshots'])==len(idle['snapshots'])==2
for p in ['normal-std-128','normal-std-256','normal-virtio-vga-128','normal-ramfb-128','normal-ramfb-256']:
    d=root/p
    r=get(d)
    assert r['passed'] and r['exit']==0 and r['self_tests']==72 and r['usb_sha256_after']==img['usb_sha256']
    lines=(d/'serial.txt').read_text().splitlines()
    passes=[s for s in lines if s.startswith('  pass ')]
    assert len(passes)==72 and 'register of its own start, verification and stop' in passes[-1]
    assert any(img['measurement']+' (measured; equal' in line for line in lines)
    assert r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
for sub in ['fixed-64','checked-64']:
    here=root/sub
    r=get(here)
    assert r['passed'] and r['keys']==['ret','q','f10','y','esc','ret','f10','ret'] and r['usb_sha256']==img['usb_sha256']
    assert [x['data'] for x in r['events'] if x['event']=='SHUTDOWN']==[{'guest':True,'reason':'guest-shutdown'}]
    log=(here/'firmware.txt').read_text()
    assert 'owned-handoff' not in log and log.splitlines()[-3:]==['handoff-refused','refusal_watchdog_status=0000000000000000','refusal-power-confirmed']
    for name,action in [('refused',first),('confirm',confirm),('cancelled',first),('confirm-again',confirm)]:
        frame=(here/(name+'.ppm')).read_bytes()
        assert matches(frame,action)
        assert not matches(frame,first if action==confirm else confirm)
        magic,size,depth,pixels=frame.split(b'\n',3)
        width,height=map(int,size.split());stride=width*3
        blank=pixels[:3]*width
        groups=[]; g=[]
        for y in range(height):
            row=pixels[y*stride:(y+1)*stride]
            if row!=blank:g.append(y)
            elif g:groups.append(g);g=[]
        for band in groups[:4]:
            last=max(max(j for j in range(width) if pixels[y*stride+j*3:y*stride+j*3+3]!=pixels[:3]) for y in band)
            damaged=bytearray(pixels)
            for y in band:
                at=y*stride+last*3
                damaged[at:at+3]=pixels[:3]
            assert not matches(b'\n'.join([magic,size,depth,bytes(damaged)]),action)
print('Parent shutdown without input; revised refusal remained visible for at least 310 seconds.')
print('Two fresh QEMU refusal boots: eight intact frames accepted; eight wrong prompts and 32 clipped lines rejected.')
print('Five USB success profiles: 72 final passes, register closure, confirmed guest shutdown, idle internal NVMe.')

import hashlib,json,runpy,sys,zipfile
from pathlib import Path
d=Path(__file__).resolve().parent
reader=runpy.run_path(str(d/'source/refusal_screen.py'))
with zipfile.ZipFile(d/'hosted-slice.zip') as z:
    def raw(n):return z.read('usb-observations/'+n)
    p='allocation-refusal/'
    receipt=json.loads(raw(p+'result.json'))
    assert receipt['passed'] and receipt['keys']==['ret','q','f10','y','esc','ret','f10','ret']
    assert not any(receipt['interval']['counter_deltas']['sentinel'].values())
    assert hashlib.sha256(raw(p+'internal.raw')).hexdigest()==receipt['snapshots'][0]['nvme_sha256']==receipt['snapshots'][1]['nvme_sha256']
    for s in receipt['snapshots']:assert hashlib.sha256(raw(p+s['vars_snapshot'])).hexdigest()==s['vars_sha256']
    assert [e['data'] for e in receipt['events'] if e['event']=='SHUTDOWN']==[{'guest':True,'reason':'guest-shutdown'}]
    trace=raw(p+'firmware.txt').decode().splitlines()
    assert trace[-3:]==['handoff-refused','refusal_watchdog_status=0000000000000000','refusal-power-confirmed']
    keys=list(reader['ACTIONS'])
    for name,action in [('refused',0),('confirm',1),('cancelled',0),('confirm-again',1)]:
        f=raw(p+name+'.ppm')
        assert reader['matches'](f,keys[action]) and not reader['matches'](f,keys[1-action])
        print(name,'matched the local four rendered lines; pixel-identical:',f==(d/'checked-64'/(name+'.ppm')).read_bytes())
    for case in ['128','256','virtio-vga','ramfb-128','ramfb-256']:
        rs=json.loads(raw(case+'/result.json'))
        assert rs['passed'] and rs['self_tests']==72
    print('Five hosted profiles closed at 72. The refusal guest made zero internal block requests.')

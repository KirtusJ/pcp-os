static EFI_STATUS refusal_message(SIMPLE_TEXT_OUTPUT_INTERFACE *out, CHAR16 *action) {
    uefi_call_wrapper(out->ClearScreen, 1, out);
    EFI_STATUS s = uefi_call_wrapper(out->OutputString, 2, out,
        L"PCP OS could not start.\r\nFirmware could not reserve the memory needed by the kernel.\r\n"
        L"You can switch off the computer with its power button.\r\n");
    if (EFI_ERROR(s) || !action) return s;
    return uefi_call_wrapper(out->OutputString, 2, out, action);
}

static void allocation_refusal(EFI_SYSTEM_TABLE *system) __attribute__((noreturn));
static void allocation_refusal(EFI_SYSTEM_TABLE *system) {
    EFI_BOOT_SERVICES *bs = system->BootServices;
    SIMPLE_TEXT_OUTPUT_INTERFACE *out = system->ConOut;
    SIMPLE_INPUT_INTERFACE *in = system->ConIn;
    EFI_STATUS watchdog = uefi_call_wrapper(bs->SetWatchdogTimer, 4, 0, 0, 0, NULL);
    value("refusal_watchdog_status", watchdog);
    if (!out) halt();
    BOOLEAN confirm = FALSE;
    if (!EFI_ERROR(watchdog) && in && in->WaitForKey &&
        !EFI_ERROR(uefi_call_wrapper(in->Reset, 2, in, FALSE))) {
        BOOLEAN redraw = TRUE;
        for (;;) {
            if (redraw && EFI_ERROR(refusal_message(out, confirm
                    ? L"Switch off? Enter switches off. Esc cancels.\r\n"
                    : L"Press F10 to request power off.\r\n"))) break;
            redraw = FALSE;
            UINTN index;
            EFI_INPUT_KEY key;
            if (EFI_ERROR(uefi_call_wrapper(bs->WaitForEvent, 3, 1, &in->WaitForKey, &index))) break;
            EFI_STATUS s = uefi_call_wrapper(in->ReadKeyStroke, 2, in, &key);
            if (s == EFI_NOT_READY) continue;
            if (EFI_ERROR(s)) break;
            if ((!confirm && key.ScanCode == SCAN_F10) || (confirm && key.ScanCode == SCAN_ESC)) {
                confirm = !confirm;
                redraw = TRUE;
            } else if (confirm && key.ScanCode == 0 && key.UnicodeChar == CHAR_CARRIAGE_RETURN) {
                word("refusal-power-confirmed\n");
                uefi_call_wrapper(system->RuntimeServices->ResetSystem, 4, EfiResetShutdown, EFI_SUCCESS, 0, NULL);
                break;
            }
        }
    }
    refusal_message(out, NULL);
    halt();
}


from pathlib import Path
import hashlib,json,struct,sys,uuid
from PIL import Image
base=Path(sys.argv[1])
global_guid=uuid.UUID('8be4df61-93ca-11d2-aa0d-00e098032b8c').bytes_le
def valmap(buf):
    pos=(struct.unpack_from('<H',buf,48)[0]+28+3)&~3
    values={}
    while buf[pos:pos+2]==b'\xaa\x55':
        ns,ds=struct.unpack_from('<II',buf,pos+36)
        a=pos+60; end=a+ns+ds
        if buf[pos+2]==0x3f and buf[pos+44:pos+60]==global_guid:
            values[buf[a:a+ns-2].decode('utf-16le')]=buf[a+ns:end]
        pos=(end+3)&~3
    return values
def boot_names(buf):
    vals=valmap(buf)
    order=struct.iter_unpack('<H',vals['BootOrder'])
    names=[]
    for (num,) in order:
        data=vals[f'Boot{num:04X}']
        off=6
        while data[off:off+2]!=b'\x00\x00':off+=2
        names.append(data[6:off].decode('utf-16le'))
    return names
refhash=hashlib.sha256((base/'internal-original.raw').read_bytes()).hexdigest()
for p in sorted(base.glob('*/result.json')):
    r=json.loads(p.read_text()); d=p.parent
    s={s['stage']:s for s in r['snapshots']}
    assert r['exit']==0 and r['usb_before']==r['usb_after']
    assert hashlib.sha256((d/'internal.raw').read_bytes()).hexdigest()==refhash
    for stage,v in s.items():
        raw=(d/(stage+'-vars.fd')).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==v['vars_sha256'] and v['nvme_sha256']==refhash
        cs=v['counters']['sentinel']
        assert not any(n for k,n in cs.items() if 'wr_' in k or 'flush' in k or 'unmap' in k)
    def counts(key):
        cs=s[key]['counters']['sentinel'];return (cs['rd_operations'],cs['rd_bytes'])
    if 'menu' in s:
        order=boot_names((d/'menu-vars.fd').read_bytes())
        assert 'NVMe' in order[0] and 'USB HARDDRIVE' in order[1]
        assert all((d/'menu-vars.fd').read_bytes()==(d/(stage+'-vars.fd')).read_bytes() for stage in ['selected','end'])
        assert counts('menu')==counts('selected')==counts('end')==(48,359424)
        if d.name.startswith('refusal'):
            with Image.open(d/'selected.png') as sel, Image.open(d/'end.png') as end:
                assert sel.size==end.size and sel.convert('RGB').tobytes()==end.convert('RGB').tobytes()
            assert 'owned-handoff' not in (d/'firmware.txt').read_text()
        if d.name.startswith('accepted'):
            assert 'owned-handoff' in (d/'firmware.txt').read_text() and sum(l.startswith('  pass ') for l in (d/'end-serial.txt').read_text().splitlines())==66
        if len(s)>4:
            last=list(s)[-1];assert counts(last)==(58,574464)
        print(d.name,'NVMe first; USB second; internal read counts',[(k,counts(k)) for k in s])
    else:
        assert counts('end')==(22,270336)
        print(d.name,'unattended',counts('end'))

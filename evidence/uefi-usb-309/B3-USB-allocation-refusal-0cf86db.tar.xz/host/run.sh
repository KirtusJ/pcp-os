set -eu
sdk=$1
dest=$2
src=$(cd "$(dirname "$0")" && pwd)
cc -std=c11 -Wall -Wextra -Werror -DGNU_EFI_USE_MS_ABI -fshort-wchar -mno-red-zone -I"$sdk/include/efi" -I"$sdk/include/efi/x86_64" "$src/check.c" -o "$dest"
for mode in watchdog-error no-out no-in no-event input-reset-error write-error wait-error read-error confirmed-reset-returned; do "$dest" "$mode"; done

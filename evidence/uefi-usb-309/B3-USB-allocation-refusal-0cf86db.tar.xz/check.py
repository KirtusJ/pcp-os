import json
from pathlib import Path
import sys
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'src/examples/firmware-owned-uefi'))
import usb_trial
qemu='/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64'
ovmf=Path('/workspace/scratch/15ccefba7c7d/validation/pkg/root/usr/share/OVMF')
media=root/sys.argv[1]
usb_trial.allocation_refusal_trial(qemu,ovmf/'OVMF_CODE_4M.fd',ovmf/'OVMF_VARS_4M.fd',media/'usb.img',json.loads((media/'image.json').read_text()),root/sys.argv[2])

"""Replay the recorded USB, NVMe, firmware and UART observations from an extracted archive."""
import hashlib
import json
import re
import runpy
from pathlib import Path

ROOT = Path(__file__).resolve().parent
observer = runpy.run_path(str(ROOT / "src/examples/firmware-owned-uefi/usb_observer.py"))
reader = runpy.run_path(str(ROOT / "src/examples/tester-cd/check.py"))
glyphs = reader["kernel_glyphs"]()
def sha(data):
    return hashlib.sha256(data).hexdigest()
def text_at(frame, offset=0):
    header, dimensions, depth, pixels = frame.split(b"\n", 3)
    row = int(dimensions.split()[0]) * 3 * offset
    aligned = b"\n".join((header, dimensions, depth, pixels[row:] + pixels[:row]))
    return " ".join(" ".join(reader["read_screen"](aligned, glyphs)).split())
def read_json(file):
    return json.loads(file.read_text())

expected = [
    "the stop key ends a program that never yields, long before its budget",
    "a program the person stopped is STOPPED in the kernel's task table, as it is in what the kernel observed of it",
    "a program waiting in a read of the keyboard is woken by each key's interrupt and reads the keys in order: it idled until the first and exited 0 on the third",
    "the stop key ends a program that is asleep (for the longest sleep accepted: its deadline does not overflow) at once, and all its memory comes back",
    "the stop key ends a program that waits in a read of the keyboard; it had read Ctrl and Alt and was never handed Delete; all its memory comes back",
    "a stop key pressed before a program is started does not stop it",
]
for name in ("std-final", "ramfb-aligned"):
    folder = ROOT / name
    result = read_json(folder / "result.json")
    for tag, digest in result["frames"].items():
        assert sha((folder / (tag + ".ppm")).read_bytes()) == digest
    def frame(tag):
        return (folder / (tag + ".ppm")).read_bytes()
    first = text_at(frame("verification-before"))
    assert first == text_at(frame("verification-after"))
    assert "NOT VERIFIED: 6 of 71 self-tests failed." in first and "42 events" in first
    assert "chain is intact" in first and re.search(r"\b[0-9a-f]{64}\b", first)
    refusal = "Not started: the kernel did not verify itself, and starts no program."
    assert any(refusal in text_at(frame("refused"), offset) for offset in (0, 10))
    for tag in ("first-question", "second-question"):
        question = text_at(frame(tag))
        assert all(phrase in question for phrase in ("Switch PCP OS off?", "Enter switch off", "Esc go back"))
    assert "surf.elf" in text_at(frame("cancelled")).lower()
    snapshots = result["snapshots"]
    assert [s["stage"] for s in snapshots] == ["before", "home", "after-cancel", "shutdown"]
    internal = sha((folder / "internal.raw").read_bytes())
    for s in snapshots:
        data = (folder / s["vars_snapshot"]).read_bytes()
        assert s["nvme_sha256"] == internal and observer["variables"](data) == s["variables"]
    intervals = [observer["compare"](folder, a, b) for a, b in zip(snapshots, snapshots[1:])]
    assert result["intervals"] == intervals
    assert all(i["nvme_bytes_preserved"] and not any(i["counter_deltas"]["sentinel"].values()) for i in intervals)
    assert all(i["vars_bytes_changed"] == 0 for i in intervals[1:])
    assert [(event["data"]["guest"], event["data"]["reason"]) for event in result["events"]
            if event["event"] == "SHUTDOWN"] == [(True, "guest-shutdown")]
    lines = (folder / "serial.txt").read_text().splitlines()
    assert [line[7:] for line in lines if line.startswith("  FAIL ")] == expected == result["failures"]
    assert sum(line.startswith("  pass ") for line in lines) == result["passed"] == 66
    assert any("pass the kernel's register" in line for line in lines) and result["usb_unchanged"]
    assert not any("starting surf.elf" in line for line in lines)
    print(name, "66 passes, six named failures, refusal, cancel, guest shutdown and disk observations verified")

for profile, verdict in (("normal", "Verified: all 72 self-tests it ran passed."),
                          ("lost", "NOT VERIFIED: 6 of 72 self-tests failed.")):
    images = []
    for state in ("present", "absent"):
        folder = ROOT / "serial-new" / (profile + "-" + state)
        frame = (folder / "guest/stopped.ppm").read_bytes()
        screen = text_at(frame)
        result = read_json(folder / "result.json")
        assert verdict in screen and "Hold its power button until it goes dark." in screen
        assert sha(frame) == result["frame_sha256"] and result["qemu_running"]
        assert ("dev: isa-serial" in (folder / "qtree.txt").read_text()) == (state == "present")
        images.append(frame)
    assert images[0] == images[1]
    print(profile, "UART present and absent stopped framebuffers are identical")

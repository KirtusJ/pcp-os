from pathlib import Path
import subprocess,sys
here=Path(__file__).resolve().parent
source=(here/'arch.rs').read_text()
start=source.index('const COM1: u16')
end=source.index('/// Whether the processor says',start)
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=True)
(out/'probe.rs').write_text((here/'probe.rs').read_text()+'\n'+source[start:end])
subprocess.run(['rustc','--edition=2021','-O',str(out/'probe.rs'),'-o',str(out/'probe')],check=True)
subprocess.run([str(out/'probe')],check=True)

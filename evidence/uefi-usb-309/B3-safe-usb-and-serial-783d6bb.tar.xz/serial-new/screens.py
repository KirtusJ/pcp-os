"""Read the stopped screen of a guest with or without an emulated UART."""
import hashlib,json,runpy,subprocess,sys,time
from pathlib import Path
base=Path(__file__).resolve().parent
kind,serial_mode,qemu=sys.argv[1:]
out=base/(kind+'-'+serial_mode);out.mkdir()
path=base/'src/examples/tester-cd/check_stopped_screen.py'
s=path.read_text()
a=s.index('        end = time.monotonic() + 20\n');b=s.index('        self.rpc("qmp_capabilities")',a)
s=s[:a]+'        self.process.stdout.readline()\n'+s[b:]
s=s.replace('"unix:%s,server=on,wait=off" % sock','"stdio"').replace('stdout=subprocess.DEVNULL','text=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE')
for op,channel in (('readline','stdout'),('write','stdin'),('flush','stdin')):
    s=s.replace('self.stream.'+op+'(','self.process.'+channel+'.'+op+'(')
target='"image=%s desktop=%s" % (digest, mode)'
assert s.count(target)==1;s=s.replace(target,'"image=%s desktop=%s then=off" % (digest, mode)')
if serial_mode=='absent':
    target='"file:%s" % self.serial';assert s.count(target)==1;s=s.replace(target,'"none"')
api={'__name__':'test_observer','__file__':str(path)};exec(compile(s,str(path),'exec'),api)
guest=api['Guest'](qemu,base/'bin'/(kind+'.elf32'),'800x600','pc',out/'guest',api['CHECK']['kernel_glyphs']())
try:
    # Query the actual object tree as a check independent of the launch arguments.
    devices=guest.rpc('human-monitor-command',**{'command-line':'info qtree'})
    (out/'qtree.txt').write_text(devices)
    present='dev: isa-serial' in devices
    assert present==(serial_mode=='present')
    rows=guest.screen('stopped',lambda lines:any(api['STOPPED'] in row for row in lines),timeout=110)
    screen=api['text_of'](rows)
    verdict='NOT VERIFIED: 6 of 72 self-tests failed.' if kind=='lost' else 'Verified: all 72 self-tests it ran passed.'
    assert verdict in screen and api['POWER'] in screen and guest.running()
    serial=out/'guest/serial.txt'
    counts=None
    if present:
        log=serial.read_text().splitlines()
        counts=[sum(s.startswith('  pass ') for s in log),sum(s.startswith('  FAIL ') for s in log)]
        assert counts==([66,6] if kind=='lost' else [72,0])
    else:
        assert not serial.exists()
    result=dict(kind=kind,uart=present,screen=screen,serial_counts=counts,frame_sha256=hashlib.sha256((out/'guest/stopped.ppm').read_bytes()).hexdigest(),qemu_running=True)
    (out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
finally:
    guest.end()

use std::cell::RefCell;
#[derive(Default)]
struct Device {
    status: u8,
    first: Option<u8>,
    second: Option<u8>,
    scratch: u8,
    scratch_reads: usize,
    polls: usize,
    busy_remaining: usize,
    writes: Vec<(u16,u8)>,
}
thread_local! { static DEVICE:RefCell<Device> = RefCell::new(Device::default()); }
fn inb(p:u16)->u8{
    DEVICE.with_borrow_mut(|d| match p-COM1 {
        5 => {d.polls+=1;if d.busy_remaining>0 {d.busy_remaining-=1;0} else {d.status}},
        7 => {d.scratch_reads+=1;match d.scratch_reads {1=>d.first,2=>d.second,_=>None}.unwrap_or(d.scratch)},
        other=>panic!("unexpected read {other}"),
    })
}
fn outb(p:u16,value:u8) {
    DEVICE.with_borrow_mut(|d|{d.writes.push((p-COM1,value));if p==COM1+7{d.scratch=value;}});
}
fn start(label:&str,initial:u8,first:Option<u8>,second:Option<u8>,expected:&[(u16,u8)],ready:bool){
    SERIAL.store(false,std::sync::atomic::Ordering::SeqCst);
    DEVICE.with_borrow_mut(|d|*d=Device{status:initial,first,second,scratch:0x35,..Default::default()});
    serial_init();
    assert_eq!(serial_present(),ready);
    DEVICE.with_borrow(|d|{assert_eq!(d.writes,expected);assert_eq!(d.polls,1);
        println!("{label} init: status={initial:02x} accepted={ready} scratch_reads={} writes={:x?} retained_scratch={:02x}",d.scratch_reads,d.writes,d.scratch);});
}
fn put(label:&str,byte:u8,status:u8,busy:usize,reads:usize,sent:bool,ready:bool){
    let before=DEVICE.with_borrow_mut(|d|{d.status=status;d.busy_remaining=busy;(d.polls,d.writes.len())});
    serial_put(byte);
    DEVICE.with_borrow(|d|{
        let writes=&d.writes[before.1..]; assert_eq!(d.polls-before.0,reads);
        if sent {assert_eq!(writes,&[(0,byte)]);}else{assert!(writes.is_empty());}
        assert_eq!(serial_present(),ready);
        println!("{label} byte={byte:02x} last_status={status:02x} polls={} writes={writes:x?} still_enabled={ready}",d.polls-before.0);
    });
}
fn main(){
    let setup=[(7,0x5a),(7,0xa5),(1,0),(3,0x80),(0,1),(1,0),(3,3),(2,0xc7),(4,0xb)];
    start("absent",0xff,None,None,&[],false);
    put("absent, later byte",0x41,0xff,0,0,false,false);
    start("only first echo succeeds",0,None,Some(0x5a),&setup[..2],false);
    put("second echo failed, later byte",0x41,0x60,0,0,false,false);
    start("scratch fixed at zero",0,Some(0),Some(0),&setup[..1],false);
    start("scratch fixed at A5",0,Some(0xa5),Some(0xa5),&setup[..1],false);
    start("zero line status with both scratch echoes",0,None,None,&setup,true);
    put("never ready",0x41,0,0,1_000_000,false,false);
    put("ready after timed out",0x42,0x60,0,0,false,false);
    start("ready",0x60,None,None,&setup,true);
    put("first byte",0x41,0x60,0,1,true,true);
    put("ready on final poll",0x42,0x20,999_999,1_000_000,true,true);
    put("ready after final poll",0x43,0x20,1_000_000,1_000_000,false,false);
    put("following timed-out byte",0x44,0x60,0,0,false,false);
    start("line status changes to all ones",0x60,None,None,&setup,true);
    put("prior good byte",0x41,0x60,0,1,true,true);
    put("all ones, first byte",0x42,0xff,0,1,false,false);
    put("all ones, following byte",0x43,0xff,0,0,false,false);
    put("apparently ready after disappearance",0x44,0x60,0,0,false,false);
    start("absent pattern on final permitted poll",0x60,None,None,&setup,true);
    put("last sample is all ones",0x41,0xff,999_999,1_000_000,false,false);
    put("no polls after late absence",0x42,0x60,0,0,false,false);
}

set -eu
study=$(cd "$(dirname "$0")" && pwd)
rt=/workspace/scratch/6fbc6fd5187a/runtime
previous=/workspace/scratch/edecb50126f6/boot-audit/uefi-bios-regression
export CARGO_HOME="$previous/cargo" CARGO_NET_OFFLINE=true
export PATH="$rt/register-live/rust197/bin:$rt/register-live/rust197/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$previous/bin:$rt/root/usr/bin:$PATH"
export LD_LIBRARY_PATH="$rt/lib"
export PCPOS_KERNEL_STAGE="$1/stage"
cd "$study/src/PCP_OS_Rust/crates/pcpos-kernel"
sh run.sh build > "$study/kernel/build.log" 2>&1
cp target/pcpos-kernel.elf32 "$study/kernel/kernel.elf32"
python3 -B tools/measure.py "$study/kernel/kernel.elf32"

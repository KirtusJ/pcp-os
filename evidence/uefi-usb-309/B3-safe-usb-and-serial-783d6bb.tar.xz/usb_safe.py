from pathlib import Path
import argparse, hashlib, json, re, subprocess, sys, time
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'src/examples/firmware-owned-uefi'))
import usb_trial as usb
from usb_observer import capture,compare
p=argparse.ArgumentParser();p.add_argument('out',type=Path);p.add_argument('--video',default='std');p.add_argument('--qemu',required=True);p.add_argument('--firmware',type=Path,required=True);args=p.parse_args()
out=args.out.resolve();out.mkdir()
volume=root/'media/usb.img'; image=json.loads((root/'media/image.json').read_text())
cmd=usb.usb_command(args.qemu,args.firmware/'OVMF_CODE_4M.fd',args.firmware/'OVMF_VARS_4M.fd',volume,out,128,args.video)
serial=out/'serial.txt';trace=out/'firmware.txt'
record=dict(args=cmd,snapshots=[],actions=[],frames={})
def save(): (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
with (out/'qemu.stderr').open('wb') as err, subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
    try:
        mon=usb.OPTICAL['Monitor'](vm);rpc=mon.call;rpc('qmp_capabilities')
        record['media']=rpc('query-block');record['snapshots'].append(capture(rpc,out,'before'));rpc('cont')
        usb.OPTICAL['wait_for'](lambda:'it is in SAFE and starts no program' in serial.read_text(errors='replace'),'lost-key boot into safe mode',90)
        screen=usb.OPTICAL['DesktopScreens'](mon,out,20)
        def frame(name,condition):
            rows=screen.wait(name,lambda lines:condition(' '.join(' '.join(lines).split())))
            text=' '.join(' '.join(rows).split())
            (out/(name+'.txt')).write_text('\n'.join(rows)+'\n')
            record['frames'][name]=hashlib.sha256((out/(name+'.ppm')).read_bytes()).hexdigest()
            save();return text
        def key(name):
            mon.key(name);record['actions'].append(name);time.sleep(.20)
        def snap(name):
            rpc('stop');record['snapshots'].append(capture(rpc,out,name));rpc('cont')
        frame('home',lambda t:'Programs' in t)
        snap('home')
        key('f5')
        witness=lambda t:'NOT VERIFIED: 6 of 71 self-tests failed.' in t and "The register's chain is intact." in t and re.search(r'\b[0-9a-f]{64}\b',t)
        first=frame('verification-before',witness)
        key('esc');frame('home-return',lambda t:'Programs' in t and 'VERIFICATION' not in t)
        key('ret')
        frame('launcher',lambda t:'surf.elf' in t.lower() and 'disabled' in t.lower())
        key('ret')
        def refusal_text(regular_rows,frame):
            sentence='Not started: the kernel did not verify itself, and starts no program.'
            if sentence in ' '.join(' '.join(regular_rows).split()):
                return True
            header,size,depth,pixels=frame.split(b'\n',3)
            width,height=map(int,size.split())
            offset=width*3*10
            shifted=b'\n'.join((header,size,depth,pixels[offset:]+pixels[:offset]))
            rows=screen.read(shifted,screen.glyphs) or []
            return 'Not started: the kernel did not verify itself, and starts no program.' in ' '.join(' '.join(rows).split())
        screen.wait_frame('refused',refusal_text)
        record['frames']['refused']=hashlib.sha256((out/'refused.ppm').read_bytes()).hexdigest()
        save()
        key('f5');second=frame('verification-after',witness)
        assert first==second
        key('esc');frame('launcher-return',lambda t:'surf.elf' in t.lower() and 'disabled' in t.lower())
        key('f10');question=lambda t:'Switch PCP OS off?' in t and 'Enter switch off' in t and 'Esc go back' in t
        frame('first-question',question);key('esc')
        frame('cancelled',lambda t:'surf.elf' in t.lower() and not question(t))
        snap('after-cancel')
        key('f10');frame('second-question',question);key('ret')
        usb.OPTICAL['wait_for'](lambda:rpc('query-status')['status']=='shutdown','confirmed shutdown',30)
        record['snapshots'].append(capture(rpc,out,'shutdown'));record['events']=list(mon.events)
        rpc('quit');record['qemu_exit']=vm.wait(timeout=10)
        record['intervals']=[compare(out,x,y) for x,y in zip(record['snapshots'],record['snapshots'][1:])]
        log=serial.read_text().splitlines()
        record['passed']=sum(s.startswith('  pass ') for s in log)
        record['failures']=[s[7:] for s in log if s.startswith('  FAIL ')]
        record['usb_unchanged']=usb.digest(volume)==image['usb_sha256']
        assert record['qemu_exit']==0 and record['passed']==66 and len(record['failures'])==6
        assert '6 SELF-TEST(S) FAILED' in log and any("pass the kernel's register" in s for s in log)
        assert not any('starting surf.elf' in s for s in log)
        assert any(image['measurement']+' (measured; equal' in s for s in log)
        assert [(e['data']['guest'],e['data']['reason']) for e in record['events'] if e['event']=='SHUTDOWN']==[(True,'guest-shutdown')]
        assert record['usb_unchanged'] and all(i['nvme_bytes_preserved'] and not any(i['counter_deltas']['sentinel'].values()) for i in record['intervals'])
        assert all(not i['vars_bytes_changed'] for i in record['intervals'][1:])
        record['verified']=True
    finally:
        save()
        if vm.poll() is None:vm.kill();vm.wait()

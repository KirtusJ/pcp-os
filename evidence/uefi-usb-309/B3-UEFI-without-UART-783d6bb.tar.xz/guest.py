"""Operate a USB boot from framebuffer observations with the emulated UART removed."""
from pathlib import Path
import hashlib, json, re, subprocess, sys, time

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "src/examples/firmware-owned-uefi"))
import usb_trial as fixture
from usb_observer import capture, compare

profile, qemu, firmware, dest = sys.argv[1:]
out = root / dest
out.mkdir()
media = root / ("media-" + profile)
image = json.loads((media / "image.json").read_text())
video = "std" if profile == "normal" else "ramfb"
fw = Path(firmware)
args = fixture.usb_command(qemu, fw / "OVMF_CODE_4M.fd", fw / "OVMF_VARS_4M.fd", media / "usb.img", out, 128, video)
args[args.index("-serial") + 1] = "none"
receipt = {"profile": profile, "args": args, "actions": [], "frames": {}, "snapshots": [], "image": image}
def save():
    (out / "result.json").write_text(json.dumps(receipt, indent=2) + "\n")
def flatten(rows):
    return " ".join(" ".join(rows).split())

with (out / "qemu.stderr").open("wb") as err, subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err) as vm:
    try:
        monitor = fixture.OPTICAL["Monitor"](vm)
        rpc = monitor.call
        rpc("qmp_capabilities")
        tree = rpc("human-monitor-command", **{"command-line": "info qtree"})
        (out / "qtree.txt").write_text(tree)
        assert "dev: isa-serial" not in tree
        receipt["media"] = rpc("query-block")
        assert any(d["device"] == "stick" and d["inserted"]["ro"] for d in receipt["media"])
        receipt["snapshots"].append(capture(rpc, out, "before"))
        screen = fixture.OPTICAL["DesktopScreens"](monitor, out, 60)
        def key(k):
            monitor.key(k)
            receipt["actions"].append(k)
            time.sleep(.25)
        def view(name, condition):
            rows = screen.wait(name, lambda rows: condition(flatten(rows)))
            (out / (name + ".txt")).write_text("\n".join(rows) + "\n")
            receipt["frames"][name] = fixture.digest(out / (name + ".ppm"))
            save()
            return rows
        def snapshot(name):
            rpc("stop")
            receipt["snapshots"].append(capture(rpc, out, name))
            rpc("cont")
        rpc("cont")
        view("home", lambda text: "Programs" in text)
        snapshot("home")
        key("f5")
        verdict = "Verified at start: all 71 self-tests passed." if profile == "normal" else "NOT VERIFIED: 6 of 71 self-tests failed."
        view("startup", lambda text: verdict in text and "chain is intact" in text and re.search(r"\b[0-9a-f]{64}\b", text))
        key("esc")
        view("returned", lambda text: "Programs" in text)
        key("ret")
        view("launcher", lambda text: "surf.elf" in text)
        key("ret")
        if profile == "normal":
            # The program switches to its own 640 by 360 graphics mode.
            # Read it as an image; the desktop font reader expects a larger screen.
            def application_visible():
                path = out / "playing.ppm"
                rpc("screendump", filename=str(path))
                frame = path.read_bytes()
                header, dimensions, depth, rgb = frame.split(b"\n", 3)
                if (header, dimensions, depth) != (b"P6", b"640 360", b"255") or len(rgb) != 640 * 360 * 3:
                    return False
                # Surfbird's local-media menu specifies these four RGB colors.
                expected = {(16, 42, 51), (112, 231, 227), (242, 246, 247), (203, 218, 221)}
                return set(zip(rgb[::3], rgb[1::3], rgb[2::3])) == expected
            fixture.OPTICAL["wait_for"](application_visible, "Surfbird graphical screen", 30)
            receipt["frames"]["playing"] = fixture.digest(out / "playing.ppm")
            save()
            time.sleep(1)
            key("spc")
            view("played", lambda text: "surf.elf" in text)
            key("f4")
            rows = view("register", lambda text: "chain intact" in text and "TASK_STARTED" in text and "TASK_ENDED" in text and "DONE" in text)
            started = [re.search(r'id (T\d+)', row)[1] for row in rows if 'TASK_STARTED' in row and 'label surf.elf' in row]
            ended = [m[1] for row in rows if (m := re.search(r'TASK_ENDED.*?id (T\d+).*?DONE', row))]
            assert len(started) == 1 and started[0] in ended, (started, ended)
            receipt["completed_task"] = started[0]
            key("esc")
            view("back-from-register", lambda text: "surf.elf" in text and "TASK_ENDED" not in text)
        else:
            view("refused", lambda text: "Not started: the kernel did not verify itself, and starts no program." in text)
        key("f10")
        question = lambda text: "Switch PCP OS off?" in text and "Enter switch off" in text and "Esc go back" in text
        view("first-question", question)
        key("esc")
        view("cancelled", lambda text: "surf.elf" in text and not question(text))
        snapshot("cancelled")
        key("f10")
        view("second-question", question)
        key("ret")
        fixture.OPTICAL["wait_for"](lambda: rpc("query-status")["status"] == "shutdown", "guest confirmed shutdown", 30)
        receipt["snapshots"].append(capture(rpc, out, "shutdown"))
        receipt["events"] = list(monitor.events)
        rpc("quit")
        receipt["qemu_exit"] = vm.wait(timeout=10)
        assert receipt["qemu_exit"] == 0
        assert [(e["data"]["guest"], e["data"]["reason"]) for e in receipt["events"] if e["event"] == "SHUTDOWN"] == [(True, "guest-shutdown")]
        stages = receipt["snapshots"]
        intervals = [compare(out, a, b) for a, b in zip(stages, stages[1:])]
        receipt["intervals"] = intervals
        assert all(i["nvme_bytes_preserved"] and not any(i["counter_deltas"]["sentinel"].values()) for i in intervals)
        assert all(i["vars_bytes_changed"] == 0 for i in intervals[1:])
        assert fixture.digest(media / "usb.img") == image["usb_sha256"] and not (out / "serial.txt").exists()
        receipt["verified"] = True
    finally:
        save()
        if vm.poll() is None:
            vm.kill()
            vm.wait()

"""Read the saved screen and storage evidence from the two UEFI boots without a UART."""
import hashlib
import json
from pathlib import Path
import re
import runpy

base = Path(__file__).resolve().parent
api = runpy.run_path(str(base / "src/examples/tester-cd/check.py"))
obs = runpy.run_path(str(base / "src/examples/firmware-owned-uefi/usb_observer.py"))
glyphs = api["kernel_glyphs"]()
def screen(file):
    return api["read_screen"](file.read_bytes(), glyphs)
def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()

for profile, directory in (("normal", "normal-final"), ("lost", "lost-guest")):
    folder = base / directory
    r = json.loads((folder / "result.json").read_text())
    assert r["verified"] and r["qemu_exit"] == 0 and r["profile"] == profile
    assert r["args"][r["args"].index("-serial") + 1] == "none"
    assert "dev: isa-serial" not in (folder / "qtree.txt").read_text()
    assert not (folder / "serial.txt").exists()
    assert any(d["device"] == "stick" and d["inserted"]["ro"] for d in r["media"])
    assert [s["stage"] for s in r["snapshots"]] == ["before", "home", "cancelled", "shutdown"]
    for tag, digest in r["frames"].items():
        assert sha(folder / (tag + ".ppm")) == digest
    def contents(tag):
        return " ".join(" ".join(screen(folder / (tag + ".ppm"))).split())
    startup = contents("startup")
    assert re.search(r"\b[0-9a-f]{64}\b", startup) and "chain is intact" in startup
    for tag in ("first-question", "second-question"):
        t = contents(tag)
        assert all(s in t for s in ("Switch PCP OS off?", "Enter switch off", "Esc go back"))
    assert "surf.elf" in contents("cancelled")
    if profile == "normal":
        assert "Verified at start: all 71 self-tests passed." in startup
        h, size, depth, rgb = (folder / "playing.ppm").read_bytes().split(b"\n", 3)
        assert (h, size, depth) == (b"P6", b"640 360", b"255") and len(rgb) == 640 * 360 * 3
        assert set(zip(rgb[::3], rgb[1::3], rgb[2::3])) == {(16,42,51),(112,231,227),(242,246,247),(203,218,221)}
        rows = screen(folder / "register.ppm")
        starts = [re.search(r'id (T\d+)', row)[1] for row in rows if 'TASK_STARTED' in row and 'label surf.elf' in row]
        ends = [m[1] for row in rows if (m := re.search(r'TASK_ENDED\s+id (T\d+); outcome DONE', row))]
        assert len(starts) == 1 and starts[0] == r["completed_task"] and starts[0] in ends
    else:
        assert "NOT VERIFIED: 6 of 71 self-tests failed." in startup
        assert "Not started: the kernel did not verify itself, and starts no program." in contents("refused")
    for st in r["snapshots"]:
        assert sha(folder / "internal.raw") == st["nvme_sha256"]
        assert obs["variables"]((folder / st["vars_snapshot"]).read_bytes()) == st["variables"]
    intervals = [obs["compare"](folder, a, b) for a, b in zip(r["snapshots"], r["snapshots"][1:])]
    assert intervals == r["intervals"]
    assert all(i["nvme_bytes_preserved"] and not any(i["counter_deltas"]["sentinel"].values()) for i in intervals)
    assert all(i["vars_bytes_changed"] == 0 for i in intervals[1:])
    assert [(e["data"]["guest"], e["data"]["reason"]) for e in r["events"] if e["event"] == "SHUTDOWN"] == [(True, "guest-shutdown")]
    assert json.loads((base / ("media-" + profile) / "image.json").read_text()) == r["image"]
    print(profile, r["image"]["measurement"], "verified")

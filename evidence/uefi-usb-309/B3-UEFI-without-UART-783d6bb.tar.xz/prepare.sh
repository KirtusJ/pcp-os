set -eu
cd "$(dirname "$0")"
d=$(pwd)
b=$1
for kind in normal lost; do
  if test "$kind" = lost; then export PCPOS_KERNEL_FEATURES=lost-key-demo; else unset PCPOS_KERNEL_FEATURES; fi
  bash "$d/build-kernel.sh" "$b" > "$d/$kind.measure"
  cp "$d/kernel/kernel.elf32" "$d/kernel/$kind.elf32"
  python3 "$d/make_media.py" "$d/src" "$d/kernel/$kind.elf32" /workspace/scratch/6fbc6fd5187a/runtime/dist-landed/PCP-OS.iso /workspace/scratch/15ccefba7c7d/validation/pkg/root/usr "$d/media-$kind" > "$d/$kind-media.log" 2>&1
done

"""Observe first boot with xHCI USB input and no i8042, without injecting any keys."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('source','media','qemu','firmware','output'):
        p.add_argument(name,type=Path)
    a=p.parse_args()
    out=a.output.resolve()
    out.mkdir()
    sys.path.insert(0,str(a.source.resolve()/'examples/firmware-owned-uefi'))
    import usb_trial
    from usb_observer import capture,compare
    fw=a.firmware
    media=a.media.resolve()
    args=usb_trial.usb_command(str(a.qemu),fw/'OVMF_CODE_4M.fd',fw/'OVMF_VARS_4M.fd',media/'usb.img',out,128)
    pos=args.index('-machine')+1
    assert args[pos]=='q35'
    args[pos]='q35,i8042=off'
    args.extend(['-device','usb-kbd,id=external-usb-keyboard,bus=xhci.0'])
    receipt={'args':args}
    with (out/'stderr.txt').open('w') as err,subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
        try:
            mon=usb_trial.OPTICAL['Monitor'](vm)
            rpc=mon.call
            rpc('qmp_capabilities')
            receipt['usb_inventory']=rpc('human-monitor-command',**{'command-line':'info usb'})
            assert 'QEMU USB Keyboard, ID: external-usb-keyboard' in receipt['usb_inventory'] and 'QEMU USB MSD, ID: usb' in receipt['usb_inventory']
            before=capture(rpc,out,'before')
            rpc('cont')
            usb_trial.OPTICAL['wait_for'](lambda:rpc('query-status')['status']=='shutdown','unattended completion',60)
            rpc('screendump',filename=str(out/'shutdown.ppm'))
            after=capture(rpc,out,'shutdown')
            receipt.update(snapshots=[before,after],interval=compare(out,before,after),events=mon.events.copy())
            rpc('quit')
            receipt['exit']=vm.wait(timeout=10)
        finally:
            if vm.poll() is None:
                vm.kill()
                vm.wait()
            (out/'result.json').write_text(json.dumps(receipt,indent=2)+'\n')
    serial=(out/'serial.txt').read_text()
    trace=(out/'firmware.txt').read_text()
    digest=json.loads((media/'image.json').read_text())['measurement']
    assert digest+' (measured; equal' in serial
    assert 'owned-handoff' in trace and 'keyboard: no controller' in serial
    assert 'the self-tests that press keys were not run: there is no keyboard controller' in serial
    assert sum(x.startswith('  pass ') for x in serial.splitlines())==66
    assert 'ALL SELF-TESTS PASS.' in serial
    assert any(e['event']=='SHUTDOWN' and e['data']=={'guest':True,'reason':'guest-shutdown'} for e in receipt['events'])
    assert receipt['exit']==0 and receipt['interval']['nvme_bytes_preserved']
    assert not any(receipt['interval']['counter_deltas']['sentinel'].values())
    assert hashlib.sha256((media/'usb.img').read_bytes()).hexdigest()==json.loads((media/'image.json').read_text())['usb_sha256']
    print(receipt['usb_inventory'], 'USB boot, absent i8042: 66 final passes and guest-requested shutdown; no key injected')
if __name__=='__main__':
    main()

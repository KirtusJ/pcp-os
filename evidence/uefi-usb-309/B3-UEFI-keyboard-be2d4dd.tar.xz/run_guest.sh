set -eu
dir=$(cd "$(dirname "$0")" && pwd)
mode=$1
sdk=/workspace/scratch/15ccefba7c7d/validation/pkg/root/usr
qemu=/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64
public=/workspace/scratch/6fbc6fd5187a/pcp/PCP-OS.iso
python3 -B "$dir/make_media.py" "$dir/src" "$dir/$mode/kernel.elf32" "$public" "$sdk" "$dir/$mode/media" > "$dir/$mode/image-build.log" 2>&1
if [ "$mode" = no-replay ]; then
  if python3 -B "$dir/guest.py" "$dir/src" "$dir/$mode/media" "$qemu" "$sdk/share/OVMF" "$dir/$mode/stock-refusal" stock > "$dir/$mode/stock-refusal.log" 2>&1; then
    echo 'Original checker unexpectedly accepted the no-replay configuration' >&2
    exit 1
  fi
  rg -F 'ValueError: missing OVMF USB boot device or startup self-tests' "$dir/$mode/stock-refusal.log"
  profile=no-replay
else
  profile=stock
fi
python3 -B "$dir/guest.py" "$dir/src" "$dir/$mode/media" "$qemu" "$sdk/share/OVMF" "$dir/$mode/guest" "$profile"

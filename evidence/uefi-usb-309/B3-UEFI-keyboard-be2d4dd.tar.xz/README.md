# B3 keyboard coverage and UEFI USB observations

Tested kernel source be2d4dd42521b6d49f7cdc3ab0d39682db6f22d3. Each kernel was built locally in its ordinary layout and, separately, using the repository’s relocation patch for the guarded UEFI USB fixture. The x86-64 QEMU guests had no network. UEFI guests used Q35, standard VGA, 128 MiB, stock OVMF, a read-only boot image and a freshly created internal NVMe test disk.

| Q35 USB profile | Startup result | Closing result |
|---|---|---|
| Normal i8042 input and replay | 71 passes on F5 and serial | 72 on serial after register verification and confirmed F10 |
| Normal i8042 input, simulated refusal of test-key replay | 65 passes on F5 and serial, with the six-check skip explanation | 66 on serial after register verification and confirmed F10 |
| i8042 absent, xHCI USB keyboard and USB storage present | 65 serial pass records before the final register check. The kernel reported no keyboard controller and did not open the desktop | 66 on serial, followed by guest-requested shutdown with zero key events sent by the observer |

The USB-only case used the same default kernel and read-only USB image as the normal case. Its host-side device inventory identified the USB keyboard. This exercises the current VM’s post-handoff path. The physical EliteBook’s controller and firmware behavior remain unmeasured. All completed UEFI runs retained the USB and internal NVMe bytes. Their measured internal block request counters stayed at zero. In the interactive runs the OVMF variable store differed by 6,047 bytes by Home and by zero afterward. For the USB-only guest the 6,047-byte difference covers the entire boot-to-shutdown interval.

Comparing the full serial pass labels as multisets shows precisely six key-dependent results absent from each limited run. The seven retained checks include all three rejected-batch results, the 50 ms sleep result and the three task admission or frame recovery results. The original replay probe accepted five edited log pairs with incorrect coverage. Draft 8395a86 changed the check to compare identities and multiplicities. It accepted the unaltered pair and rejected all five controls. Its ordinary unmodified-input QEMU run also passed. The original stock USB runner’s 71-pass fixture remains separate. Its trial against the 65-pass guest refused at Home.

Four separately booted PC guests with the hypervisor flag withheld showed the final check count on the stopped screen. Counts matched final serial at both controller-absent sizes (66), with keyboard replay (72), and with test replay suppressed (66). Native frames were captured with QMP over standard I/O because this host refused the checker’s Unix-domain socket. The adapter preserved assertions, commands, inputs and capture order. The offline replay also verifies that all four frames reject a one-short expected count. None of these boots used physical media.

## Replay

From the extracted directory, run the following with Python 3 and NumPy. Keep assertions enabled.

    sha256sum --quiet -c SHA256SUMS
    python3 -B replay.py > repeated.json
    cmp readback.json repeated.json
    python3 -B checker/controls.py default/guest/serial.txt no-replay/guest/serial.txt > repeated-controls.txt
    cmp checker/control-results.txt repeated-controls.txt

The archive contains the guest captures, serial and firmware traces, original storage snapshots and after-run copies of the disposable internal disks. The two image receipts identify the USB and kernel bytes. The kernel and USB images are omitted. The build and runner scripts record tool paths used on the original host. For another host supply its own QEMU, OVMF, compiler and EFI prefix.

"""Exercise both CLI decisions on the same captured logs and controlled changes to named pass records."""
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
import json,runpy,sys
from unittest.mock import patch

def run(script, normal, limited):
    mod=runpy.run_path(str(script))
    def reply(log):
        return 33,log,sum(line.startswith('  pass ') for line in log.splitlines())
    output=StringIO()
    rc=0
    with patch.dict(mod['main'].__globals__,boot=lambda *args: next(answers)), patch.object(sys,'argv',[str(script),'default','demo']), redirect_stdout(output):
        answers=iter((reply(normal),reply(limited)))
        try: mod['main']()
        except SystemExit as e: rc=e.code
    return rc,output.getvalue().strip()

def replace_pass(log, old, new):
    text='  pass '+old+'\n'
    assert text in log
    return log.replace(text,'  pass '+new+'\n',1)

base=Path(__file__).resolve().parent
normal=Path(sys.argv[1]).read_text()
limited=Path(sys.argv[2]).read_text()
match=runpy.run_path(str(base/'replay_probe.py'))
keys=match['KEY_CHECKS']
common=list(match['REPLAY_INDEPENDENT'])
by_name=match['pass_inventory']
assert sum(by_name(normal).values())==72 and sum(by_name(limited).values())==66
cases={
    'intact':(normal,limited),
    'omitted name admission replaced with key-dependent pass':(normal,replace_pass(limited,common[2],keys[0])),
    'missing third batch result masked by duplicate sleep':(normal,replace_pass(limited,common[0],common[1])),
    'same shared loss from both runs':(replace_pass(normal,common[0],common[1]),replace_pass(limited,common[0],common[1])),
    'both runs contain same unexpected duplicate of a key check':(normal+'  pass '+keys[0]+'\n',limited+'  pass '+keys[0]+'\n'),
    'wrong unrelated shared-test identity in one run':(normal,replace_pass(limited,normal.split('  pass ')[1].splitlines()[0],'substitute'))
}
for name,(a,b) in cases.items():
    old,_=run(base/'original.py',a,b)
    new,detail=run(base/'replay_probe.py',a,b)
    assert old==0 and new==int(name!='intact'),(name,old,new,detail)
    print(f'{name}: original {old}, proposed {new}')

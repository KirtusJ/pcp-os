"""Run the pinned stopped-screen check using a QMP pipe on a host without AF_UNIX."""
from pathlib import Path
import sys
base=Path(__file__).resolve().parent
file=base/'src/examples/tester-cd/check_stopped_screen.py'
source=file.read_text()
start=source.index('        end = time.monotonic() + 20\n')
end=source.index('        self.rpc("qmp_capabilities")',start)
source=source[:start]+'        self.process.stdout.readline()\n'+source[end:]
source=source.replace('"unix:%s,server=on,wait=off" % sock','"stdio"')
source=source.replace('stdout=subprocess.DEVNULL','text=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE')
source=source.replace('self.stream.write(', 'self.process.stdin.write(').replace('self.stream.flush()', 'self.process.stdin.flush()').replace('self.stream.readline()', 'self.process.stdout.readline()')
exec(compile(source,str(file),'exec'),{'__name__':'__main__','__file__':str(file)})

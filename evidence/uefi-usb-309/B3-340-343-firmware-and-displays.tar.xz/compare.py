"""Compare the sole operator display when both the serial port and the keyboard may be unavailable."""
from pathlib import Path
import hashlib
import json
import sys

base = Path(__file__).resolve().parent
mode, qemu = sys.argv[1:]
profiles = [("absent", "default", "pc,i8042=off", "no controller"),
            ("busy", "keyboard-busy-demo", "pc", "a controller is there but did not take its set-up in time; it is not used"),
            ("silent", "keyboard-silent-demo", "pc", "the controller is set up but the keyboard did not acknowledge; it is not used"),
            ("ready", "default", "pc", "a PS/2 controller answered")]
assert mode in ("measured", "mismatch")
out = base / mode
out.mkdir()
path = base / "src/examples/tester-cd/check_stopped_screen.py"
s = path.read_text()
a = s.index("        end = time.monotonic() + 20\n")
b = s.index('        self.rpc("qmp_capabilities")', a)
s = s[:a] + "        self.process.stdout.readline()\n" + s[b:]
s = s.replace('"unix:%s,server=on,wait=off" % sock', '"stdio"').replace(
    "stdout=subprocess.DEVNULL", "text=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE")
for op, channel in (("readline", "stdout"), ("write", "stdin"), ("flush", "stdin")):
    s = s.replace("self.stream." + op + "(", "self.process." + channel + "." + op + "(")
arg = '"image=%s desktop=%s" % (digest, mode)'
assert s.count(arg) == 1
digest = "digest" if mode == "measured" else '"0" * 64'
s = s.replace(arg, '"image=%s desktop=%s then=off" % (' + digest + ', mode)')
controls = {}
for name, profile, machine, expected in profiles:
    pair = []
    for port in ("present", "absent"):
        src = s
        if port == "absent":
            target = '"file:%s" % self.serial'
            assert src.count(target) == 1
            src = src.replace(target, '"none"')
        api = {"__name__": "host_observer", "__file__": str(path)}
        exec(compile(src, str(path), "exec"), api)
        directory = out / (name + "-" + port)
        guest = api["Guest"](qemu, base / "bin" / (profile + ".elf32"), "320x200", machine, directory,
                             api["CHECK"]["kernel_glyphs"]())
        try:
            tree = guest.rpc("human-monitor-command", **{"command-line": "info qtree"})
            (directory / "qtree.txt").write_text(tree)
            assert ("dev: isa-serial" in tree) == (port == "present")
            assert not any(d.get("inserted") for d in guest.rpc("query-block"))
            rows = guest.screen("stopped", lambda rows: any(api["STOPPED"] in row for row in rows))
            text = api["text_of"](rows)
            assert guest.running() and "?" not in text and api["POWER"] in text
            if port == "present":
                lines = guest.serial.read_text().splitlines()
                assert guest.outcome() == expected
                passed = guest.passed()
                failed = sum(line.startswith("  FAIL ") for line in lines)
                assert (passed, failed) == ((40, 1) if mode == "mismatch" else (72 if name == "ready" else 66, 0))
                verdict = (f"NOT VERIFIED: {failed} of {passed+failed} self-tests failed." if failed
                           else f"Verified: all {passed} self-tests it ran passed.")
            else:
                assert not guest.serial.exists()
            assert verdict in text
            for outcome, reason in api["REASONS"].items():
                if reason:
                    assert text.count(reason) == int(outcome == expected)
            pair.append((directory / "stopped.ppm").read_bytes())
        finally:
            guest.end()
    assert pair[0] == pair[1]
    controls[name] = {"keyboard": expected, "verdict": verdict, "frame_sha256": hashlib.sha256(pair[0]).hexdigest()}
    (out / "result.json").write_text(json.dumps(controls, indent=2) + "\n")
    print(mode, name, verdict, flush=True)

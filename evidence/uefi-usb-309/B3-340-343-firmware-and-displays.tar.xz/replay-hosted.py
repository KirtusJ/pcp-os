"""Verify and replay the first independent keyboard/stopped-screen CI artifact for PR 340."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from zipfile import ZipFile

here = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve()
origin = json.loads((here / 'origin.json').read_text())
archive = here / 'hosted.zip'
assert archive.stat().st_size == origin['bytes']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == origin['artifact_sha256']
assert subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip() == origin['head']
with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    with ZipFile(archive) as z:
        assert z.testzip() is None
        for p in z.namelist():
            assert (tmp/p).resolve().is_relative_to(tmp)
        z.extractall(tmp)
    records = tmp / 'stopped-screen'
    original = (records/'capture-controls.json').read_bytes()
    subprocess.run([sys.executable,'-IB',repo/'examples/tester-cd/check_stopped_captures.py',records],check=True)
    assert (records/'capture-controls.json').read_bytes() == original
    report=json.loads(original)
    assert not report['failures'] and len(report['checks']) == 35 and len(report['skip_checks']) == 24
    print('Original and replayed capture controls match byte for byte.')

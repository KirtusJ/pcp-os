# Guarded firmware decisions and serial/no-serial display replay

The original guarded-UEFI traces and result.json files come from three SHA-256-verified Actions artifacts. The archived serial and JSON files are verbatim extracted records. Each run has the two candidate and two public-control machines at 128 and 256 MiB. Run python3 -B replay-firmware.py to check all twelve records. Place the original ZIPs alongside it under the names below to verify the archive hashes as well. The source filename of the failed record is guarded-uefi/candidate-256/serial.txt.

| Local ZIP | Run | Artifact | SHA-256 |
| --- | --- | --- | --- |
| failed.zip | 44967122946 attempt 1 | 14731764763 | eb05c0c388ec5eaf88ac3445be652751f4b8ea83793e07bfa38e77e776eba9d8 |
| pass.zip | 44967122946 attempt 2 | 14732155906 | 33e0566ac131dfc0990f09636d69d887bc58f2f913fae6be1bafb010767cde52 |
| ack.zip | 44968818717 | 14732742975 | d4701dedcb2c326e14245b84228d8cc6b0e4ff25d75b6a8dd2e1320e2bf17648 |

The first two runs tested PR 340 at 7b28989e7e658a89610768a7243492f7bcafbb51. The first failed record ends at the raw bytes ALLO without a handoff. The rerun completed both admitted boots. The third run tested PR 343 at 2ba076465150e21ff999844a2d738373c4f03567. All four cases explicitly acknowledge the final decision in the GRUB output. python3 -B check_handshake.py /path/to/343-checkout exercises both successful FIFO paths and three incomplete or mismatched transcripts against the actual code.

The keyboard/stopped-screen CI file hosted.zip is the original artifact 14731234340 from run 44967122897 on PR 340 at 7b28989. Run python3 -B replay-hosted.py /path/to/340-checkout for the original capture checker and a byte-for-byte comparison against the original control report.

For an independent readback of sixteen local boots, link the same 340 checkout into this directory as src and run python3 -B recheck.py. The kernels at bin/ were built from fresh, separate stages using Rust 1.97.0. There are four keyboard profiles, with and without a serial port, run with the correct measurement and with a deliberate mismatched measurement. Each pair's 320x200 screen is compared byte for byte. compare.py is the actual QEMU observer using the repository's checker over QMP stdio. These are emulated hardware tests.

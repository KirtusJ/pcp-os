"""Check the serial and result evidence from the failed run, its rerun and the acknowledgment change."""
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parent
expected = {
    "failed": "eb05c0c388ec5eaf88ac3445be652751f4b8ea83793e07bfa38e77e776eba9d8",
    "pass": "33e0566ac131dfc0990f09636d69d887bc58f2f913fae6be1bafb010767cde52",
    "ack": "d4701dedcb2c326e14245b84228d8cc6b0e4ff25d75b6a8dd2e1320e2bf17648",
}
for run, digest in expected.items():
    file=root/(run+".zip")
    archive=None
    if file.exists():
        assert hashlib.sha256(file.read_bytes()).hexdigest()==digest
        archive=ZipFile(file)
        assert archive.testzip() is None
    for ram in (128, 256):
        for variant, word in (("public","DENY"),("candidate","ALLOW")):
            name=f"guarded-uefi/{variant}-{ram}"
            def read(member):
                if archive:
                    data=archive.read(name+"/"+member)
                    copies=root/"original-records"/run/name
                    copies.mkdir(exist_ok=True,parents=True)
                    (copies/member).write_bytes(data)
                    return data
                return (root/"original-records"/run/name/member).read_bytes()
            serial=read("serial.txt")
            report=json.loads(read("result.json"))
            assert report["ram_mib"] == ram
            tail=serial.split(b"AWAIT-PLACEMENT",1)[1]
            handoff=b"ATTEMPT-HANDOFF" in tail
            kernel=b"PCP OS kernel" in tail
            if run=="failed" and variant=="candidate" and ram==256:
                assert len(serial)==7545 and tail==b"\n\rALLO" and not handoff and not kernel
                print(run,variant,ram,"ends at ALLO, before handoff")
                continue
            assert tail.lstrip(b"\n\r").startswith(word.encode())
            if run=="ack":
                marker=("PLACEMENT-DECISION-"+word).encode()
                assert tail.splitlines().count(marker)==1 and report["placement_decision"]==word
            if variant=="public":
                assert not handoff and not kernel and not report["admitted"]
            else:
                if run=="ack": assert tail.index(marker) < tail.index(b"ATTEMPT-HANDOFF") < tail.index(b"PCP OS kernel")
                assert handoff and kernel and report["admitted"] and report["startup_passes"]==71 and report["shutdown"]
                assert report["nvs_before"]==report["nvs_at_launcher"]==report["nvs_before_shutdown"]
            print(run,variant,ram,word,"handoff" if handoff else "halted before handoff")
    if archive: archive.close()

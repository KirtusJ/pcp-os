from pathlib import Path
import hashlib, json, runpy
root = Path(__file__).resolve().parent
api = runpy.run_path(str(root/"src/examples/tester-cd/check_stopped_screen.py"))
glyphs = api["CHECK"]["kernel_glyphs"]()
for mode in ("measured", "mismatch"):
    records = json.loads((root/mode/"result.json").read_text())
    assert set(records) == {"ready","absent","busy","silent"}
    for name, record in records.items():
        host = root/mode/(name+"-present")
        bare = root/mode/(name+"-absent")
        frame = (host/"stopped.ppm").read_bytes()
        assert frame == (bare/"stopped.ppm").read_bytes() and frame.split(b"\n",2)[1] == b"320 200"
        assert hashlib.sha256(frame).hexdigest() == record["frame_sha256"]
        assert "dev: isa-serial" in (host/"qtree.txt").read_text() and "dev: isa-serial" not in (bare/"qtree.txt").read_text()
        assert not (bare/"serial.txt").exists()
        lines = (host/"serial.txt").read_text().splitlines()
        passes = sum(s.startswith("  pass ") for s in lines)
        fails = sum(s.startswith("  FAIL ") for s in lines)
        assert (passes, fails) == ((40, 1) if mode == "mismatch" else (72 if name == "ready" else 66, 0))
        assert [l for l in lines if l.startswith("keyboard: ")] == ["keyboard: " + record["keyboard"]]
        text = api["text_of"](api["PINS"]["read"](frame,glyphs))
        verdict = f"NOT VERIFIED: {fails} of {passes+fails} self-tests failed." if fails else f"Verified: all {passes} self-tests it ran passed."
        assert verdict == record["verdict"] and verdict in text and api["POWER"] in text and "?" not in text
        for outcome,reason in api["REASONS"].items():
            if reason:
                assert text.count(reason) == int(outcome == record["keyboard"])
    print(mode, "four pairs of 320x200 screens verified")

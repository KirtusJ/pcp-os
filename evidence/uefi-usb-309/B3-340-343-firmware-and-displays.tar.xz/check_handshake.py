import os
import select
import sys
import tempfile
import threading
import time
from pathlib import Path
sys.path.insert(0,str(Path(sys.argv[1]).resolve() / "examples/guarded-uefi"))
import trial

real_until = trial.until
def short_until(predicate, description, vm):
    return real_until(predicate, description, vm, seconds=1.5)
trial.until = short_until

class VM:
    def poll(self):
        return None

for word, outcome in ((b"ALLOW","ok"),(b"DENY","ok"),(b"ALLOW","missing-final-echo"),(b"DENY","wrong-confirmation"),(b"ALLOW","unterminated-confirmation")):
    with tempfile.TemporaryDirectory() as tmp:
        serial=Path(tmp)/"serial.txt"; pipe=Path(tmp)/"input"
        os.mkfifo(pipe);serial.write_bytes(b"firmware\n\rAWAIT-PLACEMENT\n\r")
        failures=[]
        def reader():
            try:
                with pipe.open("rb",buffering=0) as src, serial.open("ab",buffering=0) as output:
                    for i,c in enumerate(word):
                        assert src.read(1)==bytes([c])
                        assert not select.select([src],[],[],0.025)[0], "another byte preceded the current echo"
                        if outcome=="missing-final-echo" and i==len(word)-1:
                            return
                        output.write(bytes([c]))
                    assert src.read(1)==b"\r"
                    final=word if outcome!="wrong-confirmation" else b"UNEXPECTED"
                    output.write(b"\n\rPLACEMENT-DECISION-"+final)
                    if outcome!="unterminated-confirmation":
                        output.write(b"\n\r")
            except BaseException as exc:
                failures.append(exc)
        thread=threading.Thread(target=reader);thread.start()
        try:
            result=trial.confirm_decision(word,pipe,serial,VM())
            assert outcome=="ok" and result==word.decode()
        except TimeoutError as exc:
            assert outcome!="ok" and ("echo" if outcome=="missing-final-echo" else "confirmation") in str(exc)
        thread.join(2);assert not thread.is_alive() and not failures,failures
        print(word.decode(),outcome,"passed")

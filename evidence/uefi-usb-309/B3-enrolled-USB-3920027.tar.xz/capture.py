from pathlib import Path
import hashlib,json,re,runpy,shutil,subprocess,time

here=Path(__file__).resolve().parent
base=Path('/workspace/scratch/15ccefba7c7d')
root=base/'validation/pkg/root/usr/share'
selected=root/'qemu/firmware/40-edk2-x86_64-secure-enrolled.json'
fd=json.loads(selected.read_text())
mapping=fd['mapping']
assert {'requires-smm','secure-boot','enrolled-keys'}<=set(fd['features'])
firmware=root/'OVMF'/Path(mapping['executable']['filename']).name
template=root/'OVMF'/Path(mapping['nvram-template']['filename']).name
qemu=base/'validation/bin/qemu-system-x86_64';media=here.parent/'usb-build/fixtures/usb.img'
pin=json.loads((here.parent/'usb-build/fixtures/image.json').read_text())
out=here/'result';out.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert pin['usb_sha256']==sha(media)
nvram=out/'private-enrolled-vars.fd';shutil.copyfile(template,nvram)
serial=out/'serial.txt';diag=out/'firmware-debugcon.txt'
cmd=[str(qemu),'-machine','q35,smm=on','-accel','tcg','-cpu','max','-m','256M','-smp','1',
     '-global','driver=cfi.pflash01,property=secure,value=on','-nic','none','-vga','std','-display','none','-monitor','none','-qmp','stdio',
     '-serial','file:'+str(serial),'-debugcon','file:'+str(diag),'-global','isa-debugcon.iobase=0xe9',
     '-drive',f'if=pflash,unit=0,format=raw,readonly=on,file={firmware}',
     '-drive',f'if=pflash,unit=1,format=raw,file={nvram}','-device','qemu-xhci,id=xhci',
     '-drive',f'if=none,id=stick,format=raw,readonly=on,file={media}',
     '-device','usb-storage,bus=xhci.0,id=usb,drive=stick,removable=on,bootindex=1','-boot','strict=on','-S','-no-reboot']
r={'command':cmd,'platform':'Q35/TCG, one CPU, 256 MiB, Secure Boot, factory MS-enrolled OVMF, no guest NIC or internal storage',
   'qemu_version':subprocess.check_output([str(qemu),'--version'],text=True).splitlines()[0],
   'ovmf_version':'2025.02-8+deb13u1','firmware_selection':fd,'firmware_sha256':sha(firmware),'initial_private_vars_sha256':sha(nvram),
   'template_sha256':sha(template),'usb_before_sha256':sha(media),'efi_sha256':pin['efi_sha256'],
   'source_head':'39200277158b3b6c5d6d3b9fda9f62463768ab37','same_usb_ordinary_boot':'../../usb-build/results/std-256/result.json'}
with (out/'stderr.txt').open('wb') as err:
 vm=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err)
 try:
  q=runpy.run_path(str(base/'usb-published/examples/optical-disk-check/check.py'))['Monitor'](vm)
  q.call('qmp_capabilities')
  blocks=q.call('query-block');r['blocks']=blocks
  stick=next(b for b in blocks if b['device']=='stick');assert stick['removable'] and stick['inserted']['ro'] and Path(stick['inserted']['file'])==media
  r['usb_devices']=q.call('human-monitor-command',**{'command-line':'info usb'})
  q.call('cont');t0=time.monotonic();line=None
  while time.monotonic()-t0<60:
   text=re.sub(r'\x1b\[[0-9;=?]*[A-Za-z]','',serial.read_text(errors='replace')) if serial.exists() else ''
   for s in text.splitlines():
    if re.search(r'failed to load Boot[0-9a-f]+ .*USB.*: (Access Denied|Security Violation)$',s,re.I):
     line=s;break
   if (line and 'No bootable option or device was found.' in text) or vm.poll() is not None:break
   time.sleep(.12)
  r['seconds_to_outcome']=round(time.monotonic()-t0,2);r['firmware_line']=line
  r['pcpos_kernel_banner_seen']='PCP OS kernel ' in text
  r['usb_loader_trace']=diag.read_text(errors='replace') if diag.exists() else ''
  r['vm_status_before_host_stop']=q.call('query-status')
  q.call('screendump',filename=str(out/'console.ppm'));r['console_p6_sha256']=sha(out/'console.ppm')
  r['events_before_host_stop']=q.events.copy()
  q.call('quit');r['host_stop_exit']=vm.wait(timeout=10)
 finally:
  if vm.poll() is None:vm.kill();vm.wait()
  r['usb_after_sha256']=sha(media);r['template_after_sha256']=sha(template);r['private_vars_after_sha256']=sha(nvram)
  (out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
assert line and not r['pcpos_kernel_banner_seen'] and r['usb_before_sha256']==r['usb_after_sha256'] and sha(template)==r['initial_private_vars_sha256']
print(line)

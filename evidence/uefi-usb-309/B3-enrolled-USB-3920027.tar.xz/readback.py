from pathlib import Path
import hashlib,json,re,runpy,shutil,struct

base=Path(__file__).resolve().parent;root=Path('/workspace/scratch/15ccefba7c7d');out=base/'result'; fw=root/'validation/pkg/root/usr/share'
r=json.loads((out/'result.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
clean=re.sub(r'\x1b\[[0-9;=?]*[A-Za-z]','',(out/'serial.txt').read_text())
lines=clean.splitlines()
denied=next(x for x in lines if re.fullmatch(r'BdsDxe: failed to load Boot[0-9a-f]+ "UEFI QEMU QEMU USB HARDDRIVE [^"]+" from PciRoot\(0x0\)/Pci\(0x2,0x0\)/USB\(0x0,0x0\): Access Denied',x,re.I))
assert 'BdsDxe: No bootable option or device was found.' in lines and not r['pcpos_kernel_banner_seen'] and r['usb_loader_trace']==''
assert 'Access Denied' in (out/'console-ocr.txt').read_text() and sha((out/'console.ppm').read_bytes())==r['console_p6_sha256']
m=runpy.run_path(str(root/'usb-published/examples/firmware-owned-uefi/usb_observer.py'))['variables']
template=fw/'OVMF/OVMF_VARS_4M.ms.fd'; private=out/'private-enrolled-vars.fd'
before=m(template.read_bytes());after=m(private.read_bytes())
security={k:v for k,v in before.items() if k.split('/')[-1] in ('PK','KEK','db','dbx','SecureBootEnable','CustomMode')}
assert {k.split('/')[-1] for k in security}=={'PK','KEK','db','dbx','SecureBootEnable','CustomMode'} and all(after[k]==v for k,v in security.items())
assert next(v for k,v in security.items() if k.endswith('/SecureBootEnable'))['sha256']==sha(b'\x01')
assert next(v for k,v in security.items() if k.endswith('/CustomMode'))['sha256']==sha(b'\x00')
efi=(base/'verified-input.efi').read_bytes();pe=struct.unpack_from('<I',efi,0x3c)[0]; opt=pe+24
assert efi[pe:pe+4]==b'PE\0\0' and struct.unpack_from('<H',efi,opt)[0]==0x20b
certificate=struct.unpack_from('<II',efi,opt+112+8*4);assert certificate==(0,0)
assert sha(efi)==r['efi_sha256']
assert sha(template.read_bytes())==r['template_sha256']==r['initial_private_vars_sha256']==r['template_after_sha256']
assert sha((base.parent/'usb-build/fixtures/usb.img').read_bytes())==r['usb_before_sha256']==r['usb_after_sha256']
summary={'source_head':r['source_head'],'firmware_line':denied,'firmware_followup':lines[-2:],'qemu':r['qemu_version'],'ovmf':r['ovmf_version'],'firmware_fingerprint':r['firmware_sha256'],'factory_vars_sha256':r['template_sha256'],'factory_profile':r['firmware_selection']['description'],'usb_sha256_before_and_after':r['usb_after_sha256'],'bootx64_efi_sha256':sha(efi),'pe_certificate_table_offset_size':certificate,'secure_boot_enable':1,'custom_mode':0,'enrollment_variables_before_and_after':security,'loader_trace_bytes':0,'kernel_banner_seen':False,'framebuffer_sha256':r['console_p6_sha256'],'vm_end':'Host quit after firmware refused USB. QEMU was still running; no guest shutdown was claimed.','capture_note':'The capture accepted either Access Denied or Security Violation. The serial and framebuffer on this run reported Access Denied.'}
(out/'readback.json').write_text(json.dumps(summary,indent=2)+'\n')
shutil.copyfile(fw/'qemu/firmware/40-edk2-x86_64-secure-enrolled.json',out/'factory-profile.json')
print(denied,len(security))

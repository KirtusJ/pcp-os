"""Verify the refusal and the before/after enrolled OVMF variable stores offline."""
from pathlib import Path
import hashlib,json,re,struct
from usb_observer import variables
root=Path(__file__).resolve().parent
def data(path):return (root/path).read_bytes()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load(path):return json.loads(data(path))
r=load('result/result.json');ordinary=load('ordinary.json');receipt=load('image.json')
assert r['usb_before_sha256']==r['usb_after_sha256']==ordinary['usb_sha256_after']==receipt['usb_sha256']
assert r['efi_sha256']==receipt['efi_sha256']
assert 'enrolled-keys' in r['firmware_selection']['features']
assert ordinary['passed'] and ordinary['self_tests']==72 and ordinary['exit']==0
assert ordinary['shutdown']=={'guest':True,'reason':'guest-shutdown'}
assert r['host_stop_exit']==0 and r['vm_status_before_host_stop']['running'] and not r['pcpos_kernel_banner_seen']
assert not data('result/firmware-debugcon.txt') and 'PCP OS kernel ' not in data('result/serial.txt').decode()
assert re.search(r'BdsDxe: failed to load Boot[0-9a-f]+ "[^"\n]*USB[^"\n]+" from [^\n]+: Access Denied',data('result/serial.txt').decode(),re.I)
assert 'Access Denied' in data('result/console-ocr.txt').decode() and r['console_p6_sha256']==sha(data('result/console.ppm'))
header=data('efi-header.bin');pos=struct.unpack_from('<I',header,0x3c)[0]
assert header[pos:pos+4]==b'PE\0\0' and struct.unpack_from('<H',header,pos+24)[0]==0x20b
assert struct.unpack_from('<II',header,pos+24+112+32)==(0,0)
initial=data('factory-vars.fd');final=data('result/private-enrolled-vars.fd')
assert len(initial)==len(final) and sha(initial)==r['initial_private_vars_sha256']==r['template_after_sha256'] and sha(final)==r['private_vars_after_sha256']
a,b=variables(initial),variables(final)
names=lambda ks: sorted(k.split('/',1)[-1] for k in ks)
policy={'PK','KEK','db','dbx','SecureBootEnable','CustomMode'}
keys={k for k in a if k.split('/',1)[-1] in policy}
assert set(names(keys))==policy and all(a[k]==b[k] for k in keys)
assert next(a[k]['sha256'] for k in keys if k.endswith('/SecureBootEnable'))==sha(b'\x01')
assert next(a[k]['sha256'] for k in keys if k.endswith('/CustomMode'))==sha(b'\x00')
summary={'firmware_message':r['firmware_line'],'ordinary_guest_checks':ordinary['self_tests'],'unsigned_efi_sha256':r['efi_sha256'],
 'usb_sha256':r['usb_after_sha256'],'certificate_table':[0,0],'variables_changed_bytes':sum(x!=y for x,y in zip(initial,final)),
 'added':names(set(b)-set(a)),'removed':names(set(a)-set(b)),'modified':names(k for k in a.keys()&b.keys() if a[k]!=b[k]),
 'secure_boot_policy_unchanged':sorted(policy)}
print(json.dumps(summary,indent=2,sort_keys=True))

# Same virtual USB under ordinary and enrolled firmware

The existing QEMU USB fixture built from source commit 39200277158b3b6c5d6d3b9fda9f62463768ab37 was attached read-only. An ordinary stock Q35 guest reached Home and shut down after 72 checks. Another Q35 guest used Debian's factory Microsoft-enrolled OVMF configuration, a disposable copy of its variable store, and no internal disk. Both guests used the same USB SHA-256. No HP hardware was involved.

Firmware in the enrolled guest reported Access Denied for the USB. There was no loader trace or kernel banner. The host stopped the virtual machine at the firmware prompt. Comparison against the original variable store finds 3,509 changed bytes. BootOrder appeared, and Boot0001, ConIn, ConOut, ErrOut and MTC changed. The six recorded Secure Boot policy values were identical. Inspecting the full EFI executable extracted from the virtual FAT volume gave an empty PE certificate table. The archive contains its header and the full-file hash recorded during capture. The USB image and EFI application are omitted.

With Python 3 on an extracted copy, run:

    sha256sum --quiet -c SHA256SUMS
    python3 -B replay.py > repeated.json
    cmp repeated.json expected.json

The archive includes both variable-store images, original serial and framebuffer, the firmware configuration selector, a positive boot receipt and the unchanged tracked variable decoder. All variable-store data here belongs to disposable or publicly distributed virtual firmware. Physical machines may behave differently.

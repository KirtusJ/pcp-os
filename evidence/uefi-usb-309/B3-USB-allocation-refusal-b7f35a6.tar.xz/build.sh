set -eu
study=$(cd "$(dirname "$0")" && pwd)
rt=/workspace/scratch/6fbc6fd5187a/runtime
previous=/workspace/scratch/edecb50126f6/boot-audit/uefi-bios-regression
export CARGO_HOME="$previous/cargo" CARGO_NET_OFFLINE=true
export PATH="$rt/register-live/rust197/bin:$rt/register-live/rust197/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$previous/bin:$rt/root/usr/bin:$PATH"
export LD_LIBRARY_PATH="$rt/lib"
export PCPOS_KERNEL_STAGE="$study/stage"
cd "$study/src/PCP_OS_Rust/crates/pcpos-kernel"
for mode in default
do
  if [ "$mode" = "default" ]; then unset PCPOS_KERNEL_FEATURES; else export PCPOS_KERNEL_FEATURES=no-key-replay-demo; fi
  sh run.sh build > "$study/$mode/build.log" 2>&1
  cp target/pcpos-kernel.elf32 "$study/$mode/kernel.elf32"
  python3 -B tools/measure.py "$study/$mode/kernel.elf32"
done

from pathlib import Path
import json,sys
d=Path(__file__).resolve().parent
sys.path.insert(0,str(d/'src/examples/firmware-owned-uefi'))
import usb_trial
q='/workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64'
ovmf=Path('/workspace/scratch/15ccefba7c7d/validation/pkg/root/usr/share/OVMF')
m=d/'revised-media'
results=[]
for ram,video in [(128,'std'),(256,'std'),(128,'virtio-vga'),(128,'ramfb'),(256,'ramfb')]:
    r=usb_trial.trial(q,ovmf/'OVMF_CODE_4M.fd',ovmf/'OVMF_VARS_4M.fd',m/'usb.img',json.loads((m/'image.json').read_text()),d/f'normal-{video}-{ram}',ram,video)
    assert r['passed'] and r['self_tests']==72 and not any(any(i['counter_deltas']['sentinel'].values()) for i in r['intervals'])
    results.append(r.get('framebuffer_address'))
    print(ram,video,r['self_tests'],r.get('framebuffer_address'),flush=True)
assert results[-1]!=results[-2]

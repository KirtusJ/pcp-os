set -eu
w=$1
rt=/workspace/scratch/6fbc6fd5187a/runtime
export CARGO_HOME="$w/cargo" CARGO_NET_OFFLINE=true
export PATH="$rt/register-live/rust197/bin:$rt/register-live/rust197/lib/rustlib/x86_64-unknown-linux-gnu/bin/gcc-ld:$rt/root/usr/bin:$PATH"
export LD_LIBRARY_PATH="$rt/lib" PCPOS_KERNEL_STAGE="$(cat "$w/build-path")/stage"
cd "$w/fix/PCP_OS_Rust/crates/pcpos-kernel"
for kind in default no-key-replay-demo keyboard-busy-demo keyboard-silent-demo; do
    if test "$kind" = default;then unset PCPOS_KERNEL_FEATURES;else export PCPOS_KERNEL_FEATURES="$kind"; fi
    sh run.sh build > "$w/bin/$kind.log" 2>&1
    cp target/pcpos-kernel.elf32 "$w/bin/$kind.elf32"
    python3 tools/measure.py "$w/bin/$kind.elf32" > "$w/bin/$kind.measure"
done

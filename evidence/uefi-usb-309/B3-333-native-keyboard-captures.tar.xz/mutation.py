from pathlib import Path
import json, shutil, subprocess, sys, tempfile
root = Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as temp:
    work = Path(temp)
    shutil.copytree(root / 'fix', work / 'fix')
    output = work / 'guests'
    output.mkdir()
    for folder in (root / 'guests').iterdir():
        if folder.is_dir():
            (output / folder.name).symlink_to(folder, target_is_directory=True)
    file = work / 'fix/examples/tester-cd/check_stopped_screen.py'
    text = file.read_text()
    guard = '    if outcome is not None:'
    assert text.count(guard) == 1
    file.write_text(text.replace(guard, '    if False:  # H6 disabled only in this copy'))
    run = subprocess.run([sys.executable, '-IB', str(file.with_name('check_stopped_captures.py')), str(output)],
                         text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    report = json.loads((output / 'capture-controls.json').read_text())
    assert run.returncode == 1 and len(report['failures']) == 21
    assert report == json.loads((root / 'mutation-result.json').read_text())
    print('H6 disabled: 21 adverse captures were admitted and the checker failed')

"""Capture native logs for each of the three kernels; repeat every combined verdict from those records."""
import concurrent.futures,json,runpy,sys
from pathlib import Path
checker,out,qemu=map(Path,sys.argv[1:4]); kernels=list(map(Path,sys.argv[4:]))
api=runpy.run_path(str(checker))
out.mkdir()
def observe(entry):
    name,kernel=entry
    code,log,count=api['boot'](str(qemu),kernel,120)
    (out/f'{name}.txt').write_bytes(log.encode())
    return [code,count]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    meta=dict(zip(('normal','skipped','lost'),pool.map(observe,zip(('normal','skipped','lost'),kernels))))
(out/'outcomes.json').write_text(json.dumps(meta,indent=2)+'\n')
logs={k:(out/f'{k}.txt').read_text() for k in meta}
assert meta=={'normal':[33,72],'skipped':[33,66],'lost':[35,66]}
assert not api['coverage_problems'](api['pass_inventory'](logs['normal']),api['pass_inventory'](logs['skipped']))
assert not api['lost_key_problems'](35,logs['lost'],api['pass_inventory'](logs['skipped']))
print(meta)

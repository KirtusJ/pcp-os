from pathlib import Path
import collections,contextlib,io,json,runpy,sys
root=Path(__file__).resolve().parent
api=runpy.run_path(str(root/'replay_probe.py')); main=api['main']
normal=(root/'normal.txt').read_text(); demo=(root/'no-replay.txt').read_text(); lost=(root/'lost.txt').read_text()
keys=set(api['KEY_CHECKS']); passes=api['pass_inventory'](lost); failures=collections.Counter(x[len('  FAIL '):] for x in lost.splitlines() if x.startswith('  FAIL '))
assert set(failures)<=keys and set(passes)&keys and len(set(passes)&keys)==2
assert sum(passes.values())==68 and sum(failures.values())==4
print('Credited after zero scripted key deliveries:')
for key in sorted(keys & set(passes)): print(key)
print('Four key-dependent checks failed. The final register closure passed.')
def check(label,exitcode,losslog):
    cases=iter([(33,normal),(33,demo),(exitcode,losslog)])
    def recorded(*unused):
        code,log=next(cases)
        return code,log,sum(api['pass_inventory'](log).values())
    main.__globals__['boot']=recorded
    original=sys.argv;sys.argv=['replay_probe.py','normal','demonstration','--lost-keys','lost']
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            try: main();code=0
            except SystemExit as exit: code=exit.code
    finally:sys.argv=original
    print(label,code)
    return code
assert check('original',35,lost)==0
one='  FAIL '+sorted(failures)[0]+'\n'
assert check('unexpected exit 1 and truncated log',1,one)==0
assert check('terminated process and truncated log',-15,one)==0
assert check('successful exit deliberately conflicts with a failure',33,one)==1

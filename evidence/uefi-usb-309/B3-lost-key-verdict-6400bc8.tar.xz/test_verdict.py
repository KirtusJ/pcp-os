"""Read complete logs; challenge the final status, label inventory and register closure separately."""
import sys,runpy,re
from pathlib import Path
from collections import Counter
root=Path(sys.argv[1])
api=runpy.run_path(str(Path(sys.argv[2])))
base=(root/'lost.txt').read_text()
expected=api['pass_inventory']((root/'no-replay.txt').read_text())
keys=api['KEY_CHECKS']
check=lambda status,log:api['lost_key_problems'](status,log,expected)
assert check(35,base)
good=base
for label in keys: good=good.replace('  pass '+label+'\n','  FAIL '+label+'\n')
good=good.replace('4 self-test(s) failed','6 self-test(s) failed').replace('4 SELF-TEST(S) FAILED','6 SELF-TEST(S) FAILED')
if len(sys.argv)>3: good=Path(sys.argv[3]).read_text()
assert not check(35,good),check(35,good)
verdict='6 SELF-TEST(S) FAILED'
close="  pass the kernel's register of its own start, verification and stop verifies and replays without a problem"
head=next(s for s in good.splitlines() if s.startswith('kernel register:'))
independent=next(s for s in good.splitlines() if s.startswith('  pass '))
cases={
    'contradictory skip':(35,good.replace(verdict,api['NOT_RUN']+'\n'+verdict)),
    'unexpected exit':(1,good), 'process terminated':(-15,good), 'successful exit':(33,good),
    'truncated exit':(1,'  FAIL '+keys[0]+'\n'),
    'missing failure':(35,good.replace('  FAIL '+keys[0]+'\n','')),
    'duplicate failure':(35,good.replace('  FAIL '+keys[0],'  FAIL '+keys[1],1)),
    'key credited as pass':(35,good.replace('  FAIL '+keys[0],'  pass '+keys[0],1)),
    'missing independent pass':(35,good.replace(independent+'\n','',1)),
    'duplicate independent pass':(35,good.replace(independent,independent+'\n'+independent,1)),
    'missing closure':(35,good.replace(close+'\n','')),
    'missing final head':(35,good.replace(head+'\n','')),
    'head precedes closure':(35,good.replace(close+'\n'+head,head+'\n'+close)),
    'short digest':(35,good.replace(head,head[:-1])),
    'wrong failure total':(35,good.replace(verdict,'5 SELF-TEST(S) FAILED')),
    'contradictory verdicts':(35,good.replace(verdict,'ALL SELF-TESTS PASS\n'+verdict)),
    'duplicate verdict':(35,good.replace(verdict,verdict+'\n'+verdict)),
    'truncated before verdict':(35,good.split(verdict)[0]),
}
for name,(status,log) in cases.items():
    assert check(status,log),name
print(f'{len(cases)} altered outcomes rejected; complete six-failure control accepted')

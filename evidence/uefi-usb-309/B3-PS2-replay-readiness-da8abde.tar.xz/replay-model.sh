#!/bin/sh
set -eu
here=$(cd "$(dirname "$0")" && pwd)
dir=$(mktemp -d)
trap 'rm -rf "$dir"' EXIT
for version in original revised; do
    python3 "$here/extract.py" "$here/$version.rs" "$here/model.rs" > "$dir/$version.rs"
    rustc --edition 2021 "$dir/$version.rs" -o "$dir/$version"
done
"$dir/original" input-busy output-pending busy-after-command new-pending-byte > "$dir/original.txt"
"$dir/revised" > "$dir/revised.txt"
cmp "$here/original.txt" "$dir/original.txt"
cmp "$here/revised.txt" "$dir/revised.txt"

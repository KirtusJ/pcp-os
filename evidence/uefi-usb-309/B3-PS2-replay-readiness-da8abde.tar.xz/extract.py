"""Compile exactly the candidate's two Rust functions with the supplied host-only I/O model."""
from pathlib import Path
import sys
source=Path(sys.argv[1]).read_text()
model=Path(sys.argv[2]).read_text()
def function(name):
    start=source.index(name)
    end=source.index('\n}',start)+2
    return source[start:end]
print(model, function('fn controller_wait_write()'),function('pub fn keyboard_replays()'),sep='\n')

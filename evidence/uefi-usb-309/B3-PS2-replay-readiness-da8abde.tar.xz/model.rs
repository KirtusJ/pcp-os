use std::sync::atomic::{AtomicBool, AtomicU32, AtomicU64, Ordering};
use std::sync::Mutex;
static PROBE: AtomicU32 = AtomicU32::new(0);
static PROBE_HIT: AtomicBool = AtomicBool::new(false);
static TICKS: AtomicU64 = AtomicU64::new(0);
static READS: AtomicU32 = AtomicU32::new(0);
static COMMAND: AtomicBool = AtomicBool::new(false);
static IN_CRITICAL: AtomicBool = AtomicBool::new(false);
static MODE: AtomicU32 = AtomicU32::new(0);
static WRITES: Mutex<Vec<(u16,u8)>> = Mutex::new(Vec::new());

mod arch {
    use super::*;
    pub fn ticks() -> u64 { TICKS.load(Ordering::SeqCst) }
    pub fn wait_until(t:u64) { TICKS.store(t,Ordering::SeqCst); }
    pub fn without_interrupts<R>(f:impl FnOnce()->R)->R {
        IN_CRITICAL.store(true,Ordering::SeqCst);
        let r=f();
        IN_CRITICAL.store(false,Ordering::SeqCst);
        r
    }
}
fn keys_forget() {}
fn in8(port:u16)->u8 {
    assert_eq!(port,0x64);
    let read=READS.fetch_add(1,Ordering::SeqCst);
    let command=COMMAND.load(Ordering::SeqCst);
    match MODE.load(Ordering::SeqCst) {
        1=>2,      // input buffer stays full
        2=>1,      // unread byte never clears
        3 if command=>2,   // command accepted, then input buffer stays full
        4 if !command && read<3=>2, // delayed initial readiness
        5 if command && read<5=>2, // delayed parameter readiness
        6 if !command && IN_CRITICAL.load(Ordering::SeqCst)=>1,
        _=>0
    }
}
fn out8(port:u16,byte:u8) {
    WRITES.lock().unwrap().push((port,byte));
    if port==0x64 {
        assert_eq!(byte,0xd2);
        COMMAND.store(true,Ordering::SeqCst);
    } else {
        assert_eq!((port,byte),(0x60,0xf4));
        // Healthy and transient cases supply a synthetic match. The no-echo case does not.
        if matches!(MODE.load(Ordering::SeqCst),0|4|5) && PROBE.load(Ordering::SeqCst)==0x1f4 {
            PROBE.store(0,Ordering::SeqCst);
            PROBE_HIT.store(true,Ordering::SeqCst);
        }
    }
}
fn main(){
    let modes=["ready","input-busy","output-pending","busy-after-command","initially-busy","briefly-busy-after-command","new-pending-byte","no-echo"];
    let expected_bad:Vec<String>=std::env::args().skip(1).collect();
    let mut bad=Vec::new();
    for (i,label) in modes.iter().enumerate(){
        MODE.store(i as u32,Ordering::SeqCst);
        TICKS.store(0,Ordering::SeqCst);
        READS.store(0,Ordering::SeqCst);
        COMMAND.store(false,Ordering::SeqCst);
        PROBE.store(0,Ordering::SeqCst);
        PROBE_HIT.store(false,Ordering::SeqCst);
        WRITES.lock().unwrap().clear();
        let result=keyboard_replays();
        let writes=WRITES.lock().unwrap().clone();
        let expected:&[(u16,u8)] = match i {1|2|6=>&[],3=>&[(0x64,0xd2)],_=>&[(0x64,0xd2),(0x60,0xf4)]};
        let ok=writes==expected && result==matches!(i,0|4|5) && PROBE.load(Ordering::SeqCst)==0;
        println!("{label}: {writes:x?}, replay={result}, matches={ok}");
        if !ok {bad.push(label.to_string());}
    }
    assert_eq!(bad,expected_bad);
}

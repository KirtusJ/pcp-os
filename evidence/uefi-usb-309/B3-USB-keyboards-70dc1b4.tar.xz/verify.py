"""Verify all seven independent keyboard and firmware control guest records."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for sub in ('guests/ps2','guests/usb','guests/neither','guests/both','repeat/both','control/guests/usb','control/guests/neither'):
    folder = root / sub
    r = json.loads((folder / 'result.json').read_text())
    profile = folder.name
    usb = profile in ('usb','both')
    i8042 = profile in ('ps2','both')
    assert ('QEMU USB Keyboard' in r['usb_inventory']) == usb
    assert ('dev: i8042' in (folder/'machine.txt').read_text()) == i8042
    assert r['exit'] == 0 and r['shutdown'] == {'guest':True,'reason':'guest-shutdown'}
    assert r['usb_sha256'] == r['usb_after'] and r['disk_before'] == r['disk_after']
    firmware = (folder/'firmware.txt').read_text()
    if sub.startswith('control'):
        keys = [int(line.split('=')[1],16) for line in firmware.splitlines() if line.startswith('unicode=')]
        assert keys == r['codes'] == ([98,51] if usb else [])
        assert firmware.strip().endswith('KEYBOARD-CONTROL-END')
    else:
        assert r['usb_sha256'] == 'fe8bc66801f2eef6125bd03f7ec2b15fab1fc13307dd93a7f52c0cfdcdc827aa'
        serial = (folder/'serial.txt').read_text()
        assert 'owned-handoff' in firmware and 'Bochs, 1920x1080' in r['display']
        assert 'USB' in r['firmware_usb'] and r['firmware_usb'] in serial
        assert r['measurement']+' (measured; equal' in serial
        assert r['all_pass'] and 'ALL SELF-TESTS PASS.' in serial
        assert r['pass_lines'] == sum(line.startswith('  pass ') for line in serial.splitlines()) == (72 if i8042 else 59)
        assert bool(r['desktop']) == ('desktop: 1920x1080' in serial) == i8042
        if i8042:
            home = sha(folder/'kernel-display.ppm')
            assert home == sha(folder/'restored-home.ppm') != sha(folder/'verification.ppm')
            assert sha(folder/'verification.ppm') != sha(folder/'power.ppm')
            if usb:
                assert r['mixed_home_unchanged'] and home == sha(folder/'mixed-no-response.ppm')
            if sub.startswith('repeat'):
                assert home == sha(folder/'mixed-second-timeout.ppm') == sha(folder/'home-after-detach.ppm')
                assert 'QEMU USB Keyboard' not in r['usb_after_detach'] and 'QEMU USB MSD' in r['usb_after_detach']
        else:
            assert 'keyboard: no controller' in serial
    print(sub,'verified')

/* Read two keystrokes from the firmware console in a QEMU TCG guest. */
#include <efi.h>
#include <efilib.h>
#include <cpuid.h>

static int qemu_tcg(void) {
    unsigned a, b, c, d;
    __cpuid(1, a, b, c, d);
    if (!(c & (1u << 31))) return 0;
    __cpuid(0x40000000, a, b, c, d);
    return b == 0x54474354 && c == 0x43544743 && d == 0x47435447;
}

static void emit(char c) {
    __asm__ volatile("outb %0, %1" : : "a"(c), "Nd"((UINT16)0xe9));
}

static void text(const char *s) {
    while (*s) emit(*s++);
}

static void field(const char *name, UINT64 value) {
    static const char digits[] = "0123456789abcdef";
    text(name);
    emit('=');
    for (int shift = 60; shift >= 0; shift -= 4) emit(digits[(value >> shift) & 15]);
    emit('\n');
}

EFI_STATUS efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *system) {
    if (!qemu_tcg()) return EFI_UNSUPPORTED;
    InitializeLib(image, system);
    EFI_SIMPLE_TEXT_IN_PROTOCOL *console = system->ConIn;
    if (!console) return EFI_UNSUPPORTED;
    uefi_call_wrapper(console->Reset, 2, console, FALSE);
    text("KEYBOARD-CONTROL-READY\n");
    UINTN count=0;
    for (UINTN attempt=0; attempt<500 && count<2; ++attempt) {
        EFI_INPUT_KEY key;
        EFI_STATUS s=uefi_call_wrapper(console->ReadKeyStroke, 2, console, &key);
        if (s==EFI_SUCCESS) {
            field("scan",key.ScanCode);
            field("unicode",key.UnicodeChar);
            ++count;
        } else if (s!=EFI_NOT_READY) {
            field("read_status",s);
            break;
        }
        uefi_call_wrapper(system->BootServices->Stall, 1, 10000);
    }
    field("key_count",count);
    text("KEYBOARD-CONTROL-END\n");
    uefi_call_wrapper(system->RuntimeServices->ResetSystem,4,EfiResetShutdown,EFI_SUCCESS,0,NULL);
    return EFI_SUCCESS;
}

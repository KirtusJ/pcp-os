# Usage: sh build.sh GNU_EFI_PREFIX NEW_BUILD_DIRECTORY
set -eu
src=$(cd "$(dirname "$0")" && pwd)
prefix=$1
mkdir "$2"
cd "$2"
gcc -Wall -Wextra -Werror -fpic -fshort-wchar -fno-stack-protector -mno-red-zone -DEFI_FUNCTION_WRAPPER -I"$prefix/include/efi" -I"$prefix/include/efi/x86_64" -c "$src/probe.c" -o probe.o
ld -nostdlib -znocombreloc -T "$prefix/lib/elf_x86_64_efi.lds" -shared -Bsymbolic "$prefix/lib/crt0-efi-x86_64.o" probe.o -L"$prefix/lib" -lefi -lgnuefi -o probe.so
objcopy -j .text -j .rodata -j .sdata -j .data -j .dynamic -j .dynsym -j .rel -j .rela -j .reloc --target=efi-app-x86_64 probe.so BOOTX64.EFI
truncate -s 8M probe.img
mformat -i probe.img ::
mmd -i probe.img ::/EFI ::/EFI/BOOT
mcopy -i probe.img BOOTX64.EFI ::/EFI/BOOT/BOOTX64.EFI

"""Read b and 3 through OVMF before a kernel starts, with or without a USB keyboard."""
import argparse
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

p=argparse.ArgumentParser(description=__doc__)
for n in ('source','qemu','firmware','vars','image','out'):
    p.add_argument('--'+n, type=Path, required=True)
p.add_argument('profile',choices=('usb','neither'))
a=p.parse_args()
sys.path.insert(0,str(a.source.resolve()/'examples/firmware-owned-uefi'))
import usb_trial
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
image=a.image.resolve()
out=a.out.resolve()/a.profile
out.mkdir(parents=True,exist_ok=False)
cmd=usb_trial.usb_command(str(a.qemu.resolve()),a.firmware.resolve(),a.vars.resolve(),image,out,128)
cmd[cmd.index('q35')]='q35,i8042=off'
if a.profile=='usb':
    cmd.extend(['-device','usb-kbd,bus=xhci.0,port=2,id=keyboard'])
record={'profile':a.profile,'argv':cmd,'usb_sha256':sha(image),'firmware_sha256':sha(a.firmware),'vars_template_sha256':sha(a.vars),'disk_before':sha(out/'internal.raw')}
w=usb_trial.OPTICAL['wait_for']
with (out/'stderr.txt').open('wb') as errors:
    vm=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors)
    try:
        monitor=usb_trial.OPTICAL['Monitor'](vm);call=monitor.call
        call('qmp_capabilities')
        qtree=call('human-monitor-command',**{'command-line':'info qtree'})
        (out/'machine.txt').write_text(qtree)
        assert 'dev: i8042' not in qtree
        record['usb_inventory']=call('human-monitor-command',**{'command-line':'info usb'})
        assert ('QEMU USB Keyboard' in record['usb_inventory'])==(a.profile=='usb')
        assert next(b for b in call('query-block') if b['device']=='stick')['inserted']['ro']
        call('cont')
        trace=out/'firmware.txt'
        w(lambda:trace.is_file() and 'KEYBOARD-CONTROL-READY' in trace.read_text(),'firmware console ready',45)
        monitor.key('b')
        time.sleep(.25)
        monitor.key('3')
        w(lambda:call('query-status')['status']=='shutdown','diagnostic finished',20)
        record['shutdown']=next(e['data'] for e in monitor.events if e['event']=='SHUTDOWN')
        lines=trace.read_text().splitlines()
        record['codes']=[int(v.split('=')[1],16) for v in lines if v.startswith('unicode=')]
        assert lines[-1]=='KEYBOARD-CONTROL-END' and record['codes']==([98,51] if a.profile=='usb' else [])
        call('quit');record['exit']=vm.wait(timeout=10)
        assert record['shutdown']=={'guest':True,'reason':'guest-shutdown'} and record['exit']==0
    finally:
        if vm.poll() is None:vm.kill();vm.wait()
        record['disk_after']=sha(out/'internal.raw')
        record['usb_after']=sha(image)
        (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
assert record['disk_before']==record['disk_after'] and record['usb_sha256']==record['usb_after']
print(a.profile,record['codes'])

"""Read a stopped screen after a deliberately incorrect image measurement."""
from pathlib import Path
import argparse
import json
import re
import subprocess

root = Path(__file__).resolve().parent
source = root / "src/examples/tester-cd/check_stopped_screen.py"
code = source.read_text()
start = code.index('        end = time.monotonic() + 20\n')
end = code.index('        self.rpc("qmp_capabilities")', start)
code = code[:start] + "        self.process.stdout.readline()\n" + code[end:]
code = code.replace('"unix:%s,server=on,wait=off" % sock', '"stdio"').replace("stdout=subprocess.DEVNULL", "text=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE")
for method, handle in (("write", "stdin"), ("flush", "stdin"), ("readline", "stdout")):
    code = code.replace(f"self.stream.{method}(", f"self.process.{handle}.{method}(")
target = '"image=%s desktop=%s" % (digest, mode)'
assert code.count(target) == 1
code = code.replace(target, '"image=%s desktop=%s then=off" % ("0" * 64, mode)')
api = {"__name__": "host_observer", "__file__": str(source)}
exec(compile(code, str(source), "exec"), api)
p = argparse.ArgumentParser()
p.add_argument("kernel", type=Path)
p.add_argument("qemu")
a = p.parse_args()
observations = []
for mode, machine in (("320x200","pc,i8042=off"),("800x600","pc")):
    dest = root / ("wrong-image-" + mode)
    guest = api["Guest"](a.qemu, a.kernel.resolve(), mode, machine, dest, api["CHECK"]["kernel_glyphs"]())
    try:
        rows = guest.screen("stopped", lambda rows: any(api["STOPPED"] in row for row in rows))
        screen = api["text_of"](rows)
        serial = guest.serial.read_text().splitlines()
        passed = sum(row.startswith("  pass ") for row in serial)
        failed = sum(row.startswith("  FAIL") for row in serial)
        obs = dict(mode=mode, passed=passed, failed=failed, running=guest.running(), screen=screen,
                   failures=[s for s in serial if s.startswith("  FAIL")])
        observations.append(obs)
        assert failed and obs["running"] and "Verified: all" not in screen
        assert f"NOT VERIFIED: {failed} of {passed + failed} self-tests failed." in screen
        assert api["POWER"] in screen and (api["NO_KEYBOARD"] in screen) == ("i8042=off" in machine)
    finally:
        guest.end()
        (root/"failed-starts.json").write_text(json.dumps(observations,indent=2)+"\n")
print(json.dumps(observations))

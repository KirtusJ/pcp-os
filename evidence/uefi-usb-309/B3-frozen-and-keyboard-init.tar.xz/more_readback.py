"""Re-read all six outcomes from archived frames, QMP and serial."""
import json
from pathlib import Path
import runpy
from hashlib import sha256
root=Path(__file__).resolve().parent
api=runpy.run_path(str(root/'src/examples/tester-cd/check.py'))
any_size=runpy.run_path(str(root/'src/examples/tester-cd/check_compact_pins.py'))['read']
refusal=runpy.run_path(str(root/'src/examples/firmware-owned-uefi/refusal_screen.py'))
observer=runpy.run_path(str(root/'src/examples/firmware-owned-uefi/usb_observer.py'))
n=root/'low'
entry=json.loads((n/'result.json').read_text())
assert entry['passed'] and entry['keys']==['ret','q','f10','y','esc','ret','f10','ret']
first,confirm=tuple(refusal['ACTIONS'])
for filename,action in [('refused',first),('confirm',confirm),('cancelled',first),('confirm-again',confirm)]:
    assert refusal['matches']((n/f'{filename}.ppm').read_bytes(),action)
events=[e for e in entry['events'] if e['event']=='SHUTDOWN']
assert len(events)==1 and events[0]['data']=={'guest':True,'reason':'guest-shutdown'}
assert observer['compare'](n,*entry['snapshots'])==entry['interval']
assert entry['interval']['nvme_bytes_preserved'] and not any(entry['interval']['counter_deltas']['sentinel'].values())
assert sha256((n/'internal.raw').read_bytes()).hexdigest()==entry['snapshots'][-1]['nvme_sha256']
assert 'owned-handoff' not in (n/'firmware.txt').read_text()
for folder in sorted(root.glob('wrong-image-*')):
    pix=(folder/'stopped.ppm').read_bytes()
    rows=any_size(pix,api['kernel_glyphs']())
    screen=' '.join(' '.join(rows).split())
    serial=(folder/'serial.txt').read_text().splitlines()
    passed=sum(s.startswith('  pass ') for s in serial)
    failed=sum(s.startswith('  FAIL') for s in serial)
    assert (passed,failed)==(40,1) and f'NOT VERIFIED: {failed} of {passed+failed} self-tests failed.' in screen
    assert 'Hold its power button until it goes dark.' in screen
    assert ('No keyboard this kernel can use answered' in screen)==('320x200' in folder.name)
    print(folder.name,passed,failed,'manual power instruction visible')
print('64 MiB: refusal, question, cancellation, new question and one confirmed shutdown; zero internal NVMe requests')

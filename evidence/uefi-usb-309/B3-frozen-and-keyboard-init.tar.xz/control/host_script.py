"""Compile the candidate's actual key-script and drain functions against a scripted port and clock."""
import subprocess
import sys
from pathlib import Path

here = Path(__file__).resolve().parent
dev = (here/"dev.rs").read_text()
main = (here/"main.rs").read_text()

def item(s, start):
    offset=s.index(start)
    return s[offset:s.index("\n}",offset)+2]

types=dev[dev.index("#[derive(Clone, Copy, PartialEq, Eq)]\npub enum KeyPacing"):dev.index("/// For the kernel's self-tests, which have nobody")]
functions=[item(dev,tag) for tag in ["fn controller_wait_write()", "pub fn keyboard_replays()", "pub fn keyboard_script(", "pub fn keyboard_script_finish()", "pub fn keyboard_script_left()", "fn script_tick("]]
prefix=r'''
use std::sync::atomic::{AtomicBool,AtomicU32,AtomicU64,Ordering};
use std::sync::Mutex;
static T:AtomicU64=AtomicU64::new(0);
static BLOCKED:AtomicBool=AtomicBool::new(false);
static POLLS:AtomicU32=AtomicU32::new(0);
static DURATION:AtomicU32=AtomicU32::new(0);
static BEFORE:AtomicU32=AtomicU32::new(0);
static ARM:AtomicBool=AtomicBool::new(false);
static PROBE:AtomicU32=AtomicU32::new(0);
static PROBE_HIT:AtomicBool=AtomicBool::new(false);
static WRITES:Mutex<Vec<(u16,u8)>>=Mutex::new(Vec::new());
const O:Ordering=Ordering::SeqCst;
mod arch {
    use super::*;
    pub struct Single<T>(Mutex<T>);
    impl<T> Single<T> { pub const fn new(x:T)->Self{Self(Mutex::new(x))} pub fn with<R>(&self,f:impl FnOnce(&mut T)->R)->R{f(&mut *self.0.lock().unwrap())}}
    pub fn without_interrupts<R>(f:impl FnOnce()->R)->R{f()}
    pub fn ticks()->u64{T.load(O)}
    pub fn wait_until(t:u64){while ticks()<t{ let n=T.fetch_add(1,O)+1; script_tick(n); }}
    pub fn interrupts_on(){} pub fn interrupts_off(){}
}
mod user {
    pub fn idle_in_key_read()->bool{super::BLOCKED.load(super::O)}
    pub fn sleeping_idle_ticks(_:u64)->Option<u64>{None}
}
fn in8(p:u16)->u8{assert_eq!(p,0x64); if BEFORE.fetch_update(O,O,|x|x.checked_sub(1)).is_ok(){return 2;} if POLLS.fetch_update(O,O,|x|x.checked_sub(1)).is_ok(){2}else{0}}
fn out8(p:u16,v:u8){WRITES.lock().unwrap().push((p,v)); if p==0x64 && v==0xd2 && ARM.swap(false,O){POLLS.store(DURATION.load(O),O);} if p==0x60 && PROBE.load(O)==(0x100 | u32::from(v)){PROBE.store(0,O); PROBE_HIT.store(true,O);}}
fn keys_forget(){} fn stop_requested()->bool{false} fn keys_waiting()->bool{false}
mod dev {pub use super::{keyboard_script_finish,keyboard_script_left}; pub(super) fn keys_forget(){super::keys_forget()} pub(super) fn stop_requested()->bool{super::stop_requested()} }
'''
suffix=r'''
fn start(d:u32,p:KeyPacing){
    T.store(0,O); POLLS.store(0,O); BEFORE.store(0,O); ARM.store(false,O); BLOCKED.store(true,O);
    assert!(keyboard_replays()); WRITES.lock().unwrap().clear(); DURATION.store(d,O);
    ARM.store(true,O); keyboard_script(1,&[0x1e,0x9e],p);
}
fn state()->(usize,usize,bool){SCRIPT.with(|s|(s.next,s.len,s.stalled))}
fn main(){
    for (label,d,stalls,pre) in [("ready",0,false,0),("ready on final poll",99999,false,0),("busy through final poll",100000,true,0),("input busy one tick",0,false,1)]{
        start(d,KeyPacing::BlockedRead); BEFORE.store(pre,O); arch::wait_until(3);
        let writes=WRITES.lock().unwrap().clone(); let result=script_drain();
        if stalls {assert_eq!(writes,[(0x64,0xd2)]);assert_eq!(state(),(0,0,true));assert!(result.is_err());}
        else {assert_eq!(writes,[(0x64,0xd2),(0x60,0x1e),(0x64,0xd2),(0x60,0x9e)]);assert_eq!(state(),(2,2,false));assert!(result.is_ok());}
        println!("{label}: probe=true writes={writes:x?}, state={:?}, drain={result:?}",state());
    }
    start(100000,KeyPacing::Timed);
    // The first script timer interrupt comes only after keyboard_script_finish returns to drain.
    let result=script_drain(); let writes=WRITES.lock().unwrap().clone();
    assert_eq!(writes,[(0x64,0xd2)]); assert_eq!(state(),(0,0,true)); assert_eq!(result,Ok(()));
    println!("timeout during drain: writes={writes:x?} state={:?} drain={result:?}",state());
    start(0,KeyPacing::BlockedRead); BEFORE.store(u32::MAX,O); arch::wait_until(3000);
    assert_eq!(state(),(0,2,false)); assert!(WRITES.lock().unwrap().is_empty()); let result=script_drain(); assert!(result.is_err());
    println!("continuously busy before command: after 3000 ticks state={:?} writes=[] drain_if_called={result:?}",state());
}
'''
generated="\n".join([prefix,types,*functions,item(main,"fn script_drain()"),suffix])
out=Path(sys.argv[1])
out.mkdir(exist_ok=True)
(out/"model.rs").write_text(generated)
subprocess.run(["rustc","--edition=2021","-O",str(out/"model.rs"),"-o",str(out/"model")],check=True)
subprocess.run([str(out/"model")],check=True)

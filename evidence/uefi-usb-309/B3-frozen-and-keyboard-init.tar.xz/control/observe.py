from pathlib import Path
import json,subprocess,sys,time
kernel,measure,qemu,dest,kind=map(str,sys.argv[1:])
out=Path(dest); out.mkdir()
assert kind in ('healthy','edge','cutoff')
val=subprocess.check_output([sys.executable,measure,kernel],text=True).strip()
cmd=[qemu,'-cpu','max','-machine','pc','-accel','tcg','-m','128M','-smp','1','-kernel',kernel,'-append',f'image={val} then=off','-nic','none','-display','none','-monitor','none','-serial','file:'+str(out/'serial.txt'),'-device','isa-debug-exit,iobase=0xf4,iosize=0x04','-no-reboot']
with (out/'qemu-stderr.txt').open('wb') as e, subprocess.Popen(cmd,stderr=e,stdout=subprocess.DEVNULL) as vm:
    try:
        deadline=time.monotonic()+45
        while time.monotonic()<deadline:
            st=vm.poll()
            log=(out/'serial.txt').read_text(errors='replace') if (out/'serial.txt').exists() else ''
            if st is not None or (kind=='cutoff' and 'B3 observed at +2000' in log):break
            time.sleep(.1)
        res=dict(measurement=val,variant=kind,guest_exit=vm.poll(),passed=sum(s.startswith('  pass ') for s in log.splitlines()),closed="pass the kernel's register of its own start" in log,observations=[s for s in log.splitlines() if s.startswith('B3 ')])
        (out/'result.json').write_text(json.dumps(res,indent=2)+'\n')
        print(json.dumps(res),flush=True)
        if kind=='cutoff':
            assert res['guest_exit'] is None and not res['closed'] and '+2000 timer periods: idle_in_key_read=true queued=false script_sent=0 length=0 stalled=true' in log
        else:
            assert res['guest_exit']==33 and res['passed']==72 and res['closed']
    finally:
        if vm.poll() is None:vm.terminate();vm.wait(timeout=10)

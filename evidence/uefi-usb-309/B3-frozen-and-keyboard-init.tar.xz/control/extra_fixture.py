"""Add observation to the pre-command and trailing-release cases on a disposable test copy."""
from pathlib import Path
import subprocess,sys
where=Path(__file__).resolve().parent
root,mode=Path(sys.argv[1]),sys.argv[2]
assert mode in ('busy-before','trailing')
dev=root/'dev.rs'; main=root/'main.rs'
subprocess.run([sys.executable,str(where/'fixture.py'),str(where/'dev.rs'),str(dev),'100000'],check=True)
s=dev.read_text()
def edit(src,old,new):
    assert src.count(old)==1,old
    return src.replace(old,new,1)
t=(where/'main.rs').read_text()
if mode=='busy-before':
    s=edit(s,"        let start = B3_START.load",'''        if s.pacing == KeyPacing::BlockedRead && crate::user::idle_in_key_read() && !B3_ARMED.swap(true,Ordering::Relaxed) {
            B3_START.store(ticks,Ordering::Relaxed);
            B3_BUSY.store(u32::MAX,Ordering::Relaxed);
            crate::log(format_args!("B3 busy before replay command for blocked reader"));
        }
        let start = B3_START.load''')
else:
    s=edit(s,'        s.pacing = KeyPacing::Timed;','''        if s.next < s.len && !B3_ARMED.load(Ordering::Relaxed) {
            B3_DRAIN.store(true,Ordering::Relaxed);
            crate::log(format_args!("B3 drain started with {} remaining",s.len-s.next));
        }
        s.pacing = KeyPacing::Timed;''')
    s=edit(s,'static B3_BUSY:', '''static B3_DRAIN: AtomicBool = AtomicBool::new(false);
pub fn b3_drain_has_timeout() -> bool { B3_ARMED.load(Ordering::Relaxed) && B3_DRAIN.load(Ordering::Relaxed) }
static B3_BUSY:''')
    s=edit(s,'if s.pacing == KeyPacing::BlockedRead && !B3_ARMED.swap(true,Ordering::Relaxed)', 'if B3_DRAIN.load(Ordering::Relaxed) && !B3_ARMED.swap(true,Ordering::Relaxed)')
    s=s.replace('B3 first blocked reader: model','B3 first trailing release: model')
    t=edit(t,'    if !done {\n        Err("the key script did not finish")','''    if dev::b3_drain_has_timeout() {
        crate::log(format_args!("B3 drain decision done={} initial_success={} current_success={}",done,woke_on_interrupt,dev::keyboard_script_finish()));
    }
    if !done {
        Err("the key script did not finish")''')
dev.write_text(s); main.write_text(t)

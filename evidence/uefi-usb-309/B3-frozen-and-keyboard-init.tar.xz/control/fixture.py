"""Instrument only the first read-paced script, with the rest of the guest unchanged."""
from pathlib import Path
import sys
original, target, count=Path(sys.argv[1]),Path(sys.argv[2]),int(sys.argv[3])
s=original.read_text()
def once(old,new):
    global s
    assert s.count(old)==1, old
    s=s.replace(old,new,1)
once("fn in8(port: u16) -> u8 {", """static B3_BUSY: core::sync::atomic::AtomicU32 = core::sync::atomic::AtomicU32::new(0);
static B3_ARMED: AtomicBool = AtomicBool::new(false);
static B3_START: core::sync::atomic::AtomicU64 = core::sync::atomic::AtomicU64::new(0);
fn in8(port: u16) -> u8 {
    if port == 0x64 && B3_BUSY.load(Ordering::Relaxed) != 0 {
        B3_BUSY.fetch_sub(1, Ordering::Relaxed);
        return (unsafe { arch::port_in8(port) }) | 2;
    }""")
once("fn script_tick(ticks: u64) {\n    SCRIPT.with(|s| {","""fn script_tick(ticks: u64) {
    SCRIPT.with(|s| {
        let start = B3_START.load(Ordering::Relaxed);
        if start != 0 && [1,200,2000].contains(&ticks.saturating_sub(start)) {
            crate::log(format_args!("B3 observed at +{} timer periods: idle_in_key_read={} queued={} script_sent={} length={} stalled={}", ticks-start, crate::user::idle_in_key_read(), keys_waiting(), s.next, s.len, s.stalled));
        }""")
once("            out8(0x64, 0xD2);\n            // A byte is counted", """            out8(0x64, 0xD2);
            if s.pacing == KeyPacing::BlockedRead && !B3_ARMED.swap(true,Ordering::Relaxed) {
                B3_START.store(ticks,Ordering::Relaxed);
                B3_BUSY.store(COUNT,Ordering::Relaxed);
                crate::log(format_args!("B3 first blocked reader: model {} busy status samples after accepted command",COUNT));
            }
            // A byte is counted""".replace("COUNT",str(count)))
target.write_text(s)

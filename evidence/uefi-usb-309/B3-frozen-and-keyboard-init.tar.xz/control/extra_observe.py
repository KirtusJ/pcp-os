from pathlib import Path
import json,subprocess,sys,time
kernel,measure,qemu,dest,kind=sys.argv[1:]
out=Path(dest); out.mkdir(); val=subprocess.check_output([sys.executable,measure,kernel],text=True).strip()
cmd=[qemu,'-cpu','max','-machine','pc','-accel','tcg','-m','128M','-smp','1','-kernel',kernel,'-append',f'image={val} then=off','-nic','none','-display','none','-monitor','none','-serial','file:'+str(out/'serial.txt'),'-device','isa-debug-exit,iobase=0xf4,iosize=0x04','-no-reboot']
needle={'trailing':'B3 drain decision done=true initial_success=true current_success=false','busy-before':'+2000 timer periods: idle_in_key_read=true queued=false script_sent=0 length=4 stalled=false'}[kind]
with (out/'qemu-stderr.txt').open('wb') as e,subprocess.Popen(cmd,stderr=e,stdout=subprocess.DEVNULL) as vm:
    try:
        end=time.monotonic()+35
        while time.monotonic()<end:
            log=(out/'serial.txt').read_text(errors='replace') if (out/'serial.txt').exists() else ''
            if needle in log or vm.poll() is not None:break
            time.sleep(.1)
        res=dict(measurement=val,variant=kind,guest_exit=vm.poll(),passed=sum(s.startswith('  pass ') for s in log.splitlines()),observations=[s for s in log.splitlines() if s.startswith('B3 ')])
        (out/'result.json').write_text(json.dumps(res,indent=2)+'\n')
        print(json.dumps(res),flush=True);assert needle in log
    finally:
        if vm.poll() is None:vm.terminate();vm.wait(timeout=10)

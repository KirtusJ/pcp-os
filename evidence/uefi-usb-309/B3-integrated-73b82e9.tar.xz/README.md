# Merged keyboard checker

Working branch z3/keyboard-init merged both commits from #330 at 73b82e96aaf187925a694e77f5ed8fa8aa6e9fdb. The two parents and the tested tree are in merged-identity.txt and identity.txt. No files differed between the merge commit and the rehearsed tree.

Three direct QEMU boots used the normal kernel, the replay-disabled demonstration and the total-loss demonstration. Two further total-loss guests withheld the processor hypervisor flag and were given a display. Their stopped screens showed six failures out of 72 at 320×200 and 1920×1080. Both reported the manual power instruction. These guests were halted by the host after recording the final screens.

After checking SHA256SUMS run python3 -B verify.py and python3 -B screens.py. The complete screen captures, serials and three process exit statuses are included.

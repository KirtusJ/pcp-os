from pathlib import Path
import json,runpy
root=Path(__file__).resolve().parent
api=runpy.run_path(str(root/'replay_probe.py'))
data=root/'combined'
stats=json.loads((data/'outcomes.json').read_text())
assert stats=={'normal':[33,72],'skipped':[33,66],'lost':[35,66]}
logs={k:(data/(k+'.txt')).read_text() for k in stats}
for key,log in logs.items():
    assert sum(api['pass_inventory'](log).values())==stats[key][1]
    assert 'kernel register: ' in log
normal=api['pass_inventory'](logs['normal']);skip=api['pass_inventory'](logs['skipped'])
assert not api['coverage_problems'](normal,skip)
assert api['NOT_RUN'] in logs['skipped'] and api['NOT_RUN'] not in logs['normal']
assert not api['lost_key_problems'](stats['lost'][0],logs['lost'],skip)
print('Verified three native serial records and exit statuses.')

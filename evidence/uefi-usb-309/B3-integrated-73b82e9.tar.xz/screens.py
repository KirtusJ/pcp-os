from pathlib import Path
import re,runpy,json
root=Path(__file__).resolve().parent
reader=runpy.run_path(str(root/'src/examples/tester-cd/check_compact_pins.py'))
alphabet=reader['CHECK']['kernel_glyphs']()
for rec in json.loads((root/'stopped-screens.json').read_text()):
    d=root/('lost-'+rec['mode']); frame=(d/'stopped.ppm').read_bytes()
    rows=reader['read'](frame,alphabet); text=' '.join(' '.join(rows).split())
    assert text==rec['screen'] and 'NOT VERIFIED: 6 of 72 self-tests failed.' in text and 'Hold its power button until it goes dark.' in text
    serial=(d/'serial.txt').read_text().splitlines()
    assert [row for row in serial if row.startswith('  FAIL ')]==rec['failures'] and len(rec['failures'])==6
    assert sum(row.startswith('  pass ') for row in serial)==66 and rec['running']
    print(rec['mode'], '6 of 72 failed; manual power instruction visible')

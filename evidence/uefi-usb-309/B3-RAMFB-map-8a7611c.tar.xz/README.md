# Loader framebuffer and memory-map measurements

B3 read the Multiboot 1 header and exact map from the original USB image previously built for 926c888 and integrated in 70dc1b4. The archive includes that image and its original receipt. The fixture uses Q35, TCG, QEMU 10.0.13, Debian OVMF and disposable media. The firmware output, before-start QMP configuration, raw 128-byte boot header and map bytes are preserved per guest. The two PCI runs also saved the BARs after kernel entry. The currently integrated kernel declines RAMFB and opens Home on virtio and standard VGA.

| Original USB guest | Boot header and active picture | Coverage in the translated Multiboot map |
| --- | --- | --- |
| RAMFB, 128 MiB | 0x104c, 800×600, 3200-byte pitch, 0x06a3f000 | All 469 pages fall in one type-2 entry [0x06a3f000, 0x06d3f000). The 1,920,000 picture bytes end at 0x06c13c00, 1,024 bytes before the last mapped-page boundary. |
| RAMFB, 256 MiB | Same mode, at 0x0ea3f000 | All 469 pages fall in [0x0ea3f000, 0x0ed3f000), type 2. |
| Virtio VGA, 128 MiB | 0x104c, 1280×800, 5120-byte pitch, 0x80000000 | Zero map entries cover the 1,000 picture pages. After handoff, QMP places the 1af4:1050 display's 8-MiB BAR 0 at that address and the kernel opens Home. |
| Standard VGA, 128 MiB | Same loader mode as virtio | Zero map entries cover the picture. QMP places 1234:1111's 16-MiB BAR 0 there. The kernel uses its independent Bochs path, two pages at 1920×1080. |

The separate EFI diagnostic queries OVMF's active console and GetMemoryMap before a kernel starts. On the 128 MiB RAMFB guest both GOP handles identify the same reservation as native EFI type 0 (EfiReservedMemoryType) with attribute field 0xf. On both virtual PCI displays OVMF reports zero overlapping descriptors. Original USB map entries translate EfiConventionalMemory to 1, EfiACPIMemoryNVS to 4, and other EFI types to 2. The separate firmware observation distinguishes native type 0 from the other types with the same translation. The diagnostic uses a different EFI application; its total descriptor counts can differ from the final kernel handoff.

Run `python3 verify.py` after extraction to recompute the bounds, descriptor overlaps, flags, page counts, PCI coverage and EFI observations. The JSON receipts record each QEMU command. The guest runner and diagnostic source are included for replay with the original USB, the repository at 70dc1b4, the specified OVMF code and variable template, and a fresh disposable directory.

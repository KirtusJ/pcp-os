/* Observe active QEMU firmware graphics modes without requesting a mode change. */
#include <efi.h>
#include <efilib.h>
#include <cpuid.h>

static int qemu_tcg(void) {
    unsigned a, b, c, d;
    __cpuid(1, a, b, c, d);
    if (!(c & (1u << 31))) return 0;
    __cpuid(0x40000000, a, b, c, d);
    return b == 0x54474354 && c == 0x43544743 && d == 0x47435447;
}

static void emit(char c) {
    __asm__ volatile("outb %0, %1" : : "a"(c), "Nd"((UINT16)0xe9));
}

static void text(const char *s) {
    while (*s) emit(*s++);
}

static void field(const char *name, UINT64 value) {
    static const char digits[] = "0123456789abcdef";
    text(name);
    emit('=');
    for (int shift = 60; shift >= 0; shift -= 4) emit(digits[(value >> shift) & 15]);
    emit('\n');
}

/* Aligned, static descriptor storage; this diagnostic never changes GOP mode. */
static UINT64 descriptor_storage[16384];

static void describe_memory(EFI_BOOT_SERVICES *bs, EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE *mode) {
    UINTN size=sizeof(descriptor_storage), key=0, stride=0;
    UINT32 version=0;
    EFI_STATUS status=uefi_call_wrapper(bs->GetMemoryMap,5,&size,descriptor_storage,&key,&stride,&version);
    field("map_status",status);
    if (EFI_ERROR(status) || stride<sizeof(EFI_MEMORY_DESCRIPTOR) || size%stride) return;
    field("map_count",size/stride);
    UINT64 first=mode->FrameBufferBase, end=first+(UINT64)4*mode->Info->PixelsPerScanLine*mode->Info->VerticalResolution;
    UINTN overlaps=0;
    for (UINTN at=0;at<size;at+=stride) {
        EFI_MEMORY_DESCRIPTOR *entry=(void *)((UINT8 *)descriptor_storage+at);
        UINT64 base=entry->PhysicalStart, limit=base+entry->NumberOfPages*4096;
        if (base<end && first<limit) {
            field("overlap_start",base);
            field("overlap_end",limit);
            field("efi_type",entry->Type);
            field("efi_attributes",entry->Attribute);
            ++overlaps;
        }
    }
    field("overlap_count",overlaps);
}

EFI_STATUS efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *system) {
    if (!qemu_tcg()) return EFI_UNSUPPORTED;
    InitializeLib(image, system);
    EFI_BOOT_SERVICES *bs = system->BootServices;
    EFI_GUID gop_guid = EFI_GRAPHICS_OUTPUT_PROTOCOL_GUID;
    EFI_HANDLE *handles = NULL;
    UINTN count = 0;
    EFI_STATUS status = uefi_call_wrapper(bs->LocateHandleBuffer, 5, ByProtocol,
                                          &gop_guid, NULL, &count, &handles);
    text("PROBE-BEGIN\n");
    field("locate_status", status);
    field("handle_count", count);
    if (!EFI_ERROR(status)) {
        for (UINTN i = 0; i < count; ++i) {
            EFI_GRAPHICS_OUTPUT_PROTOCOL *gop = NULL;
            status = uefi_call_wrapper(bs->HandleProtocol, 3, handles[i], &gop_guid, (void **)&gop);
            field("handle_index", i);
            field("console_out_handle", handles[i] == system->ConsoleOutHandle);
            field("handle_status", status);
            if (EFI_ERROR(status) || !gop || !gop->Mode || !gop->Mode->Info) continue;
            EFI_GRAPHICS_OUTPUT_PROTOCOL_MODE *mode = gop->Mode;
            EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *info = mode->Info;
            field("mode",mode->Mode);
            field("mode_info_size", mode->SizeOfInfo);
            if (mode->SizeOfInfo < sizeof(*info)) continue;
            field("width",info->HorizontalResolution);
            field("height",info->VerticalResolution);
            field("pixel_format",info->PixelFormat);
            field("pixels_per_scanline",info->PixelsPerScanLine);
            field("base",mode->FrameBufferBase);
            field("size",mode->FrameBufferSize);
            describe_memory(bs,mode);
        }
        uefi_call_wrapper(bs->FreePool, 1, handles);
    }
    text("PROBE-END\n");
    uefi_call_wrapper(system->RuntimeServices->ResetSystem, 4, EfiResetShutdown, EFI_SUCCESS, 0, NULL);
    return EFI_SUCCESS;
}

"""Decode the original guest header and map and verify the separate EFI and PCI observations."""
import hashlib
import json
import struct
from pathlib import Path

root=Path(__file__).resolve().parent
def bars(buses,start,end):
    return [(dev['id']['vendor'],dev['id']['device'],reg['bar'],reg['address'],reg['size'])
            for bus in buses for dev in bus['devices'] for reg in dev.get('regions',[])
            if reg['type']=='memory' and 0<=reg['address']<=start and end<=reg['address']+reg['size']]
def decode_map(blob):
    result=[]
    at=0
    while at<len(blob):
        size,base,n,kind=struct.unpack_from('<IQQI',blob,at)
        assert size>=20 and at+4+size<=len(blob) and n>0 and n<=2**64-1-base
        result.append((base,base+n,kind))
        at+=size+4
    assert at==len(blob)
    return result
def firmware_data(trace):
    fields={}
    handles=[]
    for line in trace.split('PROBE-BEGIN\n')[1].split('PROBE-END\n')[0].splitlines():
        name,value=line.split('=')
        if name=='handle_index':
            target={}; handles.append(target)
        else:
            target=handles[-1] if handles else fields
        target[name]=int(value,16)
    return handles
for dirname in ('guests/ramfb-128','guests/ramfb-256','guests/virtio-vga-128','pci/virtio-vga-128','pci/std-128'):
    d=root/dirname
    r=json.loads((d/'result.json').read_text()); h=(d/'boot-info.bin').read_bytes(); raw=(d/'multiboot-map.bin').read_bytes()
    assert len(h)==128 and struct.unpack_from('<I',h)[0]==0x104c and struct.unpack_from('<I',h,20)[0]==3
    assert struct.unpack_from('<II',h,44)==(len(raw),r['runtime_header']['map_address'])
    assert hashlib.sha256(raw).hexdigest()==r['memory_map']['raw_sha256']
    entries=decode_map(raw)
    assert [(e['start'],e['end'],e['type']) for e in json.loads((d/'entries.json').read_text())]==entries
    addr,pitch,w,height,bits,kind=struct.unpack_from('<QIIIBB',h,88)
    assert list(h[110:116])==[16,8,8,8,0,8] and bits==32 and kind==1 and pitch==4*w
    lo=addr//4096*4096;end=addr+pitch*height;hi=(end+4095)//4096*4096
    overlaps=[e for e in entries if e[0]<hi and lo<e[1]]
    assert r['exit']==0 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'} and r['all_pass']
    assert r['disk_before']==r['disk_after'] and r['usb_after']==r['usb_sha256']=='fe8bc66801f2eef6125bd03f7ec2b15fab1fc13307dd93a7f52c0cfdcdc827aa'
    serial=(d/'serial.txt').read_text()
    assert r['measurement']+' (measured; equal' in serial and 'ALL SELF-TESTS PASS.' in serial
    if 'ramfb' in dirname:
        assert (addr,w,height,len(entries))==((0xea3f000 if '256' in dirname else 0x6a3f000),800,600,132)
        assert overlaps==[(addr,addr+0x300000,2)] and (hi-lo)//4096==469 and hi-end==1024
        assert 'none this kernel can drive' in r['display'] and not r['desktop'] and r['pass_lines']==71
    else:
        assert (addr,w,height,len(entries),overlaps)==(0x80000000,1280,800,130,[])
        assert (hi-lo)//4096==1000 and r['desktop'] and r['pass_lines']==72
        if dirname.startswith('pci/'):
            expected=(0x1234,0x1111,0,addr,0x1000000) if 'std' in dirname else (0x1af4,0x1050,0,addr,0x800000)
            assert bars(r['pci_after_handoff'],lo,hi)==[expected]
    print(dirname,hex(addr),pitch*height,'bytes,',(hi-lo)//4096,'pages,',overlaps)
for display in ('std','ramfb','virtio-vga'):
    d=root/'firmware/guests'/display
    r=json.loads((d/'result.json').read_text())
    handles=firmware_data((d/'firmware.txt').read_text())
    assert handles==r['handles'] and len(handles)==2 and sum(h['console_out_handle'] for h in handles)==1
    for h in handles:
        assert h['map_status']==0
        addr=h['base'];end=addr+h['height']*h['pixels_per_scanline']*4
        if display=='ramfb':
            assert (h['overlap_count'],h['efi_type'],h['overlap_start'],h['overlap_end'],h['efi_attributes'])==(1,0,0x6a3f000,0x6d3f000,15)
        else:
            assert h['overlap_count']==0 and len(bars(r['pci_after_firmware'],addr,end))==1
    assert r['exit']==0 and r['shutdown']=={'guest':True,'reason':'guest-shutdown'}
    print('pre-kernel OVMF',display,'EFI overlaps',handles[0]['overlap_count'])

# Intact USB refusal and firmware fallback

Director B3, issue 309. Four fresh Q35/OVMF boots used the same read-only USB, writable bootable internal NVMe fixture, external xHCI keyboard, no i8042, 128 MiB, no network and no injected keys. The kernel was built at be2d4dd42521b6d49f7cdc3ab0d39682db6f22d3 with the repository's UEFI relocation patch. The only changed file at 8395a86c0074bd2927a0d9ebc7e01cd448c28262 was the keyboard replay checker. Firmware and USB digests are in each result.json. The starting NVMe image is the one archived in B3-USB-boot-order-70dc1b4.tar.xz at d626ef740f41d7c91a34cf8aca9df2d958deb83b.

| TCG hypervisor flag | Internal NVMe boot option | Outcome | Passes | NVMe reads | Bytes read | Changed OVMF variable-store bytes |
|---|---|---|---:|---:|---:|---:|
| Present | Second | PCP completed and requested guest shutdown | 66 | 12 | 55,296 | 6,352 |
| Present | Omitted | PCP completed and requested guest shutdown | 66 | 0 | 0 | 6,047 |
| Withheld | Second | USB executable refused, internal diagnostic also refused, firmware shell prompt | 0 | 22 | 270,336 | 6,352 |
| Withheld | Omitted | USB executable refused, firmware shell prompt | 0 | 0 | 0 | 6,047 |

OVMF loaded and started the USB executable in every row. Both refusals returned Unsupported, with empty loader traces and no kernel banner or handoff. The internal control EFI also checks for the TCG hypervisor flag at entry. With that flag withheld and NVMe listed, OVMF invoked its executable, received Unsupported, and continued to the built-in shell. In all four trials, the internal disk and USB image retained their hashes and the internal write, flush and discard counters stayed at zero. Read counts are per complete measured interval. No physical computer was tested.

The first attempt sought a stopped-kernel screen on the guarded USB with the flag withheld. It timed out after the USB executable returned Unsupported and OVMF entered its shell. Its original serial, trace and timeout are in first-attempt. The four follow-up trials record the firmware transition explicitly. The stopped-screen checks from direct kernel boots concern a different entry path.

For offline verification run sha256sum --quiet -c SHA256SUMS, then python3 -B readback.py and compare its output to verified.txt. run.sh documents the local original guest commands. Rerunning them requires the source tree, QEMU, OVMF and USB build cited in this record. All internal-original.raw and internal.raw files in this archive are disposable VM fixtures.

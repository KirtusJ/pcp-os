"""Recompute the four observed outcomes from the original serial, firmware, and QMP records."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inspect(flag, disk, expected_reads, expected_bytes):
    here = root / f"{flag}-{disk}"
    r = json.loads((here/"result.json").read_text())
    serial = (here/"serial.txt").read_text()
    trace = (here/"firmware.txt").read_text()
    events = [e for e in r["events"] if e["event"]=="SHUTDOWN"]
    def positions(pattern):
        return [m.start() for m in re.finditer(pattern,serial)]
    usb = positions(r"BdsDxe: starting Boot[^\n]*from PciRoot[^\n]*/USB\(")
    refused = positions(r"BdsDxe: failed to start Boot[^\n]*from PciRoot[^\n]*/USB\([^\n]*Unsupported")
    internal = positions(r"BdsDxe: starting Boot[^\n]*from PciRoot[^\n]*/NVMe\(")
    denied = positions(r"BdsDxe: failed to start Boot[^\n]*from PciRoot[^\n]*/NVMe\([^\n]*Unsupported")
    shell = positions(r"BdsDxe: starting Boot[^\n]*EFI Internal Shell")
    passes = re.findall(r"^  pass (.+)$",serial,re.M)
    assert len(usb)==1 and r["exit"]==0 and r["keys_sent"]==0
    assert r["args"][r["args"].index("-cpu")+1]==("max" if flag=="present" else "max,-hypervisor")
    assert (",bootindex=2" in next(v for v in r["args"] if v.startswith("nvme,")))==(disk=="listed")
    if flag=="present":
        assert len(passes)==66 and "register of its own start, verification and stop" in passes[-1]
        assert not refused and not shell and not internal and not denied and "owned-handoff" in trace
        assert len(events)==1 and events[0]["data"]=={"guest":True,"reason":"guest-shutdown"}
    else:
        assert not trace and not passes and not events and "Shell>" in serial
        assert len(refused)==len(shell)==1 and usb[0]<refused[0]<shell[0]
        assert len(internal)==len(denied)==int(disk=="listed")
        if internal:
            assert refused[0]<internal[0]<denied[0]<shell[0]
    a,b = r["snapshots"]
    assert a["nvme_sha256"]==b["nvme_sha256"]==sha(here/"internal.raw")==sha(root/"internal-original.raw")
    assert sha(here/"before-vars.fd")==a["vars_sha256"]
    assert sha(here/"end-vars.fd")==b["vars_sha256"]==sha(here/"vars.fd")
    vb,ve=(here/"before-vars.fd").read_bytes(),(here/"end-vars.fd").read_bytes()
    assert len(vb)==len(ve)
    changed=sum(l!=r for l,r in zip(vb,ve))
    changes={key:n-a["counters"]["sentinel"][key] for key,n in b["counters"]["sentinel"].items()}
    assert changes==r["interval"]["counter_deltas"]["sentinel"]
    assert changes["rd_operations"]==expected_reads and changes["rd_bytes"]==expected_bytes
    assert not any(n for k,n in changes.items() if k not in ("rd_operations","rd_bytes"))
    assert changed==r["interval"]["vars_bytes_changed"]
    assert r["usb_before"]==r["usb_after"]==json.loads((root/"image.json").read_text())["usb_sha256"]
    print(flag,disk,len(passes),expected_reads,expected_bytes,changed)
for row in (("present","listed",12,55296),("present","unlisted",0,0),
            ("withheld","listed",22,270336),("withheld","unlisted",0,0)):
    inspect(*row)

set -eu
root=$(pwd)
for flag in present withheld
do
  for nvme in listed unlisted
  do
    python3 -B "$root/fallback/guest.py" "$flag" "$nvme" "$root/fixed/src" "$root/fixed/default/media" "$root/fallback/internal-original.raw" /workspace/scratch/15ccefba7c7d/validation/bin/qemu-system-x86_64 /workspace/scratch/15ccefba7c7d/validation/pkg/root/usr/share/OVMF "$root/fallback/$flag-$nvme"
  done
done

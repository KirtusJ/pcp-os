"""Boot one guarded UEFI USB fixture with only a USB keyboard and the hypervisor flag withheld."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import runpy
import subprocess
import sys
import time

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("video", choices=("std","ramfb","virtio-vga"))
    for arg in ("source","media","qemu","firmware","output"):
        parser.add_argument(arg, type=Path)
    a = parser.parse_args()
    src, out, media = (p.resolve() for p in (a.source, a.output, a.media))
    out.mkdir()
    sys.path.insert(0, str(src / "examples/firmware-owned-uefi"))
    import usb_trial
    from usb_observer import capture, compare
    stopped = runpy.run_path(str(src / "examples/tester-cd/check_stopped_screen.py"))
    glyphs = stopped["CHECK"]["kernel_glyphs"]()
    cmd = usb_trial.usb_command(str(a.qemu), a.firmware / "OVMF_CODE_4M.fd", a.firmware / "OVMF_VARS_4M.fd", media/"usb.img", out, 128, a.video)
    cmd[cmd.index("-machine")+1] = "q35,i8042=off"
    cmd[cmd.index("-cpu")+1] = "max,-hypervisor"
    cmd.extend(["-device","usb-kbd,id=external-usb-keyboard,bus=xhci.0"])
    result = {"command":cmd,"keys_injected":0}
    with (out/"stderr.txt").open("w") as err, subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
        try:
            monitor = usb_trial.OPTICAL["Monitor"](vm)
            rpc = monitor.call
            rpc("qmp_capabilities")
            inventory = rpc("human-monitor-command", **{"command-line":"info usb"})
            assert "QEMU USB Keyboard, ID: external-usb-keyboard" in inventory and "QEMU USB MSD, ID: usb" in inventory
            result["usb_inventory"] = inventory
            before = capture(rpc, out, "before")
            rpc("cont")
            serial_file = out / "serial.txt"
            usb_trial.OPTICAL["wait_for"](lambda: "ALL SELF-TESTS PASS." in serial_file.read_text(errors="replace"),"final serial verdict",75)
            serial = serial_file.read_text()
            trace = (out/"firmware.txt").read_text().splitlines()
            assert "owned-handoff" in trace and any(re.search(r"BdsDxe: starting Boot.*USB", x) for x in serial.splitlines())
            assert json.loads((media/"image.json").read_text())["measurement"] + " (measured; equal" in serial
            assert "the self-tests that press keys were not run: there is no keyboard controller" in serial
            assert "  pass the kernel's register of its own start, verification and stop verifies and replays without a problem" in serial
            passed = sum(s.startswith("  pass ") for s in serial.splitlines())
            assert passed == 66
            # Two equal, successive native frames after the final serial verdict.
            last = None
            for i in range(12):
                time.sleep(0.4)
                rpc("screendump", filename=str(out/"stopped.ppm"))
                image = (out/"stopped.ppm").read_bytes()
                if image == last:
                    rows = stopped["PINS"]["read"](image, glyphs)
                    if rows and any(stopped["STOPPED"] in r for r in rows):
                        break
                last = image
            else:
                raise ValueError("no stable stopped screen")
            (out/"screen.txt").write_text("\n".join(rows)+"\n")
            errors = stopped["stopped_problems"](rows, False, passed)
            assert not errors, errors
            assert stopped["stopped_problems"](rows, False, passed-1)
            assert stopped["stopped_problems"](rows, True, passed)
            status = rpc("query-status")["status"]
            assert status == "running"
            cpu_info = rpc("query-cpus-fast")
            regs = rpc("human-monitor-command", **{"command-line":"info registers"})
            (out/"registers.txt").write_text(regs)
            result.update(passed=passed, status_before_pause=status, cpu_info=cpu_info,
                          halted_cpu_observed="HLT=1" in regs, dimensions=image.split(b"\n",2)[1].decode())
            if a.video != "std":
                result["loader_display"], result["framebuffer_address"] = usb_trial.loader_picture(serial, trace, out/"stopped.ppm")
            rpc("stop")
            after = capture(rpc, out, "end")
            result.update(snapshots=[before,after], interval=compare(out,before,after), events=monitor.events.copy())
            assert not any(e["event"] == "SHUTDOWN" for e in monitor.events)
            assert result["interval"]["nvme_bytes_preserved"] and not any(result["interval"]["counter_deltas"]["sentinel"].values())
            sha = hashlib.sha256((media/"usb.img").read_bytes()).hexdigest()
            assert sha == json.loads((media/"image.json").read_text())["usb_sha256"]
            result["usb_sha256"] = sha
            rpc("quit")
            result["exit"] = vm.wait(timeout=10)
            assert result["exit"] == 0
        finally:
            if vm.poll() is None:
                vm.kill()
                vm.wait()
            (out/"result.json").write_text(json.dumps(result,indent=2)+"\n")
    print(a.video, result["passed"], result["dimensions"], result["halted_cpu_observed"], result["interval"]["vars_bytes_changed"])

if __name__ == "__main__":
    main()

"""Compare guest USB loader outcomes and firmware storage access in a disposable Q35/OVMF VM."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("flag", choices=("present","withheld"))
    p.add_argument("internal", choices=("listed","unlisted"))
    for name in ("source","image","nvme","qemu","firmware","out"):
        p.add_argument(name,type=Path)
    a = p.parse_args()
    out = a.out.resolve()
    out.mkdir()
    sys.path.insert(0, str(a.source.resolve()/"examples/firmware-owned-uefi"))
    import usb_trial
    from usb_observer import capture,compare
    code = a.firmware / "OVMF_CODE_4M.fd"
    vars_template = a.firmware / "OVMF_VARS_4M.fd"
    media = a.image.resolve()
    args = usb_trial.usb_command(str(a.qemu),code,vars_template,media/"usb.img",out,128)
    args[args.index("-machine")+1] = "q35,i8042=off"
    if a.flag == "withheld":
        args[args.index("-cpu")+1] = "max,-hypervisor"
    args.extend(["-device","usb-kbd,id=external-usb-keyboard,bus=xhci.0"])
    if a.internal == "listed":
        i = next(i for i,arg in enumerate(args) if arg.startswith("nvme,"))
        args[i] += ",bootindex=2"
    shutil.copyfile(a.nvme, out/"internal.raw")
    nvme = digest(out/"internal.raw")
    assert nvme == "16963acd2f53b44c46fd01314a7b40d9e08933fb9929091bc3b9315e272d364c"
    receipt = json.loads((media/"image.json").read_text())
    before_usb = digest(media/"usb.img")
    assert before_usb == receipt["usb_sha256"]
    result = {"args":args, "flag":a.flag, "internal_boot_option":a.internal, "usb_before":before_usb,
              "nvme_before":nvme,"code_sha256":digest(code),"initial_vars_sha256":digest(vars_template),
              "qemu":subprocess.check_output([str(a.qemu),"--version"],text=True).splitlines()[0], "keys_sent":0}
    with (out/"stderr.txt").open("w") as err, subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err) as vm:
        try:
            monitor = usb_trial.OPTICAL["Monitor"](vm)
            rpc = monitor.call
            rpc("qmp_capabilities")
            inv = rpc("human-monitor-command", **{"command-line":"info usb"})
            assert "QEMU USB Keyboard, ID: external-usb-keyboard" in inv and "QEMU USB MSD, ID: usb" in inv
            result["usb_inventory"] = inv
            stick = next(b for b in rpc("query-block") if b.get("device")=="stick")
            assert stick["removable"] and stick["inserted"]["ro"]
            before = capture(rpc,out,"before")
            rpc("cont")
            serial_file = out / "serial.txt"
            if a.flag == "present":
                usb_trial.OPTICAL["wait_for"](lambda:rpc("query-status")["status"]=="shutdown","guest shutdown",60)
            else:
                usb_trial.OPTICAL["wait_for"](lambda:"Shell>" in serial_file.read_text(errors="replace"),"firmware shell prompt",60)
                assert rpc("query-status")["status"]=="running"
                rpc("stop")
            rpc("screendump", filename=str(out/"end.ppm"))
            final = capture(rpc,out,"end")
            serial = serial_file.read_text(errors="replace")
            trace = (out/"firmware.txt").read_text()
            lines = [s for s in serial.splitlines() if "BdsDxe:" in s]
            passed = sum(s.startswith("  pass ") for s in serial.splitlines())
            usb_start = next(i for i,s in enumerate(lines) if "starting Boot" in s and "USB" in s)
            events = monitor.events.copy()
            if a.flag=="present":
                assert "owned-handoff" in trace and receipt["measurement"]+" (measured; equal" in serial
                assert passed==66 and "ALL SELF-TESTS PASS." in serial and "there is no keyboard controller" in serial
                assert any(e["event"]=="SHUTDOWN" and e["data"]=={"guest":True,"reason":"guest-shutdown"} for e in events)
                assert not any("starting Boot" in s and "NVME" in s.upper() for s in lines)
                outcome = "kernel, then guest shutdown"
            else:
                usb_refusal = next(i for i,s in enumerate(lines) if "failed to start" in s and "USB" in s and "Unsupported" in s)
                shell = next(i for i,s in enumerate(lines) if "starting Boot" in s and "EFI Internal Shell" in s)
                assert usb_start < usb_refusal < shell and not trace and not passed
                assert "ALL SELF-TESTS PASS." not in serial and not any(e["event"]=="SHUTDOWN" for e in events)
                nvme_start = [i for i,s in enumerate(lines) if "starting Boot" in s and "NVME" in s.upper()]
                if a.internal=="listed":
                    nvme_refusal = next(i for i,s in enumerate(lines) if "failed to start" in s and "NVME" in s.upper() and "Unsupported" in s)
                    assert len(nvme_start)==1 and usb_refusal < nvme_start[0] < nvme_refusal < shell
                else:
                    assert not nvme_start
                outcome = "firmware shell"
            result.update(outcome=outcome,passed=passed,boot_lines=lines,snapshots=[before,final],events=events,
                          interval=compare(out,before,final),usb_after=digest(media/"usb.img"),nvme_after=digest(out/"internal.raw"))
            assert before_usb==result["usb_after"] and nvme==result["nvme_after"]
            stats = result["interval"]["counter_deltas"]["sentinel"]
            assert not any(v for k,v in stats.items() if "wr_" in k or "unmap" in k or "flush" in k)
            rpc("quit")
            result["exit"]=vm.wait(timeout=10)
            assert result["exit"]==0
        finally:
            if vm.poll() is None:
                vm.kill()
                vm.wait()
            (out/"result.json").write_text(json.dumps(result,indent=2)+"\n")
    print(a.flag,a.internal,outcome,passed,stats["rd_operations"],stats["rd_bytes"],result["interval"]["vars_bytes_changed"],flush=True)
if __name__=="__main__":
    main()

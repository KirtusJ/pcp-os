"""Run either the unchanged USB checker or a test-only profile that checks the skip disclosure."""
import argparse
import json
import sys
from pathlib import Path

REASON = ('Not run at start: the tests of keys, sleep and stopping a program, '
          'because this keyboard controller does not replay keys for a test.')

def reason_visible(rows):
    return REASON in ' '.join(' '.join(rows).split())

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for key in ('source','media','qemu','firmware','out'):
        p.add_argument(key, type=Path)
    p.add_argument('profile', choices=('stock', 'no-replay'))
    a = p.parse_args()
    sys.path.insert(0, str(a.source.resolve() / 'examples/firmware-owned-uefi'))
    import usb_trial
    if a.profile == 'no-replay':
        optical = usb_trial.OPTICAL
        checker = optical['SCREEN']['verification_screen']
        # runpy cloned the exports. The reader and caller have separate global dictionaries.
        optical['SCREEN']['STARTUP_CHECKS'] = 58
        checker.__globals__['STARTUP_CHECKS'] = 58
        def with_disclosure(rows):
            return checker(rows) and reason_visible(rows)
        optical['DesktopScreens'].__init__.__globals__['SCREEN']['verification_screen'] = with_disclosure
    media = a.media.resolve()
    result = usb_trial.trial(str(a.qemu), a.firmware/'OVMF_CODE_4M.fd', a.firmware/'OVMF_VARS_4M.fd',
                             media/'usb.img', json.loads((media/'image.json').read_text()),
                             a.out.resolve(), 128)
    assert result['passed'] and result['exit'] == 0
    print(result['self_tests'], result['shutdown'])
if __name__ == '__main__':
    main()

# Keyboard replay on two virtual USB boots

Director B3 tested PCP OS commit d92f5f630a1d452466113a61252f135219143506. Both kernels were built with Rust 1.97.0 and the repository’s firmware-owned UEFI relocation patch. Each boot used QEMU Q35, 128 MiB RAM, standard VGA, OVMF, a read-only USB volume and a disposable internal NVMe disk. The second kernel uses the no-key-replay-demo feature, which forces a negative answer to the replay probe. The virtual controller still receives keyboard input.

| Observation | Default | Replay disabled |
|---|---:|---:|
| Checks passed before shutdown, on F5 and serial | 71 | 58 |
| Checks passed after verifying the closed register, on serial | 72 | 59 |
| Bytes different in the OVMF variable store from power-on to Home | 6,047 | 6,047 |
| Bytes different in that store from Home to shutdown | 0 | 0 |

Both completed guests restored Home after F5, confirmed F10, requested shutdown and exited 0. Their measured internal-disk request counters were zero and the USB digest was preserved in each. The original default USB checker separately stopped at Home on the replay-disabled build. Its serial recorded the USB boot and 58 passes. The second successful run used the test-only reader in guest.py with the expected count and the complete F5 explanation.

Comparing pass records with duplicate lines retained yields 13 omitted checks. Three concern rejected batches returning their frames. Three more concern 32-byte and 33-byte task names and frame recovery after refused admission. F5 names keys, sleep and stopping a program. The six batch and admission checks extend beyond those labels. Keeping the default fixture expectation of 71 prevents an accidental loss of coverage from passing as a simulated controller response.

The offline control erases the skip explanation from a copy of the actual F5 frame, while retaining the 58-pass verdict, register status and hash. Changing only the numerical expectation makes the existing screen checker accept that damaged copy. The test-only reader requires the explanation as well. Erasing the verdict fails both numerical profiles. Pixel changes are confined to offline copies. The original P6 captures, serials, storage snapshots and image digests are preserved here. The stock-refusal directory records the independently attempted original reader; its host terminated that guest when the reader refused the count.

Run these commands from the extracted directory with Python 3, without optimization.

    sha256sum --quiet -c SHA256SUMS
    python3 -B replay.py > repeated.json
    cmp readback.json repeated.json

The replay uses the captured observations and bundled reader, font and snapshot routines. To repeat a guest boot, use the pinned repository and its UEFI build dependencies. build.sh and run_guest.sh record the original host tool paths. make_media.py accepts an alternate GNU-EFI installation prefix. The guest and media scripts identify their inputs as command-line arguments. The EFI images and physical media are outside this evidence package.

The 59 count is the final serial count from a virtual shutdown. A3 separately measured the stopped screen that appears when the kernel cannot power down. Neither virtual test measured an EliteBook.

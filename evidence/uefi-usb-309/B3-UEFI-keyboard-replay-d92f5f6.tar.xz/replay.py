"""Replay both UEFI F5 frames, the missing-warning control and the serial pass inventory."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import runpy

from guest import REASON, reason_visible

ROOT = Path(__file__).resolve().parent
SERIAL_REASON = 'the asynchronous self-tests were not run: this keyboard controller does not replay keys for a test'
CLOSE = "the kernel's register of its own start, verification and stop verifies and replays without a problem"

def without_row(frame, row):
    magic, shape, depth, pixels = frame.split(b'\n', 3)
    width, height = map(int, shape.split())
    assert magic == b'P6' and depth == b'255' and len(pixels) == width * height * 3
    stride = width * 20 * 3
    return b'\n'.join((magic, shape, depth, b'')) + pixels[:row*stride] + pixels[:stride] + pixels[(row+1)*stride:]

def inspect(directory, skipped, screen):
    receipt = json.loads((directory / 'result.json').read_text())
    image = json.loads((directory.parent / 'media/image.json').read_text())
    log = (directory / 'serial.txt').read_text().splitlines()
    checks = [line.removeprefix('  pass ') for line in log if line.startswith('  pass ')]
    assert checks[-1] == CLOSE and checks.count(CLOSE) == 1
    assert not any(line.startswith('  FAIL') for line in log)
    startup = 58 if skipped else 71
    assert len(checks) == startup + 1 and (SERIAL_REASON in log) == skipped
    assert receipt['self_tests'] == len(checks) and receipt['passed']
    assert receipt['exit'] == 0 and receipt['shutdown'] == {'guest': True, 'reason': 'guest-shutdown'}
    assert receipt['usb_sha256_after'] == image['usb_sha256']
    assert any(image['measurement'] + ' (measured; equal' in line for line in log)
    observer = runpy.run_path(str(ROOT/'src/examples/firmware-owned-uefi/usb_observer.py'))
    def sha(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()
    assert sha(directory/'internal.raw') == receipt['nvme_sha256_after_quit']
    assert sha(directory/'vars.fd') == receipt['vars_sha256_after_quit']
    snapshots = receipt['snapshots']
    assert [s['stage'] for s in snapshots] == ['before','home','shutdown']
    assert [observer['compare'](directory, before, after) for before, after in zip(snapshots, snapshots[1:])] == receipt['intervals']
    for event in receipt['intervals']:
        assert event['nvme_bytes_preserved']
        assert not any(event['counter_deltas']['sentinel'].values())
    assert receipt['intervals'][1]['vars_bytes_changed'] == 0
    def rows(frame):
        return screen['read_screen'](frame, glyphs)
    glyphs = screen['kernel_glyphs']()
    frame = (directory/'home-verification.ppm').read_bytes()
    visible = rows(frame)
    assert len(visible) == 54 and bool(reason_visible(visible)) == skipped
    stock = screen['verification_screen']
    stock.__globals__['STARTUP_CHECKS'] = 71
    assert stock(visible) == (not skipped)
    stock.__globals__['STARTUP_CHECKS'] = startup
    assert stock(visible)
    assert not stock(rows(without_row(frame, 3)))
    assert re.search(r'\b[0-9a-f]{64}\b', ' '.join(visible))
    out = {'startup': startup, 'final': len(checks), 'f5_reason': skipped,
           'usb_sha256': image['usb_sha256'], 'f5_sha256': hashlib.sha256(frame).hexdigest(),
           'nvme_request_counters_zero': True,
           'firmware_store_byte_differences': [i['vars_bytes_changed'] for i in receipt['intervals']]}
    if skipped:
        index, = [i for i, line in enumerate(visible) if REASON in line]
        erased = rows(without_row(frame, index))
        assert stock(erased) and not reason_visible(erased)
        out['count_adjusted_reader_accepts_erased_disclosure'] = True
    return checks[:-1], out

def main():
    screen = runpy.run_path(str(ROOT/'src/examples/tester-cd/check.py'))
    normal, a = inspect(ROOT/'default/guest', False, screen)
    limited, b = inspect(ROOT/'no-replay/guest', True, screen)
    delta = Counter(normal) - Counter(limited)
    assert len(normal) - len(limited) == sum(delta.values()) == 13 and not (Counter(limited)-Counter(normal))
    batch = 'rejected batch returns the frames of every member'
    assert delta[batch] == 3
    for term in ('32 bytes is admitted','33 bytes is refused','cannot be admitted as a task leaves no memory behind'):
        assert sum(count for name, count in delta.items() if term in name) == 1
    # Distinguish a reader refusal at Home from a loader or kernel refusal.
    refusal = ROOT/'no-replay/stock-refusal'
    original = (refusal/'serial.txt').read_text()
    assert re.search(r'BdsDxe: starting Boot[0-9A-Fa-f]{4} [^\n]*USB', original)
    assert len([s for s in original.splitlines() if s.startswith('  pass ')]) == 58
    assert SERIAL_REASON in original and 'owned-handoff' in (refusal/'firmware.txt').read_text()
    assert 'ValueError: missing OVMF USB boot device or startup self-tests' in (ROOT/'no-replay/stock-refusal.log').read_text()
    print(json.dumps({'source':'d92f5f630a1d452466113a61252f135219143506','default':a,
                      'no_replay':b,'omitted_startup_checks':dict(delta)},indent=2))
if __name__ == '__main__':
    main()

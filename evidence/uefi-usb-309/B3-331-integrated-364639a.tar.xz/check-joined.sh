set -eu
w=$1; qemu=$2
python3 -IB "$w/run_stdio.py" "$w/combined/examples/tester-cd/check_stopped_screen.py" "$w/bin/default.elf32" "$w/bin/no-key-replay-demo.elf32" "$w/joined-guests" --busy "$w/bin/keyboard-busy-demo.elf32" --silent "$w/bin/keyboard-silent-demo.elf32" --qemu "$qemu"
python3 -IB "$w/combined/examples/tester-cd/check_stopped_captures.py" "$w/joined-guests"

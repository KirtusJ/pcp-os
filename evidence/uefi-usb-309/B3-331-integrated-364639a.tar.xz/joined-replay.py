"""Replay #332/#333's joined captures and the compact failed-measurement controls."""
from pathlib import Path
import hashlib, json, runpy, subprocess, sys
root = Path(__file__).resolve().parent
path = root / 'combined/examples/tester-cd'
subprocess.run([sys.executable, '-IB', str(path/'check_stopped_captures.py'),str(root/'joined-guests')], check=True)
assert (root/'joined-controls.json').read_bytes() == (root/'joined-guests/capture-controls.json').read_bytes()
check = runpy.run_path(str(path/'check_stopped_screen.py'))
glyphs = check['CHECK']['kernel_glyphs']()
results = json.loads((root/'double-failure/result.json').read_text())
assert [r['name'] for r in results] == ['absent','busy','silent','ready']
for r in results:
    folder = root / 'double-failure' / r['name']
    pixels = (folder/'stopped.ppm').read_bytes()
    assert pixels.split(b'\n',2)[1] == b'320 200' and hashlib.sha256(pixels).hexdigest() == r['frame_sha256']
    rows = check['PINS']['read'](pixels, glyphs)
    text = check['text_of'](rows)
    serial = (folder/'serial.txt').read_text().splitlines()
    assert len([s for s in serial if s.startswith('  pass ')]) == r['passes'] == 40
    assert [s for s in serial if s.startswith('  FAIL')] == r['failures'] and len(r['failures']) == 1
    assert 'measur' in r['failures'][0]
    assert [s for s in serial if s.startswith('keyboard: ')] == ['keyboard: ' + r['keyboard']]
    assert text == r['text'] and '?' not in text and check['POWER'] in text
    assert 'NOT VERIFIED: 1 of 41 self-tests failed.' in text
    for outcome, reason in check['REASONS'].items():
        if reason:
            assert text.count(reason) == int(outcome == r['keyboard'])
print('four 320x200 frames matched the serial verdict and keyboard outcome')

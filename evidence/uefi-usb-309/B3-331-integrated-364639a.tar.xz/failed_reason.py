"""Observe the compact power-off screen when both image verification and keyboard initialization fail."""
from pathlib import Path
import hashlib
import json
import sys

root = Path(__file__).resolve().parent
source = root / "combined/examples/tester-cd/check_stopped_screen.py"
code = source.read_text()
start = code.index("        end = time.monotonic() + 20\n")
end = code.index('        self.rpc("qmp_capabilities")', start)
code = code[:start] + "        self.process.stdout.readline()\n" + code[end:]
code = code.replace('"unix:%s,server=on,wait=off" % sock', '"stdio"').replace(
    "stdout=subprocess.DEVNULL", "text=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE")
for operation, channel in (("readline", "stdout"), ("write", "stdin"), ("flush", "stdin")):
    code = code.replace("self.stream." + operation + "(", "self.process." + channel + "." + operation + "(")
parameter = '"image=%s desktop=%s" % (digest, mode)'
assert code.count(parameter) == 1
code = code.replace(parameter, '"image=%s desktop=%s then=off" % ("0" * 64, mode)')
api = {"__name__": "capture", "__file__": str(source)}
exec(compile(code, str(source), "exec"), api)
qemu = sys.argv[1]
profiles = [
    ("absent", "default", "pc,i8042=off", "no controller"),
    ("busy", "keyboard-busy-demo", "pc", "a controller is there but did not take its set-up in time; it is not used"),
    ("silent", "keyboard-silent-demo", "pc", "the controller is set up but the keyboard did not acknowledge; it is not used"),
    ("ready", "default", "pc", "a PS/2 controller answered")
]
glyphs = api["CHECK"]["kernel_glyphs"]()
records = []
for name, profile, machine, expected in profiles:
    out = root / "double-failure" / name
    guest = api["Guest"](qemu, root / "bin" / (profile + ".elf32"), "320x200", machine, out, glyphs)
    try:
        rows = guest.screen("stopped", lambda view: any(api["STOPPED"] in row for row in view))
        text = api["text_of"](rows)
        lines = guest.serial.read_text().splitlines()
        failures = [line for line in lines if line.startswith("  FAIL ")]
        passed = guest.passed()
        assert len(failures) == 1 and "measur" in failures[0] and guest.running(), failures
        assert guest.outcome() == expected
        assert f"NOT VERIFIED: 1 of {passed + 1} self-tests failed." in text
        assert api["POWER"] in text and "?" not in text and "Verified: all" not in text
        for outcome, reason in api["REASONS"].items():
            if reason:
                assert text.count(reason) == int(expected == outcome), (name, text)
        records.append({"name": name, "profile": profile, "passes": passed, "failures": failures, "keyboard": expected,
                        "text": text, "frame_sha256": hashlib.sha256((out/"stopped.ppm").read_bytes()).hexdigest()})
        (root / "double-failure/result.json").write_text(json.dumps(records, indent=2) + "\n")
        print(name, passed, failures[0].strip(), flush=True)
    finally:
        guest.end()

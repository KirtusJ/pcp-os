// SPDX-License-Identifier: GPL-2.0-or-later
#ifndef DOOM_OMEGA_H
#define DOOM_OMEGA_H
#include "p_mobj.h"

extern boolean omega_mode;
void Omega_Init(void);
mobjtype_t Omega_MapActor(mobjtype_t type, const mapthing_t *spawn);
boolean Omega_ExitLocked(void);
boolean Omega_IsFamily(mobjtype_t type);
boolean Omega_NoRespawn(mobjtype_t type);
void Omega_LogSpawn(mobj_t *actor);
#endif

// SPDX-License-Identifier: GPL-2.0-or-later
// Ultra Omega Barrel -- all extra states and actor types are appended to Doom's
// original tables, so vanilla game data keeps its numeric identities.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "doomstat.h"
#include "p_local.h"
#include "omega.h"
#include "m_argv.h"
#include "i_system.h"
#include "sounds.h"
#include "s_sound.h"
#include "w_wad.h"

extern boolean P_LookForPlayers(mobj_t *, boolean);
extern void A_Look(mobj_t *);
extern void A_Chase(mobj_t *);
extern void A_FaceTarget(mobj_t *);
extern void A_PosAttack(mobj_t *);
extern void A_SPosAttack(mobj_t *);
extern void A_TroopAttack(mobj_t *);
extern void A_BruisAttack(mobj_t *);
extern void A_Pain(mobj_t *);
extern void A_Fall(mobj_t *);
extern void A_Scream(mobj_t *);

boolean omega_mode;
static boolean in_episode(void)
{
    return omega_mode && gameepisode == 1 && gamemission == doom;
}

boolean Omega_IsFamily(mobjtype_t type)
{
    return type == MT_OMEGA_BOSS || type == MT_OMEGA_HEIR_HUSK || type == MT_OMEGA_HEIR_MINI;
}

boolean Omega_NoRespawn(mobjtype_t type)
{
    // A spent shell stays spent, including under -respawn. This bounds each
    // original monster's family tree and avoids respawning children at (0,0).
    return type >= MT_OMEGA_MINI && type <= MT_OMEGA_DRUM;
}

static const char *role(mobjtype_t t)
{
    switch (t)
    {
        case MT_OMEGA_BOSS: return "ULTRA OMEGA";
        case MT_OMEGA_HUSK: return "HUSK";
        case MT_OMEGA_HEIR_HUSK: return "HEIR HUSK";
        case MT_OMEGA_HEIR_MINI: return "HEIR MINI";
        case MT_OMEGA_SHOTMINI: return "SHOT MINI";
        case MT_OMEGA_DRUM: return "DRUM";
        default: return "MINI";
    }
}

mobjtype_t Omega_MapActor(mobjtype_t type, const mapthing_t *spawn)
{
    if (!in_episode()) return type;
    switch (type)
    {
        case MT_POSSESSED: return MT_OMEGA_MINI;
        case MT_SHOTGUY: return MT_OMEGA_SHOTMINI;
        case MT_TROOP: return MT_OMEGA_HUSK;
        case MT_BARREL: return MT_OMEGA_DRUM;
        case MT_BRUISER:
            // The two original Phobos Anomaly closets. Identity is position-
            // based, so setup/restart/load never depends on a spawn counter.
            if (gamemap == 8)
                return spawn->x == 304 && spawn->y == 2864 ? MT_OMEGA_BOSS : MT_OMEGA_HUSK;
            break;
        default: break;
    }
    return type;
}

void Omega_LogSpawn(mobj_t *actor)
{
    if (actor->type == MT_OMEGA_BOSS)
        printf("OMEGA: ULTRA OMEGA placed in E1M8 (%d hp)\n", actor->health);
}

// Offsets from the first state of a monster. A parent may hatch twice, in
// two distinct persistent states. Thus saving in the split cannot duplicate
// a child. Terminal minis skip both hatching actions.
enum {
    IDLE_A, IDLE_B, WALK_A, WALK_B, WINDUP, ATTACK, RECOVER, PAIN,
    BREAK, HATCH_FIRST, HATCH_LAST, FALL, DEBRIS, BODY_STATES
};

boolean Omega_ExitLocked(void)
{
    thinker_t *th;
    if (!in_episode() || gamemap != 8) return false;
    for (th = thinkercap.next; th != &thinkercap; th = th->next)
    {
        mobj_t *m;
        if (th->function.acp1 != (actionf_p1)P_MobjThinker) continue;
        m = (mobj_t *)th;
        if (Omega_IsFamily(m->type) &&
            (m->health > 0 || m->state != &states[m->info->spawnstate + DEBRIS]))
            return true;
    }
    return false;
}

static void shell_debris(mobj_t *m)
{
    line_t tag = {0};
    int i;
    if (!Omega_IsFamily(m->type) || !in_episode() || gamemap != 8 || Omega_ExitLocked()) return;
    for (i = 0; i < MAXPLAYERS; ++i)
        if (playeringame[i] && players[i].health > 0)
        {
            tag.tag = 666; // Doom's original Phobos Anomaly arena floor.
            EV_DoFloor(&tag, lowerFloorToLowest);
            printf("OMEGA: last shell defeated; arena floor 666 released\n");
            players[consoleplayer].message = "LAST SHELL DOWN. THE YARD IS OPEN.";
            return;
        }
}

static void shell_fire(mobj_t *m)
{
    switch (m->type)
    {
        case MT_OMEGA_MINI: case MT_OMEGA_HEIR_MINI: A_PosAttack(m); break;
        case MT_OMEGA_SHOTMINI: A_SPosAttack(m); break;
        case MT_OMEGA_BOSS: A_BruisAttack(m); break;
        default: A_TroopAttack(m); break;
    }
}

static void shell_break(mobj_t *m)
{
    A_Fall(m);
    A_Scream(m);
    if (m->type == MT_OMEGA_BOSS)
        players[consoleplayer].message = "THE OUTER SHELL IS CRACKING!";
}

static boolean hatch(mobj_t *parent, mobjtype_t type, int side)
{
    static const int8_t offsets[][2] = {
        {1,0}, {-1,0}, {0,1}, {0,-1}, {1,1}, {-1,-1}, {-1,1}, {1,-1}, {0,0}
    };
    int i, ring;
    mobj_t probe = {0};
    mobj_t *child;
    fixed_t reach = mobjinfo[type].radius + 6 * FRACUNIT;
    probe.type = type;
    probe.radius = mobjinfo[type].radius;
    probe.height = mobjinfo[type].height;
    probe.flags = mobjinfo[type].flags;
    // An idle first child can occupy the only near site in a narrow passage.
    // Try further visible floor on both sides before waiting for it to move.
    for (ring = 1; ring <= 3; ++ring)
    {
        for (i = 0; i < (int)arrlen(offsets); ++i)
        {
            fixed_t x = parent->x + side * offsets[i][0] * ring * reach;
            fixed_t y = parent->y + side * offsets[i][1] * ring * reach;
            probe.x = x;
            probe.y = y;
            probe.subsector = R_PointInSubsector(x,y);
            probe.z = probe.subsector->sector->floorheight;
            if (abs(probe.z - parent->floorz) <= 24 * FRACUNIT &&
                P_CheckPosition(&probe,x,y) && tmceilingz - tmfloorz >= probe.height &&
                P_CheckSight(parent,&probe))
                goto found;
        }
    }
    return false;

found:
    child = P_SpawnMobj(probe.x,probe.y,ONFLOORZ,type);
    child->angle = parent->angle;
    // Source actor targets are transient across vanilla save/load. If
    // missing, normal A_Look gets the new hatchling into play.
    if (parent->target && parent->target->health > 0)
        child->target = parent->target;
    if (!child->target) P_LookForPlayers(child,true);
    if (child->target) P_SetMobjState(child,child->info->seestate);
    ++totalkills;
    S_StartSound(parent,sfx_shell);
    printf("OMEGA: %s hatched %s at (%d,%d)\n",role(parent->type),role(type),
           probe.x / FRACUNIT,probe.y / FRACUNIT);
    return true;
}

static void shell_hatch(mobj_t *m)
{
    mobjtype_t type;
    int side = m->state == &states[m->info->spawnstate + HATCH_LAST] ? -1 : 1;
    switch (m->type)
    {
        case MT_OMEGA_BOSS: type = MT_OMEGA_HEIR_HUSK; break;
        case MT_OMEGA_HEIR_HUSK: type = MT_OMEGA_HEIR_MINI; break;
        case MT_OMEGA_HUSK: case MT_OMEGA_DRUM: type = MT_OMEGA_MINI; break;
        default: return;
    }
    // Vanilla's explosive drum never calls A_Fall: its last frame removes
    // it outright. Once the blast has ended, free the hatchling's space.
    if (m->type == MT_OMEGA_DRUM) A_Fall(m);
    if (!nomonsters && !hatch(m,type,side))
    {
        // A player standing on the shell or a closed lift may temporarily
        // occupy every valid site. Retry the same birth after eight tics.
        // The predecessor is what P_MobjThinker follows on the next expiry.
        --m->state;
        m->tics = 8;
    }
}

static void set_state(int index, spritenum_t sprite, int frame, int tics,
                      void (*action)(mobj_t *), int next)
{
    state_t *state = &states[index];
    state->sprite = sprite;
    state->frame = frame;
    state->tics = tics;
    state->action.acp1 = (actionf_p1)action;
    state->nextstate = next;
}

static void monster_states(int start, spritenum_t sprite, int windup, int recovery)
{
    set_state(start+IDLE_A,sprite,0,9,A_Look,start+IDLE_B);
    set_state(start+IDLE_B,sprite,1,9,A_Look,start+IDLE_A);
    set_state(start+WALK_A,sprite,0,4,A_Chase,start+WALK_B);
    set_state(start+WALK_B,sprite,1,4,A_Chase,start+WALK_A);
    set_state(start+WINDUP,sprite,2,windup,A_FaceTarget,start+ATTACK);
    set_state(start+ATTACK,sprite,3|FF_FULLBRIGHT,5,shell_fire,start+RECOVER);
    set_state(start+RECOVER,sprite,2,recovery,NULL,start+WALK_A);
    set_state(start+PAIN,sprite,4,4,A_Pain,start+WALK_A);
    set_state(start+BREAK,sprite,5,6,shell_break,start+HATCH_FIRST);
    set_state(start+HATCH_FIRST,sprite,6,6,shell_hatch,start+HATCH_LAST);
    set_state(start+HATCH_LAST,sprite,6,4,shell_hatch,start+FALL);
    set_state(start+FALL,sprite,7,6,NULL,start+DEBRIS);
    set_state(start+DEBRIS,sprite,8,-1,shell_debris,S_NULL);
}

static void monster(mobjtype_t type, mobjtype_t base, int start, int hp,
                    int radius, int height, int speed)
{
    mobjinfo_t *m = &mobjinfo[type];
    *m = mobjinfo[base];
    m->doomednum = -1;  // Assigned by Omega_MapActor or a parent shell.
    m->spawnstate = start+IDLE_A;
    m->seestate = start+WALK_A;
    m->painstate = start+PAIN;
    m->missilestate = start+WINDUP;
    if (m->meleestate) m->meleestate = start+WINDUP;
    m->deathstate = start+BREAK;
    m->xdeathstate = S_NULL;
    m->raisestate = S_NULL;
    m->spawnhealth = hp;
    m->radius = radius * FRACUNIT;
    m->height = height * FRACUNIT;
    m->speed = speed;
}

void Omega_Init(void)
{
    int i, frame;
    static const char *const names[] = {"MINI","HUSK","OMEG"};
    char lump[9];
    omega_mode = M_CheckParm("-omega") != 0;
    if (!omega_mode) return;
    if (gamemission != doom)
        I_Error("-omega requires the Ultra Omega Barrel Doom episode-one IWAD");
    for (i=0; i<3; ++i)
        for (frame=0; frame<9; ++frame)
        {
            snprintf(lump,sizeof(lump),"%s%c0",names[i],'A'+frame);
            if (W_CheckNumForName(lump) < 0)
                I_Error("-omega: missing sprite %s; load the Ultra Omega Barrel IWAD",lump);
        }
    if (W_CheckNumForName("DSSHELL") < 0)
        I_Error("-omega: missing DSSHELL; load the Ultra Omega Barrel IWAD");

    monster_states(S_OMEGA_MINI,SPR_MINI,10,8);
    monster_states(S_OMEGA_HUSK,SPR_HUSK,12,9);
    monster_states(S_OMEGA_BOSS,SPR_OMEG,15,5);
    monster(MT_OMEGA_MINI,MT_POSSESSED,S_OMEGA_MINI,15,12,28,9);
    monster(MT_OMEGA_SHOTMINI,MT_SHOTGUY,S_OMEGA_MINI,24,12,28,9);
    monster(MT_OMEGA_HEIR_MINI,MT_POSSESSED,S_OMEGA_MINI,30,12,28,10);
    monster(MT_OMEGA_HUSK,MT_TROOP,S_OMEGA_HUSK,48,20,48,8);
    monster(MT_OMEGA_HEIR_HUSK,MT_TROOP,S_OMEGA_HUSK,125,20,48,10);
    monster(MT_OMEGA_BOSS,MT_BRUISER,S_OMEGA_BOSS,1050,24,72,10);
    // A second, independently aimed shot makes the wind-up a readable cue.
    set_state(S_OMEGA_BOSS+RECOVER,SPR_OMEG,3|FF_FULLBRIGHT,8,shell_fire,S_OMEGA_BOSS+WALK_A);

    mobjinfo[MT_OMEGA_DRUM] = mobjinfo[MT_BARREL];
    mobjinfo[MT_OMEGA_DRUM].doomednum = -1;
    mobjinfo[MT_OMEGA_DRUM].deathstate = S_OMEGA_DRUM_BREAK;
    for (i=0; i<5; ++i)
    {
        states[S_OMEGA_DRUM_BREAK+i] = states[S_BEXP+i];
        states[S_OMEGA_DRUM_BREAK+i].nextstate = S_OMEGA_DRUM_BREAK+i+1;
    }
    states[S_OMEGA_DRUM_BREAK+5] = states[S_BEXP5];
    states[S_OMEGA_DRUM_BREAK+5].action.acp1 = (actionf_p1)shell_hatch;
    states[S_OMEGA_DRUM_BREAK+5].tics = 1;
    states[S_OMEGA_DRUM_BREAK+5].nextstate = S_NULL;
    printf("OMEGA: Ultra Omega Barrel rules active\n");
}

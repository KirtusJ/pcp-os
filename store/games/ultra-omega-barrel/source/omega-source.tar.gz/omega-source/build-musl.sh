#!/bin/sh
# Build a user-local compiler wrapper with static PIE startup support.
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
prefix="${1:-$here/toolchain}"
mkdir -p "$prefix"
prefix=$(CDPATH= cd -- "$prefix" && pwd)
case "$prefix" in *" "*) echo "musl GCC specs need a toolchain path without spaces" >&2; exit 1;; esac
src=$(mktemp -d)
trap 'rm -rf "$src"' EXIT HUP INT TERM
tar -xzf "$here/musl-1.2.5.tar.gz" -C "$src"
cd "$src/musl-1.2.5"
./configure --prefix="$prefix" --syslibdir="$prefix/lib" --enable-wrapper=gcc
make -j"${JOBS:-4}"
make install
python3 - "$prefix/lib/musl-gcc.specs" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
data = path.read_text()
start = next(token[:-1] for token in data.split() if token.endswith("/Scrt1.o}"))
linker = next(line for line in data.splitlines() if line.startswith("-dynamic-linker "))
regular = " ".join(linker.split()[:2])
data = data.replace(start + "}", "%{static-pie:" + start.replace("Scrt1.o", "rcrt1.o") + ";:" + start + "}}")
data = data.replace(regular, "%{static-pie:-static -pie --no-dynamic-linker -z text;:" + regular + "}")
path.write_text(data)
PY
echo "$prefix/bin/musl-gcc"

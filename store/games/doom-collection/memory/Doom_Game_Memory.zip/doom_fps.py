#!/usr/bin/env python3
"""Measure PCP OS display presents in host wall time using QEMU's QMP monitor.

Example: python3 doom_fps.py --kernel pcpos-kernel.elf32 --socket /tmp/guest.qmp
For a dedicated QMP pipe, use --pipe PATH for PATH.in / PATH.out.
The ELF must have symbols and match the running kernel. Use a dedicated QMP
connection for this CLI. For a shared controller use FrameMeter(read_counter).
"""
import argparse
import json
import os
import re
import select
import socket
import subprocess
import time
from pathlib import Path


def frame_address(kernel):
    symbols = subprocess.check_output(["nm", "-an", str(kernel)], text=True)
    addresses = {
        int(line.split()[0], 16) for line in symbols.splitlines()
        if re.search(r"\s[bB]\s+\S*3dev5SHOWS(?:\.\S+)?$", line)
    }
    if len(addresses) != 1:
        raise ValueError("Expected one PCP OS dev::SHOWS symbol in the matching kernel ELF")
    return addresses.pop()


def read_counter(command, address):
    response = command("human-monitor-command", **{"command-line": f"xp /1gx 0x{address:x}"})
    match = re.fullmatch(r"\s*([0-9a-fA-F]+):\s*0x([0-9a-fA-F]+)\s*", response)
    if not match or int(match[1], 16) != address:
        raise ValueError(f"Unexpected guest memory response {response!r}")
    return int(match[2], 16)


class FrameMeter:
    def __init__(self, counter):
        self.counter = counter
        self.first = self.previous = self.sample()

    def sample(self):
        before = time.monotonic()
        count = self.counter()
        return (before + time.monotonic()) / 2, count

    def update(self):
        now = self.sample()
        t, count = self.previous
        if now[1] < count:
            raise RuntimeError("Frame counter reset. Start a new measurement.")
        self.previous = now
        return (now[1] - count) / (now[0] - t)

    @property
    def elapsed(self):
        return self.previous[0] - self.first[0]

    @property
    def frames(self):
        return self.previous[1] - self.first[1]


class Monitor:
    def __init__(self, path, pipe):
        self.socket = None
        if pipe:
            self.reader = os.open(str(path) + ".out", os.O_RDONLY | os.O_NONBLOCK)
            self.writer = os.open(str(path) + ".in", os.O_WRONLY | os.O_NONBLOCK)
        else:
            self.socket = socket.socket(socket.AF_UNIX)
            self.socket.settimeout(4)
            self.socket.connect(str(path))
            self.reader = self.writer = self.socket.fileno()
        self.buffer = b""
        self.sequence = 0

    def command(self, name, **args):
        self.sequence += 1
        request_id = f"{os.getpid()}-{self.sequence}"
        payload = dict(execute=name, arguments=args, id=request_id)
        os.write(self.writer, (json.dumps(payload) + "\n").encode())
        deadline = time.monotonic() + 4
        while time.monotonic() < deadline:
            while b"\n" in self.buffer:
                line, self.buffer = self.buffer.split(b"\n", 1)
                message = json.loads(line)
                if message.get("id") != request_id:
                    continue
                if "error" in message:
                    raise RuntimeError(message["error"]["desc"])
                return message["return"]
            if select.select([self.reader], [], [], max(0, deadline - time.monotonic()))[0]:
                data = os.read(self.reader, 65536)
                if not data:
                    raise EOFError("QMP monitor disconnected")
                self.buffer += data
        raise TimeoutError("No matching QMP response")

    def prepare(self):
        # A FIFO monitor may have been negotiated by an earlier invocation.
        try:
            self.command("query-status")
        except RuntimeError as exc:
            if "capabilities" not in str(exc).lower():
                raise
            self.command("qmp_capabilities")

    def close(self):
        if self.socket:
            self.socket.close()
        else:
            os.close(self.reader)
            os.close(self.writer)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kernel", type=Path, required=True)
    connection = parser.add_mutually_exclusive_group(required=True)
    connection.add_argument("--socket", type=Path)
    connection.add_argument("--pipe", type=Path)
    parser.add_argument("--seconds", type=int, default=30)
    args = parser.parse_args()
    if args.seconds < 1:
        parser.error("--seconds must be positive")
    address = frame_address(args.kernel)
    monitor = Monitor(args.socket or args.pipe, bool(args.pipe))
    try:
        monitor.prepare()
        meter = FrameMeter(lambda: read_counter(monitor.command, address))
        print("wall seconds    displayed FPS", flush=True)
        for second in range(1, args.seconds + 1):
            time.sleep(max(0, meter.first[0] + second - time.monotonic()))
            fps = meter.update()
            print(f"{meter.elapsed:12.2f}    {fps:13.2f}", flush=True)
        print(f"{meter.frames} presents / {meter.elapsed:.3f} s = "
              f"{meter.frames / meter.elapsed:.2f} FPS")
    finally:
        monitor.close()


if __name__ == "__main__":
    main()

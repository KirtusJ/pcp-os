#!/bin/sh
set -eu
play_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec python3 "$play_dir/run_fork.py" "$@"

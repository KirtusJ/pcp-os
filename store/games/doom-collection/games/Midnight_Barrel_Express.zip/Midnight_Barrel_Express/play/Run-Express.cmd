@echo off
setlocal
where py.exe >nul 2>&1
if not errorlevel 1 goto pylauncher
where python.exe >nul 2>&1
if not errorlevel 1 goto python
echo Install Python 3, then double-click Run-Express.cmd again.
goto failed
:pylauncher
py -3 "%~dp0run_rail.py" %*
goto result
:python
python "%~dp0run_rail.py" %*
:result
if not errorlevel 1 exit /b 0
:failed
pause
exit /b 1

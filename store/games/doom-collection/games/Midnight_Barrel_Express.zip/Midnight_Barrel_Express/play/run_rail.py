#!/usr/bin/env python3
"""Play Midnight Barrel Express on PCP OS using QEMU."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile


PACKAGE = Path(__file__).resolve().parents[1]


def local_file(path, filename, title):
    if path:
        if path.is_file():
            return path.resolve()
        raise FileNotFoundError(f"{title}: {path}")
    default = PACKAGE / filename
    if default.is_file():
        return default
    try:
        import tkinter
        from tkinter import filedialog
        root = tkinter.Tk()
        root.withdraw()
        try:
            chosen = filedialog.askopenfilename(parent=root, title=title, initialdir=PACKAGE)
        finally:
            root.destroy()
    except ImportError:
        chosen = None
    except tkinter.TclError:
        chosen = None
    if chosen:
        return Path(chosen).resolve()
    raise FileNotFoundError(f"{title}. Place {filename} beside install.py or supply its path.")


def find_qemu(override):
    program = override or "qemu-system-x86_64"
    found = shutil.which(program)
    if found:
        return str(Path(found).resolve())
    if not override and os.name == "nt":
        for name in ("ProgramFiles", "ProgramFiles(x86)"):
            if os.environ.get(name):
                candidate = Path(os.environ[name]) / "qemu" / "qemu-system-x86_64.exe"
                if candidate.is_file():
                    return str(candidate)
    raise FileNotFoundError("Install QEMU with x86 system emulation or pass --qemu PATH.")


def qemu_help(qemu, option):
    result = subprocess.run([qemu, option, "help"], capture_output=True, text=True,
                            errors="replace", check=False, timeout=15)
    return result.stdout + result.stderr


def sound_options(qemu, mute):
    devices = qemu_help(qemu, "-device")
    audio = qemu_help(qemu, "-audiodev")
    drivers = set(line.strip().lower() for line in audio.splitlines())
    if os.name == "nt":
        candidates = ("dsound", "sdl")
    elif sys.platform == "darwin":
        candidates = ("coreaudio", "sdl")
    else:
        candidates = ("pipewire", "pa", "sdl", "alsa")
    backend = "none" if mute else next((b for b in candidates if b in drivers), "none")
    options = ["-audiodev", backend + ",id=omega"]
    sound_devices = [device for device in ("AC97", "adlib")
                     if re.search(r'name "' + device + r'"', devices, re.I)]
    for device in sound_devices:
        options.extend(["-device", device + ",audiodev=omega"])
    if backend == "none" or not sound_devices:
        print("Launching with silent audio.", flush=True)
    elif "adlib" not in sound_devices:
        print("This QEMU build supplies sound effects only.", flush=True)
    return options


def snapshot_options(qemu, stage, kernel, fresh):
    """Use a dedicated snapshot disk per game build and QEMU version."""
    sibling = Path(qemu).with_name("qemu-img.exe" if os.name == "nt" else "qemu-img")
    image_tool = str(sibling) if sibling.is_file() else shutil.which("qemu-img")
    if not image_tool:
        print("For saves across launches, install qemu-img alongside QEMU.", flush=True)
        return [], False
    version = subprocess.check_output([qemu, "--version"]).splitlines()[0]
    identity = hashlib.sha256(version)
    identity.update(b"\0midnight-barrel-express\0")
    for file in (kernel, stage / "rail.elf", stage / "doom1.wad"):
        identity.update(hashlib.sha256(file.read_bytes()).digest())
    home = Path.home()
    if os.name == "nt":
        home = Path(os.environ.get("LOCALAPPDATA", home / "AppData/Local"))
    elif sys.platform == "darwin":
        home = home / "Library/Application Support"
    else:
        home = Path(os.environ.get("XDG_STATE_HOME", home / ".local/state"))
    directory = home / "Midnight Barrel Express"
    directory.mkdir(parents=True, exist_ok=True)
    disk = directory / (identity.hexdigest()[:24] + ".qcow2")
    if not disk.exists():
        # A racing invocation must never truncate an existing player's snapshots.
        with tempfile.TemporaryDirectory(dir=directory) as staging:
            blank = Path(staging) / "new.qcow2"
            subprocess.run([image_tool, "create", "-q", "-f", "qcow2", str(blank), "64M"],
                           check=True)
            try:
                os.link(blank, disk)
            except FileExistsError:
                pass
    info = json.loads(subprocess.check_output([image_tool, "info", "--output=json", str(disk)]))
    resume = not fresh and any(s.get("name") == "express" for s in info.get("snapshots", []))
    # QEMU option strings escape a literal comma by doubling it.
    path = str(disk).replace(",", ",,")
    options = ["-drive", f"file={path},format=qcow2,if=ide,index=0"]
    if resume:
        print("Resuming your saved Midnight Barrel Express session.", flush=True)
        options.extend(["-loadvm", "express"])
    print(f"Checkpoint disk: {disk}", flush=True)
    print("To keep progress, open the QEMU monitor (Ctrl+Alt+2), enter 'savevm express',"
          " and wait for the prompt. Ctrl+Alt+1 returns to the game.", flush=True)
    return options, True


def run_guest(command, stage):
    # PCP OS may occasionally miss a test keystroke during its cold-boot self-test.
    for attempt in range(3):
        missed_key = False
        safe_before_game = False
        with subprocess.Popen(command, cwd=stage, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, text=True, errors="replace") as guest:
            for line in guest.stdout:
                print(line, end="", flush=True)
                if "FAIL a program waiting in a read of the keyboard" in line:
                    missed_key = True
                if "(1 self-test(s) failed): it is in SAFE and starts no program" in line:
                    safe_before_game = True
            status = guest.wait()
        if status in (0, 33):
            return
        if status != 35 or not (missed_key and safe_before_game) or attempt == 2:
            raise RuntimeError(f"QEMU exited with status {status}.")
        print("PCP OS missed a keyboard self-test input. Restarting the guest.", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--iwad", type=Path, help="original Doom shareware 1.9 doom1.wad")
    parser.add_argument("--kernel", type=Path, help="PCP OS pcpos-kernel.elf32")
    parser.add_argument("--qemu", help="qemu-system-x86_64 executable")
    parser.add_argument("--mute", action="store_true", help="play silently")
    parser.add_argument("--fresh", action="store_true", help="start the game without loading a checkpoint")
    args = parser.parse_args()
    try:
        qemu = find_qemu(args.qemu)
        engine = PACKAGE / "rail.elf"
        if not engine.is_file():
            raise FileNotFoundError(f"Extract the full game package. {engine.name} is missing.")
        base = local_file(args.iwad, "doom1.wad", "Choose the original shareware Doom 1.9 IWAD")
        kernel = local_file(args.kernel, "pcpos-kernel.elf32", "Choose your PCP OS kernel")
        audio = sound_options(qemu, args.mute)
        # The multiboot loader splits each module name at its first space.
        # Staging relative names also works when the player's path contains commas.
        with tempfile.TemporaryDirectory(prefix="midnight-barrel-express-") as stage_name:
            stage = Path(stage_name)
            source = base
            steps = [("install.py", "campaign.wad"), ("install_rail.py", "doom1.wad")]
            for installer, output in steps:
                subprocess.run([sys.executable, str(PACKAGE / installer), str(source),
                                str(stage / output)], check=True)
                source = stage / output
            shutil.copyfile(engine, stage / "rail.elf")
            snapshots, has_monitor = snapshot_options(qemu, stage, kernel, args.fresh)
            command = [qemu, "-name", "Midnight Barrel Express", "-machine", "pc,accel=tcg",
                       "-cpu", "max", "-m", "256M", "-vga", "std", "-nic", "none",
                       "-kernel", str(kernel), "-initrd",
                       "rail.elf -omega -express -warp 1 9 -iwad doom1.wad,doom1.wad",
                       "-append", "auto=rail.elf then=off", "-serial", "stdio", "-monitor",
                       "vc" if has_monitor else "none", "-no-reboot",
                       "-device", "isa-debug-exit,iobase=0xf4,iosize=0x04", *audio, *snapshots]
            print("Opening Midnight Barrel Express. Arrows move and turn. Ctrl fires. Space operates the train.", flush=True)
            run_guest(command, stage)
    except (OSError, subprocess.SubprocessError, RuntimeError, ValueError) as error:
        parser.exit(1, f"{error}\n")


if __name__ == "__main__":
    main()

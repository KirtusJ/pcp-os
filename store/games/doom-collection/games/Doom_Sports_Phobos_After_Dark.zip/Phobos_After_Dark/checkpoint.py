"""Optional, local QEMU checkpoints for Phobos After Dark."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def _save_directory():
    home = Path.home()
    if os.name == 'nt':
        base = Path(os.environ.get('LOCALAPPDATA') or home / 'AppData' / 'Local')
    elif sys.platform == 'darwin':
        base = home / 'Library' / 'Application Support'
    else:
        base = Path(os.environ.get('XDG_STATE_HOME') or home / '.local' / 'state')
    return base / 'Phobos After Dark'


def checkpoint_options(qemu, stage, kernel, fresh, machine_options=()):
    """Return QEMU arguments and whether a graphical monitor should be enabled."""
    qemu = Path(qemu)
    sibling = qemu.with_name('qemu-img.exe' if os.name == 'nt' else 'qemu-img')
    tool = str(sibling) if sibling.is_file() else shutil.which('qemu-img')
    if not tool:
        print('Playing without checkpoints. Install qemu-img with QEMU to save rounds.', flush=True)
        return [], False

    stage = Path(stage)
    version = subprocess.check_output([str(qemu), '--version'], timeout=15).splitlines()[0]
    identity = hashlib.sha256(b'phobos-after-dark/checkpoint-v1\0' + version)
    # A saved VM includes its devices. Host audio backend names may differ, but
    # AC97 and OPL must be plugged in exactly as they were at save time.
    devices = [machine_options[i + 1] for i, value in enumerate(machine_options[:-1])
               if value == '-device']
    identity.update(json.dumps(devices, separators=(',', ':')).encode())
    for path in (Path(kernel), stage / 'golf.elf', stage / 'doom1.wad'):
        with path.open('rb') as handle:
            digest = hashlib.sha256()
            for chunk in iter(lambda: handle.read(1024 * 1024), b''):
                digest.update(chunk)
        identity.update(digest.digest())

    directory = _save_directory()
    directory.mkdir(parents=True, exist_ok=True)
    disk = directory / (identity.hexdigest() + '.qcow2')
    if not disk.exists():
        # Never replace an existing player's checkpoint disk during a racing launch.
        with tempfile.TemporaryDirectory(dir=directory) as tmp:
            blank = Path(tmp) / 'new.qcow2'
            subprocess.run([tool, 'create', '-q', '-f', 'qcow2', str(blank), '64M'],
                           check=True, timeout=30)
            try:
                os.link(blank, disk)
            except FileExistsError:
                pass
    raw = subprocess.check_output([tool, 'info', '--output=json', str(disk)], timeout=30)
    info = json.loads(raw)
    if info.get('format') != 'qcow2' or info.get('backing-filename'):
        raise ValueError(f'Invalid golf checkpoint disk: {disk}')
    # The path is embedded in a QEMU key/value option. Double literal commas.
    arguments = ['-drive', f'file={str(disk).replace(",", ",,")},format=qcow2,if=ide,index=0']
    if not fresh and any(entry.get('name') == 'golf' for entry in info.get('snapshots', [])):
        arguments += ['-loadvm', 'golf']
        print('Resuming the saved golf round.', flush=True)
    print(f'Checkpoint disk: {disk}', flush=True)
    print('Ctrl+Alt+2 opens the monitor. Enter savevm golf, wait for the prompt, '
          'then press Ctrl+Alt+1 to return to the course.', flush=True)
    return arguments, True

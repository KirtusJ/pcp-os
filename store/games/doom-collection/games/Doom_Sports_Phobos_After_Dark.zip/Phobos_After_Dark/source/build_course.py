"""Compile original classic DOOM golf courses. Usage: python build_course.py doom1.wad course.wad"""
from pathlib import Path
from math import sin, cos, pi
from struct import pack, unpack_from, iter_unpack
import random, sys
from PIL import Image, ImageDraw
from course_data import HOLES, NIGHT_HOLES
import night_art

MAP_NAMES="THINGS LINEDEFS SIDEDEFS VERTEXES SEGS SSECTORS NODES SECTORS REJECT BLOCKMAP".split()

def records(fmt, rows):
    return b"".join(pack(fmt,*r) for r in rows)

def lump_set(path):
    raw=Path(path).read_bytes()
    _,n,ofs=unpack_from('<4sII',raw)
    return {name.rstrip(b'\0').decode():raw[start:start+length] for start,length,name in iter_unpack('<II8s',raw[ofs:ofs+16*n])}

def wad(path, lumps):
    payload=bytearray()
    entries=[]
    for name,body in lumps:
        entries.append((12+len(payload),len(body),name.encode()))
        payload.extend(body)
    Path(path).write_bytes(pack('<4sII',b'PWAD',len(entries),12+len(payload))+payload+records('<II8s',entries))

FONT={
 'A':'010101111101101','B':'110101110101110','C':'011100100100011','D':'110101101101110',
 'E':'111100110100111','F':'111100110100100','G':'011100101101011','H':'101101111101101',
 'I':'111010010010111','J':'001001001101010','K':'101101110101101','L':'100100100100111',
 'M':'101111111101101','N':'101111111111101','O':'010101101101010','P':'110101110100100',
 'Q':'010101101111011','R':'110101110101101','S':'011100010001110','T':'111010010010010',
 'U':'101101101101111','V':'101101101101010','W':'101101111111101','X':'101101010101101',
 'Y':'101101010010010','Z':'111001010100111','0':'111101101101111','1':'010110010010111',
 '2':'110001010100111','3':'110001010001110','4':'101101111001001','5':'111100110001110',
 '6':'011100111101111','7':'111001010010010','8':'111101111101111','9':'111101111001110',
 ' ':'000000000000000'}
def label(draw,text,x,y,color,scale=1):
    for letter in text:
        bits=FONT[letter]
        for n,ink in enumerate(bits):
            if ink=='1':
                px=x+(n%3)*scale;py=y+(n//3)*scale
                draw.rectangle((px,py,px+scale-1,py+scale-1),fill=color)
        x+=4*scale

def indexed(im,palette,transparent=False):
    # Use only true Doom palette entries; PNG palettization can pick unused padded entries.
    src=im.convert("RGBA"); pixels=list(zip(*[iter(src.tobytes())]*4))
    hist={rgb[:3] for rgb in pixels if rgb[3]}
    lookup={rgb:min(range(256),key=lambda k:sum((palette[3*k+i]-rgb[i])**2 for i in range(3))) for rgb in hist}
    return [lookup.get((r,g,b),0) if a else None for r,g,b,a in pixels]

def patch(im,pal):
    w,h=im.size;pixels=indexed(im,pal,True); body=bytearray();starts=[]
    for x in range(w):
        starts.append(8+4*w+len(body))
        y=0
        while y<h:
            if pixels[y*w+x] is None:y+=1;continue
            start=y;vals=[]
            while y<h and pixels[y*w+x] is not None:
                vals.append(pixels[y*w+x]);y+=1
            body.extend([start,len(vals),0,*vals,0])
        body.append(255)
    return pack('<4h',w,h,0,0)+pack('<'+'I'*w,*starts)+body

def flat(kind,pal):
    rng=random.Random(710+sum(map(ord,kind)));im=Image.new('RGB',(64,64));p=im.load()
    for y in range(64):
        for x in range(64):
            n=rng.choices((-9,-5,0,4,9),weights=(1,2,4,2,1))[0]
            if kind=='GFROUGH': col=(41,63,28);n+=3*((x//2+y//3)%3)
            if kind in ('GFFAIR1','GFFAIR2'): col=(66,103,39) if kind[-1]=='1' else (58,87,30);n+=3*((x+y)%3)
            if kind=='GFGREEN':col=(109,139,61);n+=2*((x+y)%3)
            if kind=='GFTEE':col=(83,106,46);n+=12 if x in (2,3,60,61) or y in (2,3,60,61) else 0
            if kind=='GFSAND':col=(163,128,77);n+=6*sin((y+2*sin(x*pi/16))*pi/4)
            if kind=='GFWATER':
                wave=sin((y+3*sin(x*pi/32))*pi/6)
                col=(0,0,125) if wave<-.30 else ((0,0,170) if wave<.82 else (54,55,232));n*=.25
            if kind=='GFLAVA':
                vein=abs(sin((x+10*sin(y*pi/32))*pi/18)+cos(y*pi/12))
                col=(226,107,23) if vein<.22 else ((168,55,18) if vein<.60 else (81,35,25))
            if kind=='GFTURF':col=(45,41,31)
            if kind in ('GFGREEN','GFFAIR1','GFFAIR2','GFROUGH','GFTEE'):n*=.52
            p[x,y]=tuple(max(0,min(255,round(c+n))) for c in col)
    return bytes(indexed(im,pal))

def blank(w,h):return Image.new('RGBA',(w,h))
def sky():
    im=blank(256,128);d=ImageDraw.Draw(im);rng=random.Random(515)
    for y in range(128):
        # A copper atmosphere over Phobos, ending in dusty mountains.
        c=(int(24+min(y,87)*.86),int(20+min(y,87)*.40),int(32+min(y,87)*.26))
        d.line((0,y,255,y),fill=c)
    for i in range(165):
        x=rng.randrange(256);y=rng.randrange(69);col=rng.choice([(130,112,101),(203,191,150),(91,80,91)])
        d.point((x,y),fill=col)
    d.ellipse((92,19,119,46),fill=(64,48,44));d.ellipse((91,18,117,44),fill=(175,99,60))
    for y in (23,26,32,36):
        d.arc((93,y-2,116,y+5),0,185,fill=(127,75,52))
    d.arc((80,21,130,44),165,338,fill=(205,165,110),width=2)
    for lay in range(3):
        ridge=[]
        for x in range(257):
            h=76+lay*6+5*sin(2*pi*x/64+lay)+6*sin(2*pi*x/128+2.3*lay)+2*sin(2*pi*x/16+lay)
            ridge.append((x,int(h)))
        d.polygon([(0,128),*ridge,(256,128)],fill=[(88,61,60),(70,51,51),(49,42,43)][lay])
    return im

def flag(index):
    im=blank(64,96);d=ImageDraw.Draw(im)
    d.ellipse((25,91,40,95),fill=(22,28,15));d.line((32,14,32,92),fill=(35,29,19),width=3)
    d.line((31,12,31,92),fill=(231,218,170),width=2)
    for y in range(45,88,12):d.line((31,y,31,y+5),fill=(107,56,33),width=2)
    color=[(185,49,28),(45,105,147),(214,117,19)][index]
    d.polygon([(32,12),(49,15),(60,12),(57,31),(45,33),(32,29)],fill=(40,27,17))
    d.polygon([(32,11),(49,14),(60,11),(56,28),(45,31),(32,27)],fill=color)
    label(d,str(index+1),36,15,(255,238,187),2)
    return im

def sign(index):
    im=blank(64,64);d=ImageDraw.Draw(im);c=[(130,56,28),(24,80,107),(143,54,23)][index]
    d.rectangle((13,29,16,63),fill=(86,67,46));d.rectangle((49,29,52,63),fill=(86,67,46))
    d.rounded_rectangle((2,8,61,44),3,fill=(30,32,27),outline=(202,164,93),width=2)
    d.rectangle((5,11,58,19),fill=c);label(d,"PHOBOS",8,13,(255,226,154))
    label(d,"0"+str(index+1),8,23,(242,216,152),3);label(d,"PAR",36,23,(192,162,98))
    label(d,str(index+3),41,31,(236,213,166),2)
    return im

def landscape(index):
    im=blank(256,128);d=ImageDraw.Draw(im)
    # Observatory, aqueduct pumping station and volcanic foundry at the far green.
    light=(199,150,82); dark=(47,42,35); shade=(77,63,49);steel=(120,100,75)
    d.polygon([(0,127),(8,118),(44,119),(61,111),(114,113),(151,106),(186,115),(219,112),(255,125),(255,127)],fill=shade)
    def rect(x0,y0,x1,y1,fill):d.rectangle((x0,y0,x1,y1),fill=fill)
    if index==0:
        for x,h,w in [(40,70,46),(132,50,74),(200,89,38)]:
            rect(x,h+17,x+w,119,dark);d.pieslice((x,h,x+w,h+44),180,359,fill=steel,outline=dark)
            d.arc((x+8,h,x+w-8,h+44),180,350,fill=shade)
            rect(x+2,h+20,x+w-2,h+23,light)
            for xx in range(x+6,x+w-4,9):rect(xx,h+30,xx+4,h+33,(193,139,63))
        d.line((109,113,109,46),fill=steel,width=2);d.line((101,63,119,54),fill=light,width=2);d.point((109,44),fill=(255,174,67))
    elif index==1:
        for x,h in [(23,77),(87,66),(158,65),(215,80)]:
            rect(x,h,x+17,121,shade);rect(x-2,h-8,x+19,h,steel);rect(x+4,h+2,x+7,116,light)
        rect(17,77,239,84,steel)
        for x in range(19,236,15):
            d.line((x,78,x+8,69,x+16,78),fill=light,width=2)
        rect(62,89,181,92,(82,95,97));rect(105,45,145,73,dark)
        d.polygon([(100,46),(125,28),(150,46)],fill=steel)
        for x in (109,120,131):rect(x,54,x+6,60,(205,155,77))
    else:
        for x,ht in [(18,64),(48,48),(179,37),(207,58)]:
            d.polygon([(x-5,119),(x+1,ht),(x+11,ht),(x+18,120)],fill=shade)
            rect(x,ht-3,x+13,ht+2,steel);rect(x+1,ht+4,x+6,ht+10,(232,123,43))
        d.polygon([(58,120),(72,70),(94,68),(107,46),(122,67),(145,66),(165,119)],fill=dark)
        for x in range(75,152,12):rect(x,84,x+5,104,(217,82,21))
        d.line((100,58,108,47,116,58),fill=light,width=2)
    return im
def map_lumps(number,hole):
    x0,x1,y0,y1=hole.bounds
    cx,cy=hole.cup
    markers=[(cx,cy-32,cy+32,'GPFLAG'+str(number)),(128,-112,-48,'GPSIGN'+str(number)),
             (x1-16,cy-128,cy+128,'GPVIEW'+str(number))]
    night=number>=4
    if night:
        markers=[(176,-144,-48,'NSIGN'+str(number)),
                 (x1-44,cy-128,cy+128,'NVIEW'+str(number)),
                 (260,64,192,'NPROP'+str(number)),
                 (334,-192,-64,'NLAMP'+str(number)),
                 (x1-176,64,192,'NLAMP'+str(number))]
        if number!=6:markers.append((cx,cy-32,cy+32,'NFLAG'+str(number)))
    xs={x0-32,x0,-32,32,64,x1,x1+32,cx-100,cx-72,cx+72,cx+100,cx}
    ys={y0-32,y0,-32,32,y1,y1+32,cy,cy-80,cy-56,cy+56,cy+80}
    xs.update(x for x in (192,384,576,768) if x<x1)
    ys.update((-96,96))
    if night:
        # Linedefs for structures and hazards already partition most lawns.
        # Keep only the boundaries needed for the tee, play area and green.
        xs={x0-32,x0,-32,32,cx-72,cx+72,x1,x1+32}
        ys={y0-32,y0,-32,32,cy-56,cy+56,y1,y1+32}
    for _,l,r,b,t in hole.hazards:xs.update((l,r));ys.update((b,t))
    if number==6:xs.update((868,932));ys.update((-256,256))
    for x,l,r,_ in markers:xs.add(x);ys.update((l,r))
    xs,ys=sorted(xs),sorted(ys)
    vertices=[(x,y) for x in xs for y in ys]
    ids={v:i for i,v in enumerate(vertices)}
    leaves={};sects=[]; sec_ids={}; lines=[]; line_ids={};sides=[];subsects=[];segs=[];nodes=[]
    def lawn(x,y):
        if x<x0 or x>x1 or y<y0 or y>y1:return 'GFTURF',12,12
        for name,l,r,b,t in hole.hazards:
            if l<x<r and b<y<t:return name,0,160
        if ((x-cx)/103)**2+((y-cy)/85)**2<1.:return 'GFGREEN',0,160
        if abs(x)<32 and abs(y)<32:return 'GFTEE',0,160
        path=hole.path
        for (xa,ya),(xb,yb) in zip(path,path[1:]):
            if xa-56<=x<=xb+60:
                f=max(0,min(1,(x-xa)/(xb-xa)));offset=abs(y-(ya+(yb-ya)*f))
                if offset<89:return ('GFFAIR1' if (int(x)//96)%2==0 else 'GFFAIR2'),0,160
        return 'GFROUGH',0,160
    def sec(i,j):
        x,y=(xs[i]+xs[i+1])/2,(ys[j]+ys[j+1])/2
        kind,low,high=lawn(x,y)
        light=224
        if night:
            kind={'GFTEE':'NGTEE','GFFAIR1':'NGFAIR1','GFFAIR2':'NGFAIR2','GFROUGH':'NGROUGH','GFGREEN':'NGGREEN','GFSAND':'NGSAND','GFWATER':'NGWATER','GFLAVA':'NGLAVA'}.get(kind,kind)
            if number==6 and 868<x<932 and -256<y<256:kind='NGRAIL'
            # Four simple pools of light across each fairway. Each radius is
            # evaluated per leaf, so the native renderer shades floor and props.
            pools=[(0,0,164),(260,144,128),(334,-180,135),(cx,cy,160)]
            light=184
            if any((x-px)**2+(y-py)**2<r*r for px,py,r in pools):light=208
            if kind in ('NGTEE','NGGREEN','NGLAVA','NGRAIL'):light=224
        key=(kind,low,high,light)
        if key not in sec_ids:
            f,low,high,light=key;sec_ids[key]=len(sects)
            sects.append((low,high,f.encode(),b'F_SKY1',light,0,0))
        return sec_ids[key]
    def midtex(a,b,side):
        if a[0]!=b[0]:return '-',0
        lo,hi=sorted((a[1],b[1]))
        for mx,ml,mh,name in markers:
            if mx==a[0] and ml<=lo and hi<=mh:
                return name,(mh-hi if side==2 else lo-ml)
        return '-',0
    cells={(i,j) for i in range(len(xs)-1) for j in range(len(ys)-1)}
    for i,j in sorted(cells,key=lambda c:(c[1],c[0])):
        x,xx=xs[i:i+2];y,yy=ys[j:j+2]; own=sec(i,j);first=len(segs)
        corners=[(x,y),(x,yy),(xx,yy),(xx,y)]
        for side,(a,b,neigh) in enumerate(zip(corners,corners[1:]+corners[:1],[(i-1,j),(i,j+1),(i+1,j),(i,j-1)])):
            inside=neigh in cells;tex,shift=midtex(a,b,side)
            if not inside:tex='GPKERB'
            va,vb=ids[a],ids[b]; edge=tuple(sorted((va,vb)))
            sd=len(sides);sides.append((shift,0,b'-',b'GPKERB' if inside and sects[own][0]!=sects[sec(*neigh)][0] else b'-',tex.encode(),own))
            if edge in line_ids:
                lid=line_ids[edge];lines[lid][-1]=sd;rev=1
            else:
                lid=len(lines);line_ids[edge]=lid
                flags=(4 if inside else 1) | (16 if tex!='-' else 0)
                if inside and sects[own][0]!=sects[sec(*neigh)][0]:flags|=1
                lines.append([va,vb,flags,0,0,sd,65535]);rev=0
            segs.append((va,vb,(16384,0,49152,32768)[side],lid,rev,0))
        leaves[i,j]=len(subsects);subsects.append((4,first))
    def box(cs):return max(ys[j+1] for i,j in cs),min(ys[j] for i,j in cs),min(xs[i] for i,j in cs),max(xs[i+1] for i,j in cs)
    def branch(cs):
        if len(cs)==1:return 32768|leaves[next(iter(cs))]
        top,bottom,left,right=box(cs);cols=sorted({i for i,j in cs});rows=sorted({j for i,j in cs})
        if len(rows)==1 or (len(cols)>1 and right-left>=top-bottom):
            split=cols[len(cols)//2];front={c for c in cs if c[0]>=split};axis=(xs[split],bottom,0,top-bottom)
        else:
            split=rows[len(rows)//2];front={c for c in cs if c[1]<split};axis=(left,ys[split],right-left,0)
        back=cs-front;a=branch(front);b=branch(back)
        nodes.append((*axis,*box(front),*box(back),a,b));return len(nodes)-1
    branch(cells)
    xo,yo=xs[0]-8,ys[0]-8;nx=(xs[-1]-xo)//128+1;ny=(ys[-1]-yo)//128+1
    offsets=[];blocks=[]
    for j in range(ny):
        for i in range(nx):
            bx,by=xo+128*i,yo+128*j
            group=[]
            for n,(a,b,*_) in enumerate(lines):
                (u,v),(uu,vv)=vertices[a],vertices[b]
                if max(u,uu)>=bx and min(u,uu)<=bx+128 and max(v,vv)>=by and min(v,vv)<=by+128:group.append(n)
            offsets.append(4+nx*ny+len(blocks));blocks.extend([0,*group,-1])
    bm=pack('<4h',xo,yo,nx,ny)+records('<H',((v,) for v in offsets))+records('<h',((v,) for v in blocks))
    return [('E1M'+str(number),b''),*zip(MAP_NAMES,[
        pack('<5h',0,0,0,1,7),records('<7H',lines),records('<hh8s8s8sH',sides),
        records('<hh',vertices),records('<6H',segs),records('<2H',subsects),records('<12h2H',nodes),
        records('<hh8s8s3h',sects),bytes((len(sects)**2+7)//8),bm])]
def kerb():
    im=Image.new('RGB',(64,64),(83,70,50));d=ImageDraw.Draw(im)
    for y in (0,12,24,36,48,60):
        d.line((0,y,63,y),fill=(129,108,74));d.line((0,y+1,63,y+1),fill=(53,47,37))
        for x in range(8 if y%24==0 else 24,64,32):d.line((x,y+1,x,y+11),fill=(63,54,40))
    return im
def main():
    if len(sys.argv)!=3:raise SystemExit('Usage: python build_course.py doom1.wad course.wad')
    pal=lump_set(sys.argv[1])['PLAYPAL'][:768];lumps=[]
    for num,hole in enumerate(HOLES,1):lumps.extend(map_lumps(num,hole))
    for num,hole in enumerate(NIGHT_HOLES,4):lumps.extend(map_lumps(num,hole))
    lumps.append(('F_START',b''))
    for name in ('GFTEE','GFFAIR1','GFFAIR2','GFROUGH','GFGREEN','GFSAND','GFWATER','GFLAVA','GFTURF'):
        lumps.append((name,flat(name,pal)))
    for name in ('NGTEE','NGFAIR1','NGFAIR2','NGROUGH','NGGREEN','NGSAND','NGWATER','NGLAVA','NGRAIL'):
        lumps.append((name,bytes(indexed(night_art.materials(name),pal))))
    lumps.extend([('F_END',b''),('P_START',b''),('GPSKY',patch(sky(),pal)),('GPKERB',patch(kerb(),pal))])
    for i in range(3):
        for prefix,gen in [('GPFLAG',flag),('GPSIGN',sign),('GPVIEW',landscape)]:
            lumps.append((prefix+str(i+1),patch(gen(i),pal)))
    for n in range(4,7):
        resources={'GPSKY':night_art.night_sky(n),'NSIGN':night_art.sign(n),'NVIEW':night_art.landmark(n),'NPROP':night_art.wayside(n,'prop'),'NLAMP':night_art.wayside(n,'lamp')}
        if n!=6:resources['NFLAG']=night_art.flag(n)
        for name,image in resources.items():lumps.append((name+str(n),patch(image,pal)))
    lumps.append(('P_END',b''));wad(sys.argv[2],lumps)
if __name__=='__main__':main()

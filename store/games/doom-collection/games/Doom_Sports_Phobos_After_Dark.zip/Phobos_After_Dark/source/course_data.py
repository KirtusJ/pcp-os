"""Geometry shared by the Phobos Pitch & Putt map compiler and its tests."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Hole:
    title: str
    par: int
    cup: tuple[int, int]
    bounds: tuple[int, int, int, int]
    hazards: tuple
    path: tuple

HOLES = (
    Hole("CRATER GREEN",3,(480,0),(-128,640,-224,224),
         (("GFSAND",208,304,-144,-40),), ((0,0),(480,0))),
    Hole("CANAL NINE",4,(768,96),(-128,928,-288,288),
         (("GFWATER",288,400,-288,64),("GFSAND",576,656,48,152)),
         ((0,0),(272,100),(448,110),(768,96))),
    Hole("HELLMOUTH",5,(960,-96),(-128,1120,-352,352),
         (("GFLAVA",384,544,-96,352),("GFSAND",704,800,-224,-96)),
         ((0,0),(290,-100),(580,-172),(960,-96))),
)

NIGHT_HOLES = (
    Hole("SIGNAL HILL", 3, (560,80), (-128,736,-256,256),
         (("GFSAND",224,320,-160,-32), ("GFWATER",384,480,128,256)),
         ((0,0),(256,32),(560,80))),
    Hole("THE SPILLWAY", 4, (784,-96), (-128,960,-320,320),
         (("GFWATER",320,448,-320,40), ("GFSAND",560,672,-16,112)),
         ((0,0),(280,88),(468,108),(784,-96))),
    Hole("DEIMOS JUNCTION", 5, (900,0), (-128,1120,-320,320),
         (("GFSAND",256,368,40,176), ("GFLAVA",528,640,-320,-64)),
         ((0,0),(384,-36),(608,24),(900,0))),
)

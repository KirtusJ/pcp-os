"""Original indexed materials and masked scenery for The Night Shift Open.

Scenery is pixel-art drawn in map units. Sixteen-pixel piles, cross braces,
glazed windows and track gauge stay consistent from prop to skyline.
"""
from math import sin, cos, pi, hypot
import random
from PIL import Image, ImageDraw

# Values near entries in DOOM's native PLAYPAL, kept distinct after quantizing.
INK=(13,12,18); NIGHT=(22,20,29); SLATE=(48,47,54); STEEL=(87,86,90)
FOG=(94,85,91); SILVER=(166,161,147); IVORY=(248,230,183)
AMBER=(249,181,61); GOLD=(210,121,37); RUST=(111,56,39)
BLUE=(65,69,153); ICE=(151,176,205); VIOLET=(117,64,108)
RED=(240,55,30); GREEN=(118,189,85)
ACCENTS=(AMBER,ICE,RED)

def cloudline(draw, base, amplitude, frequency, tint, seed):
    rng=random.Random(seed)
    xy=[(x, int(base+amplitude*sin(x*pi/64+frequency)+amplitude*.51*sin(x*pi/32+frequency*2)+amplitude*.22*sin(x*pi/8))) for x in range(256)]
    draw.polygon([(0,128),*xy,(255,128)],fill=tint)

def night_sky(n):
    rng=random.Random(1129+n)
    img=Image.new('RGB',(256,128)); d=ImageDraw.Draw(img)
    zenith,horizon,far,near=(
        ((8,8,16),(62,38,46),(50,36,43),(33,30,36)),
        ((5,7,20),(56,54,82),(58,53,69),(35,35,46)),
        ((16,5,11),(96,43,34),(71,43,44),(41,34,37)),
    )[n-4]
    for y in range(128):
        k=min(1,y/91)**1.4
        c=tuple(round(zenith[i]*(1-k)+horizon[i]*k) for i in range(3))
        d.line((0,y,255,y),fill=c)
    for _ in range(160):
        x,y=rng.randrange(256),rng.randrange(84)
        c=rng.choice([SLATE,SLATE,STEEL,ICE,IVORY])
        d.point((x,y),fill=c)
    for x,y in [(35,31),(169,42),(221,12)]:
        d.line((x-2,y,x+2,y),fill=STEEL);d.line((x,y-2,x,y+2),fill=STEEL);d.point((x,y),fill=IVORY)
    # Looking east in this renderer spans the wrap between columns 0 and 255.
    if n==4:
        for center in [19,275]:
            x,y,r=center,44,24
            d.ellipse((x-r-1,y-r-1,x+r+1,y+r+1),fill=(92,76,68))
            d.ellipse((x-r,y-r,x+r,y+r),fill=(210,176,133))
            for _ in range(55):
                dx,dy=rng.randrange(-22,22),rng.randrange(-22,22);rr=rng.choice([1,1,2,3,4])
                if hypot(dx,dy)+rr>r-1:continue
                d.ellipse((x+dx-rr,y+dy-rr,x+dx+rr,y+dy+rr),fill=(149,124,102))
                d.arc((x+dx-rr,y+dy-rr,x+dx+rr,y+dy+rr),45,170,fill=(236,202,148))
            d.arc((x-r,y-r,x+r,y+r),126,275,fill=IVORY,width=2)
    elif n==5:
        for phase,color in [(0,(43,41,62)),(4,(61,59,94)),(7,(82,78,120)),(9,(62,63,102))]:
            for x in range(256):
                y=round(39+11*sin(x*pi/128)+8*sin(x*pi/64)+phase)
                d.line((x,y,x,y+2+int(1.5*(1+cos(x*pi/32)))),fill=color)
        d.ellipse((221,24,234,37),fill=ICE);d.ellipse((225,22,237,34),fill=(25,24,39))
    else:
        for x in [21,277]:
            for r,color in [(26,(104,51,39)),(23,(159,67,30)),(21,(239,124,45)),(19,IVORY),(17,(54,36,39))]:
                d.ellipse((x-r,43-r,x+r,43+r),fill=color)
            d.ellipse((x-15,25,x+19,60),fill=(35,27,33))
    cloudline(d,71,9,.4,(69,57,65) if n==5 else far,14)
    cloudline(d,80,5,2,near,2)
    for x in range(256):
        if 46<x<80 or 122<x<199:
            h=8+int(8*abs(sin(x*.38)) +4*sin(x*.7))
            d.line((x,92-h,x,91),fill=(39,36,41))
            if x%5==0:d.point((x,89),fill=AMBER if n!=5 else ICE)
    for x in range(0,256,9):
        d.point((x,93+rng.randrange(2)),fill=rng.choice((GOLD,FOG,SLATE)))
    return img

def blank(w,h):
    return Image.new('RGBA',(w,h))

def text(d,s,x,y,fill,scale=1):
    from build_course import label
    label(d,s,x,y,fill,scale)

def scaffold(d,x,y,width,height):
    d.rectangle((x,y,x+width,y+height),fill=INK)
    for px in (x+1,x+width-2):
        d.line((px,y,px,y+height),fill=STEEL,width=2)
    for yy in range(y+2,y+height,12):
        ey=min(y+height,yy+11)
        d.line((x+2,yy,x+width-2,ey),fill=SLATE)
        d.line((x+width-2,yy,x+2,ey),fill=STEEL)
        d.line((x,yy,x+width,yy),fill=STEEL)

def lamps(d,x,y):
    d.line((x+1,y+4,x+1,127),fill=INK,width=4);d.line((x,y+5,x,127),fill=STEEL)
    d.polygon(((x-17,y-2),(x+17,y-2),(x+16,y+4),(x-16,y+4)),fill=SLATE,outline=INK)
    for xx in (x-12,x-4,x+4,x+12):
        d.rectangle((xx-2,y,xx+2,y+3),fill=IVORY);d.point((xx,y+4),fill=GOLD)
def silo(d,x,y,w,base,accent):
    d.rectangle((x,y+5,x+w,base),fill=SLATE,outline=INK)
    d.ellipse((x,y,x+w,y+12),fill=STEEL,outline=INK)
    for dx,c in [(1,STEEL),(3,SILVER),(w//3,STEEL),(w-4,INK)]:
        d.line((x+dx,y+8,x+dx,base),fill=c)
    for yy in range(y+14,base,11):
        d.line((x+1,yy,x+w-1,yy),fill=INK)
    d.rectangle((x+1,y+11,x+w-1,y+13),fill=accent)
    d.line((x+w-7,y+4,x+w-7,base),fill=STEEL)
    for yy in range(y+7,base,4):d.line((x+w-8,yy,x+w-5,yy),fill=STEEL)

def radar(d,x,y):
    # Parabolic receiving reflector tilted off-axis on its mount.
    d.polygon(((x-25,y-13),(x+21,y+3),(x+7,y+13),(x-4,y+14),(x-16,y+7)),fill=SLATE,outline=SILVER)
    for xo in range(-21,18,5):
        d.line((x+xo,y-11+int((xo+21)*.35),x+1,y+12),fill=STEEL)
    d.line((x-6,y-4,x-1,y-19,x+8,y),fill=SILVER)
    d.ellipse((x-3,y-22,x+1,y-18),fill=RED)
    d.polygon(((x-2,y+13),(x+5,y+13),(x+13,y+31),(x-11,y+31)),fill=STEEL,outline=INK)
    d.line((x,y+15,x+9,y+29),fill=SLATE,width=2)

def station(d,x,y,w,base):
    d.rectangle((x,y+7,x+w,base),fill=SLATE,outline=INK)
    d.polygon(((x-5,y+8),(x+8,y-5),(x+w-8,y-5),(x+w+5,y+8)),fill=INK,outline=STEEL)
    d.line((x-4,y+8,x+w+4,y+8),fill=AMBER,width=2)
    for dx in range(4,w-5,9):
        d.rectangle((x+dx,y+14,x+dx+5,y+23),fill=GOLD)
        d.line((x+dx+2,y+14,x+dx+2,y+23),fill=INK)
        d.line((x+dx,y+18,x+dx+4,y+18),fill=IVORY)

def landmark(n):
    im=blank(256,128);d=ImageDraw.Draw(im)
    d.polygon(((0,127),(10,118),(45,117),(69,108),(120,111),(150,99),(198,115),(234,111),(255,123),(255,127)),fill=SLATE)
    if n==4:
        for x,y in ((59,70),(177,78)):
            silo(d,x,y,24,119,RUST)
        station(d,79,84,86,121)
        radar(d,122,49)
        scaffold(d,116,79,12,35)
        for x,y in [(32,16),(202,39)]:
            scaffold(d,x,y+8,7,115-y);d.line((x+3,y-7,x+3,y+11),fill=SILVER);d.ellipse((x+1,y-9,x+5,y-5),fill=RED)
        lamps(d,225,66)
    elif n==5:
        for x,y in ((13,36),(50,16),(199,22),(225,54)):
            silo(d,x,y,18,119,ICE)
        for xx in range(61,204,9):
            d.line((xx,61,xx+9,50,xx+18,61),fill=STEEL,width=2)
        d.rectangle((60,60,205,69),fill=SLATE,outline=STEEL);d.line((65,67,202,67),fill=ICE)
        for xx in (75,106,138,168):
            d.rectangle((xx,72,xx+20,121),fill=INK)
            for j in range(14):
                col=[ICE,STEEL,BLUE,SILVER][(j*5+j//2)%4]
                d.line((xx+3+j,74+(j*7)%11,xx+3+j,118-(j*3)%5),fill=col)
            d.arc((xx-2,112,xx+23,126),182,354,fill=ICE,width=2)
        station(d,96,32,62,61)
    else:
        station(d,8,83,72,122);station(d,128,72,102,117)
        scaffold(d,78,44,13,70);scaffold(d,188,42,13,73)
        d.rectangle((74,35,204,48),fill=INK,outline=STEEL)
        for x in range(77,197,10):d.line((x,46,x+5,36,x+10,46),fill=STEEL)
        for x in (93,178):
            d.rectangle((x,46,x+9,68),fill=SLATE,outline=INK)
            d.ellipse((x+2,49,x+7,54),fill=RED);d.ellipse((x+2,58,x+7,63),fill=AMBER)
        d.rectangle((58,47,87,79),fill=INK,outline=STEEL)
        d.ellipse((61,50,84,73),fill=IVORY,outline=GOLD,width=2)
        d.line((73,53,73,62,79,65),fill=INK,width=2)
        for xx in range(7,245,7):d.point((xx,120),fill=GOLD)
    return im

def wayside(n,variant):
    im=blank(128,128);d=ImageDraw.Draw(im);c=ACCENTS[n-4]
    if variant=='lamp':
        lamps(d,63,26)
        d.polygon(((44,125),(49,118),(78,118),(84,125)),fill=SLATE,outline=STEEL)
        for x in (51,57,63,69,75):d.line((x,124,x+4,119),fill=GOLD,width=2)
        if n==6:
            d.rectangle((58,57,69,84),fill=INK,outline=STEEL)
            d.ellipse((60,60,67,67),fill=RED);d.ellipse((60,72,67,79),fill=GREEN)
    elif n==4:
        scaffold(d,52,76,22,45);radar(d,61,45)
        station(d,27,102,73,124)
    elif n==5:
        silo(d,31,29,28,118,ICE);silo(d,67,49,30,122,BLUE)
        d.line((16,119,16,80,37,80),fill=STEEL,width=5);d.line((16,115,16,80,36,80),fill=ICE)
    else:
        scaffold(d,45,58,13,66)
        d.rectangle((39,20,64,63),fill=SLATE,outline=STEEL)
        for y,col in ((26,RED),(38,GOLD),(49,GREEN)):d.ellipse((45,y,56,y+10),fill=col,outline=INK)
        d.rectangle((36,66,69,78),fill=INK,outline=STEEL);text(d,'JCT',45,70,IVORY)
    return im

def sign(n):
    im=blank(128,64);d=ImageDraw.Draw(im);accent=ACCENTS[n-4]
    d.rectangle((12,37,15,63),fill=STEEL);d.rectangle((80,37,83,63),fill=STEEL)
    d.rounded_rectangle((2,4,93,46),4,fill=INK,outline=STEEL,width=2)
    d.rectangle((5,7,90,16),fill=accent)
    text(d,'PHOBOS  NIGHT SHIFT',10,9,INK)
    text(d,f'{n:02}',7,20,IVORY,3)
    text(d,('SIGNAL','SPILLWAY','DEIMOS')[n-4],36,21,IVORY)
    text(d,'PAR '+str(n-1),36,32,accent)
    d.line((6,42,88,42),fill=SLATE)
    return im

def flag(n):
    im=blank(64,96);d=ImageDraw.Draw(im)
    d.ellipse((26,92,40,95),fill=INK);d.line((32,11,32,92),fill=INK,width=4)
    d.line((31,11,31,91),fill=IVORY,width=2)
    for y in range(39,89,12):d.line((31,y,31,y+5),fill=RED,width=2)
    d.polygon(((32,10),(47,12),(60,9),(56,29),(44,32),(32,28)),fill=ACCENTS[n-4],outline=INK)
    text(d,str(n),36,15,INK,2)
    return im

def materials(name):
    rng=random.Random(918+sum(map(ord,name)))
    im=Image.new('RGB',(64,64));p=im.load()
    for y in range(64):
        for x in range(64):
            if name=='NGRAIL':
                c=(51,56,39)
                if (y+3*(x//32))%16<6:c=(80,58,43)
                if x in (11,12,51,52):c=INK
                if x in (13,53):c=SILVER
                if x in (14,54):c=STEEL
                if y%16==2 and x in (10,16,50,56):c=GOLD
            elif name=='NGWATER':
                wave=sin(y*.55+sin(x*pi/32)*1.8)+.65*sin(y*.8+x*pi/16)
                c=((24,24,61) if wave<0 else (44,46,95)) if wave<1 else (105,110,171)
            elif name=='NGLAVA':
                w=abs(sin(x*pi/16+1.2*sin(y*pi/32))+cos(y*pi/16))
                c=AMBER if w<.12 else (170,60,28) if w<.35 else (76,42,38) if w<.8 else (48,32,35)
            elif name=='NGSAND':
                c=(150,120,87) if sin(y*pi/8+1.3*sin(x*pi/32))>.6 else (124,97,74)
            else:
                c={'NGFAIR1':(66,91,58),'NGFAIR2':(57,78,49),'NGROUGH':(47,57,41),'NGGREEN':(92,117,68),'NGTEE':(68,91,57)}[name]
                if name=='NGTEE' and (x in (2,3,60,61) or y in (2,3,60,61)):c=GOLD
            jitter=rng.choice((-5,-3,0,0,2,4))
            p[x,y]=tuple(max(0,min(255,v+jitter)) for v in c)
    return im

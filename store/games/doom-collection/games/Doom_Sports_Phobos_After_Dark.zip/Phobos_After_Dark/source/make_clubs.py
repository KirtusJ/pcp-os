"""Build the four original indexed Doom club overlays and the world golf ball.
Usage: python make_clubs.py path/to/doom1.wad path/to/clubs.wad
Requires Pillow. The player's palette is used solely for colour indexing.
"""
import io
import math
from pathlib import Path
import struct
import sys
from PIL import Image, ImageDraw


def get_palette(path):
    raw=Path(path).read_bytes()
    _,count,directory=struct.unpack_from('<4sii',raw)
    for i in range(count):
        pos,size,name=struct.unpack_from('<ii8s',raw,directory+16*i)
        if name.rstrip(b'\0')==b'PLAYPAL':
            p=raw[pos:pos+768]
            return [tuple(p[j:j+3]) for j in range(0,768,3)]
    raise ValueError('No Doom palette found.')


def patch(im,palette,offset):
    """Encode transparent pixels as Doom column posts."""
    width,height=im.size
    mapped={}
    def colour(c):
        if c not in mapped:
            mapped[c]=min(range(256),key=lambda i:sum((a-b)**2 for a,b in zip(c,palette[i])))
        return mapped[c]
    pointers=bytearray()
    pixels=bytearray()
    for x in range(width):
        pointers.extend(struct.pack('<I',8+4*width+len(pixels)))
        y=0
        while y<height:
            if im.getpixel((x,y))[3]==0:
                y+=1
                continue
            start=y
            values=[]
            while y<height and im.getpixel((x,y))[3]:
                values.append(colour(im.getpixel((x,y))[:3]));y+=1
            pixels.extend([start,len(values),0,*values,0])
        pixels.append(255)
    return struct.pack('<hhhh',width,height,*offset)+pointers+pixels


def club(number,swing):
    im=Image.new('RGBA',(130,82))
    d=ImageDraw.Draw(im)
    # Club head, shaft and hands share a local coordinate system along the shaft.
    if swing: origin=(76,-5); axis=(0.42,0.908)
    else: origin=(19,18); axis=(0.826,0.564)
    def p(t,v):
        x,y=axis
        return (round(origin[0]+x*t-y*v),round(origin[1]+y*t+x*v))
    def shape(points,fill,outline=None):
        d.polygon([p(t,v) for t,v in points], fill=fill,outline=outline)
    def line(points,fill,width=1):
        d.line([p(t,v) for t,v in points],fill=fill,width=width)
    edge='#17191d'; black='#090b0d'
    # The sleeve continues past the edge of the view so the glove is visibly held.
    grip=95 if not swing else 77
    def h(points,fill,outline=None):
        shape([(t+grip,v) for t,v in points],fill,outline)
    def hl(points,fill,width=1):
        line([(t+grip,v) for t,v in points],fill,width)
    h([(1,-11),(11,-16),(22,-13),(37,-14),(68,-12),(76,18),(60,29),(18,22),(3,11)],'#354532',edge)
    h([(7,6),(20,0),(37,5),(66,7),(70,21),(54,27),(17,18)],'#243025')
    h([(23,-13),(44,-12),(65,-7),(55,-3),(36,-3),(15,0)],'#597053')
    h([(36,-10),(46,-10),(40,-6),(32,-5)],'#78836d')
    h([(4,-12),(15,-14),(22,-7),(20,8),(16,16),(1,13),(-7,2)],'#242a29',edge)
    h([(5,-11),(11,-11),(17,-5),(15,8),(11,13),(5,10),(9,3)],'#51604d')
    # Dark underside with a narrow chrome shaft and a bright top edge.
    shape([(-3,-3),(grip+13,-3),(grip+19,1),(grip+14,4),(-3,2)],'#292c33',black)
    shape([(1,-2),(grip+10,-2),(grip+13,-1),(22,1),(3,0)],'#c0c4c8')
    line([(6,-2),(47,-2),(58,-1)],'#f4f1dd')
    line([(6,1),(58,1),(69,0)],'#687783')
    # Ferrule and tapered rubber grip.
    shape([(-1,-3),(8,-3),(10,2),(1,2)],'#242a2d',edge)
    line([(5,-2),(5,1)],'#a4a59a')
    shape([(grip-30,-3),(grip+10,-5),(grip+15,3),(grip+10,5),(grip-30,2)],'#322c29',black)
    for t in range(grip-26,grip+10,5):line([(t,-2),(t+3,2)],'#82715e')
    # Individual club profiles, built heel-first. All four have different silhouettes.
    if number==1:
        shape([(2,-4),(-4,-11),(-15,-13),(-23,-10),(-25,-4),(-22,4),(-14,9),(-5,8),(1,3)],'#48291e',black)
        shape([(-4,-9),(-15,-11),(-21,-8),(-21,-4),(-12,-4),(-6,-2)],'#9d5935')
        shape([(-17,-9),(-13,-10),(-7,-8),(-14,-8),(-20,-6)],'#e4a35e')
        shape([(-22,-1),(-13,1),(-4,0),(-3,4),(-12,7),(-18,5)],'#c3ad8a',edge)
        for n in (1,3):line([(-19,n),(-13,n+2),(-7,n+1)],'#685144')
    elif number==2:
        shape([(1,-3),(-5,-9),(-22,-8),(-22,-1),(-14,5),(-7,6),(1,2)],'#667477',black)
        shape([(-5,-7),(-20,-7),(-19,-2),(-13,2),(-6,3)],'#c1c6c3')
        for n in (-5,-3,-1):line([(-18,n),(-8,n+2)],'#6c7776')
        line([(-21,-7),(-10,-8),(-5,-7)],'#f4eddb')
    elif number==3:
        shape([(2,-4),(-4,-13),(-14,-15),(-21,-11),(-20,-1),(-12,5),(-2,3)],'#826544',black)
        shape([(-4,-10),(-13,-13),(-18,-10),(-16,-3),(-11,1),(-4,1)],'#d6b381')
        for n in (-9,-6,-3):line([(-15,n),(-6,n+1)],'#896e4f')
        line([(-18,-10),(-14,-13),(-7,-12)],'#f4deb4')
    else:
        shape([(2,-3),(-2,-4),(-2,-15),(-7,-18),(-12,-15),(-11,8),(-8,11),(-3,9),(-3,3),(2,2)],'#69756b',black)
        shape([(-4,-14),(-7,-16),(-9,-14),(-8,7),(-5,8),(-5,0)],'#b6bdb4')
        line([(-8,-14),(-8,-2)],'#f3eac8')
        line([(-5,-4),(-9,-4)],'#d6cd69',2)
    # Worn cream golf glove: a dark palm, four folded knuckles, thumb crossing grip.
    h([(-17,-6),(-12,-12),(-5,-14),(2,-11),(7,-7),(8,3),(4,10),(-2,12),(-14,9),(-20,3)],'#655b46',edge)
    h([(-14,-7),(-8,-11),(-2,-11),(5,-6),(5,1),(-4,7),(-12,5)],'#c1ad84')
    for i in range(4):
        t=-19+i*5
        v=-3-(2 if i in (1,2) else 0)
        h([(t,v),(t+2,v-3),(t+5,v-3),(t+7,v),(t+5,v+7),(t+2,v+9),(t-1,v+6)],'#a79a7c',edge)
        hl([(t+1,v),(t+3,v-2),(t+5,v-1)],'#e6d5ae')
        hl([(t+1,v+5),(t+3,v+6)],'#746b58')
    h([(-2,-10),(3,-10),(8,-6),(8,-2),(4,4),(-3,7),(-8,5),(-8,2),(-2,-2)],'#c3b596',edge)
    hl([(-4,2),(0,-2),(4,-6)],'#ede3cc',2)
    h([(8,-7),(13,-5),(14,-1),(11,7),(6,9),(4,5)],'#e0ceaa',edge)
    hl([(9,-2),(12,-1)],'#576b53',2)
    return im


def golf_ball():
    im=Image.new('RGBA',(10,10))
    d=ImageDraw.Draw(im)
    d.polygon([(2,1),(6,0),(8,2),(9,5),(8,8),(6,9),(2,9),(0,7),(0,3)],fill='#636c72')
    d.ellipse((0,0,8,8),fill='#dedaca')
    d.ellipse((1,0,6,5),fill='#fff8e6')
    for x,y,c in [(2,3,'#c2bdab'),(5,2,'#d5d0bc'),(6,5,'#a7a89e'),(3,6,'#b7b5a5'),(7,7,'#8d9895')]:d.point((x,y),fill=c)
    return im


def main():
    if len(sys.argv)!=3:raise SystemExit(__doc__)
    palette=get_palette(sys.argv[1])
    pairs=[('GCLB'+str(i),patch(club(i,False),palette,(0,0))) for i in range(1,5)]
    pairs.extend(('GSWG'+str(i),patch(club(i,True),palette,(0,0))) for i in range(1,5))
    pairs.append(('BALLA0',patch(golf_ball(),palette,(5,10))))
    directory=bytearray()
    with Path(sys.argv[2]).open('wb') as f:
        f.write(bytes(12))
        for name,data in pairs:
            directory.extend(struct.pack('<ii8s',f.tell(),len(data),name.encode()))
            f.write(data)
        start=f.tell();f.write(directory);f.seek(0);f.write(struct.pack('<4sii',b'PWAD',len(pairs),start))
if __name__=='__main__':main()

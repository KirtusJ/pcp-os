# Building Phobos After Dark

The game runs as a native PCP-OS program. Extract the engine source archive in this folder and follow its BUILD.txt on x86-64 Linux. Its build inputs include the PCP-OS Doom port, the golf rules and HUD, musl source, and the engine notices. The kernel is the supplied pcpos-kernel.elf32 described in the package notice.

## Rebuilding the course and artwork

Use Python 3.9 or newer and Pillow. From this directory run the following commands. Substitute the path to your original Doom shareware 1.9 IWAD for the example.

```sh
python3 build_course.py /path/to/doom1.wad ../assets/course.wad
python3 make_clubs.py /path/to/doom1.wad ../assets/clubs.wad
python3 make_flatcar.py /path/to/doom1.wad ../assets/flatcar.wad
python3 make_music.py
cp phobos-score.wad ../assets/soundtrack.wad
python3 compose_night.py
cp night-score.wad ../assets/night-score.wad
python3 make_night_cover.py /path/to/doom1.wad
cp night-cover.wad ../assets/titles.wad
```

The map compiler reads course_data.py and night_art.py. It builds all six original maps, their BSP trees, new flats, wall patches and four skies. If you change playable geography, keep the physics definitions in the engine's golf.c in sync. make_flatcar.py reads the palette via make_clubs.py and builds the two GFTR actor frames.

assemble.py temporarily combines your original IWAD with the six PWADs at launch. The classic event keeps its three tracks and sound effects. NIGHT_ASSETS.md describes the three Night Shift tracks, the station bell and the title art.

"""Build a 320 x 200 DOOM TITLEPIC and a standalone PWAD from the original cover.

Usage: python3 make_night_cover.py /path/to/doom1.wad
Requires Pillow. Palette indices are resolved using the player's local IWAD.
"""
import argparse
from pathlib import Path
import struct

from PIL import Image


def playpal(wad):
    signature, count, directory = struct.unpack_from('<4sII', wad)
    if signature not in (b'IWAD', b'PWAD') or directory + 16 * count > len(wad):
        raise ValueError('Expected a DOOM WAD.')
    for index in reversed(range(count)):
        pos, length, name = struct.unpack_from('<II8s', wad, directory + index * 16)
        if name.rstrip(b'\0') == b'PLAYPAL' and length >= 768 and pos + length <= len(wad):
            return wad[pos:pos + 768]
    raise ValueError('Could not locate the default 256-colour PLAYPAL.')


def doom_patch(indexed):
    width, height = indexed.size
    if height >= 255:
        raise ValueError('This full-coverage encoder expects a patch shorter than 255 pixels.')
    pixel = indexed.load()
    offsets = bytearray()
    posts = bytearray()
    for x in range(width):
        offsets.extend(struct.pack('<I', 8 + width * 4 + len(posts)))
        # One vertically contiguous post with the standard unused leading and trailing bytes.
        posts.extend(bytes((0, height, 0)))
        posts.extend(bytes(pixel[x, y] for y in range(height)))
        posts.extend(bytes((0, 255)))
    return struct.pack('<hhhh', width, height, 0, 0) + offsets + posts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('iwad', type=Path)
    parser.add_argument('--art', type=Path, default=Path(__file__).with_name('night-cover-art.png'))
    parser.add_argument('--out', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    palette = Image.new('P', (1, 1))
    palette.putpalette(playpal(args.iwad.read_bytes()))
    with Image.open(args.art) as original:
        # 320x200 native pixels are displayed as 4:3 on the original VGA display.
        rgb = original.convert('RGB').resize((320, 200), Image.Resampling.LANCZOS)
    indexed = rgb.quantize(palette=palette, dither=Image.Dither.NONE)
    patch = doom_patch(indexed)
    offset = 12 + len(patch)
    wad = (struct.pack('<4sII', b'PWAD', 1, offset) + patch
           + struct.pack('<II8s', 12, len(patch), b'TITLEPIC'))
    (args.out / 'night-cover.wad').write_bytes(wad)
    indexed.convert('RGB').resize((640, 480), Image.Resampling.NEAREST).save(
        args.out / 'night-title-preview.png')
    print(f'TITLEPIC: {indexed.width}x{indexed.height}, {len(patch)} bytes')


if __name__ == '__main__':
    main()

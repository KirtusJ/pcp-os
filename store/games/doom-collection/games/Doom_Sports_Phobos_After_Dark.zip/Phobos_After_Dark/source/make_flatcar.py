"""Build the Midnight Barrel Express putting flatcar as two native Doom sprites.

Run with the original shareware IWAD followed by an output PWAD path. Pillow is
needed to rebuild the art. Coordinates use the original 100-by-56 pixel canvas.
The flag socket is at (50, 34) and the floor-level actor origin at (50, 53).
"""
from pathlib import Path
import struct
import sys

from PIL import Image, ImageDraw
from make_clubs import get_palette, patch


def flatcar(second_frame):
    image=Image.new('RGBA',(100,56))
    d=ImageDraw.Draw(image)
    ink='#15141b'; iron='#353242'; steel='#74707c'; chrome='#b7afb0'
    oxblood='#74372f'; red='#ad4e36'; gold='#eead53'; cream='#ffe2a0'
    navy='#1d3041'; teal='#355863'; green='#3c7f4d'; sun='#d2bf79'
    def poly(points,fill,outline=None): d.polygon(points,fill=fill,outline=outline)
    def line(points,fill,width=1): d.line(points,fill=fill,width=width)
    def rivets(x1,x2,y):
        for x in range(x1,x2,7):
            d.point((x+1,y+1),fill=ink);d.point((x,y),fill=chrome)
    # Couplers and undercarriage. The asymmetric rear bogie sells the perspective.
    poly([(0,42),(6,41),(12,43),(12,47),(6,47),(5,45),(0,45)],iron,ink)
    poly([(89,38),(98,37),(99,40),(94,42),(88,42)],steel,ink)
    poly([(8,40),(88,35),(95,40),(82,48),(15,52),(7,49)],iron,ink)
    line([(13,48),(78,44),(91,38)],steel)
    for cx,cy in [(15,49),(27,49),(69,46),(82,45)]:
        d.ellipse((cx-4,cy-4,cx+4,cy+4),fill=ink)
        d.ellipse((cx-3,cy-3,cx+3,cy+3),fill=steel)
        d.ellipse((cx-2,cy-2,cx+2,cy+2),fill=iron)
        if second_frame: line([(cx-1,cy+2),(cx+1,cy-2)],chrome)
        else: line([(cx-2,cy-1),(cx+2,cy+1)],chrome)
        d.point((cx,cy),fill=gold)
    for cx,cy in [(21,48),(75,45)]:
        line([(cx-5,cy),(cx+4,cy-1)],ink,2)
        d.point((cx,cy-1),fill=steel)
    # Flat steel frame, red side enamel, thin cream railroad stripe.
    poly([(3,36),(84,32),(96,35),(96,39),(85,45),(10,50),(3,46)],ink)
    poly([(5,39),(13,41),(84,37),(84,44),(12,48),(5,45)],oxblood)
    poly([(84,37),(94,33),(94,39),(85,44)],red)
    line([(6,40),(13,42),(83,38)],gold)
    line([(14,47),(82,43)],'#a9553b')
    for x in (15,32,57,77):
        d.line((x,42-(x//26),x,47-(x//26)),fill='#542b28')
    rivets(12,80,43)
    # Accessible green on top, striped along the car. Deck height under flag is 19.
    poly([(3,37),(14,29),(87,25),(97,31),(85,39),(12,43)],'#614a38',ink)
    poly([(6,37),(16,30),(85,26),(93,31),(83,37),(13,41)],green)
    for i in range(6):
        x=14+i*12
        poly([(x,38-i//2),(x+7,32-i//2),(x+12,31-i//2),(x+4,39-i//2)],'#468452' if i%2 else '#326e40')
    line([(5,37),(13,41),(84,37),(95,30)],sun)
    line([(15,30),(85,26)],'#92ad64')
    # Low caboose on the far end: warm windows, roof vents, front marker lamps.
    poly([(70,28),(70,19),(75,16),(87,15),(92,18),(92,28),(86,31),(74,32)],navy,ink)
    poly([(73,20),(84,19),(84,29),(73,30)],teal)
    poly([(85,20),(90,18),(90,27),(85,29)],'#263848')
    d.rectangle((74,21,77,25),fill=ink); d.rectangle((79,20,82,24),fill=ink)
    d.rectangle((75,21,77,24),fill=gold); d.rectangle((80,20,82,23),fill='#e78b47')
    line([(75,24),(77,22)],cream)
    line([(86,21),(88,20),(88,24),(86,25)],'#f7b456')
    line([(72,27),(83,26)],'#b58349')
    poly([(68,18),(75,14),(89,13),(94,16),(86,20),(70,21)],ink)
    line([(70,18),(75,15),(89,14),(92,16)],steel)
    d.rectangle((76,11,79,15),fill=ink); d.rectangle((75,10,79,11),fill=iron)
    d.point((76,10),fill=chrome)
    # Gold number and two checker-painted sill plates on the near side.
    for x,y in [(11,43),(16,43),(68,40),(73,40)]:
        line([(x,y+3),(x+3,y)],gold,2)
    d.rectangle((44,40,54,44),fill=navy)
    for x,y in [(47,41),(48,41),(47,42),(47,43),(48,43),(49,42),(51,41),(51,42),(51,43),(52,42),(52,43)]:
        d.point((x,y),fill=cream)
    # Two little lanterns alternate on the physical car; both poses carry the cup.
    for x,y,on in [(8,39,not second_frame),(92,30,second_frame)]:
        d.rectangle((x-1,y-1,x+1,y+1),fill=ink)
        d.point((x,y),fill='#fff3b6' if on else '#ad6038')
        if on:d.point((x,y-1),fill=gold)
    # The cup is visibly seated in the deck at its collision centre.
    d.ellipse((46,32,54,35),fill='#9fba79')
    d.ellipse((47,33,53,35),fill=ink)
    d.line((50,5,50,34),fill='#333847',width=2)
    d.line((49,5,49,32),fill='#eee0b9')
    d.line((49,21,50,21),fill='#cd6a43')
    d.line((49,25,50,25),fill='#cd6a43')
    y=1 if second_frame else 0
    poly([(50,4),(56,2),(62,4+y),(70,4-y),(66,8),(68,11+y),(62,12),(56,10),(50,12)],'#ce5435',ink)
    line([(51,5),(56,3),(62,5+y),(68,5-y)],'#ffb867')
    # Dark-on-cream checker on the fly end and a little numeral 6 on the hoist.
    for x in range(62,66,2):
        for yy in range(6,10,2):
            d.rectangle((x,yy,x+1,yy+1),fill=cream if ((x+yy)//2)%2==0 else ink)
    line([(56,5),(53,5),(53,9),(56,9),(56,7),(54,7)],cream)
    d.point((50,3),fill=cream)
    return image


def main():
    if len(sys.argv)!=3:raise SystemExit('Usage: make_flatcar.py doom1.wad output.wad')
    palette=get_palette(sys.argv[1])
    blobs=[('GFTRA0',patch(flatcar(False),palette,(50,53))),
           ('GFTRB0',patch(flatcar(True),palette,(50,53)))]
    raw=bytearray(bytes(12)); directory=bytearray()
    for name,data in blobs:
        directory.extend(struct.pack('<ii8s',len(raw),len(data),name.encode()))
        raw.extend(data)
    raw[:12]=struct.pack('<4sii',b'PWAD',len(blobs),len(raw))
    Path(sys.argv[2]).write_bytes(raw+directory)


if __name__=='__main__':main()

# Phobos After Dark — The Night Shift Open

The night score and cover are separate add-on PWADs for Doom Sports. The first contains four new audio lumps. The second provides the expansion title screen.

| Lump | Hole or cue | Music |
| --- | --- | --- |
| D_E1M4 | Signal Hill | **Two Shorts, One Long**. A glockenspiel signal pulses over electric piano and synth bass in five beats. The loop lasts 53.34 seconds. |
| D_E1M5 | The Spillway | **Under the Weir**. A clarinet crosses a falling harp figure in compound meter. The loop lasts 36.92 seconds. |
| D_E1M6 | Deimos Junction | **Last Car to Deimos**. Short guitar chords and staggered rim taps carry the train rhythm beneath a whistle tune. The loop lasts 35.89 seconds. |
| DSPSTART | Freight reversal | A two-tone station bell with mechanical resonance and a short air-brake hiss, lasting 1.12 seconds. |

## Build the assets

The composer uses Python 3 and its standard library. The cover builder also uses Pillow and reads the default palette from a local Doom IWAD. The PCM effect is synthesized directly at 11,025 Hz. Both scripts place their PWAD alongside their source.

```sh
python3 compose_night.py
python3 make_night_cover.py /path/to/doom1.wad
```

Load the night PWADs after the original Pitch & Putt assets. The title patch supplies the illustrated plate behind the engine's mode selector. The publisher imprint, title, subtitle and putting green appear above the selector.

The full-resolution cover is `night-cover-art.png`. The 4:3 display preview is `night-title-preview.png`. The master illustration was made for this expansion and depicts the golf cup on the moving freight flatcar.

## Checks

An independent MUS parser decoded 278, 212 and 444 note-on events across the three songs. Every note had a matching release before the loop closed. Each song reached five simultaneous notes. A software General MIDI renderer produced non-silent stereo output for each arrangement. Doom's OPL instruments are supplied by the player's IWAD.

The DMX file contains the expected unsigned 8-bit PCM and 16 bytes of silence at each boundary. A separate decoder read the 320×200 full-height column-post patch. All 64,000 pixels matched the original-VGA-aspect preview.

| Output | SHA-256 |
| --- | --- |
| night-score.wad | 23af4221ca82bdf4557a3e5fe8b3acb0b3f2fa9c43bdc00550a8eb6e37ff8de9 |
| night-cover.wad | c378bd3e0420aea2da63c84da7e862c8ed1d957bd3478247a66117bb55cfac09 |

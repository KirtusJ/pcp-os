"""Compose the three original Phobos Pitch & Putt loops and their four DMX cues.

Run with Python 3. No input assets or additional packages are required.
The output PWAD is written beside this script.
"""

import collections
import math
from pathlib import Path
import random
import struct


def delay_bytes(ticks):
    """An unsigned, big-endian MUS variable-length delay."""
    parts = [ticks & 127]
    while ticks >= 128:
        ticks >>= 7
        parts.append(128 | (ticks & 127))
    return bytes(reversed(parts))


class Music:
    def __init__(self, tempo, voices):
        self.tempo = tempo
        self.events = collections.defaultdict(list)
        self.patches = set()
        self.channels = len(voices)
        for ch, (program, volume, pan) in enumerate(voices):
            self.patches.add(program)
            for control, value in ((0, program), (3, volume), (4, pan)):
                self.events[0].append((0, bytes((0x40 | ch, control, value))))
        self.events[0].append((0, bytes((0x4f, 3, 69))))

    def tick(self, beats):
        return round(beats * 60 * 140 / self.tempo)

    def play(self, channel, beat, pitch, length, velocity):
        on, off = self.tick(beat), self.tick(beat + length)
        self.events[on].append((2, bytes((0x10 | channel, 128 | pitch, velocity))))
        self.events[off].append((1, bytes((channel, pitch))))
        if channel == 15:
            self.patches.add(100 + pitch)

    def mus(self, duration):
        end = self.tick(duration)
        assert max(self.events) < end
        times = sorted(self.events) + [end]
        payload = bytearray()
        for time, next_time in zip(times, times[1:]):
            group = sorted(self.events[time], key=lambda ev: ev[0])
            for i, (_, msg) in enumerate(group):
                last = i == len(group) - 1
                payload.extend(bytes((msg[0] | (128 if last else 0),)) + msg[1:])
            payload.extend(delay_bytes(next_time - time))
        payload.append(0x60)
        instruments = b''.join(struct.pack('<H', p) for p in sorted(self.patches))
        return (struct.pack('<4s6H', b'MUS\x1a', len(payload), 16 + len(instruments),
                            self.channels, 0, len(self.patches), 0)
                + instruments + payload)


# Original eight-bar theme. Notes are intervals above a movable tonic.
# Its fingerprint is the delayed leap to the ninth and the gentle sixth below
# it. Each arrangement retains the first two bars and answers them differently.
THEME = [
    [(0.5, 7, .38), (1, 14, .86), (2.5, 9, .42), (3.25, 4, .60)],
    [(0, 6, .64), (.75, 7, .86), (2.5, 2, 1.00)],
    [(0, 4, .82), (1.5, 9, .40), (2, 11, 1.35)],
    [(.5, 12, .60), (1.5, 7, .64), (2.5, 6, 1.0)],
    [(0.5, 7, .38), (1, 14, .82), (2.5, 16, .42), (3.25, 11, .6)],
    [(0, 9, 1.30), (1.75, 6, .57), (2.5, 4, 1.00)],
    [(.0, 2, .82), (1.5, 6, .40), (2, 9, .65), (3, 7, .60)],
    [(0, 4, .74), (1, 2, .64), (2, 0, 1.55)],
]
# Bass root and upper-voice shell. The tonic's raised fourth is intentional.
HARMONY = [(0, (4, 11)), (2, (6, 9)), (9, (4, 7)), (7, (2, 6)),
           (0, (4, 11)), (6, (2, 9)), (2, (6, 9)), (7, (4, 11))]
ARRANGEMENTS = [
    # GM 11 vibraphone, 24 nylon guitar, 32 acoustic bass, 4 electric piano.
    ("Pennant in Low Gravity", 94, 60, [(11, 95, 57), (24, 84, 78), (32, 94, 63), (4, 66, 43)]),
    # A lilting six-eight pulse, with flute and fingered bass over harp.
    ("Ripple at the Flag", 76, 62, [(73, 89, 65), (46, 77, 45), (33, 91, 61), (10, 75, 82)]),
    # Muted trumpet, glassy electric piano, fretless bass and marimba.
    ("The Far Green", 87, 65, [(59, 88, 57), (4, 84, 78), (35, 92, 63), (12, 74, 37)]),
]


def arrangement(hole):
    title, tempo, tonic, voices = ARRANGEMENTS[hole]
    score = Music(tempo, voices)
    span = (4, 3, 4)[hole]
    for bar in range(16):
        phrase = bar % 8
        base = span * bar
        root, shape = HARMONY[phrase]
        low = tonic - 24 + root
        chord = [tonic - 12 + key for key in shape]
        # The second time through, vary the answer, instrumentation and dynamics.
        varied = bar >= 8
        for pos, interval, length in THEME[phrase]:
            voice = 3 if varied and phrase in (1, 3, 5, 7) else 0
            if hole == 0:
                start = pos + (.085 if pos % 1 == .5 else 0)
                score.play(voice, base + start, tonic + interval, length, 87 if pos < 2 else 77)
            elif hole == 1:
                start = .75 * pos
                score.play(voice, base + start, tonic + interval + (0 if voice == 0 else 12),
                           .71 * length, 77 if pos < 2 else 69)
            else:
                start = pos + (.14 if pos % 1 == .5 else 0)
                score.play(voice, base + start, tonic + interval, .84 * length,
                           85 if pos < 2 else 74)
        if hole == 0:
            for pos, note, dur, vel in [(0, low, 1.48, 83), (2.5, low + 7, .58, 72)]:
                score.play(2, base + pos, note, dur, vel)
            for pos, idx in ((.68, 0), (1.60, 1), (2.02, 0), (3.55, 1)):
                score.play(1, base + pos, chord[idx], .34, 69 if idx else 77)
            for pos in (0, 1.58, 2, 3.58):
                score.play(15, base + pos, 42, .07, 52 if pos == 2 else 39)
            if phrase in (1, 3, 5):
                score.play(15, base + 3, 37, .08, 46)
        elif hole == 1:
            score.play(2, base, low, 1.32, 85)
            score.play(2, base + 1.55, low + (7 if phrase % 2 else 12), .90, 65)
            harp = [chord[0], chord[1], chord[0]+12, chord[1], chord[0], chord[1]+12]
            for i, note in enumerate(harp):
                score.play(1, base + .5 * i, note, .40, (68, 54, 61, 65, 50, 55)[i])
            score.play(15, base + 1.52, 54, .08, 44)
        else:
            score.play(2, base, low, 1.52, 89)
            score.play(2, base + 2, low + 7, .74, 75)
            if phrase % 2:
                score.play(2, base + 3.34, tonic - 24 + HARMONY[(phrase+1)%8][0] - 1, .37, 68)
            for pos in (.65, 2.68):
                for idx, note in enumerate(chord):
                    score.play(1, base + pos + idx*.035, note, .72, 66 - idx*5)
            for pos in (0, 2):
                score.play(15, base + pos, 36, .09, 48 if pos else 58)
            for pos in (1, 3):
                score.play(15, base + pos, 37, .12, 55)
            for pos in (.68, 2.67, 3.65):
                score.play(15, base + pos, 42, .08, 40)
    return title, score.mus(16 * span)


SAMPLE_RATE = 11025
TAU = math.tau


def effect(kind):
    """Synthesize uint8 mono PCM in Doom DMX format. No sampled instruments."""
    duration = {"swing": .29, "cup": .54, "water": .63, "chime": .87}[kind]
    rng = random.Random(4049)
    previous = 0.
    filtered = 0.
    data = bytearray()
    for i in range(round(duration * SAMPLE_RATE)):
        t = i / SAMPLE_RATE
        white = rng.uniform(-1., 1.)
        filtered += .14 * (white - filtered)
        hiss = .7 * (white - previous)
        previous = white
        if kind == "swing":
            # Thin shaft through the air, then a short wood-and-ball contact.
            a = math.exp(-((t-.075)/.036)**2)
            u = max(0., t-.115)
            hit = 0. if t < .115 else (math.sin(TAU*(960*u+9*(1-math.exp(-45*u))))*.42
                  + math.sin(TAU*1730*u)*.24 + hiss*.60)*math.exp(-56*u)
            value = a*(.32*hiss + .15*filtered) + hit
        elif kind == "cup":
            # Ball rings the rim, knocks lower down, then settles to the left.
            value = 0.
            for impact, hz, gain in ((.02, 1350, .65), (.125, 790, .48), (.213, 455, .31), (.325, 295, .15)):
                u = t - impact
                if u >= 0:
                    modes = .56*math.sin(TAU*hz*u) + .30*math.sin(TAU*hz*1.53*u)
                    value += gain * (modes * math.exp(-31*u) + hiss*.28*math.exp(-110*u))
        elif kind == "water":
            splash = math.exp(-((t-.092)/.068)**2) + .40*math.exp(-((t-.23)/.11)**2)
            value = splash * (filtered*1.85 + .22*hiss)
            for start, freq, gain in ((.17, 218, .19), (.31, 345, .16), (.43, 273, .12)):
                u = t-start
                if u >= 0:
                    value += gain*math.exp(-28*u)*math.sin(TAU*(freq*u + 930*u*u))
        else:
            # Four short flag-bell notes borrow the score's leap to the ninth.
            value = 0.
            for start, freq, gain in ((.02, 392., .33), (.16, 587.33, .38),
                                      (.31, 440., .30), (.45, 659.26, .28)):
                u = t - start
                if u >= 0:
                    value += gain * (math.sin(TAU*freq*u)*math.exp(-6.8*u)
                                     + .23*math.sin(TAU*2.77*freq*u)*math.exp(-19*u))
        fade = min(1., i/20, (duration-t)*44)
        data.append(max(0, min(255, round(128 + 122 * value * fade))))
    padded = bytes([128])*16 + data + bytes([128])*16
    return struct.pack('<HHI', 3, SAMPLE_RATE, len(padded)) + padded


def output_wad(lumps, path):
    content = bytearray(12)
    directory = bytearray()
    for name, raw in lumps:
        directory.extend(struct.pack('<II8s', len(content), len(raw), name.encode('ascii')))
        content.extend(raw)
    content[:12] = struct.pack('<4sII', b'PWAD', len(lumps), len(content))
    path.write_bytes(content + directory)


def main():
    lumps = []
    for hole in range(3):
        title, mus = arrangement(hole)
        lumps.append((f'D_E1M{hole + 1}', mus))
        print(f'Hole {hole+1}: {title} ({len(mus)} bytes)')
    for name, kind in [('DSPISTOL', 'swing'), ('DSITEMUP', 'cup'),
                       ('DSOOF', 'water'), ('DSSWTCHN', 'chime')]:
        lumps.append((name, effect(kind)))
    output_wad(lumps, Path(__file__).with_name('phobos-score.wad'))


if __name__ == '__main__':
    main()

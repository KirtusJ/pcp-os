"""Build original native MUS songs and a DMX platform bell for Phobos After Dark.

Python 3 standard library. Run from any directory to generate night-score.wad
alongside this source. No game data, MIDI recordings or sampled audio are used.
"""
import collections
import math
from pathlib import Path
import random
import struct


def delay_bytes(ticks):
    """An unsigned, big-endian MUS variable-length delay."""
    parts = [ticks & 127]
    while ticks >= 128:
        ticks >>= 7
        parts.append(128 | (ticks & 127))
    return bytes(reversed(parts))


class Music:
    def __init__(self, tempo, voices):
        self.tempo = tempo
        self.events = collections.defaultdict(list)
        self.patches = set()
        self.channels = len(voices)
        for ch, (program, volume, pan) in enumerate(voices):
            self.patches.add(program)
            for control, value in ((0, program), (3, volume), (4, pan)):
                self.events[0].append((0, bytes((0x40 | ch, control, value))))
        self.events[0].append((0, bytes((0x4f, 3, 69))))

    def tick(self, beats):
        return round(beats * 60 * 140 / self.tempo)

    def play(self, channel, beat, pitch, length, velocity):
        on, off = self.tick(beat), self.tick(beat + length)
        self.events[on].append((2, bytes((0x10 | channel, 128 | pitch, velocity))))
        self.events[off].append((1, bytes((channel, pitch))))
        if channel == 15:
            self.patches.add(100 + pitch)

    def mus(self, duration):
        end = self.tick(duration)
        assert max(self.events) < end
        times = sorted(self.events) + [end]
        payload = bytearray()
        for time, next_time in zip(times, times[1:]):
            group = sorted(self.events[time], key=lambda ev: ev[0])
            for i, (_, msg) in enumerate(group):
                last = i == len(group) - 1
                payload.extend(bytes((msg[0] | (128 if last else 0),)) + msg[1:])
            payload.extend(delay_bytes(next_time - time))
        payload.append(0x60)
        instruments = b''.join(struct.pack('<H', p) for p in sorted(self.patches))
        return (struct.pack('<4s6H', b'MUS\x1a', len(payload), 16 + len(instruments),
                            self.channels, 0, len(self.patches), 0)
                + instruments + payload)


def output_wad(lumps, path):
    content = bytearray(12)
    directory = bytearray()
    for name, raw in lumps:
        directory.extend(struct.pack('<II8s', len(content), len(raw), name.encode('ascii')))
        content.extend(raw)
    content[:12] = struct.pack('<4sII', b'PWAD', len(lumps), len(content))
    path.write_bytes(content + directory)


# Each phrase specifies beat, semitones relative to the current register,
# duration in quarter-note beats and velocity. The three holes have different
# meters and independent melodies, written around the changing play surfaces.
def phrase(score, ch, start, tonic, notes, velocity_shift=0):
    for pos, note, duration, velocity in notes:
        score.play(ch, start+pos, tonic+note, duration, velocity+velocity_shift)


def signal_hill():
    """Signal Hill, 5/4. Alternating two short flashes and a long response."""
    score = Music(90, [(10, 94, 50), (4, 76, 81), (38, 95, 62), (89, 57, 56)])
    motifs = [
        [(.5,2,.31,81),(1,7,.66,88),(2.5,11,1.18,84),(4.2,9,.39,64)],
        [(0,7,.71,79),(1.5,4,.37,72),(2,2,.70,74),(3.5,-1,.71,69)],
        [(.5,2,.31,81),(1,7,.66,87),(2.5,14,.74,90),(3.6,11,.51,72)],
        [(0,9,1.26,78),(2,6,.37,68),(2.5,4,.63,77),(4,2,.62,63)],
        [(.5,2,.31,81),(1,7,.60,84),(2.5,9,.78,83),(3.65,6,.67,75)],
        [(0,4,.94,78),(1.5,2,.40,73),(2,0,1.12,79),(4,-1,.51,66)],
        [(0,2,1.15,78),(1.7,7,.55,76),(2.5,11,.79,84),(4,14,.58,76)],
        [(.25,9,.70,81),(1.55,7,.36,67),(2,4,1.20,76),(4,2,.48,68)]]
    harmony = [(40,55,66),(38,54,61),(35,54,62),(42,57,64),
               (36,55,62),(45,55,64),(38,54,61),(35,57,66)]
    for bar in range(16):
        k=bar%8; start=bar*5; root,a,b=harmony[k]
        phrase(score,0,start,64,motifs[k],-5 if bar>=8 and k%2 else 0)
        score.play(2,start,root,1.65,86)
        score.play(2,start+2.75,root+7,.70,72)
        score.play(2,start+4,root+(12 if k%2==0 else 7),.44,65)
        score.play(3,start+.07,a,2.05,65)
        score.play(3,start+.12,b,2.00,55)
        for beat,key,vel in ((2.18,a,67),(3.16,b,61),(4.35,a+12,52)):
            score.play(1,start+beat,key,.33,vel)
        for beat,drum,vel in ((0,36,59),(1,42,44),(2,37,53),(3.5,42,39),(4.1,37,43)):
            score.play(15,start+beat,drum,.085,vel)
        if bar in (7,15):
            score.play(15,start+4.68,46,.14,39)
        if bar>=8 and k%2:
            score.play(1,start+3.17,b+12,.58,65)
    return score.mus(80)


def spillway():
    """The Spillway, slow compound meter. A reed melody crosses falling harp arpeggios."""
    score = Music(78, [(71, 96, 55), (46, 79, 80), (33, 98, 62), (11, 77, 35)])
    bars=[
        [(0,7,1.14,82),(1.45,3,.42,78),(2,2,.68,71)],
        [(.4,0,.42,74),(1,3,.72,82),(2.1,7,.65,74)],
        [(0,10,.75,82),(.9,7,.36,65),(1.5,5,1.12,77)],
        [(.25,3,.65,78),(1.45,2,.42,70),(2,0,.78,77)],
        [(0,7,.82,82),(1,8,.39,78),(1.5,12,1.16,84)],
        [(.25,10,.65,76),(1.5,7,.43,79),(2,5,.70,79)],
        [(0,3,1.20,82),(1.5,2,.44,73),(2,0,.62,77)],
        [(.5,-2,.47,70),(1,2,.71,80),(2.25,5,.48,72)]]
    chords=[(42,57,64),(38,54,61),(45,55,64),(40,55,62),
            (35,54,62),(38,57,66),(42,57,64),(37,56,64)]
    for bar in range(16):
        k=bar%8; start=bar*3; root,a,b=chords[k]
        phrase(score,0,start,66,bars[k],-4 if bar>=8 else 0)
        score.play(2,start,root,1.11,78)
        score.play(2,start+1.55,root+7,1.08,67)
        stream=[b+12,b,a+7,b,a,root+12]
        for i,note in enumerate(stream):
            score.play(1,start+i*.5,note,.36,(76,59,58,72,53,57)[i])
        if k in (1,3,5,7):
            score.play(3,start+2.51,a+12,.38,55)
        if bar>=8 and k in (0,2,4,6):
            score.play(3,start+.05,b,.38,61)
            score.play(3,start+1.08,a+12,.39,57)
        score.play(15,start+1.52,54,.08,43)
        if k in (3,7):
            score.play(15,start+2.53,51,.1,41)
    return score.mus(48)


def deimos_junction():
    """Deimos Junction, cut-time freight: rail joints move beneath a two-note whistle."""
    score = Music(107, [(78, 92, 51), (27, 79, 80), (34, 93, 64), (16, 75, 54)])
    whistle=[
        [(0,12,.87,77),(1.2,7,1.44,81)],
        [(2.55,5,.36,67),(3.13,7,.57,69)],
        [(.05,10,1.15,76),(1.55,5,1.10,78)],
        [(2.1,3,.40,66),(2.85,2,.72,71)],
        [(.06,12,.67,82),(1.08,14,1.33,83)],
        [(1.65,12,.65,74),(2.7,7,.76,75)],
        [(0,10,.85,84),(1.22,5,.77,79),(2.55,3,.42,69)],
        [(1.15,2,.70,71),(2.55,0,.75,76)]]
    chords=[(38,53,60),(38,53,60),(41,55,60),(36,52,58),
            (43,53,62),(43,58,62),(34,53,60),(33,55,61)]
    for bar in range(16):
        k=bar%8; start=bar*4; root,a,b=chords[k]
        phrase(score,0,start,62,whistle[k],2 if bar>=8 else 0)
        for pos,note,vel in [(0,root,83),(.75,root+12,65),(1.5,root+7,79),
                              (2,root,84),(2.75,root+12,61),(3.55,root+7,72)]:
            score.play(2,start+pos,note,.36,vel)
        for pos in (.51,1.53,2.51,3.53):
            score.play(1,start+pos,a,.20,70)
            score.play(1,start+pos+.03,b,.18,61)
        if k in (1,3,5,7):
            for off,key in ((.05,a),(1.03,b),(1.67,a+12)):
                score.play(3,start+off,key,.37,70 if bar<8 else 78)
        for pos,drum,vel in ((0,36,70),(.34,42,44),(.67,37,51),(1.13,42,45),
                             (1.48,37,56),(2,36,70),(2.35,42,46),(2.67,37,49),
                             (3.13,42,44),(3.5,37,56)):
            score.play(15,start+pos,drum,.065,vel)
        if bar in (7,15):
            score.play(15,start+3.80,46,.12,53)
    return score.mus(64)


def departure_bell():
    """Two pitched strikes, a low spring and a short air-brake tail, 11025 Hz mono."""
    rate=11025; duration=1.12; rng=random.Random(16831)
    lp=0.; samples=bytearray()
    for i in range(round(rate*duration)):
        t=i/rate; amp=0.
        for start,frequency,gain in ((.02,683.,.43),(.265,912.,.38)):
            u=t-start
            if u>=0:
                for multiple,level,decay in ((1,.68,4.7),(2.62,.23,8.5),(4.11,.19,16.)):
                    amp+=gain*level*math.sin(math.tau*frequency*multiple*u)*math.exp(-decay*u)
                amp+=.075*math.sin(math.tau*172*u)*math.exp(-21*u)
        noise=rng.uniform(-1,1);lp+=.12*(noise-lp)
        amp+=lp*.34*math.exp(-((t-.66)/.14)**2)
        edge=min(1.,i/18.,(duration-t)*38.)
        samples.append(max(0,min(255,round(128+126*amp*edge))))
    pcm=bytes([128])*16+samples+bytes([128])*16
    return struct.pack('<HHI',3,rate,len(pcm))+pcm


def main():
    tracks=[('D_E1M4',signal_hill()),('D_E1M5',spillway()),('D_E1M6',deimos_junction()),
            ('DSPSTART',departure_bell())]
    output_wad(tracks, Path(__file__).with_name('night-score.wad'))
    for name,raw in tracks:
        print(f'{name}: {len(raw)} bytes')


if __name__ == '__main__':
    main()

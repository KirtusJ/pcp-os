"""Build a private golf IWAD using the player's original Doom shareware 1.9 IWAD."""
import hashlib
import struct
from pathlib import Path

HEADER = struct.Struct('<4sii')
ENTRY = struct.Struct('<ii8s')
BASE_SHA256 = '1d7d43be501e67d927e415e0b8f3e29c3bf33075e859721816f652a526cac771'
MAP_PARTS = ('THINGS','LINEDEFS','SIDEDEFS','VERTEXES','SEGS','SSECTORS','NODES','SECTORS','REJECT','BLOCKMAP')
MAPS = tuple(f'E1M{i}' for i in range(1, 7))


def read_lumps(raw, kind):
    if len(raw) < HEADER.size:
        raise ValueError('Incomplete WAD.')
    tag, count, directory = HEADER.unpack_from(raw)
    if tag != kind or count < 0 or directory < HEADER.size or directory + count * ENTRY.size > len(raw):
        raise ValueError('Invalid WAD directory.')
    result = []
    for index in range(count):
        start, length, name = ENTRY.unpack_from(raw, directory + ENTRY.size * index)
        if min(start, length) < 0 or start + length > len(raw):
            raise ValueError('Invalid WAD member bounds.')
        result.append((name.rstrip(b'\0').decode('ascii'), raw[start:start+length]))
    return result


def write_lumps(path, kind, lumps):
    with Path(path).open('wb') as dest:
        dest.write(bytes(HEADER.size))
        index = bytearray()
        for name, body in lumps:
            index.extend(ENTRY.pack(dest.tell(), len(body), name.encode('ascii')))
            dest.write(body)
        start = dest.tell()
        dest.write(index)
        dest.seek(0)
        dest.write(HEADER.pack(kind, len(lumps), start))


def between(lumps, start, end):
    names = [name for name, data in lumps]
    return lumps[names.index(start)+1:names.index(end)]


def replace_member(lumps, name, data):
    indices = [i for i, (other, _) in enumerate(lumps) if other == name]
    if len(indices) != 1:
        raise ValueError(f'Expected one original member named {name}.')
    lumps[indices[0]] = (name, data)


def add_before(lumps, marker, extra):
    where = next(i for i, (name, _) in enumerate(lumps) if name == marker)
    lumps[where:where] = extra


def single_patch_texture(name, width, height, patch_index):
    # maptexture_t followed by its single mappatch_t record
    return struct.pack('<8sihhihhhhhh', name.encode('ascii'), 0, width, height, 0, 1, 0, 0, patch_index, 1, 0)


def register_wall_textures(lumps, patches):
    members = dict(lumps)
    names_raw = members['PNAMES']
    count, = struct.unpack_from('<i', names_raw)
    if len(names_raw) != 4 + count*8:
        raise ValueError('Invalid base patch index.')
    names = [names_raw[4+8*i:12+8*i].rstrip(b'\0').decode('ascii') for i in range(count)]
    textures_raw = members['TEXTURE1']
    texture_count, = struct.unpack_from('<i', textures_raw)
    offsets = struct.unpack_from(f'<{texture_count}i', textures_raw, 4)
    textures = []
    for start in offsets:
        patch_count, = struct.unpack_from('<h', textures_raw, start+20)
        textures.append(textures_raw[start:start+22+10*patch_count])
    for name, data in patches:
        if name in names:
            raise ValueError(f'Golf patch conflicts with an original patch: {name}')
        width, height = struct.unpack_from('<hh', data)
        patch_id = len(names)
        names.append(name)
        textures.append(single_patch_texture(name, width, height, patch_id))
        if name == 'GPSKY':
            sky = next(i for i, tex in enumerate(textures) if tex[:8].rstrip(b'\0') == b'SKY1')
            textures[sky] = single_patch_texture('SKY1', width, height, patch_id)
    offsets_blob = bytearray()
    offset = 4+len(textures)*4
    for tex in textures:
        offsets_blob.extend(struct.pack('<i',offset))
        offset += len(tex)
    replace_member(lumps,'PNAMES',struct.pack('<i',len(names))+b''.join(n.encode().ljust(8,b'\0') for n in names))
    replace_member(lumps,'TEXTURE1',struct.pack('<i',len(textures))+offsets_blob+b''.join(textures))


def merge_course(base, course):
    for name in MAPS:
        start = next(i for i,(n,_) in enumerate(course) if n == name)
        target = next(i for i,(n,_) in enumerate(base) if n == name)
        group = course[start:start+1+len(MAP_PARTS)]
        if tuple(n for n,_ in group[1:]) != MAP_PARTS:
            raise ValueError(f'Incomplete map group: {name}')
        base[target:target+len(group)] = group
    flats = between(course,'F_START','F_END')
    patches = between(course,'P_START','P_END')
    add_before(base,'F_END',flats)
    add_before(base,'P_END',patches)
    register_wall_textures(base,patches)


def build(iwad, destination, asset_dir=None):
    assets = asset_dir or Path(__file__).resolve().parent/'assets'
    raw = Path(iwad).read_bytes()
    if hashlib.sha256(raw).hexdigest() != BASE_SHA256:
        raise ValueError('Please select the original Doom shareware 1.9 doom1.wad (4,196,020 bytes).')
    base = read_lumps(raw,b'IWAD')
    merge_course(base, read_lumps((assets/'course.wad').read_bytes(), b'PWAD'))
    names = {name for name,_ in base}
    for path in ('clubs.wad','flatcar.wad','soundtrack.wad','night-score.wad','titles.wad'):
        for name, data in read_lumps((assets/path).read_bytes(), b'PWAD'):
            if name in ('BALLA0','GFTRA0','GFTRB0'):
                add_before(base, 'S_END', [(name,data)])
            elif name in names:
                replace_member(base,name,data)
            else:
                base.append((name,data))
                names.add(name)
    write_lumps(destination,b'IWAD',base)

#!/usr/bin/env python3
"""Start Doom Sports: Phobos After Dark in its own PCP-OS guest."""
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from assemble import build
from checkpoint import checkpoint_options

HERE = Path(__file__).resolve().parent
GAME = 'Doom Sports: Phobos After Dark'
KERNEL_MEASUREMENT = 'acfea93fa80f2c6b455cb219ffff0bc087d8ac989108399bbcba6d08bf376535'


def qemu_program(override):
    if override:
        chosen = shutil.which(override)
        if chosen:
            return str(Path(chosen).resolve())
        raise FileNotFoundError(f'QEMU executable could not be found: {override}')
    found = shutil.which('qemu-system-x86_64')
    if found:
        return str(Path(found).resolve())
    if os.name == 'nt':
        for key in ('ProgramFiles','ProgramFiles(x86)'):
            if key in os.environ:
                path = Path(os.environ[key])/'qemu'/'qemu-system-x86_64.exe'
                if path.is_file():
                    return str(path)
    raise FileNotFoundError('Install QEMU with x86 system emulation, or pass --qemu with the path to qemu-system-x86_64.')


def select_iwad(argument):
    if argument:
        return Path(argument).expanduser().resolve()
    for file in HERE.iterdir():
        if file.name.casefold() == 'doom1.wad' and file.is_file():
            return file
    root = None
    try:
        import tkinter as tk
        from tkinter import filedialog
    except ImportError:
        pass
    else:
        try:
            root = tk.Tk()
        except tk.TclError:
            pass
    if root is not None:
        try:
            root.withdraw()
            choice = filedialog.askopenfilename(parent=root, initialdir=HERE, title='Select your original Doom shareware 1.9 doom1.wad')
        finally:
            root.destroy()
        if choice:
            return Path(choice)
    raise FileNotFoundError('Place the original Doom shareware 1.9 doom1.wad beside play.py, or supply its path with --iwad.')


def audio_flags(qemu, mute):
    if mute:
        return ['-audiodev','none,id=golf']
    def help_text(option):
        r=subprocess.run([qemu,option,'help'],capture_output=True,text=True,errors='replace',timeout=15)
        return r.stdout+r.stderr
    backends=set(line.strip().lower() for line in help_text('-audiodev').splitlines())
    choices=('dsound','sdl') if os.name=='nt' else ('coreaudio','sdl') if sys.platform=='darwin' else ('pipewire','pa','sdl','alsa','oss')
    backend=next((name for name in choices if name in backends),'none')
    if backend=='none':
        print('No supported audio output detected. Starting silently.')
    devices=help_text('-device')
    flags=['-audiodev',backend+',id=golf']
    for device in ('AC97','adlib'):
        if re.search(r'name "'+device+r'"',devices,re.I):
            flags+=['-device',device+',audiodev=golf']
    return flags


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--iwad',help='path to Doom shareware 1.9 doom1.wad')
    parser.add_argument('--qemu',help='path to the QEMU x86_64 system emulator')
    parser.add_argument('--mute',action='store_true',help='play silently')
    parser.add_argument('--fresh', action='store_true', help='skip the saved round and return to the first tee')
    parser.add_argument('--no-checkpoint', action='store_true', help='play without a checkpoint disk')
    args=parser.parse_args()
    qemu=qemu_program(args.qemu)
    source=select_iwad(args.iwad)
    audio=audio_flags(qemu,args.mute)
    with tempfile.TemporaryDirectory(prefix='phobos-after-dark-') as tmp:
        stage=Path(tmp)
        build(source,stage/'doom1.wad')
        shutil.copyfile(HERE/'golf.elf',stage/'golf.elf')
        kernel=HERE/'pcpos-kernel.elf32'
        snapshots,monitor=[],False
        if not args.no_checkpoint:
            try:
                snapshots,monitor=checkpoint_options(qemu,stage,kernel,args.fresh,machine_options=audio)
            except (OSError,ValueError,subprocess.SubprocessError) as exc:
                raise RuntimeError(f'Could not open the checkpoint disk: {exc}. To play a temporary round, use --no-checkpoint.') from exc
        command=[qemu,'-name',GAME,'-machine','pc,accel=tcg','-cpu','max','-m','256M',
                 '-vga','std','-nic','none','-kernel',str(kernel),
                 '-initrd','golf.elf -golf -warp 1 1 -iwad doom1.wad,doom1.wad',
                 '-append','auto=golf.elf then=menu image='+KERNEL_MEASUREMENT,
                 '-serial','stdio','-monitor','vc' if monitor else 'none','-no-reboot',
                 '-device','isa-debug-exit,iobase=0xf4,iosize=0x04',*audio,*snapshots]
        print('Opening the Night Shift Open. Click in the game window to play.',flush=True)
        # The supplied kernel can miss a synthetic keyboard event at cold boot.
        for attempt in range(3):
            missed_key=safe=False
            with subprocess.Popen(command,cwd=stage,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                                  text=True,errors='replace') as guest:
                for line in guest.stdout:
                    print(line,end='',flush=True)
                    missed_key |= 'FAIL a program waiting in a read of the keyboard' in line
                    safe |= 'it is in SAFE and starts no program' in line
                status=guest.wait()
            if status in (0,33):
                return
            if not (status==35 and missed_key and safe and attempt<2):
                raise RuntimeError(f'QEMU exited with status {status}. The lines above are the guest and emulator output.')
            print('The cold-start keyboard check missed a key. Restarting before tee-off.',flush=True)


if __name__=='__main__':
    try: main()
    except (ValueError,OSError,RuntimeError,subprocess.SubprocessError) as err:
        print(f'Phobos After Dark: {err}',file=sys.stderr)
        sys.exit(1)

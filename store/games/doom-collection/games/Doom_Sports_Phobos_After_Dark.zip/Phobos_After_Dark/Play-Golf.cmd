@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3 play.py %*
goto done
:use_python
python play.py %*
:done
if errorlevel 1 pause

from pathlib import Path
import argparse
import subprocess as sp, runpy, time, numpy as np, concurrent.futures, json, shutil
from PIL import Image
parser=argparse.ArgumentParser(description="Sample Tailorbird during an idle interval and ten separated keystrokes.")
parser.add_argument("repo",type=Path,help="PCP OS checkout")
parser.add_argument("base",type=Path,help="output directory containing tree-1024x768 and tree-800x600")
parser.add_argument("firmware",type=Path,help="directory containing OVMF_CODE_4M.fd and OVMF_VARS_4M.fd")
options=parser.parse_args()
base=options.base.resolve()
firm=options.firmware.resolve()
moncls=runpy.run_path(str(options.repo.resolve()/'examples/optical-disk-check/check.py'))['Monitor']
def trial(which):
 mode,card=which;d=base/f'control-{mode}-{card}';d.mkdir(exist_ok=True)
 shutil.copy(firm/'OVMF_VARS_4M.fd',d/'vars.fd');w,h=map(int,mode.split('x'))
 args=['qemu-system-x86_64','-machine','q35','-accel','tcg','-cpu','max','-smp','1','-m','256M','-drive','if=pflash,format=raw,readonly=on,file='+str(firm/'OVMF_CODE_4M.fd'),'-drive','if=pflash,format=raw,file='+str(d/'vars.fd'),'-drive','if=none,id=usbdrive,format=raw,file=fat:rw:'+str(base/f'tree-{mode}'),'-device','qemu-xhci','-device','usb-storage,drive=usbdrive,bootindex=1','-vga',card,'-display','none','-nic','none','-serial','file:'+str(d/'serial.txt'),'-no-reboot','-qmp','stdio']
 with sp.Popen(args,cwd=d,stdin=sp.PIPE,stdout=sp.PIPE,stderr=open(d/'qemu.err','wb')) as vm:
  try:
   m=moncls(vm);m.call('qmp_capabilities')
   limit=time.monotonic()+40
   while time.monotonic()<limit and 'Tailorbird first frame presented' not in (d/'serial.txt').read_text(errors='replace'):time.sleep(.09)
   log=(d/'serial.txt').read_text(errors='replace');drv=next(s for s in log.splitlines() if s.startswith('display:'))
   assert 'Tailorbird first frame presented' in log and mode in drv,(drv,log[-500:])
   time.sleep(.5);m.call('screendump',filename=str(d/'initial.ppm'))
   def pixels(p):
    with Image.open(p) as im:assert im.size==(w,h);return np.asarray(im).copy()
   initial=pixels(d/'initial.ppm');mask=np.zeros((h,w),bool)
   # Central application area excluding the Ask field and footer. A final independent check excludes any changed endpoint pixels.
   mask[h//8:h*3//4,w//6:w*4//5]=True
   mask &= np.max(np.abs(initial.astype(np.int16)-np.roll(initial.astype(np.int16),1,axis=0)),axis=2)>45
   ys,xs=np.where(mask);sample=initial[ys,xs,:].astype(np.int16)
   times=[];vals=[];best=-1;keystrokes=[];t0=time.monotonic()
   keys='abcdefghij';now=0
   while now<8:
    now=time.monotonic()-t0
    if len(keystrokes)<len(keys) and now>1+len(keystrokes)*.62:
     m.key(keys[len(keystrokes)]);keystrokes.append(now)
    m.call('screendump',filename=str(d/'current.ppm'));x=pixels(d/'current.ppm')
    disagree=np.max(np.abs(x[ys,xs,:].astype(np.int16)-sample),axis=1)>30
    vals.append(np.packbits(disagree));times.append(time.monotonic()-t0)
    if disagree.sum()>best:best=int(disagree.sum());shutil.copy(d/'current.ppm',d/'worst.ppm')
   m.call('screendump',filename=str(d/'final.ppm'));final=pixels(d/'final.ppm')
   stable=np.all(final[ys,xs]==initial[ys,xs],axis=1);diffs=np.unpackbits(np.array(vals),axis=1)[:,:len(stable)][:,stable].sum(axis=1)
   early=np.array(times)<keystrokes[0]
   results=dict(driver=drv,frames=len(times),stationary_frames=int(early.sum()),stable_edge_pixels=int(stable.sum()),stationary_max=int(diffs[early].max()),typing_max=int(diffs[~early].max()),frames_with_at_least_10_percent_of_stable_edges_changed=int((diffs>stable.sum()*.1).sum()),keys=keys)
   (d/'results.json').write_text(json.dumps(results,indent=2));print(results,flush=True)
  finally:vm.kill()
for mode,card in [('1024x768','vmware'),('800x600','vmware'),('1024x768','std')]:
 trial((mode,card))

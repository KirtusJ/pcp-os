.section .text
.global _start
_start:
    mov $2, %eax
    lea audio(%rip), %rdi
    mov $1, %esi
    syscall
    test %rax, %rax
    js failed
    mov %rax, %rdi
    mov $1, %eax
    lea wave(%rip), %rsi
    mov $LENGTH, %edx
    syscall
    cmp $LENGTH, %rax
    jne failed
    mov $35, %eax
    lea delay(%rip), %rdi
    xor %esi, %esi
    syscall
    xor %edi, %edi
    jmp quit
failed:
    mov $8, %edi
quit:
    mov $60, %eax
    syscall
.section .rodata
audio: .asciz "/dev/audio"
.balign 8
delay: .quad 0, 200000000
wave:
.rept 64
.rept 16
    .short 12000,12000
.endr
.rept 16
    .short -12000,-12000
.endr
.endr
.section .data
    .quad 0

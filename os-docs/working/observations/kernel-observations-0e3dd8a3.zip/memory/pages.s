.section .text
.global _start
_start:
    mov $9, %eax
    xor %edi, %edi
    mov $1048576, %esi
    mov $3, %edx
    mov $34, %r10d
    mov $-1, %r8
    xor %r9d, %r9d
    syscall
    xor %edi, %edi
    test %rax, %rax
    jns quit
    mov $8, %edi
quit:
    mov $60, %eax
    syscall
.section .rodata
    .quad 0
.section .data
    .quad 0

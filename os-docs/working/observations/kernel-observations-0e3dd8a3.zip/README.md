# B3 kernel observations for master 0e3dd8a3
Eight cold boots of the 8B configuration on QEMU q35, TCG, one virtual CPU, standard VGA. The model was unnecessary. Tests used direct multiboot kernel loading. Physical hardware and firmware were outside these runs.

Source commit 0e3dd8a37b9b16cf84c92328dc4890c879563fcf.
Kernel ELF SHA-256 bec4d5714b75e1fae19497dd5990067096b9329c0327da45a1838a70fb559a3a.
Code and read-only measurement 338ea2d25d86de33e8d503f16760376b1f6e8fac16efe53c33fb30232dbd35eb.
The master-bound ELF and build record are at https://github.com/KirtusJ/pcp-os/pull/276#issuecomment-7082957450 .

## Keyboard
Open Programs with Space at 1920x1080, scale 1, with Tailorbird supplied as a loader file. Press D while a single Ctrl is held (left or right). In two fresh boots press both Ctrl keys, release the first, then press D while holding the second. Each results row names the observed surface. The four PNGs preserve every pixel of the last framebuffer. The two overlap cases end on Programs.

## Program memory
Start QEMU with -machine q35,max-ram-below-4g=256M and -m 256M or -m 512M. Supply pages.elf with -initrd pages.elf and append auto=pages.elf then=menu desktop=1280x720 ui_scale=1 alongside the measurement. The guest allocates 1 MiB of ordinary anonymous read/write memory and exits. From the desktop, open Programs with Space, then Details with Ctrl+D. Read the pictured value. Use Esc, F10 and Enter to power off and emit the serial memory counts. The screenshots, glyph-decoded text, guest source and serial output are included.

## PCM audio
In separate 256 MiB boots, supply the corresponding numbered ELF under the name tone.elf. Append auto=tone.elf then=off and the measurement. Use -device AC97,audiodev=snd0 -audiodev wav,id=snd0,path=audio.wav,out.frequency=48000,out.channels=2,out.format=s16. Each guest verifies its write returned the full byte count and sleeps for 200 ms before exiting. Each binary was built from tone.s with GNU as --64 --defsym LENGTH=192 or LENGTH=8192 and the repository linker script store/games/flux-rink/guest.ld (ld -z max-page-size=0x1000). The WAV files and the original serial reports are included. Python's wave reader supplies sample frame counts. Nonzero samples count individual left and right signed 16-bit values. Host padding may vary between captures.

SHA256SUMS covers every other member. screens.json records the original QEMU P6 file hash and a second digest for the decoded 8-bit RGB pixels of each lossless PNG.
